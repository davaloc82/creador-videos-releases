# -*- coding: utf-8 -*-
"""
tts.py - Convierte un archivo de guiones en audios .mp3 usando la API de ai33.pro.

ENTRADA: un solo .txt con varios guiones separados por un encabezado:

    GUION: 1
    (texto del primer guion...)

    GUION: 2
    (texto del segundo guion...)

El numero que sigue a "GUION:" es el NOMBRE del .mp3 (1.mp3, 2.mp3, ...).

SALIDA: los .mp3 quedan en la MISMA carpeta donde esta el .txt de entrada.

La API es asincrona: el POST devuelve un task_id y luego se consulta el estado
(polling) hasta que el audio esta listo; entonces se descarga.

USO:
    python tts.py "C:\\...\\NUEVOS GUIONES\\lote_guiones.txt"
    python tts.py "<archivo.txt>" --config "<ai33_config.txt>" --forzar

Si no pasas --config, busca ai33_config.txt subiendo desde la carpeta del .txt.
Sin dependencias externas: solo la libreria estandar (urllib).
"""
import argparse
import json
import os
import re
import sys
import time
import uuid
from urllib import request as urlrequest
from urllib.error import HTTPError, URLError


# --------------------------------------------------------------- configuracion
def cargar_config(ruta):
    """Lee ai33_config.txt (CLAVE=valor por linea) a un dict de forma ultra limpia."""
    cfg = {}
    # Soportar utf-8-sig y utf-8 normal
    try:
        with open(ruta, encoding="utf-8-sig") as f:
            lineas = f.readlines()
    except Exception:
        with open(ruta, encoding="utf-8", errors="ignore") as f:
            lineas = f.readlines()

    for linea in lineas:
        s = linea.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        val = v.strip().strip("'\"")
        k_upper = k.strip().upper()
        # Si el usuario pego 'API_KEY=sk_...' dentro del valor
        if k_upper == "API_KEY":
            if val.lower().startswith("api_key="):
                val = val.split("=", 1)[1].strip().strip("'\"")
            if val.lower().startswith("bearer "):
                val = val[7:].strip().strip("'\"")
        cfg[k_upper] = val
    return cfg


def buscar_config(desde):
    """Sube desde 'desde' buscando ai33_config.txt (por si el .txt esta en subcarpeta o nicho)."""
    p = os.path.abspath(desde)
    if os.path.isfile(p):
        p = os.path.dirname(p)
    while True:
        cand = os.path.join(p, "ai33_config.txt")
        if os.path.isfile(cand):
            return cand
        padre = os.path.dirname(p)
        if padre == p:
            break
        p = padre

    # Fallback a la carpeta central ai33 de la aplicación
    base_app = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cand_app = os.path.join(base_app, "ai33", "ai33_config.txt")
    if os.path.isfile(cand_app):
        return cand_app
    return None


# --------------------------------------------------------------- parseo guiones
RE_ENCABEZADO = re.compile(r"^\s*GUION\s*:\s*(.+?)\s*$", re.IGNORECASE)
RE_TITULO = re.compile(r"^\s*TITULO\s*:\s*(.+?)\s*$", re.IGNORECASE)


def _nombre_seguro(s):
    """Deja el nombre apto para archivo (quita caracteres raros, conserva el numero)."""
    s = s.strip().strip(".")
    s = re.sub(r'[<>:"/\\|?*]+', "_", s)
    return s or "sin_nombre"


def limpiar_texto_guion(lineas):
    """Limpia líneas de títulos, acotaciones y prefijos de personaje para el sintetizador TTS."""
    limpias = []
    for ln in lineas:
        s = ln.strip()
        # Omitir títulos (son para metadatos del video en redes, no para el audio)
        if RE_TITULO.match(s):
            continue
        # Omitir acotaciones completas entre corchetes o paréntesis [música] (pausa)
        if (s.startswith("[") and s.endswith("]")) or (s.startswith("(") and s.endswith(")")):
            continue
        # Limpiar prefijos de personaje al inicio de línea (Narrador:, Voz en off:, etc.)
        s = re.sub(r"^\s*(narrador|voz\s+en\s+off|locutor|personaje\s*\d*)\s*:\s*", "", s, flags=re.IGNORECASE)
        # Limpiar acotaciones intermedias [música], [risas]
        s = re.sub(r"\[.*?\]", "", s)
        # Limpiar negritas de markdown **palabra** -> palabra
        s = re.sub(r"\*\*(.*?)\*\*", r"\1", s)
        if s:
            limpias.append(s)
    return "\n".join(limpias).strip()


def partir_guiones(ruta_txt):
    """Devuelve [(nombre, texto), ...] partiendo por 'GUION: <nombre>'."""
    with open(ruta_txt, encoding="utf-8-sig", errors="replace") as f:
        lineas = f.read().splitlines()
    bloques, actual, cuerpo = [], None, []
    for ln in lineas:
        m = RE_ENCABEZADO.match(ln)
        if m:
            if actual is not None:
                t = limpiar_texto_guion(cuerpo)
                if t:
                    bloques.append((actual, t))
            actual = _nombre_seguro(m.group(1))
            cuerpo = []
        elif actual is not None:
            cuerpo.append(ln)
    if actual is not None:
        t = limpiar_texto_guion(cuerpo)
        if t:
            bloques.append((actual, t))
    # descarta bloques sin texto
    return [(n, t) for n, t in bloques if t]


# --------------------------------------------------------------- HTTP (multipart & SSL Resiliente)
import ssl

_SSL_CTX_DEFAULT = None
_SSL_CTX_UNVERIFIED = None
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

def _obtener_ssl_context(verificar=True):
    """Obtiene un contexto SSL con soporte para bypass de antivirus si los certificados locales fallan."""
    global _SSL_CTX_DEFAULT, _SSL_CTX_UNVERIFIED
    if not verificar:
        if _SSL_CTX_UNVERIFIED is None:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            _SSL_CTX_UNVERIFIED = ctx
        return _SSL_CTX_UNVERIFIED
    if _SSL_CTX_DEFAULT is None:
        try:
            _SSL_CTX_DEFAULT = ssl.create_default_context()
        except Exception:
            _SSL_CTX_DEFAULT = _obtener_ssl_context(verificar=False)
    return _SSL_CTX_DEFAULT


def _multipart(campos):
    """Arma un cuerpo multipart/form-data. 'campos' = lista de (nombre, valor)."""
    limite = "----ai33-" + uuid.uuid4().hex
    partes = []
    for nombre, valor in campos:
        partes.append("--" + limite + "\r\n")
        partes.append(f'Content-Disposition: form-data; name="{nombre}"\r\n\r\n')
        partes.append(str(valor) + "\r\n")
    partes.append("--" + limite + "--\r\n")
    cuerpo = "".join(partes).encode("utf-8")
    return cuerpo, f"multipart/form-data; boundary={limite}"


def _post_form(url, api_key, campos):
    cuerpo, ctype = _multipart(campos)
    req = urlrequest.Request(url, data=cuerpo, method="POST")
    req.add_header("xi-api-key", api_key)
    req.add_header("Content-Type", ctype)
    req.add_header("User-Agent", _USER_AGENT)
    req.add_header("Accept", "application/json")
    return json.loads(_urlopen_reintentos(req, timeout=60).decode("utf-8"))


_TRANSITORIOS = (500, 502, 503, 504, 429)


def _urlopen_reintentos(req, timeout, intentos=4, espera=2.0):
    """
    Abre una peticion HTTP con reintentos inteligentes y compatibilidad universal:
    - Agrega User-Agent de navegador para evitar bloqueos de Cloudflare WAF.
    - Soporta bypass automatico de SSL en PCs con antivirus (Kaspersky/Avast) que interceptan HTTPS.
    """
    if not req.has_header("User-Agent"):
        req.add_header("User-Agent", _USER_AGENT)

    ultimo = None
    for i in range(intentos):
        # En el primer intento probamos SSL estandar, en reintentos o fallos usamos bypass
        ctx = _obtener_ssl_context(verificar=(i == 0))
        try:
            return urlrequest.urlopen(req, timeout=timeout, context=ctx).read()
        except HTTPError as e:
            if e.code in _TRANSITORIOS and i < intentos - 1:
                ultimo = e
                time.sleep(espera * (i + 1))
                continue
            # Informar error HTTP detallado
            if e.code == 401:
                raise RuntimeError("API Key de ai33.pro no autorizada (401). Verifica tu clave en el panel.")
            elif e.code == 403:
                raise RuntimeError("Acceso denegado en ai33.pro (403). Verifica saldo o permisos de tu cuenta.")
            raise
        except URLError as e:
            str_e = str(e).lower()
            # Si el antivirus o Windows bloqueo el certificado SSL, reintentar de inmediato con SSL no verificado
            if "certificate" in str_e or "ssl" in str_e or "verify" in str_e:
                try:
                    ctx_unv = _obtener_ssl_context(verificar=False)
                    return urlrequest.urlopen(req, timeout=timeout, context=ctx_unv).read()
                except Exception as e_ssl:
                    ultimo = e_ssl
            if i < intentos - 1:
                ultimo = e
                time.sleep(espera * (i + 1))
                continue
            raise RuntimeError(f"Error de conexion con ai33.pro: {e}")
    if ultimo:
        raise ultimo


def _get_json(url, api_key):
    req = urlrequest.Request(url, method="GET")
    req.add_header("xi-api-key", api_key)
    req.add_header("User-Agent", _USER_AGENT)
    req.add_header("Accept", "application/json")
    return json.loads(_urlopen_reintentos(req, timeout=60).decode("utf-8"))


# --------------------------------------------------------------- interpretar respuesta
_ESTADOS_OK = ("success", "succeeded", "completed", "complete", "done", "finished", "ready")
_ESTADOS_MAL = ("failed", "error", "cancelled", "canceled")


def _buscar_url_audio(obj):
    """Busca recursivamente el primer valor que parezca URL de audio."""
    encontrados = []

    def rec(x):
        if isinstance(x, str):
            low = x.lower()
            if low.startswith("http") and (
                low.endswith((".mp3", ".wav", ".m4a", ".ogg")) or "audio" in low
            ):
                encontrados.append(x)
        elif isinstance(x, dict):
            # prioriza claves tipicas
            for k in ("audio_url", "url", "file_url", "output_url", "audio", "output"):
                if k in x:
                    rec(x[k])
            for k, v in x.items():
                if k not in ("audio_url", "url", "file_url", "output_url", "audio", "output"):
                    rec(v)
        elif isinstance(x, list):
            for v in x:
                rec(v)

    rec(obj)
    return encontrados[0] if encontrados else None


# --------------------------------------------------------------- flujo por guion
def crear_tarea(cfg, texto):
    """Envia el texto (POST). CONSUME CREDITOS. Devuelve (task_id, url_directa|None).
    Se llama UNA sola vez por guion; los reintentos posteriores reutilizan el
    task_id para no volver a cobrar."""
    api_key = cfg["API_KEY"]
    campos = [
        ("text", texto),
        ("voice_id", cfg["VOICE_ID"]),
        ("speed", cfg.get("SPEED", "1")),
        ("with_transcript", cfg.get("WITH_TRANSCRIPT", "false")),
    ]
    resp = _post_form(cfg.get("TTS_URL"), api_key, campos)
    if not resp.get("success", True) and "task_id" not in resp:
        raise RuntimeError(f"la API rechazo el envio: {resp}")
    task_id = resp.get("task_id") or (resp.get("data") or {}).get("task_id")
    directo = _buscar_url_audio(resp)     # por si alguna respuesta trae ya la URL
    if not task_id and not directo:
        raise RuntimeError(f"no vino task_id ni url en la respuesta: {resp}")
    return task_id, directo


def esperar_audio(cfg, task_id):
    """Consulta la tarea hasta que el audio esta listo. Solo hace GETs: NO cobra.
    Devuelve la URL del mp3 (o lanza)."""
    api_key = cfg["API_KEY"]
    task_url = cfg.get("TASK_URL", "").replace("{task_id}", str(task_id))
    limite = time.time() + float(cfg.get("TIMEOUT", "300"))
    ultimo_prog = -1
    while time.time() < limite:
        time.sleep(3)
        try:
            estado = _get_json(task_url, api_key)
        except HTTPError as e:
            if e.code == 404:      # aun no existe la tarea; reintenta
                continue
            raise
        data = estado.get("data") if isinstance(estado, dict) else None
        if isinstance(data, list):          # forma ?task_id= devuelve lista
            data = data[0] if data else {}
        data = data or {}
        status = str(data.get("status", "")).lower()
        # la URL vive en data.metadata.audio_url; fallback: busqueda recursiva
        url = (data.get("metadata") or {}).get("audio_url") or _buscar_url_audio(estado)
        if status in _ESTADOS_MAL:
            raise RuntimeError(f"la tarea fallo: {json.dumps(estado, ensure_ascii=False)[:300]}")
        if url and (status in _ESTADOS_OK or status == ""):
            return url
        prog = data.get("progress")
        if isinstance(prog, (int, float)) and prog != ultimo_prog:
            ultimo_prog = prog
            sys.stdout.write(f" {int(prog)}%"); sys.stdout.flush()
        else:
            sys.stdout.write("."); sys.stdout.flush()
    raise TimeoutError(f"se agoto el tiempo esperando la tarea {task_id}")


def descargar(url, destino):
    req = urlrequest.Request(url, headers={"User-Agent": "ai33-tts/1.0"})
    datos = _urlopen_reintentos(req, timeout=120)
    with open(destino, "wb") as f:
        f.write(datos)


# --------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser(description="Guiones .txt -> audios .mp3 (ai33.pro)")
    ap.add_argument("archivo", help="el .txt con los guiones (GUION: <numero>)")
    ap.add_argument("--config", default=None, help="ruta a ai33_config.txt")
    ap.add_argument("--forzar", action="store_true", help="regenera aunque ya exista el .mp3")
    a = ap.parse_args()

    entrada = os.path.abspath(a.archivo)
    if not os.path.isfile(entrada):
        print(f"ERROR: no encuentro el archivo {entrada}"); sys.exit(1)

    ruta_cfg = a.config or buscar_config(entrada)
    if not ruta_cfg or not os.path.isfile(ruta_cfg):
        print("ERROR: no encuentro ai33_config.txt (usa --config o dejalo junto al .txt)")
        sys.exit(1)
    cfg = cargar_config(ruta_cfg)

    faltan = [k for k in ("API_KEY", "VOICE_ID") if not cfg.get(k)]
    if faltan:
        print(f"ERROR: completa en el config: {', '.join(faltan)}")
        sys.exit(1)

    salida_dir = os.path.dirname(entrada)
    guiones = partir_guiones(entrada)
    if not guiones:
        print("ERROR: no encontre ningun 'GUION: <numero>' con texto en el archivo.")
        sys.exit(1)

    print(f"Encontrados {len(guiones)} guiones. Voz: {cfg['VOICE_ID']}  ->  {salida_dir}")
    ok, saltados = 0, 0
    fallidos = []                       # nombres de los guiones que no salieron
    sin_intentar = 0                    # los que ni se intentaron (p.ej. API caida)
    for idx, (nombre, texto) in enumerate(guiones):
        destino = os.path.join(salida_dir, f"{nombre}.mp3")
        if os.path.exists(destino) and not a.forzar:
            print(f"  [salto] {nombre}.mp3 ya existe")
            saltados += 1
            continue
        # 1) crear la tarea UNA sola vez (esto es lo que consume creditos)
        print(f"  [{nombre}] enviando ({len(texto)} caracteres)", end=" ", flush=True)
        try:
            task_id, url = crear_tarea(cfg, texto)
        except (HTTPError, URLError, RuntimeError) as e:
            # 503 = la API de ai33 esta caida/saturada: no tiene sentido seguir
            # intentando el resto (no se creo tarea ni se cobro nada). Se corta.
            if isinstance(e, HTTPError) and e.code == 503:
                sin_intentar = len(guiones) - idx
                print(" ✕")
                print("\n⚠ La API de ai33 responde 503 (servicio NO disponible). "
                      "Es un problema temporal del servidor de ai33, no de tu "
                      "conexión ni de tus créditos.\n  No se generó ni se cobró "
                      "nada. Comprueba https://ai33.pro y reintenta más tarde.")
                break
            print(f" fallo al enviar (no se creó tarea, sin gasto): {e}")
            fallidos.append(nombre)
            continue
        # 2) esperar + descargar, reintentando SOLO esto (reusa la misma tarea:
        #    no se vuelve a cobrar aunque falle la espera o la descarga)
        ultimo_error = None
        for intento in (1, 2, 3):
            try:
                if not url:
                    url = esperar_audio(cfg, task_id)
                descargar(url, destino)
                print(f" OK -> {nombre}.mp3")
                ok += 1
                ultimo_error = None
                break
            except (HTTPError, URLError, RuntimeError, TimeoutError) as e:
                ultimo_error = e
                print(f" fallo intento {intento} (recogiendo audio ya generado): {e}")
                if intento < 3:
                    time.sleep(4)
        if ultimo_error is not None:
            fallidos.append(nombre)

    cola = f", {sin_intentar} sin intentar (API caída)" if sin_intentar else ""
    if fallidos or sin_intentar:
        detalle = (" (fallaron: " + ", ".join(fallidos) + ")") if fallidos else ""
        print(f"\nListo. {ok} generados, {saltados} saltados, "
              f"{len(fallidos)} con fallo{detalle}{cola}. "
              f"Vuelve a darle a Generar: reintenta solo los que faltan.")
    else:
        print(f"\nListo. {ok} generados, {saltados} saltados, 0 con fallo.")
    sys.exit(0 if not (fallidos or sin_intentar) else 2)


if __name__ == "__main__":
    main()
