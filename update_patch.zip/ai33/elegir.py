# -*- coding: utf-8 -*-
"""
elegir.py - Abre el dialogo nativo de Windows para elegir un archivo.
Imprime en stdout la ruta elegida (o nada si se cancela).

Se lanza como proceso aparte desde el panel: asi el dialogo corre en su propio
hilo principal (Tk no es fiable dentro de los hilos del servidor HTTP).

USO:  python elegir.py [carpeta_inicial] [--audio | --carpeta]
        --audio    -> filtra por audios (.mp3/.wav/...) en vez de .txt
        --carpeta  -> elige una CARPETA (no un archivo)
"""
import sys

FILTROS = {
    "txt":   ("Elige el .txt de guiones",
              [("Archivos de texto", "*.txt"), ("Todos los archivos", "*.*")]),
    "audio": ("Elige el audio a recortar",
              [("Audios", "*.mp3 *.wav *.m4a *.aac *.flac *.ogg"),
               ("Todos los archivos", "*.*")]),
    "video": ("Elige el video",
              [("Videos", "*.mp4 *.mov *.mkv *.webm *.avi"),
               ("Todos los archivos", "*.*")]),
}


def _fallback_powershell(tipo, inicio):
    import subprocess
    ini_clean = (inicio or "").replace("'", "''")
    if tipo == "carpeta":
        ps_code = f"""
Add-Type -AssemblyName System.Windows.Forms
$d = New-Object System.Windows.Forms.FolderBrowserDialog
$d.Description = 'Elige la carpeta con los videos'
$d.ShowNewFolderButton = $true
if ('{ini_clean}') {{ $d.SelectedPath = '{ini_clean}' }}
if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {{
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    Write-Output $d.SelectedPath
}}
"""
    else:
        titulo, filts = FILTROS.get(tipo, FILTROS["txt"])
        filt_str = "|".join([f"{n} ({p})|{p}" for n, p in filts])
        ps_code = f"""
Add-Type -AssemblyName System.Windows.Forms
$d = New-Object System.Windows.Forms.OpenFileDialog
$d.Title = '{titulo}'
$d.Filter = '{filt_str}'
if ('{ini_clean}') {{ $d.InitialDirectory = '{ini_clean}' }}
if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {{
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    Write-Output $d.FileName
}}
"""
    try:
        res = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_code],
                             capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
        return (res.stdout or "").strip()
    except Exception:
        return ""


def main():
    argv = sys.argv[1:]
    if "--carpeta" in argv:
        tipo = "carpeta"
    elif "--audio" in argv:
        tipo = "audio"
    elif "--video" in argv:
        tipo = "video"
    else:
        tipo = "txt"
    libres = [a for a in argv if not a.startswith("--")]
    inicio = libres[0] if libres else None

    # En Windows, asegurarse de conectarse al escritorio interactivo del usuario
    if sys.platform == "win32":
        try:
            import ctypes
            u32 = ctypes.windll.user32
            h_desk = u32.OpenDesktopW("Default", 0, False, 0x01FF)
            if h_desk:
                u32.SetThreadDesktop(h_desk)
        except Exception:
            pass

    ruta = ""
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.wm_attributes("-topmost", 1)
        root.lift()
        root.focus_force()
        try:
            root.update()
        except Exception:
            pass

        if tipo == "carpeta":
            ruta = filedialog.askdirectory(
                parent=root,
                title="Elige la carpeta con los videos",
                initialdir=inicio if inicio else None,
            )
        else:
            titulo, filetypes = FILTROS[tipo]
            ruta = filedialog.askopenfilename(
                parent=root,
                title=titulo,
                initialdir=inicio if inicio else None,
                filetypes=filetypes,
            )
        try:
            root.destroy()
        except Exception:
            pass
    except Exception:
        ruta = ""

    # Si Tkinter no obtuvo nada o falló, intentar fallback nativo de PowerShell
    if not ruta:
        ruta = _fallback_powershell(tipo, inicio)

    if ruta:
        sys.stdout.write(ruta)


if __name__ == "__main__":
    main()
