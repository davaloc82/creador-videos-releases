# -*- coding: utf-8 -*-
"""
voces.py - Lista las voces disponibles en ai33.pro para elegir tu voice_id.

USO:
    python voces.py --proveedor edge --idioma Spanish
    python voces.py --proveedor minimax --buscar mujer
    python voces.py --proveedor elevenlabs --genero Female

El 'voice_id' que imprime ya viene con el prefijo listo para pegar en
ai33_config.txt (VOICE_ID=...). Lee la API_KEY del mismo config.
"""
import argparse
import json
import os
import sys
from urllib import request as urlrequest
from urllib.parse import urlencode

AQUI = os.path.dirname(os.path.abspath(__file__))


def cargar_api_key(ruta_cfg):
    with open(ruta_cfg, encoding="utf-8-sig") as f:
        for linea in f:
            s = linea.strip()
            if s.upper().startswith("API_KEY=") and "=" in s:
                return s.split("=", 1)[1].strip()
    return ""


def buscar_config():
    # cualquier config del proyecto sirve para listar voces (misma API_KEY).
    # Se prioriza ecos; si no, el primer ai33_*.txt que exista en ai33/.
    candidatos = [os.path.join(AQUI, "ai33_ecos.txt")]
    try:
        candidatos += sorted(
            os.path.join(AQUI, f) for f in os.listdir(AQUI)
            if f.startswith("ai33_") and f.endswith(".txt")
        )
    except OSError:
        pass
    for c in candidatos:
        if os.path.isfile(c):
            return c
    return None


def main():
    ap = argparse.ArgumentParser(description="Lista voces de ai33.pro")
    ap.add_argument("--proveedor", required=True,
                    help="elevenlabs | minimax | clone | edge | kokoro | vbee | fishaudio")
    ap.add_argument("--idioma", default=None, help="p.ej. Spanish, Vietnamese, English")
    ap.add_argument("--genero", default=None, help="Male | Female")
    ap.add_argument("--buscar", default=None, help="texto libre (nombre, tags...)")
    ap.add_argument("--config", default=None)
    a = ap.parse_args()

    cfg = a.config or buscar_config()
    if not cfg:
        print("ERROR: no encuentro ai33_config.txt"); sys.exit(1)
    api_key = cargar_api_key(cfg)
    if not api_key:
        print("ERROR: falta API_KEY en el config"); sys.exit(1)

    params = {"provider": a.proveedor, "page_size": "100"}
    if a.idioma:
        params["language"] = a.idioma
    if a.genero:
        params["gender"] = a.genero
    if a.buscar:
        params["search"] = a.buscar
    url = "https://api.ai33.pro/v3/voices?" + urlencode(params)

    req = urlrequest.Request(url, method="GET")
    req.add_header("xi-api-key", api_key)
    with urlrequest.urlopen(req, timeout=60) as r:
        data = json.loads(r.read().decode("utf-8"))

    voces = data.get("data", [])
    if not voces:
        print("No se encontraron voces con esos filtros."); return
    print(f"{'VOICE_ID':<45} {'NOMBRE':<28} IDIOMA / GENERO")
    print("-" * 90)
    for v in voces:
        vid = v.get("voice_id", "")
        nom = (v.get("name", "") or "")[:26]
        info = f"{v.get('language','')} / {v.get('gender','')}"
        print(f"{vid:<45} {nom:<28} {info}")
    pag = data.get("pagination", {})
    if pag.get("has_more"):
        print(f"\n(hay mas de {pag.get('total','?')} voces; afina con --buscar/--idioma)")


if __name__ == "__main__":
    main()
