@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Detener Panel de Videos - NEXOR
echo ====================================================
echo   DETENIENDO SERVIDOR LOCAL DEL PANEL NEXOR
echo ====================================================

:: 1. Apagado elegante por protocolo HTTP (No activa alertas de antivirus)
curl.exe -s -m 2 -X POST http://127.0.0.1:8780/api/sistema/cerrar >nul 2>&1
curl.exe -s -m 2 -X POST http://127.0.0.1:8770/api/sistema/cerrar >nul 2>&1

:: 2. Breve espera para que el socket se cierre limpiamente
ping -n 2 127.0.0.1 >nul

:: 3. Verificación de respaldo silenciosa si algún puerto sigue ocupado
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :8780 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :8770 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
)

echo ====================================================
echo   [OK] El servidor del Panel se detuvo correctamente.
echo ====================================================
echo.
ping -n 2 127.0.0.1 >nul
exit /b 0
