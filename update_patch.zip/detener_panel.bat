@echo off
rem ==============================================================================
rem Detener Servidor del Panel de Videos
rem ==============================================================================
cd /d "%~dp0"
title Detener Panel de Videos
echo ====================================================
echo   DETENIENDO SERVIDOR LOCAL DEL PANEL (Puerto 8770)
echo ====================================================

set DETENIDO=0
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8770 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
    set DETENIDO=1
)

if "%DETENIDO%"=="1" (
    echo [OK] El servidor del Panel se detuvo correctamente.
) else (
    echo [INFO] No habia ningun servidor activo en el puerto 8770.
)
echo.
ping -n 3 127.0.0.1 >nul
exit /b 0

