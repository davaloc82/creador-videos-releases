@echo off
rem ==============================================================================
rem Detener Servidor del Panel de Videos - NEXOR
rem ==============================================================================
cd /d "%~dp0"
title Detener Panel de Videos
echo ====================================================
echo   DETENIENDO SERVIDOR LOCAL DEL PANEL NEXOR
echo ====================================================

set DETENIDO=0

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8780 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
    set DETENIDO=1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8770 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
    set DETENIDO=1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8781 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
    set DETENIDO=1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8782 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
    set DETENIDO=1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8783 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
    set DETENIDO=1
)

taskkill /F /IM pythonw.exe >nul 2>&1
if "%errorlevel%"=="0" set DETENIDO=1

if "%DETENIDO%"=="1" (
    echo [OK] El servidor del Panel se detuvo correctamente.
) else (
    echo [INFO] No habia ningun servidor activo en los puertos 8770-8783.
)
echo.
ping -n 3 127.0.0.1 >nul
exit /b 0
