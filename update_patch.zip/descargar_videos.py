#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
descargar_videos.py
-------------------
Descargador universal de videos desde redes sociales (TikTok, Facebook, Instagram, YouTube, X, etc.)
usando yt-dlp y ffmpeg.

Modo de uso:
1. Desde terminal:
   python descargar_videos.py "C:\\ruta\\a\\carpeta"
   python descargar_videos.py "C:\\ruta\\a\\carpeta\\enlaces.txt"

2. Doble clic / Sin argumentos:
   Abre un diálogo para seleccionar la carpeta o archivo .txt con enlaces.

Regla principal:
- Lee los enlaces del .txt y guarda los videos .mp4 en EL MISMO DIRECTORIO del archivo .txt.
- Registra las descargas completadas en '_descargas_historial.txt' para no re-descargar duplicados.
"""

import os
import sys
import re
import argparse
import subprocess
from pathlib import Path

# Configurar salida UTF-8 en consola de Windows
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

try:
    import yt_dlp
except ImportError:
    print("[ERROR] No se encontró yt-dlp. Instalando automáticamente...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp"], check=True)
    import yt_dlp

# Asegurar soporte de TLS impersonation para redes sociales (evita bloqueos y warnings de TikTok)
try:
    import curl_cffi
except ImportError:
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "curl-cffi"], check=False)
    except Exception:
        pass


NOMBRES_TXT_COMUNES = ("enlaces.txt", "links.txt", "urls.txt", "videos.txt", "descargas.txt")


def extraer_urls_de_archivo(txt_path: Path):
    """Lee un archivo de texto con múltiples codificaciones y extrae todas las URLs válidas."""
    contenido = ""
    for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
        try:
            contenido = txt_path.read_text(encoding=enc)
            break
        except Exception:
            continue

    if not contenido:
        return []

    urls = []
    for linea in contenido.splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#"):
            continue
        # Buscar URLs http/https
        encontradas = re.findall(r"https?://[^\s\"'<>]+", linea)
        for u in encontradas:
            u_limpia = u.strip().rstrip(".,;)>]")
            if u_limpia and u_limpia not in urls:
                urls.append(u_limpia)

    return urls


def buscar_txt_con_enlaces(directorio: Path):
    """Busca en el directorio un archivo .txt con enlaces."""
    # 1. Probar nombres estándar
    for nom in NOMBRES_TXT_COMUNES:
        cand = directorio / nom
        if cand.is_file():
            urls = extraer_urls_de_archivo(cand)
            if urls:
                return cand, urls

    # 2. Probar cualquier .txt en la carpeta
    for cand in sorted(directorio.glob("*.txt")):
        if cand.name.startswith(("_", ".")):
            continue
        urls = extraer_urls_de_archivo(cand)
        if urls:
            return cand, urls

    return None, []


def asegurar_compatibilidad_mp4(archivo_mp4: Path):
    """
    Verifica si el video usa códecs no soportados nativamente en Windows (AV1, HEVC/H.265, VP9, etc.)
    que causan que Windows Media Player o editores reproduzcan solo el audio o muestren pantalla negra/error,
    y lo convierte automáticamente a H.264/AAC estándar universal.
    """
    if not archivo_mp4.is_file() or archivo_mp4.suffix.lower() != ".mp4":
        return
    try:
        cmd = [
            "ffprobe", "-v", "error", "-select_streams", "v:0",
            "-show_entries", "stream=codec_name",
            "-of", "default=noprint_wrappers=1:nokey=1", str(archivo_mp4)
        ]
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False)
        codec = res.stdout.strip().lower()
        # Si el códec de video no es h264/avc1 (ej. av1, hevc, h265, vp9, bytevc1), convertir a H.264
        if codec and codec not in ("h264", "avc1"):
            print(f"   [COMPATIBILIDAD] Códec de video '{codec.upper()}' detectado.")
            print(f"                    Windows requiere H.264 para mostrar imagen. Convirtiendo...")
            temp_out = archivo_mp4.with_suffix(".temp_conv.mp4")
            conv_cmd = [
                "ffmpeg", "-y", "-i", str(archivo_mp4),
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                "-c:a", "aac", "-b:a", "192k",
                "-movflags", "+faststart", str(temp_out)
            ]
            r_conv = subprocess.run(conv_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if r_conv.returncode == 0 and temp_out.is_file() and temp_out.stat().st_size > 0:
                temp_out.replace(archivo_mp4)
                print(f"   [OK] Adaptado con éxito a H.264 universal (video + audio garantizados).")
            else:
                if temp_out.exists():
                    try:
                        temp_out.unlink()
                    except Exception:
                        pass
    except Exception as e:
        print(f"   [AVISO] Verificación de códec omitida: {e}")


def elegir_ruta_interactiva():
    """Abre un diálogo nativo de Windows para elegir carpeta o archivo .txt."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        
        # Preguntar si desea seleccionar archivo .txt o carpeta
        seleccion = filedialog.askopenfilename(
            title="Selecciona el archivo .txt con los enlaces a descargar",
            filetypes=[("Archivos de texto", "*.txt"), ("Todos los archivos", "*.*")]
        )
        root.destroy()
        if seleccion:
            return Path(seleccion)
    except Exception:
        pass

    # Fallback por consola
    try:
        entrada = input("\nIngresa la ruta de la carpeta o del archivo .txt con los enlaces: ").strip().strip('"').strip("'")
        if entrada:
            return Path(entrada)
    except Exception:
        pass

    return None


def descargar_videos(origen_path, calidad="mejor"):
    """
    Descarga todos los videos desde las URLs encontradas en el archivo .txt
    y los guarda en el mismo directorio.
    """
    p = Path(origen_path).resolve()

    if p.is_file() and p.suffix.lower() == ".txt":
        txt_path = p
        directorio_destino = p.parent
        urls = extraer_urls_de_archivo(txt_path)
    elif p.is_dir():
        directorio_destino = p
        txt_path, urls = buscar_txt_con_enlaces(p)
        if not txt_path:
            # Si no hay txt, verificar si se quiere crear uno o avisar
            print(f"[AVISO] No se encontró ningún archivo .txt con enlaces en: {p}")
            print(f"        Por favor coloca un archivo 'enlaces.txt' en esa carpeta con los links.")
            return False, f"No se encontró archivo .txt con enlaces en {p.name}"
    else:
        print(f"[ERROR] Ruta no encontrada o no válida: {p}")
        return False, "Ruta no encontrada"

    if not urls:
        print(f"[AVISO] El archivo {txt_path.name} no contiene enlaces válidos (http:// o https://).")
        return False, f"{txt_path.name} no contiene enlaces válidos"

    directorio_destino.mkdir(parents=True, exist_ok=True)
    archivo_historial = directorio_destino / "_descargas_historial.txt"

    print("\n" + "=" * 65)
    print("   DESCARGADOR UNIVERSAL DE VIDEOS (REDES SOCIALES)")
    print("   Facebook · TikTok · Instagram · YouTube · X")
    print("=" * 65)
    print(f"-> Carpeta de destino : {directorio_destino}")
    print(f"-> Archivo de enlaces : {txt_path.name}")
    print(f"-> Enlaces detectados : {len(urls)}")
    print(f"-> Formato de salida  : MP4 (Máxima calidad)")
    print("=" * 65 + "\n")

    # Configuración de yt-dlp optimizada para compatibilidad total con Windows
    ydl_opts = {
        # Guardar en el mismo directorio con título limpio e ID
        'outtmpl': str(directorio_destino / '%(title).80s [%(id)s].%(ext)s'),
        # Priorizar códec H.264/AVC (reproducible en cualquier versión de Windows y reproductores sin códecs extra)
        'format': (
            'bestvideo[vcodec^=avc]+bestaudio[acodec^=mp4a]/'
            'bestvideo[vcodec^=h264]+bestaudio[acodec^=aac]/'
            'bestvideo[vcodec^=avc]+bestaudio/'
            'bestvideo[vcodec^=h264]+bestaudio/'
            'best[vcodec^=avc]/'
            'best[vcodec^=h264]/'
            'bestvideo[ext=mp4]+bestaudio[ext=m4a]/'
            'bestvideo[ext=mp4]+bestaudio/'
            'best[ext=mp4]/'
            'best'
        ),
        'merge_output_format': 'mp4',
        'postprocessors': [{
            'key': 'FFmpegVideoConvertor',
            'preferedformat': 'mp4',
        }],
        # Opciones de robustez
        'ignoreerrors': True,              # Si un video falla (privado/borrado), seguir con los demás
        'no_warnings': False,
        'windowsfilenames': True,          # Evitar caracteres prohibidos en Windows
        'download_archive': str(archivo_historial), # Registro de ya descargados para no repetir
        'retries': 3,
        'fragment_retries': 3,
        # Headers para evitar bloqueos
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        },
    }

    exitosos = 0
    fallidos = 0

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        for idx, url in enumerate(urls, 1):
            print(f"\n[{idx}/{len(urls)}] Conectando: {url}")
            try:
                codigo = ydl.download([url])
                if codigo == 0:
                    exitosos += 1
                else:
                    fallidos += 1
            except Exception as e:
                print(f"   [ERROR] No se pudo descargar {url}: {e}")
                fallidos += 1

    # Verificación final de compatibilidad: asegurar que ningún video quede con HEVC
    for vid in directorio_destino.glob("*.mp4"):
        if not vid.name.startswith(("_", ".")):
            asegurar_compatibilidad_mp4(vid)

    print("\n" + "=" * 65)
    print("   RESUMEN DE DESCARGAS")
    print(f"-> Completadas con éxito : {exitosos}")
    if fallidos > 0:
        print(f"-> Con error o no disp.   : {fallidos}")
    print(f"-> Directorio final      : {directorio_destino}")
    print("=" * 65 + "\n")

    return True, f"Descargados {exitosos} de {len(urls)} videos en {directorio_destino.name}"


def main():
    parser = argparse.ArgumentParser(description="Descargador de videos de redes sociales desde un .txt")
    parser.add_argument("ruta", nargs="?", default=None, help="Ruta de la carpeta o del archivo .txt con enlaces")
    args = parser.parse_args()

    ruta = args.ruta
    if not ruta:
        ruta = elegir_ruta_interactiva()

    if not ruta:
        print("[AVISO] No se proporcionó ninguna ruta. Operación cancelada.")
        sys.exit(0)

    ok, msg = descargar_videos(ruta)
    if not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
