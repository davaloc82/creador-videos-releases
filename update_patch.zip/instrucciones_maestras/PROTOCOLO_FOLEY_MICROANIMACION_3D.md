<!-- FIRMA: POTENCIADO_CON_YOUTUBE_AGENT_SKILL_V1.0 | FECHA: 2026-11-19 -->
# Protocolo Maestro: Generación de Contenido con Personajes Sin Voz en Off (Visual Storytelling & Foley)

Este documento define la arquitectura, las instrucciones maestras y el flujo operativo integral para generar videos sin locución (historias 3D estilo Pixar, parejas, drama silente, comedia o situaciones cotidianas), conectando el **Sistema Generador de Contenido** con la extensión **FlowBatch Pro**.

---

## 1. El Paradigma: ¿Cómo funciona este formato?

A diferencia de los videos tradicionales con locución donde el audio comanda el ritmo (guion -> TTS -> Whisper -> sincronía):
* **No hay voz en off ni síntesis TTS**: El peso narrativo recae 100% en la **actuación visual del personaje**, el **diseño de sonido (Foley)**, la **música incidental** y un **texto gancho inicial (POV / Frase contextual)**.
* **El tiempo es modular y constante**: Cada clip de IA (Google Flow / Veo) tiene una duración fija (habitualmente **5.00 segundos exactos**).
* **La consistencia visual es estricta**: Los personajes no pueden mutar de ropa ni de rostro entre tomas.

---

## 2. Entradas Requeridas del Cliente / Usuario

Para iniciar un proyecto de este estilo en la interfaz del Generador, el usuario solo debe aportar:

| Parámetro | Descripción | Ejemplo |
| :--- | :--- | :--- |
| **Tema / Premisa** | La situación emocional o cómica central. | *"Una pareja de suricatas cocinando; él intenta robar comida y ella lo sorprende con ternura."* |
| **Imágenes de Personajes** | 1 a 3 imágenes fijas de los personajes base. | `p1.png` (Él), `p2.png` (Ella). |
| **Formato Objetivo** | Short (15s – 30s) o Largo (3 a 8 min). | Short (3 tomas = 15s). |
| **Pista Musical / Foley** | Estado de ánimo musical y sonidos clave. | *"Acústica alegre / lo-fi cálido + ruidos de cocina y caricias."* |

---

## 3. Instrucciones Maestras (System Prompts para la IA Generadora)

### A. Instrucción Maestra para SHORTS (15s a 30s)
```markdown
Eres un director cinematográfico especializado en animación 3D corta y narrativa silente (estilo Pixar/Illumination con diseño de sonido Foley).

Tu tarea es crear un Storyboard técnico para un Short de [15s / 20s / 30s] sin voz en off, dividido en tomas exactas de 5.00 segundos.

Para el tema: "[TEMA_DEL_USUARIO]" con los personajes [P1: Nombre/Rol] y [P2: Nombre/Rol]:

1. FRASE GANCHO (POV): Una frase breve, empática y viral para proyectar en pantalla durante los primeros 4 segundos.
2. STORYBOARD SECUENCIAL:
   - Toma 1 (00:00 - 00:05): Acción inicial + Plano de cámara + Efecto Foley clave.
   - Toma 2 (00:05 - 00:10): Desarrollo/Conflicto cómico + Plano de cámara + Efecto Foley.
   - Toma 3 (00:10 - 00:15): Remate/Giro tierno + Plano de cámara + Efecto Foley.
3. PROMPTS PARA GENERACIÓN:
   - Prompt de Imagen Semilla (Toma 1): Descripción visual detallada en inglés para fijar el escenario y personajes.
   - Prompts de Movimiento para Video (Tomas 1, 2, 3): Prompts en inglés enfocados exclusivamente en VERBOS DE ACCIÓN y MOVIMIENTO DE CÁMARA (sin volver a describir la ropa o anatomía ya presente).
```

### B. Instrucción Maestra para VIDEOS LARGOS (3 a 8 Minutos)
En formato largo, un único plano continuo cansa y se degrada. Se estructura como una **Compilación de Micro-Episodios Temáticos**:
* **Estructura**: 8 a 12 micro-historias independientes de 20 a 30 segundos cada una (4 a 6 clips de 5s por episodio).
* **Separadores**: Cada episodio lleva un título breve en pantalla ("Momento 1: La alarma mañanera", "Momento 2: Compartiendo el paraguas").
* **Dinámica**: La música de fondo cambia o modula según el sketch para mantener la retención de audiencia en YouTube/Facebook.

---

## 4. Diferencia Vital en los Prompts (Semilla vs. Movimiento)

Este es el punto que evita personajes deformes o alucinaciones en Google Flow:

```
[Prompt de Imagen Semilla (Modo Imagen)]
       │
       ▼
Fija: Estilo Pixar 3D, Personajes P1/P2, Ropa, Iluminación y Entorno
       │
       ▼
Renderiza Imagen Inicial (001.jpg)
       │
       ▼
[Prompt de Movimiento (Modo Vídeo con Fotograma Inicial)]
       │
       ▼
Describe ÚNICAMENTE:
1. Verbos de acción física
2. Movimiento de cámara cinemático
3. Estado de ánimo / Expresión facial
       │
       ▼
Renderiza Vídeo (001_video.mp4)
```

### Reglas de Oro para los Prompts de Movimiento:
1. **NO re-describir la ropa ni el color de piel**: Flow ya tiene la imagen de entrada. Si escribes *"A 30-year-old man in a gray suit..."*, el motor de vídeo intentará redibujar la ropa encima y causará glitches.
2. **SÍ describir dirección de movimiento y cámara**:
   * *Correcto*: `"The character smiles playfully, turns around and reaches toward the table. Subtle push-in camera, cinematic 3D lighting, smooth 60fps."`

---

## 5. El Flujo de Trabajo Técnico en el Panel de Generación

### 1. `sincronia.txt` (Matemático y Predecible)
Al no existir archivo de locución Whisper, el software calcula la sincronía automáticamente en base a bloques de 5.00s:
```text
# | inicio   | fin      | dur  | cubre
1 | 00:00.00 | 00:05.00 | 5.00 | Escena 1: Preparando ingredientes en la mesa
2 | 00:05.00 | 00:10.00 | 5.00 | Escena 2: Intento de robo de comida y sorpresa
3 | 00:10.00 | 00:15.00 | 5.00 | Escena 3: Abrazo cómplice y reconciliación
```

### 2. Pista de Audio
* **Canal 1 (Música de fondo)**: Archivo instrumental de 15s/30s con fade-out suave al final.
* **Canal 2 (Capa Foley)**: Efectos puntuales agregados en la línea de tiempo en los segundos exactos (`00:03.20` ruido de sartén, `00:07.50` estornudo, `00:13.00` beso/abrazo).

### 3. Texto en Pantalla (POV)
El archivo de subtítulo o superposición genera una sola tarjeta visual:
* **Texto**: `"POV: Cuando intentas cocinar y tu pareja solo quiere mimos 🤍"`
* **Tiempo en pantalla**: `00:00.00` a `00:04.50` (desaparece antes del clímax para no tapar la animación).

---

## 6. Integración con FlowBatch Pro (`flow-batch`)

Para que el panel le entregue la tanda lista a la extensión:

### Escenario A: Continuidad con Fotograma Inicial Único (Shorts de 3 tomas)
1. **Paso 1**: Se envía el prompt de imagen semilla a FlowBatch Pro (Modo Imagen con referencias `P1`/`P2`). Flow genera `001.jpg`.
2. **Paso 2**: Ese `001.jpg` se carga en la sección de Modo Vídeo de FlowBatch Pro como Fotograma Inicial.
3. **Paso 3**: Se ejecutan los prompts de movimiento secuenciales.

### Escenario B: Encadenamiento por Último Fotograma (Keyframe Chaining)
* Para tomas continuas sin corte de cámara, la extensión toma el fotograma de cierre de `Toma N` y lo alimenta como inicio de `Toma N+1`.
* **Regla de corte**: Máximo **2 a 3 encadenamientos consecutivos**. En la toma 4 se debe aplicar un corte cinematográfico (nueva semilla en primer plano o contraplano) para resetear la nitidez y evitar el *generative drift* (degradación acumulada de píxeles).

---

## 7. Resumen de Salidas Generadas por el Sistema

Cuando el cliente pulse *"Generar Proyecto Sin Voz en Off"*, el sistema produce:
1. `prompts_imagen.txt`: Prompt semilla en inglés con las etiquetas `(P1)`, `(P2)` correspondientes.
2. `prompts_movimiento.txt`: Lista de acciones puras en inglés, una por clip de 5 segundos.
3. `sincronia.txt`: Guía temporal matemática a pasos de 5.00s.
4. `pov_hook.txt`: Frase gancho para superposición inicial.
5. `audio_base.mp3`: Pista musical con foley mezclado.




### CATÁLOGO DE LAS 21 FÓRMULAS VIRALES DE GANCHO (OBLIGATORIO ELEGIR UNA):
Para superar el Muro de los 3 Segundos con veredicto matemático FUERTE (score >75/100), el guion DEBE abrir utilizando una de estas estructuras comprobadas:
1. **The Statistic (La Estadística):** Cifra inesperada + consecuencia inmediata ("El 90% de los conductores comete este error en lluvia...").
2. **The Mistake (El Error Actual):** Señala el error que el espectador comete ahora ("Tus primeros 30 segundos son la razón por la que nadie termina tus videos. No es el tema.").
3. **Someone Else's Result (Resultado Ajeno):** Caso concreto de un tercero + mecanismo ("Este canal pasó de cero a cien mil seguidores con un solo formato. Lo he mapeado.").
4. **Contrarian Flip (El Contraste):** Afirma la creencia popular y demuestra por qué falla ("Todos dicen que ahorres el diez por ciento. Los millonarios hacen exactamente lo contrario.").
5. **The Warning (La Advertencia):** Un costo o peligro real inminente ("No subas otro video antes de revisar este ajuste.").
6. **The Direct Address (Dirección Directa):** Interpela al espectador con "tú / tu" en las primeras 6 palabras ("Si tienes un crédito activo, este dato te va a ahorrar miles de dólares.").
7. **The Question (La Pregunta Abierta):** Duda crítica sin auto-responderse ("¿Por qué los trenes más rápidos del mundo tienen la punta de un pájaro?").
8. **The Clock (La Cuenta Regresiva):** Beneficio acotado en tiempo real ("En los próximos sesenta segundos sabrás exactamente qué hacer.").
9. **The Superlative (El Superlativo):** El más rápido, más letal o más eficiente de su categoría.
10. **The Insider (La Verdad Oculta):** Revelación de un mecanismo interno que nadie enseña.

### REGLAS HEURÍSTICAS DE ORO PARA EL GANCHO (PRIMEROS 10 A 15 SEGUNDOS):
- **Dirección con 'Tú':** Nombra a la persona ("tú", "tu", "te") en las primeras 6 palabras.
- **Cifras Concretas:** Reemplaza adjetivos vagos ("increíble", "asombroso", "loco") por números, fechas o nombres específicos.
- **Riesgo / Coste Palpable (Stakes):** Nombra lo que pierde el espectador (tiempo, dinero, seguridad, prestigio) si no escucha la solución.
- **Brevedad Óptima:** El gancho debe tener entre 9 y 24 palabras (8 a 12 segundos hablados antes del giro).
