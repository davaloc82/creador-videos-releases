@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Instalador de Dependencias - Creador de Videos (Universal)

echo ====================================================================
echo    CREADOR DE VIDEOS  -  CONFIGURACION E INSTALACION DE ENTORNO
echo ====================================================================
echo.

rem Detectar si se esta ejecutando dentro de un archivo ZIP temporal sin descomprimir
echo "%~dp0" | findstr /i "AppData\Local\Temp" >nul
if not errorlevel 1 (
    echo ====================================================================
    echo   [ALERTA IMPORTANTE]
    echo   Estas intentando ejecutar el programa directamente dentro del ZIP.
    echo   Windows no permite ejecutar programas dentro de una carpeta comprimida.
    echo.
    echo   PASOS PARA RESOLVERLO:
    echo   1. Cierra esta ventana.
    echo   2. Ve al archivo "Creador_de_Videos_Universal.zip" que descargaste.
    echo   3. Haz CLIC DERECHO sobre el archivo ZIP y elige "Extraer todo...".
    echo   4. Entra a la carpeta descomprimida y ejecuta "panel.bat".
    echo ====================================================================
    echo.
    pause
    exit /b 1
)

rem 1. Verificar Python
echo [1/4] Verificando instalacion de Python...
where python >nul 2>&1
if errorlevel 1 (
    echo [!] Python no se encontro configurado en el sistema.
    echo [*] Intentando instalar Python 3.11 automaticamente mediante Windows Package Manager (winget)...
    echo.
    winget install Python.Python.3.11 --accept-package-agreements --accept-source-agreements
    where python >nul 2>&1
    if errorlevel 1 (
        echo.
        echo ====================================================================
        echo [AVISO] Se abrira la pagina oficial de descarga de Python en tu navegador.
        echo.
        echo 1. Descarga e instala Python desde la pagina que se abrira.
        echo 2. IMPORTANTE: Durante la instalacion, asegurate de MARCAR la casilla:
        echo      [X] "Add python.exe to PATH" (Agregar Python al PATH).
        echo 3. Una vez instalado Python, vuelve a ejecutar este archivo.
        echo ====================================================================
        echo.
        start https://www.python.org/downloads/
        pause
        exit /b 1
    ) else (
        echo [*] Python instalado correctamente.
    )
)
for /f "tokens=*" %%i in ('python --version 2^>^&1') do echo [*] %%i detectado.

rem 2. Instalar / actualizar librerias de Python
echo.
echo [2/4] Verificando e instalando librerias necesarias (faster-whisper, Pillow, numpy, yt-dlp)...
python -m pip install --upgrade pip --quiet
python -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo.
    echo [ERROR] Hubo un inconveniente al instalar las librerias con pip.
    echo Asegurate de tener conexion a internet activa.
    echo.
    pause
    exit /b 1
)
echo [*] Todas las librerias de Python estan listas.

rem 3. Verificar FFmpeg
echo.
echo [3/4] Verificando FFmpeg (necesario para el corte y ensamblaje de video)...
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo [!] FFmpeg no se encontro en la variable PATH del sistema.
    echo [*] Intentando instalar FFmpeg automaticamente mediante Windows Package Manager (winget)...
    echo.
    winget install Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
    where ffmpeg >nul 2>&1
    if errorlevel 1 (
        echo.
        echo ====================================================================
        echo [AVISO] No se pudo instalar FFmpeg de forma automatica.
        echo.
        echo Para que el montaje de video funcione, descarga FFmpeg gratis de:
        echo https://www.gyan.dev/ffmpeg/builds/ (ffmpeg-release-essentials.zip)
        echo y anade la subcarpeta 'bin' a las Variables de Entorno de Windows.
        echo ====================================================================
        echo.
    ) else (
        echo [*] FFmpeg instalado y detectado con exito.
    )
) else (
    echo [*] FFmpeg detectado correctamente en el sistema.
)

rem 4. Crear carpeta de proyectos por defecto
echo.
echo [4/4] Verificando carpeta de trabajo...
set "CARPETA_TRABAJO=%USERPROFILE%\Downloads\PROYECTOS_VIDEO"
if not exist "%CARPETA_TRABAJO%" (
    mkdir "%CARPETA_TRABAJO%"
    echo [*] Carpeta creada en: %CARPETA_TRABAJO%
) else (
    echo [*] Carpeta existente: %CARPETA_TRABAJO%
)

echo.
echo ====================================================================
echo  [EXITO] Todo el entorno esta configurado y listo para trabajar.
echo ====================================================================
echo.
echo Ya puedes iniciar el sistema haciendo doble clic en "panel.bat".
echo.
pause
