@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Creador de Videos (Universal)

echo ====================================================================
echo   INICIANDO CREADOR DE VIDEOS (UNIVERSAL)...
echo ====================================================================
echo.

rem 1. Detectar si se esta ejecutando dentro de un archivo ZIP temporal sin descomprimir
echo "%~dp0" | findstr /i "AppData\Local\Temp" >nul
if not errorlevel 1 (
    echo ====================================================================
    echo   [ALERTA IMPORTANTE]
    echo   Estas intentando ejecutar el programa directamente dentro del ZIP.
    echo   Windows no permite ejecutar programas dentro de una carpeta comprimida.
    echo.
    echo   PASOS PARA RESOLVERLO:
    echo   1. Cierra esta ventana.
    echo   2. Ve al archivo "Creador_de_Videos_Universal.zip" que descargaste.
    echo   3. Haz CLIC DERECHO sobre el archivo ZIP y elige "Extraer todo...".
    echo   4. Entra a la carpeta descomprimida y ejecuta "panel.bat".
    echo ====================================================================
    echo.
    pause
    exit /b 1
)

rem 2. Verificar que Python este instalado
where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] No se detecto Python instalado en tu computadora.
    echo Se abrira el instalador de dependencias...
    echo.
    call "%~dp0instalar_dependencias.bat"
    if errorlevel 1 (
        pause
        exit /b 1
    )
)

rem 2.1 Auditoria y auto-reparacion del entorno (librerias de Python y FFmpeg)
if exist "%~dp0verificar_entorno.py" (
    python "%~dp0verificar_entorno.py"
)

rem 3. Iniciar el servidor Python
rem Nota: panel.py abre automaticamente una sola pestana en el navegador cuando el servidor esta listo.
echo [*] Iniciando servidor y abriendo navegador...
echo ====================================================================
echo   IMPORTANTE: NO CIERRES ESTA VENTANA MIENTRAS USES EL PROGRAMA
echo ====================================================================
echo.

python panel.py

if errorlevel 1 (
    echo.
    echo ====================================================================
    echo   El servidor se ha detenido o ha ocurrido un error.
    echo ====================================================================
    pause
)
