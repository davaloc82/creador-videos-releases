@echo off
rem ==============================================================================
rem Lanzador del Panel de Videos - Creador Universal
rem Doble clic para abrirlo. Mantiene el servidor activo.
rem ==============================================================================
chcp 65001 >nul
cd /d "%~dp0"
title Panel de Videos - Creador Universal

rem 1. Buscar interprete de Python funcional compatible (Prioridad: 3.11 y 3.12)
set "PY="
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if "%PY%"=="" if exist "C:\Python311\python.exe" set "PY=C:\Python311\python.exe"
if "%PY%"=="" if exist "%ProgramFiles%\Python311\python.exe" set "PY=%ProgramFiles%\Python311\python.exe"
if "%PY%"=="" if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if "%PY%"=="" if exist "C:\Python312\python.exe" set "PY=C:\Python312\python.exe"
if "%PY%"=="" if exist "%ProgramFiles%\Python312\python.exe" set "PY=%ProgramFiles%\Python312\python.exe"

rem 2. Si no esta en rutas fijas, probar comando python del sistema pero VALIDANDO compatibilidad (3.10 a 3.12, NO 3.13+)
if "%PY%"=="" (
    where python >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys; sys.exit(0 if (3, 10) <= sys.version_info < (3, 13) else 1)" >nul 2>&1
        if not errorlevel 1 set "PY=python"
    )
)

rem 3. Si aun no hay Python compatible (ej: el cliente no tiene Python o tiene Python 3.13+ incompatible), autoinstalar Python 3.11 oficial desde redist
if "%PY%"=="" (
    if exist "%~dp0redist\python-3.11.9-amd64.exe" (
        echo [*] Configurando entorno de Python 3.11 oficial para IA y subtitulos...
        echo [*] Instalando en segundo plano, por favor espera un momento...
        start /wait "" "%~dp0redist\python-3.11.9-amd64.exe" /quiet InstallAllUsers=0 PrependPath=0 Include_pip=1 SimpleInstall=1
        if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
            set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
        )
    )
)

if "%PY%"=="" (
    echo ====================================================================
    echo   [ERROR] No se detecto un interprete de Python compatible (3.11/3.12).
    echo   Python 3.13+ no es compatible con el motor de subtitulos de IA en Windows.
    echo   Por favor instala Python 3.11 desde la carpeta redist\ o descarga:
    echo   https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
    echo ====================================================================
    pause
    exit /b 1
)

rem 3. Auditar y calibrar dependencias
if exist "%~dp0core\verificar_entorno.py" (
    "%PY%" "%~dp0core\verificar_entorno.py"
) else if exist "%~dp0verificar_entorno.py" (
    "%PY%" "%~dp0verificar_entorno.py"
)

rem 4. Iniciar Panel Web
"%PY%" panel.py

if errorlevel 1 (
    echo.
    echo [ERROR] El servidor se cerro con error.
    pause
)
