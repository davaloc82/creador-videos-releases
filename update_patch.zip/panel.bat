@echo off
rem ==============================================================================
rem Lanzador del Panel de Videos - Creador Universal
rem Doble clic para abrirlo. Mantiene el servidor activo.
rem ==============================================================================
chcp 65001 >nul
cd /d "%~dp0"
title Panel de Videos - Creador Universal

rem 1. Probar si existe un Python funcional (ignorando el falso alias de WindowsApps)
set "PY="
python -c "import sys" >nul 2>&1
if not errorlevel 1 (
    set "PY=python"
) else (
    if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    if exist "%ProgramFiles%\Python311\python.exe" set "PY=%ProgramFiles%\Python311\python.exe"
    if exist "%ProgramFiles%\Python312\python.exe" set "PY=%ProgramFiles%\Python312\python.exe"
    if exist "C:\Python311\python.exe" set "PY=C:\Python311\python.exe"
    if exist "C:\Python312\python.exe" set "PY=C:\Python312\python.exe"
)

rem 2. Si Python no esta instalado, ofrecer instalacion automatica silenciosa
if "%PY%"=="" (
    echo ====================================================================
    echo   [AVISO] No se detecto un interprete de Python funcional.
    echo ====================================================================
    if exist "%~dp0redist\python-3.11.9-amd64.exe" (
        echo [*] Instalando Python 3.11 de forma automatica y silenciosa...
        echo     (Esto toma aproximadamente 20 segundos, por favor espera...)
        start /wait "" "%~dp0redist\python-3.11.9-amd64.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 SimpleInstall=1
        if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
            set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
            echo [OK] Python 3.11 instalado correctamente.
        )
    )
    if "%PY%"=="" (
        echo [ERROR] No se pudo encontrar ni instalar Python.
        echo Por favor ejecuta el instalador en: redist\python-3.11.9-amd64.exe
        pause
        exit /b 1
    )
)

rem 3. Auditar y calibrar dependencias
if exist "%~dp0core\verificar_entorno.py" (
    "%PY%" "%~dp0core\verificar_entorno.py"
) else if exist "%~dp0verificar_entorno.py" (
    "%PY%" "%~dp0verificar_entorno.py"
)

rem 4. Iniciar Panel Web
"%PY%" panel.py

if errorlevel 1 (
    echo.
    echo [ERROR] El servidor se cerro con error.
    pause
)
