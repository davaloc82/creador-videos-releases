@echo off
rem ==============================================================================
rem Lanzador del Panel de Videos - Creador Universal
rem Doble clic para abrirlo. Mantiene el servidor activo.
rem ==============================================================================
chcp 65001 >nul
cd /d "%~dp0"
title Panel de Videos - Creador Universal

rem 1. Buscar interprete de Python funcional
set "PY="
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if "%PY%"=="" if exist "C:\Python311\python.exe" set "PY=C:\Python311\python.exe"
if "%PY%"=="" if exist "%ProgramFiles%\Python311\python.exe" set "PY=%ProgramFiles%\Python311\python.exe"
if "%PY%"=="" if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if "%PY%"=="" if exist "C:\Python312\python.exe" set "PY=C:\Python312\python.exe"
if "%PY%"=="" if exist "%ProgramFiles%\Python312\python.exe" set "PY=%ProgramFiles%\Python312\python.exe"

rem 2. Si no esta en rutas fijas, probar comando python del sistema
if "%PY%"=="" (
    where python >nul 2>&1
    if not errorlevel 1 set "PY=python"
)

rem 3. Si aun no hay Python, probar instalador silencioso en redist si existe
if "%PY%"=="" (
    if exist "%~dp0redist\python-3.11.9-amd64.exe" (
        echo [*] Instalando Python 3.11 de forma automatica y silenciosa...
        start /wait "" "%~dp0redist\python-3.11.9-amd64.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 SimpleInstall=1
        if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
            set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
        )
    )
)

if "%PY%"=="" (
    echo ====================================================================
    echo   [ERROR] No se detecto un interprete de Python funcional.
    echo   Instala Python 3.11 desde: https://www.python.org/downloads/
    echo ====================================================================
    pause
    exit /b 1
)

rem 4. Auditar dependencias
if exist "%~dp0core\verificar_entorno.py" (
    "%PY%" "%~dp0core\verificar_entorno.py"
) else if exist "%~dp0verificar_entorno.py" (
    "%PY%" "%~dp0verificar_entorno.py"
)

rem 5. Iniciar Panel Web
"%PY%" panel.py

if errorlevel 1 (
    echo.
    echo [ERROR] El servidor se cerro con error.
    pause
)
