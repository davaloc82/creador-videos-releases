#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
panel.py - Panel web local (hub) para gestionar el contenido de cada nicho
desde una sola interfaz, con menu lateral.

    python panel.py            (o doble clic en panel.bat)

Abre http://127.0.0.1:8770. Sin dependencias externas (solo la libreria
estandar) y SIN base de datos: lee las carpetas en vivo.

DISENO POR NICHOS
-----------------
El CODIGO vive en este hub, en una subcarpeta por nicho (psico/, ecos/,
famosos/). El CONTENIDO (carpetas de guion, videos, audios) vive aparte, en
su propia unidad, y cada nicho lo apunta con "raiz". Anadir un nicho es
agregar UNA entrada al registro NICHOS y su vista en el JS; no se toca el
resto.

Nichos configurados:
  - psico   : monta el video final -> <raiz>/_VIDEOS FINALES/<carpeta>.mp4
  - ecos    : recorta cada clip al ritmo de la narracion (para CapCut)
  - famosos : indexa el material de un famoso y recorta los clips por guion
  - peliculas: recap "te cuento una peli" -> voz + fuente -> video final sin subs
  - drama   : monta como psico pero SIN texto en pantalla (estilo pelicula)
  - finanzas: como psico, carpetas por titulo, video final en la propia carpeta
  - novelas : telenovela hablada; cada clip trae su voz -> recorta la cola
              muerta (Whisper), nivela y une, SIN subtitulos (por ahora)
"""
import base64
import collections
import datetime
import http.server
import json
import os
import re
import shutil
import socketserver
import subprocess
import sys
import threading
import time
import webbrowser
import mimetypes
import warnings
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

# Silenciar ruidos externos (Hugging Face Hub, deprecaciones, avisos informativos)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
os.environ.setdefault("PYTHONWARNINGS", "ignore")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")

def _subproc_silent_kwargs(**extra):
    """Garantiza que cualquier invocación de subproceso en Windows no muestre ventana negra."""
    kw = dict(extra)
    if sys.platform.startswith("win"):
        kw["creationflags"] = kw.get("creationflags", 0) | 0x08000000
        si = kw.get("startupinfo") or subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        kw["startupinfo"] = si
    return kw

def _es_ruido_log(linea: str) -> bool:
    if not linea:
        return True
    txt = linea.lower()
    return any(p in txt for p in (
        "unauthenticated requests to the hf hub",
        "hf_token",
        "userwarning",
        "futurewarning",
        "solicitudes no autenticadas",
        "huggingface_hub",
    ))

def _ultima_linea_job(log_deque) -> str:
    if not log_deque:
        return ""
    for item in reversed(log_deque):
        if not _es_ruido_log(item):
            return item
    return ""


AQUI = Path(__file__).resolve().parent
CORE_DIR = AQUI / "core"
if str(CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CORE_DIR))
ADMIN_LIC_DIR = AQUI / "admin_licencias"
if ADMIN_LIC_DIR.is_dir() and str(ADMIN_LIC_DIR) not in sys.path:
    sys.path.insert(0, str(ADMIN_LIC_DIR))
ADMINLTE_DIR = AQUI / "AdminLTE" / "AdminLTE"
PUERTO = 8770
MARCADOR = ".publicado"        # archivo que marca "ya subido, no volver a montar"

VIDEO_EXTS = (".mp4", ".mov", ".mkv", ".webm")
AUDIO_EXTS = (".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg")

USER_DOWNLOADS = (Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads").resolve()

NICHOS = {
    "psico": {
        "nombre": "Psicología Oscura",
        "tipo": "psico",
        "raiz": USER_DOWNLOADS / "GUIONES PSICO OSCURA",
        "codigo": AQUI / "psico",
        "variante": "grok",
        "auxiliar": "veo",
        "productor": "producir.py",
        "finales": "_VIDEOS FINALES",
        "configurado": True,
    },
    "ecos": {
        "nombre": "Ecos del Alma",
        "tipo": "ecos",
        "raiz": USER_DOWNLOADS / "NUEVOS GUIONES",
        "codigo": AQUI / "ecos",
        "variante": "grok",
        "script": "cortar_escenas.py",
        "configurado": True,
    },
    "famosos": {
        "nombre": "Famosos",
        "tipo": "famosos",
        "raiz": USER_DOWNLOADS / "FAMOSOS",
        "codigo": AQUI / "famosos",
        "script": "producir_famosos.py",
        "productor": "producir_famosos.py",
        "configurado": True,
    },
    "peliculas": {
        "nombre": "Películas (recaps)",
        "tipo": "peliculas",
        "raiz": USER_DOWNLOADS / "PELICULAS",
        "codigo": AQUI / "peliculas",
        "productor": "producir.py",
        "configurado": True,
    },
    "drama": {
        "nombre": "Drama IA",
        "tipo": "psico",
        "raiz": USER_DOWNLOADS / "Dramalandia",
        "codigo": AQUI / "drama",
        "variante": "grok",
        "auxiliar": "veo",
        "productor": "producir.py",
        "finales": "_VIDEOS FINALES",
        "configurado": True,
    },
    "finanzas": {
        "nombre": "Finanzas",
        "tipo": "finanzas",
        "raiz": USER_DOWNLOADS / "FINANZAS",
        "codigo": AQUI / "finanzas",
        "variante": "grok",
        "productor": "producir_finanzas.py",
        "configurado": True,
    },
    "desastres": {
        "nombre": "Desastres (Disaster Explainer)",
        "tipo": "desastres",
        "raiz": USER_DOWNLOADS / "DESASTRES",
        "codigo": AQUI / "desastres",
        "variante": "grok",
        "productor": "producir_desastres.py",
        "configurado": True,
    },
    "novelas": {
        "nombre": "Novelas Habladas",
        "tipo": "novelas",
        "raiz": USER_DOWNLOADS / "NOVELAS",
        "codigo": AQUI / "novelas",
        "variante": "grok",
        "productor": "producir.py",
        "finales": "_VIDEOS FINALES",
        "configurado": True,
    },
    "ebook": {
        "nombre": "Ebooks (leer y colorear)",
        "tipo": "ebook",
        "raiz": USER_DOWNLOADS / "EBOOKS",
        "codigo": AQUI / "ebook",
        "script": "generar_ebook.py",
        "configurado": True,
    },
    "mapas": {
        "nombre": "🌍 Mapas Virales",
        "tipo": "mapas",
        "raiz": USER_DOWNLOADS / "MAPAS",
        "codigo": AQUI / "mapas",
        "productor": "producir_mapas.py",
        "finales": "_VIDEOS FINALES",
        "estudio": USER_DOWNLOADS / "posibles nichos" / "plantilla_mapa.html",
        "configurado": True,
    },
}

# Auto-crear carpetas base de nichos si no existen (100% amigable con nuevas PCs)
for _ninfo in NICHOS.values():
    try:
        if isinstance(_ninfo.get("raiz"), Path):
            _ninfo["raiz"].mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
NICHO_DEF = "famosos"


# --------------------------------------------------------------- utilidades
def _leer_titulo(sincronia: Path):
    if not sincronia.is_file():
        return None
    for linea in sincronia.read_text(encoding="utf-8", errors="replace").splitlines():
        s = linea.strip()
        if s.lower().split(":", 1)[0].strip() == "titulo" and ":" in s:
            t = s.split(":", 1)[1].strip()
            if t:
                return t
        m = re.search(r"SINCRON[ÍI]A\s*—\s*GUION\s*\d+\s*—\s*(.+)", s, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return None


def _mtime(p: Path):
    try:
        return p.stat().st_mtime
    except OSError:
        return 0


def _creacion_time(p: Path) -> float:
    try:
        st = p.stat()
        return getattr(st, "st_ctime", st.st_mtime)
    except OSError:
        return 0.0


def _fecha_str(p: Path) -> str:
    try:
        t = _creacion_time(p)
        if t <= 0:
            return ""
        return datetime.datetime.fromtimestamp(t).strftime("%d/%m %H:%M")
    except Exception:
        return ""


def _escanear_medios_universal(proy: Path):
    """Escanea videos e imágenes en proy y sus subdirectorios recursivamente
    en cualquier idioma (grok, veo, imagen, imagenes, videos, clips, etc.)."""
    ignored = {"cortes", "_videos finales", "_videos_finales", "_temp", "__pycache__"}
    v_exts = (".mp4", ".mov", ".mkv", ".webm")
    i_exts = (".jpg", ".jpeg", ".png", ".webp")
    clips_vid = []
    clips_img = []
    if proy.is_dir():
        for p in proy.rglob("*"):
            if not p.is_file(): continue
            if any(ign in [part.lower() for part in p.parts] for ign in ignored): continue
            if p.name.upper().startswith("FINAL"): continue
            if not re.search(r"\d", p.name): continue
            suf = p.suffix.lower()
            if suf in v_exts and p not in clips_vid:
                clips_vid.append(p)
            elif suf in i_exts and p not in clips_img:
                clips_img.append(p)
    return clips_vid, clips_img


CARPETA_PROYECTOS = (Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads" / "PROYECTOS_VIDEO").resolve()

def _raices_configuradas():
    raices = [n["raiz"] for n in NICHOS.values() if n.get("configurado") and n.get("raiz")]
    raices.append(CARPETA_PROYECTOS)
    try:
        from gestor_nichos import cargar_nichos_usuario
        for nu in cargar_nichos_usuario():
            if nu.get("ruta"):
                raices.append(Path(nu["ruta"]).resolve())
    except Exception:
        pass
    return raices


def _dentro_de_nicho(p: Path):
    p = p.resolve()
    for raiz in _raices_configuradas():
        r = Path(raiz).resolve()
        if p == r or r in p.parents:
            return True
    return False


# --------------------------------------------------------------- jobs
JOBS = {}      # clave -> {"estado": montando|activo|ok|error, "log": deque, "inicio": t}


def montaje_activo():
    """Clave del proceso en curso, si hay uno. Solo se permite UNO a la vez en
    todo el hub (transcribir/renderizar/CLIP saturan la CPU)."""
    for ruta, j in JOBS.items():
        if j["estado"] in ("montando", "activo"):
            return ruta
    return None


def _job_serial(clave):
    if not clave:
        return None
    j = JOBS.get(clave)
    if not j:
        try:
            p_res = str(Path(clave).resolve())
            j = JOBS.get(p_res)
        except Exception:
            pass
    if not j:
        for k, v in JOBS.items():
            try:
                if Path(k).resolve() == Path(clave).resolve():
                    j = v
                    break
            except Exception:
                pass
    if not j:
        return None
    return {"estado": j["estado"], "linea": _ultima_linea_job(j["log"])}


def _nombre_amable(clave):
    """Nombre legible del proceso: si la clave es una subcarpeta grok/veo, se
    muestra la carpeta del guion (la padre); si no, la propia carpeta."""
    p = Path(clave)
    return p.parent.name if p.name.lower() in ("grok", "veo") else p.name


def estado_actual():
    """Info del proceso en curso, para el modal de 'procesando'."""
    clave = montaje_activo()
    if not clave:
        return {"activo": False}
    j = JOBS[clave]
    return {"activo": True, "nombre": _nombre_amable(clave),
            "linea": _ultima_linea_job(j["log"]), "estado": j["estado"]}


def cancelar_proceso():
    """Detiene el proceso en curso (y sus hijos: ffmpeg, etc.). En Windows se
    usa taskkill /T para matar todo el arbol; si no, terminate()."""
    clave = montaje_activo()
    if not clave:
        return False, "no hay ningún proceso activo"
    j = JOBS.get(clave) or {}
    j["cancelado"] = True
    proc = j.get("proc")
    if proc and proc.poll() is None:
        try:
            if sys.platform.startswith("win"):
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                               capture_output=True)
            else:
                proc.terminate()
        except Exception:
            try:
                proc.terminate()
            except Exception:
                pass
    return True, "cancelado"


def lanzar_proceso(clave, args, cwd=None):
    """Lanza un comando en segundo plano y guarda su log en JOBS[clave].
    Un solo proceso activo a la vez en todo el hub."""
    activo = montaje_activo()
    if activo and activo != clave:
        return False, "ya hay un proceso en curso; espera a que termine"
    if clave in JOBS and JOBS[clave]["estado"] in ("montando", "activo"):
        return False, "ya se está ejecutando"
    log = collections.deque(maxlen=120)
    JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time()}
    # PYTHONUNBUFFERED: sin esto, los print() del hijo se quedan en el buffer
    # (stdout es una tuberia, no una consola) y el panel no muestra el avance
    # hasta que el proceso termina. Con esto, el progreso llega en vivo.
    core_dir = str(CORE_DIR.resolve())
    aqui_dir = str(AQUI.resolve())
    ppath = os.pathsep.join(filter(None, [aqui_dir, core_dir, os.environ.get("PYTHONPATH")]))
    entorno = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
               "PYTHONUNBUFFERED": "1", "PYTHONPATH": ppath,
               "PYTHONWARNINGS": "ignore",
               "HF_HUB_DISABLE_SYMLINKS_WARNING": "1",
               "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1"}
    try:
        from ffmpeg_resolver import detectar_ffmpeg
        ff_exe = detectar_ffmpeg()
        if ff_exe and Path(ff_exe).is_file():
            ff_bin = str(Path(ff_exe).parent)
            entorno["PATH"] = ff_bin + os.pathsep + entorno.get("PATH", "")
    except Exception:
        pass
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace",
                            env=entorno, cwd=str(cwd) if cwd else None)
    JOBS[clave]["proc"] = proc

    def seguir():
        for linea in proc.stdout:
            linea = linea.rstrip()
            if linea and not _es_ruido_log(linea):
                log.append(linea)
        code = proc.wait()
        JOBS[clave]["estado"] = ("cancelado" if JOBS[clave].get("cancelado")
                                 else ("ok" if code == 0 else "error"))

    threading.Thread(target=seguir, daemon=True).start()
    return True, "lanzado"


# --------------------------------------------------------------- deteccion psico
def fila_psico(proy: Path, nicho: dict):
    """Una fila de la tabla: el estado de la variante montable (grok o proy)."""
    var = proy / nicho.get("variante", "grok")
    aux = proy / nicho.get("auxiliar", "veo")

    clips_vid, clips_img = _escanear_medios_universal(proy)
    n_v = len(clips_vid)
    n_i = len(clips_img)
    total_medios = n_v + n_i

    cortes_dir = var / "cortes" if var.is_dir() else (proy / "cortes")
    cortes = list(cortes_dir.glob("[0-9][0-9]_*.mp4")) if cortes_dir.is_dir() else []

    finales_dir = Path(nicho["raiz"]) / nicho.get("finales", "_VIDEOS FINALES")
    final = finales_dir / f"{proy.name}.mp4"
    final = final if final.is_file() else None

    config = var / "config.yaml" if (var / "config.yaml").is_file() else (proy / "config.yaml")
    sincronia = var / "sincronia.txt" if (var / "sincronia.txt").is_file() else (proy / "sincronia.txt")
    audio = var / "aud.mp3" if (var / "aud.mp3").is_file() else (proy / "aud.mp3")
    if not audio.is_file():
        cands_aud = [x for x in proy.rglob("*") if x.is_file() and x.suffix.lower() in AUDIO_EXTS and "cortes" not in x.parts and "_limpio" not in x.stem.lower()]
        if cands_aud: audio = cands_aud[0]
    titulo = _leer_titulo(sincronia)

    insumos = [audio, config, sincronia] + clips_vid + clips_img
    entrada_max = max((_mtime(x) for x in insumos if x.exists()), default=0)
    desactualizado = bool(final) and _mtime(final) < entrada_max

    falta = []
    if not audio.exists():
        falta.append("audio")
    if not total_medios:
        falta.append("clips/imágenes")
    if not config.exists():
        falta.append("config")
    if not sincronia.exists():
        falta.append("sincronía")
    elif not titulo:
        falta.append("título")
    if audio.exists() and total_medios and not final:
        falta.append("montar")
    if final and desactualizado:
        falta.append("re-montar")

    if final and desactualizado:
        estado = "desactualizado"
    elif final:
        estado = "montado"
    elif audio.exists() and total_medios:
        estado = "listo"
    else:
        estado = "pendiente"

    publicado = (var.is_dir() and (var / MARCADOR).exists()) or (proy / MARCADOR).exists()
    if publicado:
        estado = "publicado"
        falta = []
    m = re.match(r"^(\d+)", proy.name)
    num = int(m.group(1)) if m else 0

    etq_clips = f"{n_v}v+{n_i}i" if n_i else n_v

    return {
        "nombre": proy.name,
        "ruta": str(var.resolve()) if var.is_dir() else str(proy.resolve()),
        "num": num,
        "estado": estado,
        "falta": falta,
        "clips": etq_clips,
        "cortes": len(cortes),
        "veo_img": n_i,
        "titulo": titulo,
        "publicado": publicado,
        "montable": audio.exists() and bool(total_medios) and not publicado,
        "job": _job_serial(str(var.resolve()) if var.is_dir() else str(proy.resolve())),
        "t_creacion": _creacion_time(proy),
        "fecha": _fecha_str(proy),
    }


def escanear(nicho_id: str):
    nicho = NICHOS.get(nicho_id)
    if not nicho or not nicho.get("configurado"):
        return None
    if nicho["tipo"] == "psico":
        raiz = Path(nicho["raiz"])
        filas = [fila_psico(d, nicho) for d in raiz.iterdir()
                 if d.is_dir() and re.match(r"^\d", d.name)]
        # ultimas carpetas creadas primero; las publicadas caen al fondo.
        filas.sort(key=lambda f: (f["publicado"], -f.get("t_creacion", 0), -f["num"], f["nombre"].lower()))
        return {"nicho": nicho_id, "nombre": nicho["nombre"], "raiz": str(raiz),
                "filas": filas, "montaje_activo": montaje_activo()}
    if nicho["tipo"] == "finanzas":
        return escanear_finanzas(nicho)
    if nicho["tipo"] == "desastres":
        return escanear_desastres(nicho)
    if nicho["tipo"] == "novelas":
        return escanear_novelas(nicho)
    if nicho["tipo"] == "mapas":
        return escanear_mapas(nicho)
    return None


# --------------------------------------------------------------- deteccion mapas
MAPAS_LANGS = ("es", "en", "pt", "fr", "de", "it", "zh", "ja", "ko", "ru")


def fila_mapas(proy: Path, nicho: dict, audio_fijo: Path = None):
    """Estado de un proyecto de Mapas Virales: soporta 1 idioma (aud.mp3 + mapa.txt)
    o multi-idioma en la misma carpeta (ej. aud_es.mp3 + mapa_es.txt, aud_en.mp3 + mapa_en.txt).
    Busca audios y configuraciones en la raíz del proyecto y en subcarpetas grok/ si existen."""
    finales_dir = Path(nicho["raiz"]) / nicho.get("finales", "_VIDEOS FINALES")
    dirs_insumos = [proy]
    if (proy / "grok").is_dir():
        dirs_insumos.append(proy / "grok")

    by_lang = {}
    if audio_fijo:
        audio = audio_fijo
        cand_fin = finales_dir / f"{audio_fijo.stem}.mp4"
        cand_proy = proy / f"{audio_fijo.stem}.mp4"
        final = cand_fin if cand_fin.is_file() else cand_proy
        nombre_mostrar = f"{audio_fijo.stem} (Raíz)"
    else:
        mp3s = []
        for d in dirs_insumos:
            for x in sorted(d.glob("*.mp3"), key=lambda p: p.name.lower()):
                if not x.name.startswith("_") and "_limpio" not in x.stem.lower() and x not in mp3s:
                    mp3s.append(x)

        for p in mp3s:
            stem = p.stem.lower().strip()
            m_l = re.match(r"^(?:aud|audio|voz|guion|voice)?[_-]?([a-z]{2})$", stem) or re.search(r"[_-]([a-z]{2})$", stem)
            if m_l and m_l.group(1) in MAPAS_LANGS:
                lc = m_l.group(1)
                if lc not in by_lang or stem.startswith("aud"):
                    by_lang[lc] = p

        audio = None
        for d in dirs_insumos:
            if (d / "aud.mp3").is_file():
                audio = d / "aud.mp3"
                break
        if not audio:
            audio = mp3s[0] if mp3s else (proy / "aud.mp3")

        cand_fin = finales_dir / f"{proy.name}.mp4"
        cand_proy = proy / f"{proy.name}.mp4"
        final = cand_fin if cand_fin.is_file() else cand_proy
        nombre_mostrar = proy.name

    cands_cfg = []
    cfg_nombres = (
        "mapa_es.txt", "mapa_es.txt.txt", "mapa_es.json",
        "mapas_es.txt", "mapas_es.txt.txt",
        "mapa.txt", "mapa.txt.txt", "mapa.json.txt", "mapa.json",
        "mapas.txt", "mapas.txt.txt", "mapas.json.txt", "mapas.json",
        "mapa_en.txt", "mapa_en.txt.txt", "mapa_en.json",
        "mapas_en.txt", "mapas_en.txt.txt",
    )
    for d in dirs_insumos:
        for n in cfg_nombres:
            cand_p = d / n
            if cand_p.is_file() and cand_p not in cands_cfg:
                cands_cfg.append(cand_p)

    cfg_json = max(cands_cfg, key=lambda p: p.stat().st_mtime) if cands_cfg else (proy / "mapa.txt")
    pines_count = 6
    titulo = proy.name
    if cfg_json.is_file():
        try:
            raw_t = cfg_json.read_text(encoding="utf-8-sig", errors="replace").strip()
            i0 = raw_t.find("{")
            if i0 != -1:
                d_cfg, _ = json.JSONDecoder().raw_decode(raw_t, i0)
                titulo = d_cfg.get("titulo", titulo)
                pines_count = len(d_cfg.get("pins", []))
        except Exception:
            pass

    f_prompts_txt = proy / "prompts.txt"
    tiene_prompts_txt = f_prompts_txt.is_file() and f_prompts_txt.stat().st_size > 10
    total_prompts_count = 0
    if tiene_prompts_txt:
        try:
            total_prompts_count = len([x for x in f_prompts_txt.read_text(encoding="utf-8", errors="ignore").splitlines() if x.strip() and not x.strip().startswith(("#", "//"))])
        except Exception:
            pass

    veo_dir = proy / "veo"
    veo_imgs = [x for x in veo_dir.iterdir() if x.is_file() and x.suffix.lower() in _FLOWBATCH_IMG_EXTS] if veo_dir.is_dir() else []
    veo_count = len(veo_imgs)

    tiene_guion = (proy / "guion.txt").is_file() or (proy / "dis_guion.txt").is_file()
    tiene_sinc = (proy / "sincronia.txt").is_file() and (proy / "sincronia.txt").stat().st_size > 0
    tiene_prompts = (
        tiene_prompts_txt
        or ((proy / "prompts_para_chat.txt").is_file() and (proy / "prompts_para_chat.txt").stat().st_size > 0)
        or ((proy / "imagen.txt").is_file() and (proy / "imagen.txt").stat().st_size > 0)
        or ((proy / "referencias.txt").is_file() and (proy / "referencias.txt").stat().st_size > 0)
    )

    if by_lang and not audio_fijo:
        order = {k: i for i, k in enumerate(MAPAS_LANGS)}
        langs_ord = sorted(by_lang.keys(), key=lambda x: order.get(x, 99))
        etq_idiomas = " · ".join(l.upper() for l in langs_ord)
        faltan_montar = []
        algun_desact = False
        videos_ok = []
        for lc in langs_ord:
            aud_l = by_lang[lc]
            cand_fin_l = finales_dir / f"{proy.name}_{lc.upper()}.mp4"
            cand_proy_l = proy / f"{proy.name}_{lc.upper()}.mp4"
            mp4_l = cand_fin_l if cand_fin_l.is_file() else cand_proy_l
            cfgs_l = []
            for d in dirs_insumos:
                for n in (f"mapa_{lc}.txt", f"mapa_{lc}.txt.txt", f"mapa_{lc}.json", "mapa.txt", "mapa.json"):
                    cand_p = d / n
                    if cand_p.is_file() and cand_p not in cfgs_l:
                        cfgs_l.append(cand_p)
            ins_l = [aud_l] + cfgs_l
            t_in = max((_mtime(x) for x in ins_l if x.exists()), default=0)
            if mp4_l.is_file():
                videos_ok.append(mp4_l)
                if _mtime(mp4_l) < t_in:
                    algun_desact = True
            else:
                faltan_montar.append(lc.upper())

        final_ok = videos_ok[0] if videos_ok else None
        falta = []
        if faltan_montar:
            falta.append("montar " + "/".join(faltan_montar))
        if algun_desact:
            falta.append("re-montar")

        if not faltan_montar and not algun_desact and videos_ok:
            estado = "montado"
        elif algun_desact or (videos_ok and faltan_montar):
            estado = "desactualizado"
        else:
            estado = "listo"
        cortes_str = f"Idiomas: {etq_idiomas}"
        hay_audio = True
    else:
        final_ok = final if final.is_file() else None
        insumos = [x for x in (audio, cfg_json) if x.exists()]
        entrada_max = max((_mtime(x) for x in insumos), default=0)
        desactualizado = bool(final_ok) and _mtime(final_ok) < entrada_max

        falta = []
        if not audio.exists():
            falta.append("audio (.mp3)")
        if audio.exists() and not tiene_sinc and not final_ok:
            falta.append("segmentar")
        if audio.exists() and not final_ok:
            falta.append("montar")
        if final_ok and desactualizado:
            falta.append("re-montar")

        if final_ok and desactualizado:
            estado = "desactualizado"
        elif final_ok:
            estado = "montado"
        elif audio.exists():
            estado = "listo"
        else:
            estado = "pendiente"
        cortes_str = "Satelital 9:16"
        hay_audio = audio.exists()

    publicado = (proy / MARCADOR).exists()
    if publicado:
        estado, falta = "publicado", []
    m = re.match(r"^(\d+)", nombre_mostrar)
    num = int(m.group(1)) if m else 999

    clips_vid, clips_img = _escanear_medios_universal(proy)
    n_v, n_i = len(clips_vid), len(clips_img)
    clips_etq = f"{pines_count} pines ({n_v}v+{n_i}i)" if (n_v or n_i) else f"{pines_count} pines"

    return {
        "nombre": nombre_mostrar,
        "ruta": str(proy.resolve()).replace("\\", "/"),
        "num": num,
        "estado": estado,
        "falta": falta,
        "clips": clips_etq,
        "cortes": cortes_str,
        "veo_img": n_i,
        "veo_count": veo_count,
        "tiene_prompts_txt": tiene_prompts_txt,
        "prompts_count": total_prompts_count,
        "titulo": titulo,
        "publicado": publicado,
        "montable": hay_audio and not publicado,
        "tiene_guion": tiene_guion,
        "tiene_sinc": tiene_sinc,
        "tiene_prompts": tiene_prompts,
        "video_final": str(final_ok.resolve()) if final_ok else "",
        "job": _job_serial(str(proy.resolve())),
        "t_creacion": _creacion_time(proy),
        "fecha": _fecha_str(proy),
    }


def escanear_mapas(nicho):
    raiz = Path(nicho["raiz"])
    estudio = nicho.get("estudio")
    finales_dir = raiz / nicho.get("finales", "_VIDEOS FINALES")
    finales_dir.mkdir(parents=True, exist_ok=True)
    base = {
        "nicho": "mapas",
        "nombre": nicho["nombre"],
        "raiz": str(raiz),
        "estudio": str(estudio.resolve()) if estudio and Path(estudio).exists() else "",
        "finales_dir": str(finales_dir.resolve()).replace("\\", "/"),
        "montaje_activo": montaje_activo(),
        "configurado": True,
    }
    if not raiz.is_dir():
        return {**base, "filas": []}
    filas = []
    # 1. Subcarpetas de episodios
    for d in raiz.iterdir():
        if d.is_dir() and not d.name.startswith(("_", ".")):
            filas.append(fila_mapas(d, nicho))
    # 2. Si hay audios .mp3 directamente en la carpeta raiz (como "guion comida.mp3")
    for mp3 in sorted(raiz.glob("*.mp3")):
        if not mp3.name.startswith("_"):
            filas.append(fila_mapas(raiz, nicho, audio_fijo=mp3))
    # Ordenar por fecha de creacion descendente (los creados al ultimo primero)
    filas.sort(key=lambda f: (f["publicado"], -f.get("t_creacion", 0), f["nombre"].lower()))
    return {**base, "filas": filas}



# --------------------------------------------------------------- deteccion finanzas
def fila_finanzas(proy: Path, nicho: dict):
    """Estado de un proyecto de Finanzas: detecta medios en grok, veo, imagen o proy."""
    var = proy / nicho.get("variante", "grok")
    clips_vid, clips_img = _escanear_medios_universal(proy)
    n_v = len(clips_vid)
    n_i = len(clips_img)
    total_medios = n_v + n_i

    audio = var / "aud.mp3" if (var / "aud.mp3").is_file() else (proy / "aud.mp3")
    if not audio.is_file():
        cands_aud = [x for x in proy.rglob("*") if x.is_file() and x.suffix.lower() in AUDIO_EXTS and "cortes" not in x.parts and "_limpio" not in x.stem.lower()]
        if cands_aud: audio = cands_aud[0]

    sincronia = var / "sincronia.txt" if (var / "sincronia.txt").is_file() else (proy / "sincronia.txt")
    titulo = _leer_titulo(sincronia)
    final = proy / f"{proy.name}.mp4"
    final = final if final.is_file() else None

    insumos = [audio, sincronia] + clips_vid + clips_img
    entrada_max = max((_mtime(x) for x in insumos if x.exists()), default=0)
    desactualizado = bool(final) and _mtime(final) < entrada_max

    falta = []
    if not audio.exists():     falta.append("audio")
    if not total_medios:       falta.append("clips/imágenes")
    if not sincronia.exists(): falta.append("sincronía")
    elif not titulo:           falta.append("título")
    if audio.exists() and total_medios and not final: falta.append("montar")
    if final and desactualizado:               falta.append("re-montar")

    if final and desactualizado: estado = "desactualizado"
    elif final:                  estado = "montado"
    elif audio.exists() and total_medios: estado = "listo"
    else:                        estado = "pendiente"

    publicado = (proy / MARCADOR).exists()
    if publicado:
        estado = "publicado"; falta = []
    m = re.match(r"^(\d+)", proy.name); num = int(m.group(1)) if m else 0

    etq_clips = f"{n_v}v+{n_i}i" if n_i else n_v

    return {
        "nombre": proy.name,
        "ruta": str(proy.resolve()),
        "num": num, "estado": estado, "falta": falta,
        "clips": etq_clips, "cortes": 0, "veo_img": n_i,
        "titulo": titulo, "publicado": publicado,
        "montable": audio.exists() and bool(total_medios) and not publicado,
        "job": _job_serial(str(proy.resolve())),
        "t_creacion": _creacion_time(proy),
        "fecha": _fecha_str(proy),
    }


def escanear_finanzas(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "finanzas", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    var = nicho.get("variante", "grok")
    filas = [fila_finanzas(d, nicho) for d in raiz.iterdir()
             if d.is_dir() and (d / var).is_dir()]     # solo carpetas con grok/
    filas.sort(key=lambda f: (f["publicado"], -f.get("t_creacion", 0), -f["num"], f["nombre"].lower()))
    return {**base, "filas": filas}


# --------------------------------------------------------------- deteccion desastres
def fila_desastres(proy: Path, nicho: dict):
    """Estado de un proyecto de Desastres: detecta medios en grok, veo, imagen o proy."""
    var = proy / nicho.get("variante", "grok")
    clips_vid, clips_img = _escanear_medios_universal(proy)
    n_v = len(clips_vid)
    n_i = len(clips_img)
    total_medios = n_v + n_i

    audio = var / "aud.mp3" if (var / "aud.mp3").is_file() else (proy / "aud.mp3")
    if not audio.is_file():
        cands_aud = [x for x in proy.rglob("*") if x.is_file() and x.suffix.lower() in AUDIO_EXTS and "cortes" not in x.parts and "_limpio" not in x.stem.lower()]
        if cands_aud: audio = cands_aud[0]

    sincronia = var / "sincronia.txt" if (var / "sincronia.txt").is_file() else (proy / "sincronia.txt")
    titulo = _leer_titulo(sincronia)
    final = proy / f"{proy.name}.mp4"
    final = final if final.is_file() else None

    insumos = [audio, sincronia] + clips_vid + clips_img
    entrada_max = max((_mtime(x) for x in insumos if x.exists()), default=0)
    desactualizado = bool(final) and _mtime(final) < entrada_max

    falta = []
    if not audio.exists():     falta.append("audio")
    if not sincronia.exists(): falta.append("sincronía")
    elif not titulo:           falta.append("título")
    if audio.exists() and sincronia.exists() and not final: falta.append("montar")
    if final and desactualizado:                            falta.append("re-montar")

    if final and desactualizado: estado = "desactualizado"
    elif final:                  estado = "montado"
    elif audio.exists() and sincronia.exists(): estado = "listo"
    else:                        estado = "pendiente"

    publicado = (proy / MARCADOR).exists()
    if publicado:
        estado = "publicado"; falta = []
    m = re.match(r"^(\d+)", proy.name); num = int(m.group(1)) if m else 0

    etq_clips = f"{n_v}v+{n_i}i" if n_i else n_v

    return {
        "nombre": proy.name,
        "ruta": str(proy.resolve()),
        "num": num, "estado": estado, "falta": falta,
        "clips": etq_clips, "cortes": 0, "veo_img": n_i,
        "titulo": titulo, "publicado": publicado,
        "montable": audio.exists() and sincronia.exists() and not publicado,
        "job": _job_serial(str(proy.resolve())),
        "t_creacion": _creacion_time(proy),
        "fecha": _fecha_str(proy),
    }


def escanear_desastres(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "desastres", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    var = nicho.get("variante", "grok")
    filas = [fila_desastres(d, nicho) for d in raiz.iterdir()
             if d.is_dir() and (d / var).is_dir()]
    filas.sort(key=lambda f: (f["publicado"], -f.get("t_creacion", 0), -f["num"], f["nombre"].lower()))
    return {**base, "filas": filas}


# --------------------------------------------------------------- deteccion novelas
def fila_novelas(proy: Path, nicho: dict):
    """Estado de una novela: <proy>/grok con clips (cada uno con su voz). NO usa
    aud.mp3 ni sincronia.txt: el montaje recorta la cola muerta de cada clip y
    los une. El video final vive en <raiz>/_VIDEOS FINALES/<carpeta>.mp4."""
    var = proy / nicho.get("variante", "grok")
    clips = [x for x in var.glob("*.mp4")
             if re.match(r"^\d", x.name) and not x.name.upper().startswith("FINAL")] if var.is_dir() else []
    cortes_dir = var / "cortes"
    cortes = list(cortes_dir.glob("[0-9][0-9]_*.mp4")) if cortes_dir.is_dir() else []
    finales_dir = Path(nicho["raiz"]) / nicho.get("finales", "_VIDEOS FINALES")
    final = finales_dir / f"{proy.name}.mp4"
    final = final if final.is_file() else None

    entrada_max = max((_mtime(x) for x in clips), default=0)
    desactualizado = bool(final) and _mtime(final) < entrada_max

    falta = []
    if not clips:
        falta.append("clips")
    if clips and not final:
        falta.append("montar")
    if final and desactualizado:
        falta.append("re-montar")

    if final and desactualizado:
        estado = "desactualizado"
    elif final:
        estado = "montado"
    elif clips:
        estado = "listo"
    else:
        estado = "pendiente"

    publicado = var.is_dir() and (var / MARCADOR).exists()
    if publicado:
        estado = "publicado"
        falta = []
    m = re.match(r"^(\d+)", proy.name)
    num = int(m.group(1)) if m else 0

    sinc_cand = None
    for cand in (var / "sincronia.txt", proy / "sincronia.txt"):
        if cand.is_file():
            sinc_cand = cand
            break
    titulo = _leer_titulo(sinc_cand) if sinc_cand else None

    return {
        "nombre": proy.name,
        "ruta": str(var.resolve()),        # la carpeta grok (la que se monta)
        "num": num, "estado": estado, "falta": falta,
        "clips": len(clips), "cortes": len(cortes), "veo_img": 0,
        "titulo": titulo, "publicado": publicado,
        "montable": bool(clips) and not publicado,
        "job": _job_serial(str(var.resolve())),
        "t_creacion": _creacion_time(proy),
        "fecha": _fecha_str(proy),
    }


def escanear_novelas(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "novelas", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    filas = [fila_novelas(d, nicho) for d in raiz.iterdir()
             if d.is_dir() and re.match(r"^\d", d.name)]
    filas.sort(key=lambda f: (f["publicado"], -f.get("t_creacion", 0), -f["num"], f["nombre"].lower()))
    return {**base, "filas": filas}


# --------------------------------------------------------------- deteccion ecos
def fila_ecos(proy: Path, nicho: dict):
    """Estado de un guion de Ecos: detecta clips de video + imagenes + audio en cualquier carpeta -> cortes."""
    clips_vid, clips_img = _escanear_medios_universal(proy)

    # Audio en raiz o subcarpetas
    audios = [x for x in proy.rglob("*")
              if x.is_file() and x.suffix.lower() in AUDIO_EXTS
              and "cortes" not in x.parts
              and "_limpio" not in x.stem.lower()
              and "_fluido" not in x.stem.lower()]

    cortes_dir = proy / "cortes"
    if not cortes_dir.is_dir():
        cand = [d for d in proy.rglob("cortes") if d.is_dir()]
        cortes_dir = cand[0] if cand else (proy / "cortes")
    cortes = list(cortes_dir.glob("[0-9][0-9]_*.mp4")) if cortes_dir.is_dir() else []
    limpio = bool(list(cortes_dir.glob("*_limpio.mp3"))) if cortes_dir.is_dir() else False

    tiene_guion = (proy / "guion.txt").is_file() or (proy / "dis_guion.txt").is_file()
    tiene_sinc = (proy / "sincronia.txt").is_file() and (proy / "sincronia.txt").stat().st_size > 0
    tiene_img = (proy / "imagen.txt").is_file() and (proy / "imagen.txt").stat().st_size > 0

    n_v = len(clips_vid)
    n_i = len(clips_img)
    total_tomas = n_v + n_i

    # Detección de proyecto motion graphics / código / diagramas didácticos
    es_motion = False
    for p_cfg in [proy / "config_nicho.json", proy.parent / "config_nicho.json"]:
        if p_cfg.is_file():
            try:
                c_data = json.loads(p_cfg.read_text(encoding="utf-8"))
                if c_data.get("requiere_imagenes") is False and c_data.get("requiere_videos") is False:
                    es_motion = True
                elif c_data.get("tipo_produccion") in ("codigo_motion", "motion", "animacion_codigo", "diagramas", "motion_graphics"):
                    es_motion = True
                elif c_data.get("modo_montaje") in ("motion_graphics", "codigo"):
                    es_motion = True
                elif "motion" in str(c_data.get("estilo_visual", "")).lower() or "infografía animada" in str(c_data.get("estilo_visual", "")).lower():
                    es_motion = True
                if es_motion:
                    break
            except Exception:
                pass

    # Desglose detallado de clips: videos + imagenes
    if n_i:
        etq_clips = f"{n_v}v+{n_i}i"
    elif n_v:
        etq_clips = f"{n_v}v"
    elif es_motion:
        etq_clips = "Motion"
    else:
        etq_clips = 0

    tiene_ref = (proy / "referencias.txt").is_file() and (proy / "referencias.txt").stat().st_size > 0
    tiene_seo = (proy / "seo.txt").is_file() and (proy / "seo.txt").stat().st_size > 0

    falta = []
    if not audios:
        falta.append("audio")
    if tiene_guion and not tiene_sinc:
        falta.append("sincronia")
    if tiene_guion and tiene_sinc and not tiene_img and not es_motion:
        falta.append("prompts")
    if not total_tomas and not es_motion:
        falta.append("clips/imágenes")

    if cortes:
        estado = "cortado"
    elif not falta:
        estado = "listo"
    else:
        estado = "pendiente"

    num = int(re.match(r"^(\d+)", proy.name).group(1)) if re.match(r"^(\d+)", proy.name) else 0

    video_sub = cortes_dir / "video_subtitulado.mp4"
    video_completo = video_sub if video_sub.is_file() else (cortes_dir / "video_completo.mp4")
    if not video_completo.is_file():
        video_completo = proy / "video.mp4" if (proy / "video.mp4").is_file() else None

    return {
        "ruta": str(proy.resolve()),
        "nombre": proy.name,
        "num": num,
        "clips": etq_clips,
        "n_videos": n_v,
        "n_imagenes": n_i,
        "total_tomas": total_tomas,
        "cortes": len(cortes),
        "n_cortes": len(cortes),
        "limpio": limpio,
        "fecha": _fecha_str(proy),
        "t_creacion": _creacion_time(proy),
        "falta": falta,
        "estado": estado,
        "tiene_guion": tiene_guion,
        "tiene_sinc": tiene_sinc,
        "tiene_img": tiene_img,
        "tiene_ref": tiene_ref,
        "tiene_seo": tiene_seo,
        "tiene_prompts": bool(tiene_img or tiene_ref or (proy / "prompts.txt").is_file() or (proy / "prompts_para_chat.txt").is_file()),
        "tiene_movimiento": (proy / "movimiento.txt").is_file() and (proy / "movimiento.txt").stat().st_size > 0,
        "tiene_video": bool(video_completo),
        "tiene_sub": video_sub.is_file(),
        "video_completo": str(video_completo.resolve()) if video_completo else "",
        "cortable": (total_tomas > 0 or es_motion) and bool(audios),
        "job": _job_serial(str(proy.resolve())),
    }


def escanear_ecos(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "ecos", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    filas = [fila_ecos(d, nicho) for d in raiz.iterdir()
             if d.is_dir() and re.match(r"^\d", d.name)]
    filas.sort(key=lambda f: (-f.get("t_creacion", 0), f["num"], f["nombre"].lower()))
    return {**base, "filas": filas}


# ------------------------------------------------------------ deteccion ebooks
EBOOK_IMG_EXT = (".jpg", ".jpeg", ".png", ".webp")
EBOOK_POR_HISTORIA = 6


def fila_ebook(d: Path, nicho: dict):
    """Estado de un libro: guiones.md (historias) + veo/ (imagenes) -> PDF."""
    md = d / "guiones.md"
    if not md.is_file():
        cand = sorted(d.glob("*.md"))
        md = cand[0] if cand else None
    historias, t_fuente = 0, 0.0
    if md and md.is_file():
        txt = md.read_text(encoding="utf-8", errors="replace")
        historias = len(re.findall(r"^\**\s*P1\s*[\.\):]", txt, re.M))
        t_fuente = max(t_fuente, _mtime(md) or 0)
    imgs = 0
    for nom in ("veo", "imagenes", "imágenes"):
        v = d / nom
        if v.is_dir():
            for f in v.iterdir():
                if f.suffix.lower() in EBOOK_IMG_EXT and re.match(r"^\d", f.stem):
                    imgs += 1
                    t_fuente = max(t_fuente, _mtime(f) or 0)
            break
    need = historias * EBOOK_POR_HISTORIA
    salida = d / "salida"
    pdfs = sorted(salida.glob("*.pdf"), key=lambda x: x.stat().st_mtime) if salida.is_dir() else []
    pdf = pdfs[-1] if pdfs else None
    falta = []
    if not historias:
        falta.append("guiones")
    if imgs < max(need, 1):
        falta.append("imágenes (%d/%d)" % (imgs, need) if need else "imágenes")
    if falta:
        estado = "pendiente"
    elif pdf and (_mtime(pdf) or 0) >= t_fuente:
        estado = "generado"
    elif pdf:
        estado = "desactualizado"
    else:
        estado = "listo"
    return {
        "nombre": d.name, "ruta": str(d.resolve()),
        "t_creacion": _creacion_time(d),
        "fecha": _fecha_str(d),
        "estado": estado, "falta": falta,
        "historias": historias, "imagenes": imgs,
        "paginas": (4 + 2 * historias) if historias else 0,
        "guion": str(md.resolve()) if md else "",
        "pdf": str(pdf.resolve()) if pdf else "",
        "generable": not falta,
        "job": _job_serial(str(d.resolve())),
    }


def escanear_ebook(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "ebook", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    filas = [fila_ebook(d, nicho) for d in raiz.iterdir()
             if d.is_dir() and not d.name.startswith(("_", "."))]
    filas.sort(key=lambda f: (-f.get("t_creacion", 0), f["nombre"].lower()))
    return {**base, "filas": filas}


def lanzar_generar_ebook(nicho: dict, ruta: str):
    libro = Path(ruta).resolve()
    if not _dentro_de_nicho(libro) or not libro.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / nicho["script"]
    if not script.is_file():
        return False, f"no encuentro {nicho['script']}"
    return lanzar_proceso(str(libro), [sys.executable, str(script), str(libro)])


def crear_libro_ebook(nicho: dict, nombre: str):
    """Crea la carpeta de un libro nuevo con sus plantillas (guiones.md vacio)."""
    limpio = re.sub(r'[\\/:*?"<>|]', "", nombre or "").strip()
    if not limpio:
        return False, "escribe un nombre válido", ""
    raiz = Path(nicho["raiz"])
    d = raiz / limpio
    if d.exists():
        return False, "ya existe un libro con ese nombre", ""
    (d / "veo").mkdir(parents=True)
    (d / "libro.txt").write_text(
        "titulo: %s\nsubtitulo: Relatos con final para leer a todo color y colorear a tu manera\n"
        "marca: Ecos del Alma\nvolumen: 1\n" % limpio, encoding="utf-8")
    (d / "guiones.md").write_text(
        "Pega aquí las historias que te dio el chat, con el formato de\n"
        "INSTRUCCION MAESTRA EBOOK v1.md (un encabezado # por historia, P1..P6 y 'Llévalo a tu día').\n"
        "Mete las imágenes en la carpeta veo numeradas 001, 002, 003... (6 por historia, en orden).\n",
        encoding="utf-8")
    return True, "creado", str(d.resolve())


def es_audio_ingles(nombre_archivo: str) -> bool:
    """Detecta si un archivo de audio corresponde a la versión en inglés."""
    stem = Path(nombre_archivo).stem.lower().strip()
    if any(k in stem for k in ["eng", "english", "_en", "-en", "(en)"]):
        return True
    starters = (
        "the ", "she ", "he ", "why ", "what ", "how ", "did ", "in ", "today ",
        "before ", "after ", "was ", "were ", "actresses ", "actors ", "hollywood ",
        "constant", "three ", "a wild ", "a false ", "she's ", "he's ", "_they ",
        "marvel sells"
    )
    return any(stem.startswith(s) for s in starters)


def fila_famoso(d: Path):
    """Estado de un famoso: sus videos fuente, sus audios (guiones), versiones de idioma y videos producidos."""
    audios = [x.name for x in sorted(d.iterdir())
              if x.is_file() and x.suffix.lower() in AUDIO_EXTS
              and "_fluido" not in x.stem.lower()
              and not x.stem.lower().endswith("_recortado")]

    # Identificar videos finales producidos
    aud_stems = {Path(a).stem.lower() for a in audios}
    nombres_finales = {f"{d.name.lower()}.mp4"} | {f"{d.name.lower()}_{s}.mp4" for s in aud_stems}

    finales = []
    video_completo = None
    for f in sorted(d.glob("*.mp4")):
        es_version = f.stem.lower().startswith(f"{d.name.lower()}_v") and f.suffix.lower() == ".mp4"
        if f.name.lower() in nombres_finales or es_version:
            v_obj = {
                "nombre": f.name,
                "tam_mb": round(f.stat().st_size / (1024 * 1024), 1),
                "mtime": _fecha_str(f),
                "ruta": str(f.resolve()),
            }
            finales.append(v_obj)
            if not video_completo:
                video_completo = str(f.resolve())

    # Audios clasificados por idioma (Español primero por flujo de trabajo)
    audios_info = []
    finales_nombres = {vf["nombre"].lower() for vf in finales}
    for a in audios:
        es_en = es_audio_ingles(a)
        a_stem = Path(a).stem.lower()
        # Verificar si este audio en particular ya tiene su video montado
        tiene_video = any(vf["nombre"].lower() in (f"{d.name.lower()}.mp4", f"{d.name.lower()}_{a_stem}.mp4") for vf in finales)
        etq = f"🇺🇸 Inglés ({a})" if es_en else f"🇪🇸 Español ({a})"
        if tiene_video:
            etq += " ✓"
        audios_info.append({
            "archivo": a,
            "idioma": "en" if es_en else "es",
            "etiqueta": etq,
            "ya_generado": tiene_video,
        })

    # Ordenar audios para que Español quede primero por defecto
    audios_info.sort(key=lambda x: (0 if x["idioma"] == "es" else 1, x["archivo"].lower()))

    tiene_ingles = any(x["idioma"] == "en" for x in audios_info)
    tiene_espanol = any(x["idioma"] == "es" for x in audios_info)

    videos = [x for x in d.iterdir() if x.is_file() and x.suffix.lower() in VIDEO_EXTS
              and x.name.lower() not in finales_nombres
              and not x.name.startswith(".")]

    cortes_dir = d / "cortes"
    num_cortes = len([x for x in cortes_dir.glob("*.mp4") if not x.name.startswith("video_")]) if cortes_dir.is_dir() else 0

    capcut_dir = d / "clips_capcut"
    num_capcut = len([x for x in capcut_dir.glob("*.mp4")]) if capcut_dir.is_dir() else 0
    guia_capcut = (capcut_dir / "GUIA_MONTAJE_CAPCUT.txt").exists() if capcut_dir.is_dir() else False

    selecciones = sorted(x.name for x in d.iterdir()
                         if x.is_dir() and x.name.lower().startswith("seleccion"))
    indexado = (d / "_biblioteca.json").exists()

    falta = []
    if not videos:
        falta.append("videos fuente")
    if not audios:
        falta.append("audio (.mp3)")

    if finales:
        estado = "montado"
    elif not falta:
        estado = "listo"
    else:
        estado = "pendiente"

    return {
        "nombre": d.name,
        "ruta": str(d.resolve()),
        "t_creacion": _creacion_time(d),
        "fecha": _fecha_str(d),
        "videos": len(videos),
        "audios": [x["archivo"] for x in audios_info],
        "audios_info": audios_info,
        "tiene_ingles": tiene_ingles,
        "tiene_espanol": tiene_espanol,
        "cortes": num_cortes,
        "clips_capcut": num_capcut,
        "guia_capcut": guia_capcut,
        "video_completo": video_completo,
        "finales": finales,
        "falta": falta,
        "estado": estado,
        "selecciones": selecciones,
        "indexado": indexado,
        "job": _job_serial(str(d.resolve())),
    }


def escanear_famosos(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "famosos", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    filas = [fila_famoso(d) for d in sorted(raiz.iterdir())
             if d.is_dir() and not d.name.startswith("_")]
    filas.sort(key=lambda f: (-f.get("t_creacion", 0), f["nombre"].lower()))
    return {**base, "filas": filas}


# --------------------------------------------------------------- deteccion peliculas
# narraciones del modelo nuevo: 1 largo + 2 anzuelos (nombre -> sufijo de salida)
NARRS_PEL = [("largo", ""), ("P1", "_P1"), ("P2", "_P2")]


def fila_pelicula(proy: Path):
    """Estado de un recap con el modelo 1 largo + 2 anzuelos: fuente + (largo/P1/P2)
    -> por cada narracion, su <nombre>_sync.json y su video _SIN_SUBS."""
    def hallar(exts, excl=None):
        for x in sorted(proy.iterdir()):
            if x.is_file() and x.suffix.lower() in exts:
                if excl and x.stem.upper().endswith(excl):
                    continue
                return x
        return None

    def audio_llamado(nombre):
        for e in AUDIO_EXTS:
            p = proy / f"{nombre}{e}"
            if p.exists():
                return p
        return None

    fuente = hallar(VIDEO_EXTS, excl="_SIN_SUBS")
    # transcripcion de la FUENTE (para pasarla a Claude: chino -> es + guion + mapa)
    trans = bool(fuente and (fuente.with_suffix(".txt").exists()
                             or fuente.with_suffix(".srt").exists()))

    # narraciones conocidas; si no hay ninguna, cae al 1er audio suelto como 'largo'
    narrs = [(n, s, a) for n, s in NARRS_PEL if (a := audio_llamado(n))]
    if not narrs:
        a = hallar(AUDIO_EXTS)
        if a:
            narrs.append(("largo", "", a))          # compat: audio suelto = largo

    videos, algun_desact = [], False
    for nombre, suf, a in narrs:
        final = proy / f"{proy.name}{suf}_SIN_SUBS.mp4"
        sync = proy / f"{nombre}_sync.json"
        montado = final.is_file()
        ins = [x for x in (fuente, a, sync if sync.exists() else None) if x]
        desact = montado and _mtime(final) < max((_mtime(x) for x in ins), default=0)
        algun_desact = algun_desact or desact
        videos.append({"nombre": nombre, "sync": sync.exists(),
                       "montado": montado, "desactualizado": desact})

    hay_audio = bool(narrs)
    todos_ok = hay_audio and all(v["montado"] and not v["desactualizado"] for v in videos)

    if not fuente:
        estado = "pendiente"
    elif not hay_audio:
        estado = "transcrito" if trans else "sin_transcribir"
    elif todos_ok:
        estado = "montado"
    elif algun_desact:
        estado = "desactualizado"
    else:
        estado = "listo"

    falta = []
    if not fuente:
        falta.append("fuente")
    elif not hay_audio and not trans:
        falta.append("transcribir")
    if fuente and not hay_audio:
        falta.append("guión + audio (TTS)")
    pend = [v["nombre"] for v in videos if not v["montado"]]
    if fuente and hay_audio and pend:
        falta.append("montar " + "/".join(pend))
    if algun_desact:
        falta.append("re-montar")

    publicado = (proy / MARCADOR).exists()
    if publicado:
        estado, falta = "publicado", []

    return {
        "nombre": proy.name,
        "ruta": str(proy.resolve()),
        "t_creacion": _creacion_time(proy),
        "fecha": _fecha_str(proy),
        "estado": estado,
        "falta": falta,
        "fuente": fuente.name if fuente else None,
        "voz": ", ".join(v["nombre"] for v in videos) if videos else None,
        "videos": videos,
        "transcrito": trans,
        "transcribible": bool(fuente) and not publicado,
        "plan": any((proy / f"plan_{v['nombre']}.json").exists() for v in videos)
                or (proy / "plan.json").exists(),
        "publicado": publicado,
        "montable": bool(fuente) and hay_audio and not publicado,
        "job": _job_serial(str(proy.resolve())),
    }


def escanear_peliculas(nicho):
    raiz = Path(nicho["raiz"])
    base = {"nicho": "peliculas", "nombre": nicho["nombre"], "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}
    filas = [fila_pelicula(d) for d in sorted(raiz.iterdir())
             if d.is_dir() and not d.name.startswith("_")]
    filas.sort(key=lambda f: (f["publicado"], -f.get("t_creacion", 0), f["nombre"].lower()))
    return {**base, "filas": filas}


def lanzar_transcribir(nicho: dict, ruta: str, idioma: str = "zh"):
    """Transcribe el video FUENTE del recap (por defecto chino). Deja <fuente>.srt
    y <fuente>.txt junto al video, para pasar el texto a Claude (chino->es + parafraseo)."""
    proy = Path(ruta).resolve()
    if not _dentro_de_nicho(proy) or not proy.is_dir():
        return False, "ruta inválida"
    if (proy / MARCADOR).exists():
        return False, "carpeta marcada como publicada (bloqueada)"
    fuente = None
    for x in sorted(proy.iterdir()):
        if (x.is_file() and x.suffix.lower() in VIDEO_EXTS
                and not x.stem.upper().endswith("_SIN_SUBS")):
            fuente = x
            break
    if not fuente:
        return False, "no hay video fuente en la carpeta"
    script = Path(nicho.get("codigo", AQUI)) / "transcribir.py"
    if not script.is_file():
        return False, "no encuentro transcribir.py"
    args = [sys.executable, str(script), str(fuente), "--modelo", "small", "--idioma", idioma]
    return lanzar_proceso(str(proy), args)


# --------------------------------------------------------------- transcribir libre
# Herramienta general (cualquier nicho): apunta a una CARPETA con videos, eliges
# cuales (o todos) y deja el .txt/.srt junto a cada uno. Si combinas, junta todos
# los guiones en un unico _GUIONES.txt para analizar la estructura del contenido.
def _lote_script():
    """El transcribir_lote.py del hub (carga el modelo 1 vez y hace varios)."""
    for cand in (AQUI / "peliculas" / "transcribir_lote.py", AQUI / "transcribir_lote.py"):
        if cand.is_file():
            return cand
    return None


def _limpiar_ruta(txt: str) -> str:
    return (txt or "").strip().strip('"').strip("'")


def listar_videos(carpeta: str, recursivo: bool = True):
    """Lista los videos dentro de una carpeta (para elegir cuáles transcribir).
    Marca cuáles ya tienen su .txt. Universal: cualquier carpeta local."""
    base = Path(_limpiar_ruta(carpeta)).expanduser()
    try:
        base = base.resolve()
    except OSError:
        return None
    if not base.is_dir():
        return None
    it = base.rglob("*") if recursivo else base.iterdir()
    vids = []
    for x in sorted(it, key=lambda p: str(p).lower()):
        if x.is_file() and x.suffix.lower() in VIDEO_EXTS:
            vids.append({"ruta": str(x),
                         "nombre": str(x.relative_to(base)),
                         "txt": x.with_suffix(".txt").exists()})
        if len(vids) >= 800:            # tope de seguridad para carpetas enormes
            break
    return {"carpeta": str(base), "videos": vids, "recorte": len(vids) >= 800}


def listar_txts(carpeta: str):
    """Lista los .txt de una carpeta (no recursivo) para elegir el de guiones.
    Marca cuántos guiones «GUION: <n>» tiene cada uno (pista para no equivocarse)."""
    base = Path(_limpiar_ruta(carpeta)).expanduser()
    try:
        base = base.resolve()
    except OSError:
        return None
    if not base.is_dir():
        return None
    items = []
    for x in sorted(base.iterdir(), key=lambda p: str(p).lower()):
        if x.is_file() and x.suffix.lower() == ".txt":
            n = 0
            try:
                with open(x, encoding="utf-8-sig", errors="replace") as f:
                    for ln in f:
                        if re.match(r"^\s*GUION\s*:", ln, re.IGNORECASE):
                            n += 1
            except OSError:
                pass
            items.append({"ruta": str(x), "nombre": x.name, "guiones": n})
        if len(items) >= 300:
            break
    return {"carpeta": str(base), "txts": items}


def elegir_archivo_dialogo(inicio: str = "", tipo: str = "txt"):
    """Abre el diálogo nativo de Windows (proceso aparte) y devuelve la ruta
    elegida, o "" si se canceló / no hay Tk. tipo: 'txt', 'audio' o 'carpeta'."""
    script = AQUI / "ai33" / "elegir.py"
    if not script.is_file():
        return ""
    args = [sys.executable, str(script)]
    ini = _limpiar_ruta(inicio)
    if ini and Path(ini).is_dir():
        args.append(ini)
    if tipo == "audio":
        args.append("--audio")
    elif tipo == "carpeta":
        args.append("--carpeta")
    elif tipo == "video":
        args.append("--video")
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=600)
        return (r.stdout or "").strip()
    except Exception:
        return ""


def lanzar_transcribir_lote(carpeta: str, rutas, idioma="es", modelo="small", combinar=True):
    """Transcribe los videos seleccionados. Deja el .txt/.srt junto a cada uno y,
    si combinar y hay más de uno, un único <carpeta>/_GUIONES.txt con todos los
    guiones separados por 'GUION: <nombre>'."""
    files = []
    for r in (rutas or []):
        p = Path(_limpiar_ruta(r)).expanduser()
        try:
            p = p.resolve()
        except OSError:
            continue
        if p.is_file() and p.suffix.lower() in VIDEO_EXTS + AUDIO_EXTS:
            files.append(p)
    if not files:
        return False, "no seleccionaste videos válidos"
    script = _lote_script()
    if not script:
        return False, "no encuentro transcribir_lote.py"
    modelo = modelo if modelo in ("tiny", "base", "small", "medium", "large-v3") else "small"
    base = None
    if carpeta:
        b = Path(_limpiar_ruta(carpeta)).expanduser()
        base = b.resolve() if b.is_dir() else None
    destino = base or files[0].parent
    clave = str(destino)                 # un job por carpeta
    args = [sys.executable, str(script), "--idioma", idioma or "auto", "--modelo", modelo]
    if combinar and len(files) > 1:
        args += ["--combinar", str(destino / "_GUIONES.txt")]
    args += [str(f) for f in files]
    return lanzar_proceso(clave, args)


# --------------------------------------------------------------- lanzadores
def lanzar_montaje(nicho: dict, ruta: str, subs: str = None, sfx: str = None, estilo_preset: str = None):
    proy = Path(ruta).resolve()
    clave = str(proy)
    activo = montaje_activo()
    if activo and activo != clave:
        return False, "ya hay un proceso en curso; espera a que termine"
    if clave in JOBS and JOBS[clave]["estado"] in ("montando", "activo"):
        return False, "ya se está montando"
    if (proy / MARCADOR).exists():
        return False, "carpeta marcada como publicada (bloqueada)"
    if not _dentro_de_nicho(proy):
        return False, "ruta fuera del nicho"
    productor = Path(nicho.get("codigo", AQUI)) / nicho["productor"]
    if not productor.is_file():
        return False, f"no encuentro {nicho['productor']} en {productor.parent}"

    args = [sys.executable, str(productor), str(proy)]
    if nicho.get("tipo") == "mapas":
        if subs in ("0", "1"):
            args += ["--subtitulos", subs]
        if sfx in ("0", "1"):
            args += ["--sfx", sfx]
        if estilo_preset and estilo_preset != "auto":
            args += ["--preset", estilo_preset]
    else:
        cortes = proy / "cortes"
        if cortes.is_dir() and any(cortes.glob("[0-9][0-9]_*.mp4")):
            args.append("--saltar-cortes")          # re-monta rapido reusando los cortes

    log = collections.deque(maxlen=60)
    JOBS[clave] = {"estado": "montando", "log": log, "inicio": time.time()}
    # PYTHONUNBUFFERED: sin esto, los print() del hijo se quedan en el buffer
    # (stdout es una tuberia, no una consola) y el panel no muestra el avance
    # hasta que el proceso termina. Con esto, el progreso llega en vivo.
    entorno = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
               "PYTHONUNBUFFERED": "1", "PYTHONWARNINGS": "ignore",
               "HF_HUB_DISABLE_SYMLINKS_WARNING": "1",
               "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1"}
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace", env=entorno)
    JOBS[clave]["proc"] = proc

    def seguir():
        for linea in proc.stdout:
            linea = linea.rstrip()
            if linea and not _es_ruido_log(linea):
                log.append(linea)
        code = proc.wait()
        JOBS[clave]["estado"] = ("cancelado" if JOBS[clave].get("cancelado")
                                 else ("ok" if code == 0 else "error"))

    threading.Thread(target=seguir, daemon=True).start()
    return True, "montando"



def limpiar_texto_guion(lineas):
    """Limpia lineas de titulos, acotaciones y prefijos de personaje para el sintetizador TTS."""
    limpias = []
    for ln in lineas:
        s = ln.strip()
        if re.match(r"^\s*TITULO\s*:", s, re.IGNORECASE):
            continue
        if (s.startswith("[") and s.endswith("]")) or (s.startswith("(") and s.endswith(")")):
            continue
        s = re.sub(r"^\s*(narrador|voz\s+en\s+off|locutor|personaje\s*\d*)\s*:\s*", "", s, flags=re.IGNORECASE)
        s = re.sub(r"\[.*?\]", "", s)
        s = re.sub(r"\*\*(.*?)\*\*", r"\1", s)
        if s:
            limpias.append(s)
    return "\n".join(limpias).strip()


def extraer_locucion_de_dis_guion(dis_text: str) -> str:
    """Extrae únicamente el texto corrido que debe leer el locutor/TTS, eliminando encabezados técnicos y etiquetas [PIN X] (País)."""
    lineas = (dis_text or "").splitlines()
    narracion = []
    ignorar_palabras_clave = {"gancho", "pines", "cta", "modo: mundial", "modo: continental", "modo: nacional", "modo: regional"}
    for ln in lineas:
        s = ln.strip()
        if not s:
            continue
        if re.match(r"^\s*MODO\s*:", s, re.I) or re.match(r"^\s*GUION\s*:", s, re.I):
            continue
        if s.lower() in ignorar_palabras_clave:
            continue
        if re.match(r"^\s*\[PIN\s*\d+\](?:\s*\([^)]*\))?\s*$", s, re.I):
            continue
        s = re.sub(r"^\s*\[PIN\s*\d+\](?:\s*\([^)]*\))?\s*", "", s, flags=re.I)
        if s:
            narracion.append(s)
    texto_limpio = " ".join(narracion)
    return re.sub(r"\s{2,}", " ", texto_limpio).strip()


def parse_lote_dis_guiones(texto_dis: str) -> dict:
    """Parsea texto con bloques 'GUION: <nombre>' (y su MODO: previo si existe) para dis_guion.txt.
    Retorna diccionario indexado por nombre, número de guión y lista ordenada en '_lista_'."""
    if not texto_dis or not texto_dis.strip():
        return {}
    bloques = {}
    lineas = texto_dis.splitlines(True)
    m_indices = []
    for idx, ln in enumerate(lineas):
        m = re.match(r"^\s*GUION\s*:\s*(.+?)\s*$", ln.strip(), re.IGNORECASE)
        if m:
            nom = re.sub(r'[<>:"/\\|?*]+', "_", m.group(1).strip().strip("."))
            m_indices.append((idx, nom))

    if not m_indices:
        t_clean = texto_dis.strip()
        return {"_unico_": t_clean, "_lista_": [("01", t_clean)]}

    lista_items = []
    for i in range(len(m_indices)):
        idx_actual, nom_actual = m_indices[i]
        start_line = idx_actual
        if idx_actual > 0:
            prev_ln = lineas[idx_actual - 1].strip()
            if re.match(r"^\s*MODO\s*:", prev_ln, re.IGNORECASE):
                start_line = idx_actual - 1

        end_line = len(lineas)
        if i + 1 < len(m_indices):
            next_idx, _ = m_indices[i + 1]
            end_line = next_idx
            if next_idx > 0 and re.match(r"^\s*MODO\s*:", lineas[next_idx - 1].strip(), re.IGNORECASE):
                end_line = next_idx - 1

        contenido = "".join(lineas[start_line:end_line]).strip()
        bloques[nom_actual] = contenido
        m_num = re.match(r"^(\d+)", nom_actual)
        if m_num and m_num.group(1) != nom_actual:
            bloques[m_num.group(1)] = contenido
        lista_items.append((nom_actual, contenido))

    bloques["_lista_"] = lista_items
    return bloques
def parse_lote_guiones(texto: str):
    """Parsea texto con bloques 'GUION: <nombre>' seguido del texto del guion."""
    bloques = []
    lineas = (texto or "").splitlines()
    actual, cuerpo = None, []
    for ln in lineas:
        m = re.match(r"^\s*GUION\s*:\s*(.+?)\s*$", ln, re.IGNORECASE)
        if m:
            if actual is not None and cuerpo:
                t = limpiar_texto_guion(cuerpo)
                if t:
                    bloques.append((actual, t))
            nom = re.sub(r'[<>:"/\\|?*]+', "_", m.group(1).strip().strip("."))
            actual = nom or "sin_nombre"
            cuerpo = []
        elif actual is not None:
            cuerpo.append(ln)
    if actual is not None and cuerpo:
        t = limpiar_texto_guion(cuerpo)
        if t:
            bloques.append((actual, t))
    return bloques


def resolver_config_ai33(raiz_destino: Path = None, nicho: dict = None):
    """Resuelve la configuracion de voz de ai33 respetando de forma estricta e
    inquebrantable el aislamiento de nichos. NUNCA mezcla la voz de un nicho con otro."""
    candidatos = []
    r = None
    if raiz_destino:
        r = Path(raiz_destino).resolve()
        if r.is_file():
            r = r.parent

    # 1. Identificar con precision el nicho (nid)
    nid = ""
    nicho_usuario_especifico = None
    if nicho and isinstance(nicho, dict):
        nid = nicho.get("tipo") or nicho.get("id") or ""
        if str(nid).startswith("nicho_"):
            nicho_usuario_especifico = nicho

    if not nid and r:
        # A. Comparar contra nichos base del sistema
        for k, v in NICHOS.items():
            r_nicho = Path(v.get("raiz", "")).resolve()
            if r == r_nicho or r_nicho in r.parents or str(r_nicho).lower() in str(r).lower():
                nid = k
                break

        # B. Comparar contra nichos de usuario (SOLO el que coincida exactamente con la ruta)
        if not nid:
            try:
                from core.gestor_nichos import cargar_nichos_usuario
                for nu in cargar_nichos_usuario():
                    if nu.get("ruta"):
                        r_nu = Path(nu["ruta"]).resolve()
                        if r == r_nu or r_nu in r.parents:
                            nicho_usuario_especifico = nu
                            nid = nu.get("id", "")
                            break
            except Exception:
                pass

        # C. Respaldo por palabras clave en la ruta completa
        if not nid:
            s_low = str(r).lower()
            if "mapa" in s_low: nid = "mapas"
            elif "eco" in s_low or ("guiones" in s_low and "psico" not in s_low): nid = "ecos"
            elif "psico" in s_low: nid = "psicoscura"
            elif "famoso" in s_low: nid = "famosos"
            elif "pelicula" in s_low: nid = "peliculas"
            elif "finanza" in s_low: nid = "finanzas"

    # 2. Candidato 1: Buscar ai33_config.txt en el proyecto y hacia arriba hasta la raiz del nicho
    # Se detiene al llegar a Downloads, Desktop o la raiz del sistema para evitar colisiones
    if r:
        curr = r
        while True:
            c = curr / "ai33_config.txt"
            if c not in candidatos:
                candidatos.append(c)
            padre = curr.parent
            if padre == curr or curr.name.lower() in ("downloads", "descargas", "proyectos_video", "users", "usuario", "desktop", "escritorio"):
                break
            curr = padre

    # 3. Candidato 2: Archivo especializado del nicho en ai33/ (ai33_ecos.txt, ai33_mapas.txt, etc.)
    mapa_nid_archivos = {
        "ecos": "ai33_ecos.txt",
        "mapas": "ai33_mapas.txt",
        "psico": "ai33_psicoscura.txt",
        "psicoscura": "ai33_psicoscura.txt",
        "famosos": "ai33_famosos.txt",
        "peliculas": "ai33_peliculas.txt",
        "finanzas": "ai33_finanzas.txt",
        "reflexion": "ai33_reflexion.txt",
    }
    if nid in mapa_nid_archivos:
        cand_nicho = AQUI / "ai33" / mapa_nid_archivos[nid]
        if cand_nicho not in candidatos:
            candidatos.append(cand_nicho)
    elif nid and not str(nid).startswith("nicho_"):
        cand_nicho = AQUI / "ai33" / f"ai33_{nid}.txt"
        if cand_nicho not in candidatos:
            candidatos.append(cand_nicho)

    # 4. Candidato 3: Si es un nicho replicado del usuario, buscar UNICAMENTE en su propia carpeta
    if nicho_usuario_especifico and nicho_usuario_especifico.get("ruta"):
        cand_propio = Path(nicho_usuario_especifico["ruta"]).resolve() / "ai33_config.txt"
        if cand_propio not in candidatos:
            candidatos.append(cand_propio)

    # 5. Candidato 4 (ULTIMO RECURSO): ai33/ai33_config.txt central
    c_central = AQUI / "ai33" / "ai33_config.txt"
    if c_central not in candidatos:
        candidatos.append(c_central)

    cfg_encontrado = None
    ruta_encontrada = None
    try:
        sys.path.insert(0, str(AQUI / "ai33"))
        import tts
    except Exception:
        tts = None

    for cand in candidatos:
        if cand.is_file() and tts:
            try:
                c = tts.cargar_config(str(cand))
                api_key = (c.get("API_KEY") or "").strip().strip("'\"")
                if api_key and not api_key.startswith(("#", "PEGA_", "TU_")):
                    c["API_KEY"] = api_key
                    if c.get("VOICE_ID"):
                        c["VOICE_ID"] = c["VOICE_ID"].strip().strip("'\"")
                    if c.get("SPEED"):
                        c["SPEED"] = c["SPEED"].strip().strip("'\"")
                    cfg_encontrado = c
                    ruta_encontrada = cand
                    break
            except Exception:
                continue
    return cfg_encontrado, ruta_encontrada


def lanzar_crear_guiones_lote(nicho: dict, texto: str, gen_audio: bool = True, segmentar: bool = True, raiz_destino: Path = None, texto_dis_guion: str = None, gen_prompts: bool = True):
    # Deteccion inteligente de guiones con estructura de mapas virales ([PIN X], PINES o MODO:)
    es_texto_mapas = bool(re.search(r"\[PIN\s*\d+\]|^\s*PINES\b|^\s*MODO\s*:", texto or "", re.MULTILINE | re.IGNORECASE))
    es_dis_mapas = bool(re.search(r"\[PIN\s*\d+\]|^\s*PINES\b|^\s*MODO\s*:", texto_dis_guion or "", re.MULTILINE | re.IGNORECASE))

    if es_texto_mapas and not texto_dis_guion:
        # El usuario pego directamente la estructura completa de mapas en el campo principal
        texto_dis_guion = texto

    map_dis = parse_lote_dis_guiones(texto_dis_guion)
    bloques_voz = parse_lote_guiones(texto)

    # Validacion y emparejamiento inteligente entre Locucion y Distribucion
    if bloques_voz and map_dis:
        # Ambos casilleros estan presentes: verificar correspondencia
        nums_voz = [m.group(1) for b in bloques_voz if (m := re.match(r"^(\d+)", b[0]))]
        items_dis = map_dis.get("_lista_") or []
        nums_dis = [m.group(1) for item in items_dis if (m := re.match(r"^(\d+)", item[0]))]

        if nums_voz and nums_dis:
            set_voz = set(nums_voz)
            set_dis = set(nums_dis)
            # Si son completamente disjuntos (ej: voz 51..60 y dis 61..70)
            if not (set_voz & set_dis):
                return False, f"Los guiones de locución ({', '.join(nums_voz[:4])}...) no coinciden con los de distribución ({', '.join(nums_dis[:4])}...). Verifica ambos casilleros antes de generar."

        # Mantener los textos revisados o corregidos por el usuario en Box 1
        bloques = bloques_voz
    elif map_dis and not bloques_voz:
        # Solo se proveyo la distribucion: auto-extraer locucion limpia
        bloques = []
        items = map_dis.get("_lista_") or []
        for nom_item, dis_cont in items:
            loc = extraer_locucion_de_dis_guion(dis_cont)
            if loc:
                bloques.append((nom_item, loc))
        if not bloques and "_unico_" in map_dis:
            loc = extraer_locucion_de_dis_guion(map_dis["_unico_"])
            if loc:
                bloques.append(("01", loc))
    else:
        bloques = bloques_voz

    if not bloques:
        return False, "No se detectaron guiones validos. Usa el formato 'GUION: <nombre>\n<texto>' o pega la estructura con MODO y PINES."
    if raiz_destino and Path(raiz_destino).is_dir():
        raiz = Path(raiz_destino).resolve()
    else:
        raiz = Path(nicho.get("raiz", "")).resolve()
        if not raiz.is_dir():
            return False, f"La carpeta raiz no existe: {raiz}"

    clave = str(raiz)
    activo = montaje_activo()
    if activo and activo != clave:
        return False, "Ya hay un proceso activo; espera a que termine."

    import collections, shutil, subprocess
    log = collections.deque(maxlen=120)
    JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time()}

    def worker():
        sys.path.insert(0, str(AQUI / "ai33"))
        import tts

        plantilla_dir = raiz / "plantilla"
        if not plantilla_dir.is_dir() and (CARPETA_PROYECTOS / "plantilla").is_dir():
            plantilla_dir = CARPETA_PROYECTOS / "plantilla"

        log.append(f"Iniciando creacion de {len(bloques)} proyecto(s) en '{raiz.name}'...")
        cfg, ruta_cfg = resolver_config_ai33(raiz, nicho=nicho)
        prov_nom = "Voz IA"
        if cfg:
            tts_url = (cfg.get("TTS_URL") or "").lower()
            if "ai33" in tts_url:
                prov_nom = "ai33.pro"
            elif "elevenlabs" in tts_url:
                prov_nom = "ElevenLabs"
            elif "openai" in tts_url:
                prov_nom = "OpenAI"

        if gen_audio:
            if cfg and cfg.get("API_KEY"):
                log.append(f"Servicio de audio conectado: {prov_nom} (Voz: {cfg.get('VOICE_ID', 'default')})")
            else:
                log.append("[AVISO] No se encontro API de voz conectada; se crearan los proyectos solo con guion.txt.")
                log.append("  💡 Recomendacion: Para que los cortes salgan exactos se requiere aud.mp3. Puedes contratar ai33.pro (https://ai33.pro/?r=29922) o la API de tu preferencia.")
        else:
            log.append("Modo seleccionado: Solo guion (sin generacion de audio).")
            log.append("  💡 Recomendacion: Agrega aud.mp3 antes de cortar para una sincronizacion exacta.")

        # Calcular numeracion automatica si no traen numero
        existentes_num = []
        for d in raiz.iterdir():
            if d.is_dir():
                m = re.match(r"^(\d+)", d.name)
                if m:
                    existentes_num.append(int(m.group(1)))
        sig_num = (max(existentes_num) + 1) if existentes_num else 1

        total = len(bloques)
        for idx, (nombre, texto_guion) in enumerate(bloques, 1):
            if not re.match(r"^\d+", nombre):
                nombre_dir = f"{sig_num:02d}_{nombre}" if nombre != "sin_nombre" else f"{sig_num:02d}"
                sig_num += 1
            else:
                nombre_dir = nombre

            proy_dir = raiz / nombre_dir

            # PROTECCION ESENCIAL: Nunca sobreescribir ni re-segmentar proyectos que ya existan con audio o video montado
            if proy_dir.is_dir():
                tiene_video = any((proy_dir / vf).is_file() for vf in ("video_final.mp4", "final.mp4"))
                tiene_aud_real = (proy_dir / "aud.mp3").is_file() and (proy_dir / "aud.mp3").stat().st_size > 1000
                tiene_seg = (proy_dir / "sincronia.txt").is_file() or (proy_dir / "mapa.json").is_file()
                if tiene_video or (tiene_aud_real and tiene_seg):
                    log.append(f"[{idx}/{total}] [PROTEGIDO] '{nombre_dir}' ya existe con audio y sincronizacion previa. Se omite para no alterar videos publicados.")
                    continue

            log.append(f"[{idx}/{total}] Preparando '{nombre_dir}'...")
            if not proy_dir.exists():
                proy_dir.mkdir(parents=True, exist_ok=True)
                if plantilla_dir.is_dir():
                    # Copiar solo archivos de plantilla sin sobreescribir guion ni archivos que se generan con IA
                    for item in plantilla_dir.iterdir():
                        if item.is_file() and item.name.lower() not in ("guion.txt", "dis_guion.txt", "movimiento.txt", "imagen.txt", "referencias.txt", "seo.txt"):
                            shutil.copy2(item, proy_dir / item.name)
                    log.append(f"  -> Copiados archivos de plantilla a {nombre_dir}/")
                else:
                    log.append(f"  -> Creada carpeta {nombre_dir}/")

            # Estandarizar subcarpetas para imágenes y videos:
            # Para nichos personales del usuario (ecos / NUEVOS GUIONES) se mantiene veo/ y grok/
            # Para clientes y nichos replicados se estandariza a imagen/ y video/
            es_nicho_personal = ("nuevos guiones" in str(raiz).lower()) or ("ecos" in str(raiz).lower())
            sub_img = "veo" if es_nicho_personal else "imagen"
            sub_vid = "grok" if es_nicho_personal else "video"
            (proy_dir / sub_img).mkdir(parents=True, exist_ok=True)
            (proy_dir / sub_vid).mkdir(parents=True, exist_ok=True)

            # Heredar personajes maestros de la raíz del nicho si no tiene referencias.txt
            if not (proy_dir / "referencias.txt").is_file():
                for nom_ref_m in ("referencias_maestras.txt", "personajes_nicho.txt", "IDENTIDAD_PERSONAJES.txt"):
                    cand_ref = raiz / nom_ref_m
                    if not cand_ref.is_file():
                        cand_ref = raiz / "instrucciones" / nom_ref_m
                    if cand_ref.is_file():
                        try:
                            shutil.copy2(cand_ref, proy_dir / "referencias.txt")
                            log.append(f"  -> Heredados personajes maestros ({cand_ref.name}) a {nombre_dir}/referencias.txt")
                            break
                        except Exception:
                            pass

            guion_file = proy_dir / "guion.txt"
            guion_file.write_text(texto_guion, encoding="utf-8")
            log.append(f"  -> Guardado guion.txt ({len(texto_guion)} caracteres)")

            # dis_guion.txt copiado TAL CUAL (especifico de Mapas Virales o si fue provisto)
            dis_content = None
            if map_dis:
                dis_content = map_dis.get(nombre)
                if not dis_content:
                    m_n = re.match(r"^(\d+)", nombre)
                    if m_n:
                        dis_content = map_dis.get(m_n.group(1))
                if not dis_content:
                    # Emparejar por indice en _lista_ si los conteos coinciden
                    items_dis = map_dis.get("_lista_") or []
                    if idx - 1 < len(items_dis):
                        dis_content = items_dis[idx - 1][1]
                if not dis_content and len(bloques) == 1:
                    dis_content = map_dis.get("_unico_")

            if dis_content:
                dis_file = proy_dir / "dis_guion.txt"
                dis_file.write_text(dis_content, encoding="utf-8")
                log.append(f"  -> Guardado dis_guion.txt TAL CUAL ({len(dis_content)} caracteres)")
            elif plantilla_dir.is_dir() and (plantilla_dir / "dis_guion.txt").is_file():
                shutil.copy2(plantilla_dir / "dis_guion.txt", proy_dir / "dis_guion.txt")

            # Sintetizar audio
            if gen_audio and cfg and cfg.get("API_KEY"):
                aud_proy = proy_dir / "aud.mp3"
                if aud_proy.is_file() and aud_proy.stat().st_size > 1000:
                    log.append(f"  -> aud.mp3 ya existe en {nombre_dir}/")
                else:
                    voz_actual = cfg.get("VOICE_ID", "default")
                    log.append(f"  -> Generando audio con {prov_nom} (voz: {voz_actual})...")
                    try:
                        task_id, direct = tts.crear_tarea(cfg, texto_guion)
                        url = direct or tts.esperar_audio(cfg, task_id)
                        tts.descargar(url, str(aud_proy))
                        log.append(f"  [OK] Audio guardado en {nombre_dir}/aud.mp3")
                    except Exception as e:
                        log.append(f"  [ERROR] Fallo audio para {nombre_dir}: {e}")
            elif gen_audio:
                log.append(f"  [AVISO] {nombre_dir}: Sin API de voz configurada, se guardo solo guion.txt.")

            # Segmentacion
            if segmentar:
                aud_proy = proy_dir / "aud.mp3"
                tiene_audio_real = aud_proy.is_file() and aud_proy.stat().st_size > 1000
                es_mapas = (nicho.get("tipo") == "mapas") or ("mapas" in str(raiz).lower())
                if es_mapas:
                    script_seg = Path(nicho.get("codigo", AQUI / "mapas")) / "preparar_mapa.py"
                else:
                    script_seg = AQUI / "ecos" / "segmentar_guion.py"

                if script_seg.is_file() and guion_file.is_file():
                    if tiene_audio_real:
                        log.append(f"  -> Segmentando escenas sincronizadas con aud.mp3 ({nombre_dir})...")
                    else:
                        log.append(f"  -> [AVISO] {nombre_dir}: Segmentando SIN audio (tiempos estimados). Recomendado: añadir aud.mp3 para cortes exactos.")
                    try:
                        cmd = [sys.executable, str(script_seg), str(proy_dir)]
                        if es_mapas:
                            cmd.append("--forzar")
                        entorno_seg = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}
                        kw_seg = {"capture_output": True, "text": True, "encoding": "utf-8", "errors": "replace", "env": entorno_seg, "timeout": 120}
                        if sys.platform.startswith("win"):
                            kw_seg["creationflags"] = 0x08000000
                        res_sub = subprocess.run(cmd, **kw_seg)
                        if res_sub.returncode == 0:
                            log.append(f"  [OK] Segmentacion finalizada en {nombre_dir}/")
                        else:
                            err_msg = (res_sub.stderr or res_sub.stdout or "").strip()
                            log.append(f"  [AVISO] Fallo segmentacion en {nombre_dir}: {err_msg[:120]}")
                    except Exception as e:
                        log.append(f"  [AVISO] Fallo segmentacion en {nombre_dir}: {e}")

            # Generar prompts con Gemini IA (referencias.txt, imagen.txt, movimiento.txt)
            if gen_prompts and not es_mapas:
                sinc_f = proy_dir / "sincronia.txt"
                if not sinc_f.is_file() or sinc_f.stat().st_size == 0:
                    script_seg = AQUI / "ecos" / "segmentar_guion.py"
                    if script_seg.is_file() and guion_file.is_file():
                        kw_seg2 = {"capture_output": True, "timeout": 30}
                        if sys.platform.startswith("win"):
                            kw_seg2["creationflags"] = 0x08000000
                        subprocess.run([sys.executable, str(script_seg), str(proy_dir)], **kw_seg2)
                if sinc_f.is_file() and sinc_f.stat().st_size > 0:
                    log.append(f"  -> Generando referencias y escenas con Gemini IA ({nombre_dir})...")
                    try:
                        from core.generador_prompts_gemini import generar_prompts_para_proyecto
                        ok_p, msg_p, info_p = generar_prompts_para_proyecto(proy_dir, raiz)
                        if ok_p:
                            archs = []
                            if info_p.get("tiene_referencias"): archs.append("referencias.txt")
                            if info_p.get("tiene_imagen"): archs.append("imagen.txt")
                            if info_p.get("tiene_movimiento"): archs.append("movimiento.txt")
                            if info_p.get("tiene_seo"): archs.append("seo.txt")
                            log.append(f"  [OK] Prompts y SEO creados en {nombre_dir}/ ({', '.join(archs)})")
                        else:
                            log.append(f"  [AVISO] {nombre_dir}: No se generaron prompts: {msg_p}")
                    except Exception as ep:
                        log.append(f"  [AVISO] Error generando prompts para {nombre_dir}: {ep}")

        log.append(f"[COMPLETADO] Se crearon con exito {total} proyecto(s) en '{raiz.name}'.")
        JOBS[clave]["estado"] = "ok"

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    return True, f"Procesando lote de {len(bloques)} guiones..."


def lanzar_cortar_ecos(nicho: dict, ruta: str, limpiar: bool = True, subtitulos: bool = True, estilo_sub: str = None):
    grok = Path(ruta).resolve()
    if not _dentro_de_nicho(grok) or not grok.is_dir():
        return False, "ruta invalida"
    script = Path(nicho.get("codigo", AQUI / "ecos")) / nicho.get("script", "cortar_escenas.py")
    if not script.is_file():
        return False, f"no encuentro {script.name}"
    args = [sys.executable, str(script), str(grok)]
    if limpiar:
        args.append("--limpiar-silencios")
    if subtitulos:
        args.append("--subtitulos")
        if estilo_sub:
            args.extend(["--estilo-subtitulos", estilo_sub])
    else:
        args.append("--sin-subtitulos")
    return lanzar_proceso(str(grok), args)


def lanzar_segmentar_ecos(nicho: dict, ruta: str):
    p = Path(ruta).resolve()
    if not _dentro_de_nicho(p) or not p.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / "segmentar_guion.py"
    if not script.is_file():
        return False, "no encuentro segmentar_guion.py"
    args = [sys.executable, str(script), str(p)]
    return lanzar_proceso(str(p), args)


def lanzar_bloque_mapas(nicho: dict, ruta: str, bloque=1):
    proy = Path(ruta).resolve()
    clave = str(proy)
    activo = montaje_activo()
    if activo and activo != clave:
        return False, "ya hay un proceso en curso; espera a que termine"
    if clave in JOBS and JOBS[clave]["estado"] in ("montando", "activo"):
        return False, "ya se está procesando este video"
    if not _dentro_de_nicho(proy):
        return False, "ruta fuera del nicho"
    script = Path(nicho.get("codigo", AQUI)) / "productor_bloques_mapas.py"
    if not script.is_file():
        return False, f"no encuentro productor_bloques_mapas.py en {script.parent}"

    bloque_str = str(bloque).strip().lower()
    if bloque_str == "todos":
        args = [sys.executable, str(script), str(proy), "--todos"]
        desc = "Bloques modulares CapCut (B1+B2+B3)"
    elif bloque_str in ("1", "2", "3"):
        args = [sys.executable, str(script), str(proy), "--bloque", bloque_str]
        nombres = {"1": "Bloque 1 (Gancho)", "2": "Bloque 2 (Pines)", "3": "Bloque 3 (CTA)"}
        desc = nombres[bloque_str]
    else:
        return False, f"bloque inválido: {bloque}"

    log = collections.deque(maxlen=60)
    JOBS[clave] = {"estado": "montando", "log": log, "inicio": time.time()}
    entorno = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
               "PYTHONUNBUFFERED": "1", "PYTHONWARNINGS": "ignore",
               "HF_HUB_DISABLE_SYMLINKS_WARNING": "1",
               "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1"}
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace", env=entorno)
    JOBS[clave]["proc"] = proc

    def seguir():
        for linea in proc.stdout:
            linea = linea.rstrip()
            if linea and not _es_ruido_log(linea):
                log.append(linea)
        code = proc.wait()
        JOBS[clave]["estado"] = ("cancelado" if JOBS[clave].get("cancelado")
                                 else ("ok" if code == 0 else "error"))

    threading.Thread(target=seguir, daemon=True).start()
    return True, f"Renderizando {desc}..."


def lanzar_unir_ecos(nicho: dict, ruta: str):
    p = Path(ruta).resolve()
    if not _dentro_de_nicho(p) or not p.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / "segmentar_guion.py"
    if not script.is_file():
        return False, "no encuentro segmentar_guion.py"
    args = [sys.executable, str(script), str(p), "--unir"]
    return lanzar_proceso(str(p), args)


def lanzar_generar_prompts_proyecto(ruta: str, nicho_raiz: Path = None) -> tuple[bool, str]:
    p = Path(ruta).resolve()
    if not _dentro_de_nicho(p) or not p.is_dir():
        return False, "ruta inválida"
    clave = str(p)
    if clave in JOBS and JOBS[clave]["estado"] in ("montando", "activo"):
        return False, "ya se está procesando este proyecto"

    log = collections.deque(maxlen=60)
    JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time(), "linea": "Generando prompts con Gemini IA..."}

    def worker():
        try:
            log.append(f"[*] Iniciando generación de prompts con Gemini IA para {p.name}...")
            from core.generador_prompts_gemini import generar_prompts_para_proyecto
            ok, msg, info = generar_prompts_para_proyecto(p, nicho_raiz or p.parent)
            if ok:
                partes = []
                if info.get("tiene_referencias"): partes.append("referencias.txt")
                if info.get("tiene_imagen"): partes.append("imagen.txt")
                if info.get("tiene_movimiento"): partes.append("movimiento.txt")
                if info.get("tiene_seo"): partes.append("seo.txt")
                log.append(f"[OK] Archivos generados: {', '.join(partes)} con modelo {info.get('modelo', 'Gemini')}")
                JOBS[clave]["estado"] = "ok"
                JOBS[clave]["linea"] = "Prompts y SEO listos"
            else:
                log.append(f"[ERROR] {msg}")
                JOBS[clave]["estado"] = "error"
                JOBS[clave]["linea"] = f"Fallo prompts: {msg[:60]}"
        except Exception as e:
            log.append(f"[ERROR] Excepción: {e}")
            JOBS[clave]["estado"] = "error"
            JOBS[clave]["linea"] = f"Error: {str(e)[:60]}"

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    return True, f"Generando prompts y SEO para {p.name} en segundo plano..."


def lanzar_generar_seo_proyecto(ruta: str, nicho_raiz: Path = None) -> tuple[bool, str]:
    p = Path(ruta).resolve()
    if not _dentro_de_nicho(p) or not p.is_dir():
        return False, "ruta inválida"
    clave = str(p) + "_seo"
    if clave in JOBS and JOBS[clave]["estado"] in ("montando", "activo"):
        return False, "ya se está generando el SEO para este proyecto"

    log = collections.deque(maxlen=60)
    JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time(), "linea": "Generando paquete SEO con Gemini..."}

    def worker():
        try:
            log.append(f"[*] Analizando guión y generando SEO viral para {p.name}...")
            from core.generador_prompts_gemini import generar_seo_para_proyecto
            ok, msg, info = generar_seo_para_proyecto(p, nicho_raiz or p.parent)
            if ok:
                log.append(f"[OK] Paquete SEO generado con éxito: {p.name}/seo.txt ({info.get('modelo', 'Gemini')})")
                JOBS[clave]["estado"] = "ok"
                JOBS[clave]["linea"] = "SEO listo"
            else:
                log.append(f"[ERROR] {msg}")
                JOBS[clave]["estado"] = "error"
                JOBS[clave]["linea"] = f"Fallo SEO: {msg[:60]}"
        except Exception as e:
            log.append(f"[ERROR] Excepción: {e}")
            JOBS[clave]["estado"] = "error"
            JOBS[clave]["linea"] = f"Error: {str(e)[:60]}"

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    return True, f"Generando SEO para {p.name}..."


def lanzar_subtitulos_ecos(nicho: dict, ruta: str):
    p = Path(ruta).resolve()
    if not _dentro_de_nicho(p) or not p.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / "subtitulos_karaoke.py"
    if not script.is_file():
        return False, "no encuentro subtitulos_karaoke.py"
    args = [sys.executable, str(script), str(p)]
    return lanzar_proceso(str(p), args)


def lanzar_sincronizar_mapas(nicho: dict, ruta: str):
    p = Path(ruta).resolve()
    if not _dentro_de_nicho(p) or not p.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / "preparar_mapa.py"
    if not script.is_file():
        return False, "no encuentro preparar_mapa.py"
    args = [sys.executable, str(script), str(p)]
    return lanzar_proceso(str(p), args)


# ------------------------------------------------------------------ voz (ai33)
# Mapa nicho -> archivo de configuracion (voz + clave). Todos viven DENTRO del
# proyecto, en Generador_Contenido/ai33/. Para agregar un nicho nuevo: crea su
# ai33_<algo>.txt en esa carpeta y añade aquí una línea (id, etiqueta, archivo).
AI33_CONFIGS = {
    "mapas":      ("Mapas Virales",          AQUI / "ai33" / "ai33_mapas.txt"),
    "ecos":       ("Ecos del Alma",          AQUI / "ai33" / "ai33_ecos.txt"),
    "psicoscura": ("Psicología Oscura",      AQUI / "ai33" / "ai33_psicoscura.txt"),
    "famosos":    ("Famosos",                AQUI / "ai33" / "ai33_famosos.txt"),
    "peliculas":  ("Películas",              AQUI / "ai33" / "ai33_peliculas.txt"),
    "finanzas":   ("Finanzas (YouTube)",     AQUI / "ai33" / "ai33_finanzas.txt"),
}


def lanzar_voz(archivo: str, nicho: str):
    """Convierte un .txt de guiones (GUION: <numero>) en audios .mp3 con ai33.pro,
    usando el config del nicho elegido. Los .mp3 quedan en la MISMA carpeta del
    .txt. Un solo proceso a la vez."""
    p = Path(_limpiar_ruta(archivo)).expanduser()
    try:
        p = p.resolve()
    except OSError:
        return False, "ruta inválida"
    if not p.is_file() or p.suffix.lower() != ".txt":
        return False, "elige un archivo .txt con los guiones"
    entrada = AI33_CONFIGS.get(nicho)
    if not entrada:
        return False, "nicho de voz no reconocido"
    config = entrada[1]
    if not config.is_file():
        return False, f"falta el config {config.name} en ai33/"
    script = AQUI / "ai33" / "tts.py"
    if not script.is_file():
        return False, "no encuentro ai33/tts.py"
    args = [sys.executable, str(script), str(p), "--config", str(config)]
    return lanzar_proceso(str(p), args)


# ------------------------------------------------------- recortar audio (silencios)
# Presets por nicho (deben coincidir con recortar_audio.py). Solo para la UI:
# la lógica real vive en el script. Etiqueta legible -> id que entiende el script.
RECORTE_PRESETS = [
    ("mapas",     "Mapas Virales (pausas 0.2s)"),
    ("finanzas",  "Finanzas (deja pausas de 0.5s)"),
    ("ecos",      "Ecos del Alma (pausas 0.4s)"),
    ("famosos",   "Famosos (corrido, pausas 0.15s)"),
    ("peliculas", "Películas / recap (pausas 0.18s)"),
    ("suave",     "Suave (genérico, recorta poco)"),
    ("medio",     "Medio (genérico)"),
    ("fuerte",    "Fuerte (genérico, recorta mucho)"),
]
RECORTE_IDS = {p for p, _ in RECORTE_PRESETS}


def lanzar_recorte(archivo: str, nicho: str, bordes: bool = False, respiros: bool = True):
    """Limpia respiros y recorta los silencios largos de un audio según el preset
    del nicho, con recortar_audio.py. Deja <nombre>_recortado.mp3 junto al original.
    Un solo proceso a la vez."""
    p = Path(_limpiar_ruta(archivo)).expanduser()
    try:
        p = p.resolve()
    except OSError:
        return False, "ruta inválida"
    if not p.is_file() or p.suffix.lower() not in AUDIO_EXTS:
        return False, "elige un archivo de audio (.mp3, .wav, ...)"
    if nicho not in RECORTE_IDS:
        return False, "preset de recorte no reconocido"
    script = (AQUI / "herramientas" / "recortar_audio.py") if (AQUI / "herramientas" / "recortar_audio.py").is_file() else (AQUI / "recortar_audio.py")
    if not script.is_file():
        return False, "no encuentro recortar_audio.py"
    args = [sys.executable, str(script), str(p), "--nicho", nicho]
    if bordes:
        args.append("--bordes")
    if not respiros:
        args.append("--no-respiros")
    return lanzar_proceso(str(p), args)


# ------------------------------------------------- personajes (rostros del video)
def lanzar_personajes(video: str, n: int = 4):
    """Saca en imagenes a los personajes protagonicos de un video (caras en primer
    plano que se repiten), con personajes/extraer_personajes.py. Deja los retratos
    en <video>_personajes/. Un solo proceso a la vez."""
    p = Path(_limpiar_ruta(video)).expanduser()
    try:
        p = p.resolve()
    except OSError:
        return False, "ruta inválida"
    if not p.is_file() or p.suffix.lower() not in VIDEO_EXTS:
        return False, "elige un archivo de video (.mp4, .mov, ...)"
    script = AQUI / "personajes" / "extraer_personajes.py"
    if not script.is_file():
        return False, "no encuentro personajes/extraer_personajes.py"
    n = n if 1 <= n <= 12 else 4
    args = [sys.executable, str(script), str(p), "--n", str(n)]
    return lanzar_proceso(str(p), args)


def lanzar_famosos(nicho: dict, ruta: str, audio: str, dur: float = 3.0, clips: int = 3,
                   formato: str = "face_crop", subtitulos: int = 1):
    fam = Path(ruta).resolve()
    if not _dentro_de_nicho(fam) or not fam.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / "producir_famosos.py"
    if not script.is_file():
        script = Path(nicho.get("codigo", AQUI)) / nicho.get("script", "producir_famosos.py")
    if not script.is_file():
        return False, f"no encuentro {script.name}"
    args = [sys.executable, str(script), str(fam)]
    if audio:
        args += ["--audio", audio]
    if formato:
        args += ["--formato", formato]
    args += ["--subtitulos", str(subtitulos)]
    return lanzar_proceso(str(fam), args)


def lanzar_famosos_clips(nicho: dict, ruta: str, audio: str = None):
    fam = Path(ruta).resolve()
    if not _dentro_de_nicho(fam) or not fam.is_dir():
        return False, "ruta inválida"
    script = Path(nicho.get("codigo", AQUI)) / "extraer_clips_famosos.py"
    if not script.is_file():
        script = Path(nicho.get("codigo", AQUI)) / "producir_famosos.py"
        if not script.is_file():
            return False, "no encuentro el script extractor de clips"
        args = [sys.executable, str(script), str(fam), "--solo-clips"]
    else:
        args = [sys.executable, str(script), str(fam)]
    if audio:
        args += ["--audio", audio]
    return lanzar_proceso(str(fam), args)


# --------------------------------------------------------------- servidor

def escanear_enlaces_descarga(ruta: str):
    """Escanea una carpeta o archivo .txt y devuelve los enlaces y estado."""
    limpio = _limpiar_ruta(ruta)
    if not limpio:
        return False, "No se indico ninguna ruta", {}
    p = Path(limpio).expanduser().resolve()
    if not p.exists():
        return False, f"La ruta indicada no existe: {limpio}", {}
    from descargar_videos import extraer_urls_de_archivo, buscar_txt_con_enlaces
    txt_path = None
    urls = []
    if p.is_file() and p.suffix.lower() == ".txt":
        txt_path = p
        urls = extraer_urls_de_archivo(txt_path)
        directorio = p.parent
    elif p.is_dir():
        directorio = p
        txt_path, urls = buscar_txt_con_enlaces(p)
    else:
        return False, "No es un directorio ni un archivo .txt valido", {}
    videos_existentes = []
    if directorio.is_dir():
        for x in sorted(directorio.iterdir()):
            if x.is_file() and x.suffix.lower() in VIDEO_EXTS:
                tam_mb = round(x.stat().st_size / (1024 * 1024), 1)
                videos_existentes.append({"nombre": x.name, "tam": f"{tam_mb} MB"})
    historial_count = 0
    hist_file = directorio / "_descargas_historial.txt"
    if hist_file.is_file():
        try:
            historial_count = len([l for l in hist_file.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip()])
        except Exception:
            pass
    return True, "Escaneo exitoso", {
        "txt": str(txt_path) if txt_path else "",
        "txt_nombre": txt_path.name if txt_path else "",
        "directorio": str(directorio),
        "urls": urls,
        "videos_existentes": videos_existentes,
        "historial_count": historial_count
    }

def guardar_enlaces_descarga(carpeta_o_txt: str, texto_o_urls):
    """Guarda los enlaces en el archivo .txt dentro de la carpeta correspondiente."""
    p = Path(_limpiar_ruta(carpeta_o_txt)).expanduser().resolve()
    if p.is_file() and p.suffix.lower() == ".txt":
        txt_path = p
    elif p.is_dir():
        txt_path = p / "enlaces.txt"
    else:
        p.mkdir(parents=True, exist_ok=True)
        txt_path = p / "enlaces.txt"
    if isinstance(texto_o_urls, list):
        contenido = "\n".join(str(u).strip() for u in texto_o_urls if str(u).strip()) + "\n"
    else:
        contenido = str(texto_o_urls).strip() + "\n"
    txt_path.write_text(contenido, encoding="utf-8")
    from descargar_videos import extraer_urls_de_archivo
    urls = extraer_urls_de_archivo(txt_path)
    return True, f"Guardados {len(urls)} enlaces en {txt_path.name}", {
        "txt": str(txt_path),
        "txt_nombre": txt_path.name,
        "directorio": str(txt_path.parent),
        "urls": urls
    }

def lanzar_descarga_videos(ruta: str):
    """Ejecuta descargar_videos.py en la carpeta de destino guardando los videos en ella."""
    p = Path(_limpiar_ruta(ruta)).expanduser().resolve()
    if not p.exists():
        return False, "La ruta indicada no existe"
    script = (AQUI / "herramientas" / "descargar_videos.py") if (AQUI / "herramientas" / "descargar_videos.py").is_file() else (AQUI / "descargar_videos.py")
    if not script.is_file():
        return False, "No se encuentra descargar_videos.py"
    cwd = p.parent if p.is_file() else p
    clave = str(p)
    args = [sys.executable, str(script), str(p)]
    return lanzar_proceso(clave, args, cwd=str(cwd))


TEMPLATE_FILE = AQUI / "panel_template.html"

def _obtener_version_app(base_dir: Path = None) -> str:
    """Lee la versión actual desde version.json con fallback seguro."""
    objetivo = base_dir or AQUI
    try:
        v_file = objetivo / "version.json"
        if v_file.is_file():
            ver = json.loads(v_file.read_text(encoding="utf-8")).get("version", "")
            if ver:
                return str(ver).strip().lstrip("vV")
    except Exception:
        pass
    return "2.5.1"

def _resolver_instalador_nexor() -> tuple[str, Path | None]:
    """Devuelve (version, ruta_exe) del instalador NEXOR más reciente disponible."""
    univ_root = Path(r"C:\Users\Usuario\Documents\DAVID\Generador_Universal")
    ver = _obtener_version_app(univ_root if (univ_root / "version.json").is_file() else AQUI)
    nombre_esperado = f"Instalador_NEXOR_v{ver}_Setup.exe"
    candidatos_dirs = [univ_root / "dist_instalador", AQUI / "dist_instalador"]
    for d in candidatos_dirs:
        exe_exacto = d / nombre_esperado
        if exe_exacto.is_file():
            return ver, exe_exacto
    exes = []
    for d in candidatos_dirs:
        if d.is_dir():
            exes.extend(d.glob("Instalador_NEXOR_v*_Setup.exe"))
    if exes:
        mas_reciente = max(exes, key=lambda p: p.stat().st_mtime)
        m = re.search(r"v([0-9]+(?:\.[0-9]+)*)", mas_reciente.name)
        ver_exe = m.group(1) if m else ver
        return ver_exe, mas_reciente
    return ver, None

def get_pagina():
    if TEMPLATE_FILE.is_file():
        try:
            ver = _obtener_version_app(Path(r"C:\Users\Usuario\Documents\DAVID\Generador_Universal") if (Path(r"C:\Users\Usuario\Documents\DAVID\Generador_Universal\version.json")).is_file() else AQUI)
            return TEMPLATE_FILE.read_text(encoding="utf-8").replace("{{APP_VERSION}}", ver)
        except Exception as e:
            print(f"[ERROR] No se pudo leer {TEMPLATE_FILE}: {e}")
    return PAGINA


FLOWBATCH_QUEUE_FILE = AQUI / "flowbatch_cola.json"
FLOWBATCH_LOCK = threading.RLock()
_FLOWBATCH_IMG_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".mp4", ".webm", ".mov")


def _ordenar_rutas_numericas_asc(lista_rutas):
    """Ordena siempre las rutas de proyectos de menor a mayor numérico (ej: 312 antes de 313, 01 antes de 02)."""
    def _clave(ruta_str):
        p = Path(ruta_str)
        m = re.match(r"^(\d+)", p.name)
        if m:
            return (0, int(m.group(1)), p.name.lower())
        return (1, p.name.lower())
    return sorted(lista_rutas, key=_clave)


def _fb_ahora():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _fb_cargar_cola():
    with FLOWBATCH_LOCK:
        if FLOWBATCH_QUEUE_FILE.is_file():
            try:
                data = json.loads(FLOWBATCH_QUEUE_FILE.read_text(encoding="utf-8"))
                if isinstance(data, dict) and isinstance(data.get("jobs"), list):
                    return data
            except Exception:
                pass
        return {"jobs": [], "extension_seen_at": 0.0, "extension_info": {}}


def _fb_guardar_cola(data):
    with FLOWBATCH_LOCK:
        # Optimizar tamaño y eliminar payloads base64 de jobs terminados o cancelados
        for j in data.get("jobs", []):
            if j.get("estado") in ("completado", "cancelado", "error", "detenido"):
                j.pop("ref_images", None)
                j.pop("images", None)
                if "items" in j and isinstance(j["items"], list):
                    for it in j["items"]:
                        if isinstance(it, dict):
                            it.pop("data", None)
            # En jobs pendientes de escenas, tampoco persistir ref_images en cola.json
            # ya que /api/flowbatch/siguiente las carga dinámicamente de disco al despachar el lote
            j.pop("ref_images", None)

        txt = json.dumps(data, ensure_ascii=False, indent=2)
        tmp = FLOWBATCH_QUEUE_FILE.with_suffix(".tmp")
        try:
            tmp.write_text(txt, encoding="utf-8")
        except Exception:
            pass

        guardado = False
        for intento in range(8):
            try:
                os.replace(tmp, FLOWBATCH_QUEUE_FILE)
                guardado = True
                break
            except (PermissionError, OSError):
                time.sleep(0.04 * (intento + 1))

        if not guardado:
            # Fallback seguro para Windows: escritura directa in-place
            try:
                FLOWBATCH_QUEUE_FILE.write_text(txt, encoding="utf-8")
                if tmp.exists():
                    try:
                        tmp.unlink()
                    except Exception:
                        pass
                guardado = True
            except Exception as e_w:
                print(f"[ERROR CRÍTICO] Fallback guardar cola falló: {e_w}")


def _fb_parsear_prompts(texto_raw="", prompts_list=None, ruta_proyecto=""):
    if isinstance(prompts_list, list) and prompts_list:
        lineas = [str(x).strip() for x in prompts_list if str(x).strip()]
        return lineas, ""
    raw = str(texto_raw or "").strip()
    origen = "manual"
    if not raw and ruta_proyecto:
        p_proy = Path(_limpiar_ruta(ruta_proyecto))
        for cand in ("prompts.txt", "prompts_flow.txt", "prompts_imagen.txt", "imagen.txt"):
            f_cand = p_proy / cand
            if f_cand.is_file():
                try:
                    raw = f_cand.read_text(encoding="utf-8", errors="ignore").strip()
                    origen = cand
                    break
                except Exception:
                    pass
    prompts = []
    for ln in raw.splitlines():
        s = ln.strip()
        if not s or s.startswith("#") or s.startswith("//") or s.startswith("==="):
            continue
        # Limpiar prefijo numérico opcional (ej: "1. Hyper-realistic..." -> "Hyper-realistic...")
        s_clean = re.sub(r"^\d+[\.\-\)]\s*", "", s).strip() if re.match(r"^\d+[\.\-\)]\s+", s) else s
        prompts.append(s_clean if s_clean else s)
    return prompts, origen


def _fb_resolver_destino(carpeta_destino, job_id):
    raw = _limpiar_ruta(carpeta_destino or "").strip()
    if not raw:
        staging = (USER_DOWNLOADS / "veo").resolve()
        return {
            "folder_rel": "veo",
            "staging_dir": str(staging),
            "final_dir": str(staging),
            "needs_move": False,
        }

    p_check = Path(raw)
    if not p_check.is_absolute() and not raw.startswith(("\\", "/")) and ":" not in raw:
        sub_folder = raw.strip("/\\") or "veo"
        dest_real = (USER_DOWNLOADS / sub_folder).resolve()
        return {
            "folder_rel": sub_folder,
            "staging_dir": str(dest_real),
            "final_dir": str(dest_real),
            "needs_move": False,
        }

    p_dest = Path(raw).resolve()
    try:
        rel = p_dest.relative_to(USER_DOWNLOADS)
        rel_str = rel.as_posix().strip("/")
        if not rel_str:
            rel_str = "veo"
            dest_real = (USER_DOWNLOADS / "veo").resolve()
        else:
            dest_real = p_dest
        return {
            "folder_rel": rel_str,
            "staging_dir": str(dest_real),
            "final_dir": str(dest_real),
            "needs_move": False,
        }
    except ValueError:
        staging = (USER_DOWNLOADS / "veo").resolve()
        return {
            "folder_rel": "veo",
            "staging_dir": str(staging),
            "final_dir": str(p_dest),
            "needs_move": True,
        }

def _contar_referencias_requeridas(p_ref: Path) -> int:
    """Devuelve cuántos personajes (P1, P2, P3...) define referencias.txt."""
    if not p_ref or not p_ref.is_file():
        return 0
    try:
        lineas = [l.strip() for l in p_ref.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip() and not l.strip().startswith(("#", "//", "==="))]
        return len(lineas)
    except Exception:
        return 0

def _resolver_raiz_proyecto(ruta_o_carpeta: Path | str) -> Path:
    """Obtiene la carpeta raíz del guión/proyecto, sin importar si apunta a grok, veo, imagen, etc."""
    p = Path(_limpiar_ruta(str(ruta_o_carpeta))).resolve()
    if p.is_file():
        p = p.parent
    if p.name.lower() in ("veo", "grok", "imagen", "imagenes", "video", "videos", "clips", "cortes"):
        return p.parent
    return p


def _detectar_videos_existentes(carpeta_o_proyecto: Path | str) -> set[int]:
    """
    Busca de manera abierta por extensiones (.mp4, .webm, .mov) en TODO el directorio
    del proyecto/guión (grok/, veo/, video/, o cualquier subcarpeta).
    Descarta carpetas de cortes y archivos finales montados.
    Retorna el conjunto de números de escena existentes.
    """
    proy = _resolver_raiz_proyecto(carpeta_o_proyecto)
    if not proy.is_dir():
        return set()
    nums = set()
    try:
        for f in proy.rglob("*"):
            if not f.is_file() or f.suffix.lower() not in (".mp4", ".webm", ".mov"):
                continue
            parts_lower = [p.lower() for p in f.parts]
            if any(part.startswith("_") or "cortes" in part or "backup" in part or "erroneo" in part or "__pycache__" in part or ".system_generated" in part for part in parts_lower[:-1]):
                continue
            name_lower = f.name.lower()
            if name_lower.startswith(("final", "video_final", "resultado", "montado")) or name_lower == f"{proy.name.lower()}.mp4" or re.search(r"_[a-z]{2}\.mp4$", name_lower):
                continue
            try:
                if f.stat().st_size < 50 * 1024:
                    continue
            except Exception:
                continue
            m = re.search(r"(\d+)", f.stem)
            if m:
                nums.add(int(m.group(1)))
    except Exception as e:
        print(f"[AVISO] Error escaneando videos en {proy}: {e}")
    return nums


def _contar_videos_existentes(carpeta_o_proyecto: Path | str) -> int:
    """Cuenta cuántos videos existen en el proyecto."""
    nums = _detectar_videos_existentes(carpeta_o_proyecto)
    return max(nums) if nums else 0


def _calcular_start_num_videos(carpeta_o_proyecto: Path | str, total_prompts: int = 0, escenas_objetivo: list[int] | None = None) -> int:
    """
    Calcula la POSICIÓN (1-based index: 1, 2, 3, 4...) desde la cual FlowBatch debe iniciar en la lista de prompts.
    El número que va en el casillero de FlowBatch (start_num) es la posición del prompt (ej: posición 4),
    mientras que la imagen a enviar/cargar es la escena correspondiente (ej: escena 8 -> 008.jpg).
    """
    nums = _detectar_videos_existentes(carpeta_o_proyecto)
    if not nums:
        return 1

    if escenas_objetivo:
        for pos, esc in enumerate(escenas_objetivo, start=1):
            if esc not in nums:
                return pos
        return len(escenas_objetivo)

    limite = max(max(nums) + 2, (total_prompts + 1) if total_prompts else 2)
    for pos in range(1, limite):
        if pos not in nums:
            if total_prompts and pos > total_prompts:
                return total_prompts
            return pos
    return 1


def _detectar_imagenes_escenas_existentes(carpeta_o_proyecto: Path | str) -> set[int]:
    """
    Busca de manera abierta en TODO el directorio del guion (veo/, grok/, imagen/, etc.)
    archivos de imagen de escena (001.jpg, 002.png, etc.), descartando referencias (p1, p2, ref...)
    y carpetas temporales. Retorna los números de escena existentes.
    """
    proy = _resolver_raiz_proyecto(carpeta_o_proyecto)
    if not proy.is_dir():
        return set()
    nums = set()
    patron_ref = re.compile(r"^(?:p|ref)[1-9]", re.IGNORECASE)
    try:
        for f in proy.rglob("*"):
            if not f.is_file() or f.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp"):
                continue
            parts_lower = [p.lower() for p in f.parts]
            if any(part.startswith("_") or "cortes" in part or "backup" in part or "erroneo" in part or "__pycache__" in part or ".system_generated" in part for part in parts_lower[:-1]):
                continue
            if patron_ref.match(f.stem):
                continue
            try:
                if f.stat().st_size < 1024:
                    continue
            except Exception:
                continue
            m = re.search(r"(\d+)", f.stem)
            if m:
                nums.add(int(m.group(1)))
    except Exception as e:
        print(f"[AVISO] Error escaneando imágenes de escena en {proy}: {e}")
    return nums


def _contar_imagenes_escenas_existentes(carpeta_o_proyecto: Path | str) -> int:
    """Cuenta cuántas imágenes de escena existen en el proyecto."""
    nums = _detectar_imagenes_escenas_existentes(carpeta_o_proyecto)
    return max(nums) if nums else 0


def _calcular_start_num_imagenes(carpeta_o_proyecto: Path | str, total_prompts: int = 0) -> int:
    """Calcula el número de prompt de escena inicial buscando el primer número faltante a partir de 1."""
    nums = _detectar_imagenes_escenas_existentes(carpeta_o_proyecto)
    if not nums:
        return 1
    limite = max(max(nums) + 2, (total_prompts + 1) if total_prompts else 2)
    for i in range(1, limite):
        if i not in nums:
            if total_prompts and i > total_prompts:
                return total_prompts
            return i
    return 1


def _buscar_imagen_escena(p_proy: Path, idx: int) -> Path | None:
    """Busca 001.jpg, 001.png, 1.jpg, etc. de manera abierta en todo el directorio del guion."""
    num_str = f"{idx:03d}"
    candidatos = [f"{num_str}.jpg", f"{num_str}.png", f"{num_str}.jpeg", f"{num_str}.webp",
                  f"{idx}.jpg", f"{idx}.png", f"{idx}.jpeg", f"{idx}.webp"]
    for sub in ("veo", "grok", "imagen", "imagenes", ""):
        d = (p_proy / sub) if sub else p_proy
        if d.is_dir():
            for nom in candidatos:
                c = d / nom
                if c.is_file() and c.stat().st_size > 1024:
                    return c
    for nom in candidatos:
        for f in p_proy.rglob(nom):
            if f.is_file() and f.stat().st_size > 1024 and "cortes" not in f.parts and "__pycache__" not in f.parts:
                return f
    return None


def _buscar_referencia_personaje(p_proy: Path, idx_o_tag: int | str) -> Path | None:
    """Busca p1.jpg, p2.png, ref1.jpg, etc. de manera abierta en todo el directorio del guion."""
    tag = str(idx_o_tag).strip().lower()
    if not tag.startswith(("p", "ref")):
        tag = f"p{tag}"
    variantes_tag = [tag]
    if tag.startswith("p"):
        variantes_tag.append("ref" + tag[1:])
    elif tag.startswith("ref"):
        variantes_tag.append("p" + tag[3:])

    candidatos = []
    for t in variantes_tag:
        for ext in (".jpg", ".jpeg", ".png", ".webp"):
            candidatos.append(f"{t}{ext}")

    for sub in ("veo", "grok", "imagen", "referencias", ""):
        d = (p_proy / sub) if sub else p_proy
        if d.is_dir():
            for nom in candidatos:
                c = d / nom
                if c.is_file() and c.stat().st_size > 1024:
                    return c
    for nom in candidatos:
        for f in p_proy.rglob(nom):
            if f.is_file() and f.stat().st_size > 1024 and "cortes" not in f.parts and "__pycache__" not in f.parts:
                return f
    return None


def _determinar_carpeta_destino_medios(p_proy: Path, es_video: bool = False) -> Path:
    """Determina la carpeta de destino adecuada respetando la convención del proyecto (grok/video para videos, veo/imagen para imágenes)."""
    p_str = str(p_proy).lower()
    es_personal = ("nuevos guiones" in p_str) or ("ecos" in p_str)

    if es_video:
        if es_personal and (p_proy / "grok").is_dir():
            return p_proy / "grok"
        if not es_personal and (p_proy / "video").is_dir():
            return p_proy / "video"
        if (p_proy / "video").is_dir():
            return p_proy / "video"
        if (p_proy / "grok").is_dir():
            return p_proy / "grok"
        if (p_proy / "videos").is_dir():
            return p_proy / "videos"
        return (p_proy / "grok") if es_personal else (p_proy / "video")
    else:
        if es_personal and (p_proy / "veo").is_dir():
            return p_proy / "veo"
        if not es_personal and (p_proy / "imagen").is_dir():
            return p_proy / "imagen"
        if (p_proy / "imagen").is_dir():
            return p_proy / "imagen"
        if (p_proy / "veo").is_dir():
            return p_proy / "veo"
        if (p_proy / "imagenes").is_dir():
            return p_proy / "imagenes"
        return (p_proy / "veo") if es_personal else (p_proy / "imagen")


def enviar_lote_videos_a_flowbatch(carpeta_o_proyecto=None, ruta_movimiento_txt=None, prompts_movimiento=None, project_id="", start_num=None, quality="360p", gap_sec=25, profile_id="", carpeta_veo=None):
    r"""
    Construye la estructura exacta de trabajo para FlowBatch Pro en modo Video.
    1. Lee los prompts de movimiento (desde ruta_movimiento_txt, prompts_movimiento o buscando movimiento.txt).
    2. Extrae el número de escena real de cada línea (ej: '5. Zoom...', '8. Slow motion...') para asociarlo a su imagen exacta (005.jpg, 008.jpg).
    3. Limpia el prefijo numérico del prompt para que Flow reciba el prompt limpio sin números.
    4. Carga la imagen semilla en base64 para cada escena en items y en el diccionario images.
    5. Calcula el start_num automático evaluando cuáles escenas ya tienen clip de video generado en disco.
    """
    ruta_input = carpeta_o_proyecto if carpeta_o_proyecto is not None else (carpeta_veo or "")
    p_proy = _resolver_raiz_proyecto(ruta_input)
    pid = str(project_id or p_proy.name).strip()

    # 1. Obtener las líneas de prompts de movimiento
    raw_lines = []
    if ruta_movimiento_txt and Path(ruta_movimiento_txt).is_file():
        raw_lines = [l.strip() for l in Path(ruta_movimiento_txt).read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
    elif prompts_movimiento:
        raw_lines = [p.strip() for p in prompts_movimiento if p.strip()]
    else:
        cands_txt = []
        for cand_name in ("movimiento.txt", "prompts_video.txt", "videos.txt"):
            for sub in ("", "veo", "imagen", "grok", "video"):
                p_sub = (p_proy / sub / cand_name) if sub else (p_proy / cand_name)
                if p_sub.is_file():
                    cands_txt.append(p_sub)
                    break
            if cands_txt:
                break
        if not cands_txt:
            for f in p_proy.rglob("*.txt"):
                if "movimiento" in f.name.lower():
                    cands_txt.append(f)
                    break
        if cands_txt:
            raw_lines = [l.strip() for l in cands_txt[0].read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]

    # Filtrar comentarios y encabezados
    raw_lines = [l for l in raw_lines if not l.startswith(("#", "//", "==="))]

    items = []
    images_dict = {}
    escenas_detectadas = []

    for idx, line in enumerate(raw_lines, start=1):
        # Extraer el número real de escena del inicio del texto (ej: "5. Zoom...", "Scene 5: ...", "8. Slow motion...")
        m = re.match(r"^(?:prompt|escena|scene|imagen|img|frame|clip)?\s*#?\[?(\d+)\]?[\.\-:\)\s]+\s*([\s\S]+)$", line, re.I)
        if not m:
            m = re.match(r"^(\d+)\s+([\s\S]+)$", line)

        if m:
            scene_num = int(m.group(1))
            clean_prompt = m.group(2).strip()
        else:
            scene_num = idx
            clean_prompt = line.strip()

        escenas_detectadas.append(scene_num)
        num_str = f"{scene_num:03d}"

        # Buscar la imagen exacta para esa escena (001.jpg, 005.jpg, 008.jpg, etc.)
        img_path = _buscar_imagen_escena(p_proy, scene_num)
        b64_data = None
        img_name = f"{num_str}.jpg"

        if img_path and img_path.is_file():
            try:
                mime = "image/png" if img_path.suffix.lower() == ".png" else "image/jpeg"
                b64_raw = base64.b64encode(img_path.read_bytes()).decode("ascii")
                b64_data = f"data:{mime};base64,{b64_raw}"
                img_name = img_path.name
                images_dict[str(scene_num)] = b64_data
                images_dict[str(idx)] = b64_data
                images_dict[f"{num_str}.jpg"] = b64_data
            except Exception as e_b64:
                print(f"[AVISO] Error leyendo imagen {img_path}: {e_b64}")

        items.append({
            "num": idx,                       # Posición secuencial del prompt en el lote (1, 2, 3, 4, 5, 6, 7)
            "order": idx,                     # Orden 1-based para FlowBatch
            "scene_num": scene_num,           # Número real de la escena/imagen (1, 2, 5, 8, 11, 14, 17)
            "prompt": clean_prompt,
            "data": b64_data,
            "name": img_name
        })

    dest_folder = _determinar_carpeta_destino_medios(p_proy, es_video=True)
    dest_folder.mkdir(parents=True, exist_ok=True)

    if start_num is None:
        start_num = _calcular_start_num_videos(p_proy, total_prompts=len(items), escenas_objetivo=escenas_detectadas)
    else:
        sn = int(start_num)
        # Si el usuario ingresó el número de escena (ej: 8) en vez de la posición (ej: 4),
        # lo convertimos inteligentemente a la posición en la lista de prompts
        if sn in escenas_detectadas:
            start_num = escenas_detectadas.index(sn) + 1
        elif 1 <= sn <= len(items):
            start_num = sn
        else:
            start_num = max(1, min(sn, len(items)))

    job_id = f"video_{pid}"
    dest_info = _fb_resolver_destino(str(dest_folder), job_id)

    num_hechos = max(0, start_num - 1)
    escena_actual = escenas_detectadas[start_num - 1] if (1 <= start_num <= len(escenas_detectadas)) else start_num

    job_payload = {
        "job_id": job_id,
        "profile_id": str(profile_id or "").strip(),
        "mode": "video",
        "tipo_trabajo": "video",
        "titulo": f"Videos: {pid}",
        "carpeta_proyecto": str(p_proy),
        "folder": dest_info["folder_rel"],
        "folder_rel": dest_info["folder_rel"],
        "staging_dir": dest_info["staging_dir"],
        "final_dir": dest_info["final_dir"],
        "needs_move": dest_info["needs_move"],
        "prompts": [it["prompt"] for it in items],
        "total": len(items),
        "quality": quality or "360p",
        "start_num": start_num,
        "startNum": start_num,
        "gap_sec": max(15, int(gap_sec or 25)),
        "max_retries": 0,
        "autodl": True,
        "items": items,
        "images": images_dict,
        "estado": "pendiente",
        "progreso": {
            "done": num_hechos,
            "total": len(items),
            "pct": int(round((num_hechos / len(items)) * 100)) if items else 0,
            "text": f"En cola esperando a FlowBatch Pro (prompt #{start_num}, imagen {escena_actual:03d}.jpg)..." if start_num > 1 else "En cola esperando a FlowBatch Pro...",
            "num": start_num
        },
        "created_at": _fb_ahora(),
        "logs": [{
            "hora": datetime.datetime.now().strftime("%H:%M:%S"),
            "level": "info",
            "text": f"Lote de videos encolado ({len(items)} prompts, inicia en posición #{start_num} [escena #{escena_actual}, imagen {escena_actual:03d}.jpg]) -> {dest_info['final_dir']}"
        }]
    }

    return job_payload

    return job_payload



def _fb_mover_descargas_job(job):
    """
    Gestiona el destino de descargas de FlowBatch de forma 100% segura.
    1. Si not job.get("needs_move"): retorna 0 inmediatamente sin buscar ni mover nada,
       ya que FlowBatch Pro descarga directamente en final_dir.
    2. Si needs_move es True: solo mueve archivos desde staging_dir hacia final_dir,
       sin hacer ningún glob general por todo Descargas que afecte a otros proyectos.
    """
    if not job or not job.get("needs_move"):
        return 0

    staging = Path(job.get("staging_dir", "")).resolve() if job.get("staging_dir") else None
    dst_dir = Path(job.get("final_dir", "")).resolve() if job.get("final_dir") else None

    if not staging or not dst_dir or not staging.is_dir() or staging == dst_dir:
        return 0

    dst_dir.mkdir(parents=True, exist_ok=True)
    moved = 0
    try:
        # Solo mover archivos DIRECTOS de staging_dir
        for f in list(staging.iterdir()):
            if f.is_file() and f.suffix.lower() in _FLOWBATCH_IMG_EXTS:
                dest_file = dst_dir / f.name
                if dest_file.exists():
                    dest_file = dst_dir / f"{f.stem}_{int(time.time())}{f.suffix}"
                shutil.move(str(f), str(dest_file))
                moved += 1
    except Exception:
        pass
    return moved


def _fb_append_log(job, level, text):
    logs = job.setdefault("logs", [])
    logs.append({
        "hora": datetime.datetime.now().strftime("%H:%M:%S"),
        "level": level or "info",
        "text": str(text or "")[:400],
    })
    if len(logs) > 120:
        del logs[:-120]


class Handler(http.server.BaseHTTPRequestHandler):
    def _cors_origin_val(self):
        origin = (self.headers.get("Origin") or "").strip()
        if not origin:
            return None
        if (
            origin.startswith("chrome-extension://")
            or origin.startswith("http://127.0.0.1:")
            or origin.startswith("http://localhost:")
            or origin in ("http://127.0.0.1", "http://localhost")
        ):
            return origin
        return None

    def _send_cors_headers(self):
        orig = self._cors_origin_val()
        if orig:
            self.send_header("Access-Control-Allow-Origin", orig)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _json(self, obj, code=200):
        try:
            cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self._send_cors_headers()
            self.send_header("Content-Length", str(len(cuerpo)))
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.end_headers()
            self.wfile.write(cuerpo)
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            pass

    def _leer_json(self):
        """Lee y parsea el cuerpo JSON de un POST (para listas largas de rutas)."""
        try:
            n = int(self.headers.get("Content-Length", "0") or 0)
            if n <= 0:
                return {}
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def _html(self, texto):
        try:
            cuerpo = texto.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.end_headers()
            self.wfile.write(cuerpo)
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            pass

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/":
            return self._html(get_pagina())
        if u.path.startswith("/adminlte/"):
            rel = unquote(u.path[len("/adminlte/"):].lstrip("/"))
            fpath = (ADMINLTE_DIR / rel).resolve()
            if fpath.is_file() and str(fpath).startswith(str(ADMINLTE_DIR.resolve())):
                mime, _ = mimetypes.guess_type(str(fpath))
                if not mime:
                    ext = fpath.suffix.lower()
                    mime = "font/woff2" if ext == ".woff2" else ("font/woff" if ext == ".woff" else ("font/ttf" if ext == ".ttf" else "application/octet-stream"))
                cuerpo = fpath.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(len(cuerpo)))
                self.send_header("Cache-Control", "public, max-age=86400")
                self.end_headers()
                try:
                    self.wfile.write(cuerpo)
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                return
            return self._json({"error": "archivo no encontrado"}, 404)
        if u.path == "/api/hardware":
            try:
                import hardware_tuner
                return self._json(hardware_tuner.obtener_info_hardware())
            except Exception as e:
                return self._json({"error": str(e)}, 500)
        if u.path == "/api/licencia/estado":
            import licencia
            import importlib
            importlib.reload(licencia)
            return self._json(licencia.verificar_licencia())

        if u.path == "/api/licencia/historial":
            log_p = AQUI / "admin_licencias" / "licencias_emitidas.json"
            if not log_p.is_file():
                log_p = AQUI / "licencias_emitidas.json"
            registros = []
            if log_p.is_file():
                try:
                    registros = json.loads(log_p.read_text(encoding="utf-8"))
                except Exception:
                    registros = []
            return self._json({"ok": True, "licencias": list(reversed(registros))})

        if u.path == "/api/licencia/descargar_instalador":
            _, exe_path = _resolver_instalador_nexor()
            if exe_path and exe_path.is_file():
                cuerpo = exe_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", f'attachment; filename="{exe_path.name}"')
                self.send_header("Content-Length", str(len(cuerpo)))
                self.end_headers()
                self.wfile.write(cuerpo)
                return
            return self._json({"error": "Instalador no encontrado"}, 404)

        if u.path == "/api/licencia/descargar_zip":
            f_nombre = q.get("f", ["Creador_de_Videos_Universal.zip"])[0]
            base_david = Path(r"C:\Users\Usuario\Documents\DAVID").resolve()
            f_path = (base_david / f_nombre).resolve()
            if f_path.is_file() and str(f_path).startswith(str(base_david)):
                cuerpo = f_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", f'attachment; filename="{f_path.name}"')
                self.send_header("Content-Length", str(len(cuerpo)))
                self.end_headers()
                self.wfile.write(cuerpo)
                return
            return self._json({"error": "archivo no encontrado"}, 404)
        if u.path.startswith("/ui/"):
            rel = unquote(u.path[len("/ui/"):].lstrip("/"))
            ui_dir = (AQUI / "ui").resolve()
            fpath = (ui_dir / rel).resolve()
            if fpath.is_file() and str(fpath).startswith(str(ui_dir)):
                mime, _ = mimetypes.guess_type(str(fpath))
                if not mime:
                    ext = fpath.suffix.lower()
                    if ext == ".js":
                        mime = "application/javascript; charset=utf-8"
                    elif ext == ".css":
                        mime = "text/css; charset=utf-8"
                    elif ext == ".html":
                        mime = "text/html; charset=utf-8"
                    elif ext == ".json":
                        mime = "application/json; charset=utf-8"
                    else:
                        mime = "application/octet-stream"
                cuerpo = fpath.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(len(cuerpo)))
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                try:
                    self.wfile.write(cuerpo)
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                return
            return self._json({"error": "archivo no encontrado"}, 404)

        if u.path == "/api/nichos":
            nichos_u = []
            try:
                from gestor_nichos import cargar_nichos_usuario
                nichos_u = cargar_nichos_usuario()
            except Exception:
                pass
            return self._json({
                "nichos": [{"id": k, "nombre": v["nombre"],
                            "raiz": str(v.get("raiz", "")),
                            "configurado": bool(v.get("configurado"))}
                           for k, v in NICHOS.items()],
                "nichos_usuario": nichos_u,
                "def": NICHO_DEF
            })
        if u.path == "/api/proyectos":
            nicho_id = q.get("nicho", [NICHO_DEF])[0]
            raiz_param = q.get("raiz", [None])[0]

            # Si se pasó raiz o es un nicho replicado del usuario
            if raiz_param or (nicho_id and (nicho_id.startswith("nicho_") or nicho_id not in NICHOS)):
                ruta_dir = None
                if raiz_param:
                    p_r = Path(_limpiar_ruta(unquote(raiz_param))).resolve()
                    if p_r.is_dir():
                        ruta_dir = p_r
                if not ruta_dir:
                    try:
                        from gestor_nichos import cargar_nichos_usuario
                        for nu in cargar_nichos_usuario():
                            if nu.get("id") == nicho_id:
                                p_c = Path(nu.get("ruta", "")).resolve()
                                if p_c.is_dir():
                                    ruta_dir = p_c
                                break
                    except Exception:
                        pass
                if ruta_dir:
                    nicho_f = {"raiz": ruta_dir, "nombre": nicho_id, "variante": "grok", "script": "cortar_escenas.py"}
                    datos = escanear_ecos(nicho_f)
                    datos["configurado"] = True
                    return self._json(datos)

            datos = escanear(nicho_id)
            if datos is None:
                n = NICHOS.get(nicho_id, {})
                return self._json({"configurado": False,
                                   "nombre": n.get("nombre", nicho_id), "filas": []}, 200)
            datos["configurado"] = True
            return self._json(datos)
        if u.path == "/api/sistema/verificar_actualizacion":
            try:
                import core.actualizador as actualizador
                importlib.reload(actualizador)
                res = actualizador.verificar_actualizaciones()
                return self._json({"ok": True, **res})
            except Exception as e:
                return self._json({"ok": False, "error": str(e)}, 500)

        if u.path in ("/api/ecos", "/api/videos"):
            if u.path == "/api/videos" and q.get("carpeta"):
                carpeta = unquote(q.get("carpeta", [""])[0])
                rec = q.get("rec", ["1"])[0] != "0"
                datos = listar_videos(carpeta, rec)
                if datos is None:
                    return self._json({"ok": False, "msg": "esa carpeta no existe"}, 400)
                return self._json({"ok": True, **datos})
            if q.get("carpeta"):
                carpeta = unquote(q.get("carpeta", [""])[0])
                nicho_f = {"raiz": Path(carpeta), "nombre": "Canal", "variante": "grok", "script": "cortar_escenas.py"}
                return self._json(escanear_ecos(nicho_f))
            if q.get("nicho_id"):
                n_id = q.get("nicho_id", [""])[0]
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            p_c = Path(nu.get("ruta", ""))
                            if p_c.is_dir():
                                nicho_f = {"raiz": p_c, "nombre": nu.get("nombre", "Canal"), "variante": "grok", "script": "cortar_escenas.py"}
                                return self._json(escanear_ecos(nicho_f))
                except Exception:
                    pass
            return self._json(escanear_ecos(NICHOS["ecos"]))
        if u.path == "/api/famosos":
            return self._json(escanear_famosos(NICHOS["famosos"]))
        if u.path == "/api/peliculas":
            return self._json(escanear_peliculas(NICHOS["peliculas"]))
        if u.path == "/api/ebook":
            return self._json(escanear_ebook(NICHOS["ebook"]))
        if u.path == "/api/elegir_txt":
            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "txt")
            return self._json({"ok": bool(ruta), "ruta": ruta})
        if u.path == "/api/leer_txt":
            ruta = unquote(q.get("ruta", [""])[0])
            p = Path(_limpiar_ruta(ruta)).resolve()
            if p.is_file() and p.suffix.lower() == ".txt":
                try:
                    contenido = p.read_text(encoding="utf-8-sig", errors="replace")
                    return self._json({"ok": True, "contenido": contenido, "nombre": p.name, "ruta": str(p)})
                except Exception as e:
                    return self._json({"ok": False, "error": str(e)}, 500)
            return self._json({"ok": False, "error": "Archivo no encontrado o invalido"}, 400)
        if u.path == "/api/elegir_audio":
            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "audio")
            return self._json({"ok": bool(ruta), "ruta": ruta})
        if u.path == "/api/elegir_carpeta":
            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "carpeta")
            return self._json({"ok": bool(ruta), "ruta": ruta})
        if u.path == "/api/elegir_video":
            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "video")
            return self._json({"ok": bool(ruta), "ruta": ruta})
        if u.path == "/api/historias/videos":
            try:
                from core.cortar_historias import escanear_videos_disponibles
                return self._json({"ok": True, "videos": escanear_videos_disponibles()})
            except Exception as ex:
                return self._json({"ok": False, "videos": [], "error": str(ex)})

        if u.path == "/api/txts":
            carpeta = unquote(q.get("carpeta", [""])[0])
            datos = listar_txts(carpeta)
            if datos is None:
                return self._json({"ok": False, "msg": "esa carpeta no existe"}, 400)
            return self._json({"ok": True, **datos})
        if u.path == "/api/voz/configs":
            return self._json({"configs": [
                {"id": k, "nombre": v[0], "listo": v[1].is_file()}
                for k, v in AI33_CONFIGS.items()]})
        if u.path == "/api/recorte/presets":
            return self._json({"presets": [{"id": p, "nombre": n}
                                           for p, n in RECORTE_PRESETS]})
        if u.path == "/api/estado":
            return self._json(estado_actual())
        if u.path == "/api/job":
            clave = unquote(q.get("ruta", [""])[0])
            j = _job_serial(clave)
            return self._json(j or {"estado": None, "linea": ""})
        if u.path == "/api/videos":
            carpeta = unquote(q.get("carpeta", [""])[0])
            rec = q.get("rec", ["1"])[0] != "0"
            datos = listar_videos(carpeta, rec)
            if datos is None:
                return self._json({"ok": False, "msg": "esa carpeta no existe"}, 400)
            return self._json({"ok": True, **datos})
        if u.path == "/api/abrir":
            ruta = Path(unquote(q.get("ruta", [""])[0]))
            if (_dentro_de_nicho(ruta) or ruta.exists()) and ruta.exists():
                self._abrir(ruta)
                return self._json({"ok": True})
            return self._json({"ok": False}, 400)

        if u.path == "/api/dashboard/metricas":
            try:
                import dashboard_metricas
                return self._json(dashboard_metricas.obtener_metricas_dashboard())
            except Exception as e:
                return self._json({"ok": False, "error": str(e)}, 500)

        if u.path == "/api/descargar/scan":
            ruta = unquote(q.get("ruta", [""])[0])
            ok, msg, datos = escanear_enlaces_descarga(ruta)
            return self._json({"ok": ok, "msg": msg, **datos}, 200 if ok else 400)

        if u.path == "/api/subtitulos/estilos":
            try:
                from subtitulos_estilos import listar_estilos
                return self._json({"estilos": listar_estilos()})
            except Exception:
                return self._json({"estilos": []})

        if u.path == "/api/nicho/subtitulos_config":
            n_id = q.get("nicho", [None])[0] or q.get("id", [None])[0]
            ruta_p = q.get("ruta", [None])[0]
            target_dir = None
            if ruta_p:
                p_c = Path(_limpiar_ruta(unquote(ruta_p))).resolve()
                if p_c.is_dir(): target_dir = p_c
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            target_dir = Path(nu.get("ruta", "")).resolve()
                            break
                except Exception: pass
            cfg_file = (target_dir / "config_nicho.json") if target_dir else (CARPETA_PROYECTOS / "config_canal.json")
            estilo = "capcut_karaoke"
            activos = True
            if cfg_file.is_file():
                try:
                    with open(cfg_file, "r", encoding="utf-8") as f:
                        d = json.load(f)
                        estilo = d.get("estilo_subtitulos", estilo)
                        activos = d.get("subtitulos_activos", activos)
                except Exception: pass
            return self._json({"ok": True, "estilo_subtitulos": estilo, "subtitulos_activos": activos})

        if u.path == "/api/nicho/voz_config":
            n_id = q.get("nicho", [None])[0] or q.get("id", [None])[0]
            ruta_p = q.get("ruta", [None])[0]
            target_dir = None
            if ruta_p:
                p_c = Path(_limpiar_ruta(unquote(ruta_p))).resolve()
                if p_c.is_dir(): target_dir = p_c
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            target_dir = Path(nu.get("ruta", "")).resolve()
                            break
                except Exception: pass
            cfg, ruta_cfg = resolver_config_ai33(target_dir)
            api_k = cfg.get("API_KEY", "") if cfg else ""
            v_id = cfg.get("VOICE_ID", "clone_2618875") if cfg else "clone_2618875"
            spd = cfg.get("SPEED", "1.0") if cfg else "1.0"
            return self._json({
                "ok": True,
                "api_key": api_k,
                "voice_id": v_id,
                "speed": spd,
                "ruta_config": str(ruta_cfg) if ruta_cfg else "",
                "carpeta": str(target_dir or CARPETA_PROYECTOS)
            })

        if u.path == "/api/nicho/gemini_config":
            try:
                from core.diseccion_multimodal import obtener_info_gemini
                info = obtener_info_gemini()
                return self._json({"ok": True, **info})
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 500)

        if u.path == "/api/audio":
            ruta = unquote(q.get("ruta", [""])[0])
            p_aud = Path(_limpiar_ruta(ruta)).resolve()
            if p_aud.is_file():
                ext = p_aud.suffix.lower()
                mime = "audio/mpeg" if ext == ".mp3" else ("audio/wav" if ext == ".wav" else "audio/mp4")
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(p_aud.stat().st_size))
                self.end_headers()
                try:
                    with open(p_aud, "rb") as fa:
                        self.wfile.write(fa.read())
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                return
            return self._json({"error": "audio no encontrado"}, 404)

        if u.path == "/api/flowbatch/estado":
            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                ahora_ts = time.time()
                visto_ts = float(data.get("extension_seen_at") or 0.0)
                jobs = data.get("jobs", [])
                ext_info = data.get("extension_info", {})

                # Proyectar versión ultraligera de jobs para la UI (sin prompts ni datos pesados)
                jobs_ui = []
                for j in jobs:
                    j_min = {
                        "job_id": j.get("job_id"),
                        "profile_id": j.get("profile_id", ""),
                        "titulo": j.get("titulo", ""),
                        "tipo_trabajo": j.get("tipo_trabajo", ""),
                        "estado": j.get("estado", ""),
                        "carpeta_proyecto": j.get("carpeta_proyecto", ""),
                        "final_dir": j.get("final_dir", ""),
                        "total": j.get("total", 0),
                        "start_num": j.get("start_num"),
                        "progreso": j.get("progreso", {}),
                        "created_at": j.get("created_at", ""),
                        "logs": (j.get("logs") or [])[-6:],
                    }
                    jobs_ui.append(j_min)

                return self._json({
                    "ok": True,
                    "extension_online": (ahora_ts - visto_ts) < 45.0 if visto_ts else False,
                    "extension_seen_at": visto_ts,
                    "last_profile_id": ext_info.get("last_profile_id", ""),
                    "last_extension_id": ext_info.get("last_extension_id", ""),
                    "pendientes": sum(1 for j in jobs if j.get("estado") in ("pendiente", "despachado")),
                    "en_proceso": sum(1 for j in jobs if j.get("estado") == "en_proceso"),
                    "completados": sum(1 for j in jobs if j.get("estado") == "completado"),
                    "jobs": jobs_ui,
                    "downloads_root": str(USER_DOWNLOADS),
                })

        if u.path == "/api/flowbatch/siguiente":
            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                ahora_ts = time.time()
                data["extension_seen_at"] = ahora_ts
                q = parse_qs(u.query)
                req_profile_id = (q.get("profile_id", [""])[0] or "").strip()
                req_ext_id = (q.get("extension_id", [""])[0] or "").strip()
                if req_profile_id or req_ext_id:
                    ext_info = data.setdefault("extension_info", {})
                    if req_profile_id:
                        ext_info["last_profile_id"] = req_profile_id
                    if req_ext_id:
                        ext_info["last_extension_id"] = req_ext_id

                jobs = data.get("jobs", [])
                # Si un job quedo despachado >25s sin iniciar ni reportar, devolverlo a pendiente
                for j in jobs:
                    if j.get("estado") == "despachado":
                        disp_ts = float(j.get("dispatched_ts") or 0.0)
                        if ahora_ts - disp_ts > 25.0:
                            j["estado"] = "pendiente"

                # Auto-recuperación de jobs que finalizaron en disco o quedaron en 99% sin enviar DONE
                for j in jobs:
                    if j.get("estado") == "en_proceso":
                        prog = j.get("progreso") or {}
                        num_act = int(prog.get("num") or 0)
                        tot_exp = int(j.get("total") or 1)
                        pct_act = int(prog.get("pct") or 0)
                        origen_txt = str(j.get("origen", "")).lower()
                        titulo_txt = str(j.get("titulo", "")).lower()
                        es_ref = "referencias" in origen_txt or titulo_txt.startswith("referencias")
                        fin_d = j.get("final_dir") or j.get("staging_dir")
                        if fin_d:
                            p_veo = Path(fin_d)
                            if es_ref:
                                _fb_mover_descargas_job(j)
                                tiene_p1 = any((p_veo / f"p1{ext}").is_file() for ext in (".jpg", ".jpeg", ".png"))
                                if tiene_p1 and (pct_act >= 90 or num_act >= tot_exp):
                                    j["estado"] = "completado"
                                    j["finished_at"] = _fb_ahora()
                                    j["progreso"]["pct"] = 100
                                    j["progreso"]["text"] = f"Finalizado: {tot_exp} OK (verificado en disco)"
                                    _fb_append_log(j, "ok", "Auto-completado: referencias verificadas en disco.")

                # Comprobar si este perfil específico ya tiene un trabajo en proceso
                hay_en_proceso = any(
                    j.get("estado") == "en_proceso" and (
                        not req_profile_id
                        or not j.get("profile_id")
                        or j.get("profile_id") == req_profile_id
                    )
                    for j in jobs
                )

                siguiente = None
                if not hay_en_proceso:
                    for j in jobs:
                        if j.get("estado") == "pendiente":
                            job_prof = (j.get("profile_id") or "").strip()
                            # Filtrar cola: entregar únicamente trabajos con estado pendiente asignados
                            # a ese profile_id (o trabajos sin asignar)
                            if not job_prof or not req_profile_id or job_prof == req_profile_id:
                                if not job_prof and req_profile_id:
                                    j["profile_id"] = req_profile_id
                                j["estado"] = "despachado"
                                j["dispatched_ts"] = ahora_ts
                                j["dispatched_at"] = _fb_ahora()
                                _fb_append_log(j, "info", f"Trabajo entregado a FlowBatch Pro (perfil: {req_profile_id or 'default'}).")

                                # max_retries = 0 por contrato para mapas (evitar gasto de créditos innecesario)
                                max_retries = int(j.get("max_retries", 0)) if j.get("max_retries") is not None else 0

                                # Cargar o refrescar ref_images desde disco si existen
                                ref_images = dict(j.get("ref_images") or {})
                                p_proy_raw = j.get("carpeta_proyecto") or j.get("final_dir") or j.get("staging_dir") or ""
                                p_raiz = _resolver_raiz_proyecto(p_proy_raw) if p_proy_raw else None

                                if p_raiz and p_raiz.is_dir():
                                    es_trabajo_video = (j.get("mode") == "video") or (j.get("tipo_trabajo") == "video")
                                    p_dest = _determinar_carpeta_destino_medios(p_raiz, es_video=es_trabajo_video)
                                    p_dest.mkdir(parents=True, exist_ok=True)

                                    # Cargar referencias buscando de manera abierta en todo el guión
                                    for num in (1, 2, 3):
                                        key = f"P{num}"
                                        f_ref = _buscar_referencia_personaje(p_raiz, num)
                                        if f_ref and f_ref.is_file():
                                            try:
                                                mime = "image/png" if f_ref.suffix.lower() == ".png" else "image/jpeg"
                                                b64 = base64.b64encode(f_ref.read_bytes()).decode("ascii")
                                                ref_images[key] = f"data:{mime};base64,{b64}"
                                            except Exception as e_b64:
                                                print(f"[AVISO] Error leyendo ref {f_ref}: {e_b64}")

                                # Recalcular start_num en caliente según los archivos en disco (imágenes o videos)
                                es_trabajo_video = (j.get("mode") == "video") or (j.get("tipo_trabajo") == "video")
                                total_elementos = len(j.get("items") or j.get("prompts") or [])
                                if p_raiz and p_raiz.is_dir():
                                    if es_trabajo_video:
                                        escenas_obj = [it.get("scene_num") or it.get("num") for it in j.get("items", []) if isinstance(it, dict)]
                                        start_num_disco = _calcular_start_num_videos(p_raiz, total_elementos, escenas_objetivo=escenas_obj)
                                    else:
                                        start_num_disco = _calcular_start_num_imagenes(p_raiz, total_elementos)
                                else:
                                    start_num_disco = 1

                                start_num = j.get("start_num")
                                if start_num is None:
                                    start_num = start_num_disco
                                else:
                                    start_num = int(start_num)
                                    if es_trabajo_video:
                                        escenas_obj = [it.get("scene_num") or it.get("num") for it in j.get("items", []) if isinstance(it, dict)]
                                        if start_num in escenas_obj:
                                            start_num = escenas_obj.index(start_num) + 1
                                    if start_num_disco > start_num:
                                        start_num = start_num_disco

                                if total_elementos and start_num > total_elementos:
                                    start_num = total_elementos

                                j["start_num"] = start_num

                                siguiente = {
                                    "job_id": j["job_id"],
                                    "profile_id": j.get("profile_id") or req_profile_id,
                                    "mode": "video" if es_trabajo_video else "image",
                                    "tipo_trabajo": j.get("tipo_trabajo", "video" if es_trabajo_video else "escenas"),
                                    "prompts": j.get("prompts", []),
                                    "items": j.get("items", []),
                                    "start_num": start_num,
                                    "startNum": start_num,
                                    "folder": j.get("folder_rel") or "veo",
                                    "prefix": j.get("prefix", ""),
                                    "quality": j.get("quality", "360p" if es_trabajo_video else "1k"),
                                    "gap_sec": j.get("gap_sec", 25 if es_trabajo_video else 15),
                                    "max_retries": max_retries,
                                    "autodl": True,
                                }
                                if j.get("images"):
                                    siguiente["images"] = j["images"]
                                if ref_images:
                                    siguiente["ref_images"] = ref_images
                                    j["ref_images"] = ref_images
                                break

                _fb_guardar_cola(data)
                return self._json({"ok": True, "has_job": bool(siguiente), "job": siguiente})

        if u.path in ("/nexor.png", "/favicon.ico", "/nexor.ico"):
            f_img = AQUI / ("nexor.png" if "png" in u.path else "nexor.ico")
            if f_img.is_file():
                mime = "image/png" if "png" in u.path else "image/x-icon"
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(f_img.stat().st_size))
                self.end_headers()
                try:
                    with open(f_img, "rb") as fi:
                        self.wfile.write(fi.read())
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                return

        self._json({"error": "no encontrado"}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path in ("/api/sistema/cerrar", "/api/sistema/apagar", "/api/sistema/detener"):
            def apagar_proceso():
                time.sleep(0.4)
                global SERVIDOR_HTTP
                if SERVIDOR_HTTP:
                    try:
                        SERVIDOR_HTTP.shutdown()
                        SERVIDOR_HTTP.server_close()
                    except Exception:
                        pass
                os._exit(0)

            threading.Thread(target=apagar_proceso, daemon=True).start()
            return self._json({"ok": True, "msg": "Servidor apagado correctamente"})

        if u.path == "/api/sistema/aplicar_actualizacion":
            body = self._leer_json()
            download_url = body.get("download_url", "")
            try:
                import core.actualizador as actualizador
                importlib.reload(actualizador)
                res = actualizador.aplicar_actualizacion(download_url=download_url)
                return self._json(res, 200 if res.get("ok") else 400)
            except Exception as e:
                return self._json({"ok": False, "msg": str(e)}, 500)

        if u.path == "/api/sistema/reiniciar":
            try:
                import core.actualizador as actualizador
                importlib.reload(actualizador)
                actualizador.programar_reinicio_servidor(AQUI)
                return self._json({"ok": True, "msg": "Reinicio del servidor programado correctamente"})
            except Exception as e:
                return self._json({"ok": False, "msg": str(e)}, 500)

        if u.path == "/api/licencia/activar":
            body = self._leer_json()
            email = body.get("email", "").strip()
            cliente = body.get("cliente", "").strip()
            codigo = body.get("codigo", body.get("clave", "")).strip()
            import licencia
            import importlib
            importlib.reload(licencia)
            ok, msg = licencia.registrar_licencia_cliente(email, cliente, codigo)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/licencia/emitir":
            body = self._leer_json()
            cliente = body.get("cliente", "").strip()
            email = body.get("email", "").strip().lower()
            notificar_webhook = bool(body.get("notificar_webhook", True))

            if not cliente or not email or "@" not in email:
                return self._json({"ok": False, "msg": "Nombre y correo electronico valido requeridos."}, 400)

            try:
                from generar_codigo_cliente import calcular_codigo_licencia, guardar_registro_licencia
            except ImportError:
                import sys
                sys.path.insert(0, str(AQUI / "admin_licencias"))
                from generar_codigo_cliente import calcular_codigo_licencia, guardar_registro_licencia

            codigo = calcular_codigo_licencia(email, cliente)
            guardar_registro_licencia(cliente, email, codigo)

            # Sincronizar copia en AQUI / licencias_emitidas.json (1 sola linea por cliente)
            for dest_log in [AQUI / "licencias_emitidas.json"]:
                try:
                    regs = []
                    if dest_log.is_file():
                        regs = json.loads(dest_log.read_text(encoding="utf-8"))
                    e_norm = (email or "").strip().lower()
                    enc = False
                    for r in regs:
                        if r.get("email", "").strip().lower() == e_norm:
                            r["fecha"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            r["cliente"] = cliente
                            r["codigo_licencia"] = codigo
                            r["estado"] = "emitida"
                            enc = True
                            break
                    if not enc:
                        regs.append({
                            "fecha": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "cliente": cliente,
                            "email": email,
                            "codigo_licencia": codigo,
                            "estado": "emitida"
                        })
                    dest_log.write_text(json.dumps(regs, indent=2, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass

            ver_nexor, exe_resuelto = _resolver_instalador_nexor()
            exe_nombre = exe_resuelto.name if exe_resuelto else f"Instalador_NEXOR_v{ver_nexor}_Setup.exe"

            # Notificar al Webhook de Google Apps Script si esta habilitado
            if notificar_webhook:
                try:
                    import licencia
                    licencia._notificar_david_async({
                        "evento": "LICENCIA_EMITIDA_ADMIN",
                        "cliente": cliente,
                        "email": email,
                        "codigo_licencia": codigo,
                        "fecha": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "software": f"NEXOR v{ver_nexor}"
                    })
                except Exception as ex:
                    print(f"Error al notificar webhook: {ex}")

            primer_nombre = cliente.split()[0]
            mensaje_cliente = (
                f"🌟 ¡Hola {primer_nombre}! Gracias por adquirir NEXOR — Sistema Integrado de Replicación de Canales.\n\n"
                f"Aquí tienes tus datos oficiales de acceso y licencia:\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"👤 Nombre Registrado : {cliente}\n"
                f"📧 Correo de Compra  : {email}\n"
                f"🔑 Código de Licencia: {codigo}\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📋 CÓMO INSTALAR Y ACTIVAR TU SISTEMA:\n"
                f"1. Ejecuta el instalador oficial: {exe_nombre}\n"
                f"2. Sigue los pasos del asistente (se instalará de forma silenciosa en tu computadora sin pedir claves de administrador).\n"
                f"3. Al terminar, abre el acceso directo 'NEXOR' de tu escritorio.\n"
                f"4. En la pantalla de Activación que se abrirá en tu navegador, ingresa tus 3 datos tal como aparecen arriba:\n"
                f"   • Correo Electrónico: {email}\n"
                f"   • Nombre del Comprador: {cliente}\n"
                f"   • Código de Acceso / Licencia: {codigo}\n"
                f"5. Haz clic en el botón azul: 'Registrar y Activar en este Equipo'.\n\n"
                f"¡Listo! Tu sistema NEXOR quedará activado de por vida en tu computadora."
            )

            return self._json({
                "ok": True,
                "cliente": cliente,
                "email": email,
                "codigo": codigo,
                "mensaje_cliente": mensaje_cliente,
                "instalador_nombre": exe_nombre,
                "instalador_url": "/api/licencia/descargar_instalador"
            })

        if u.path == "/api/licencia/abrir_carpeta":
            try:
                target_dir = Path(r"C:\Users\Usuario\Documents\DAVID\Generador_Universal\dist_instalador")
                if not target_dir.is_dir():
                    target_dir = Path(r"C:\Users\Usuario\Documents\DAVID")
                os.startfile(str(target_dir))
                return self._json({"ok": True})
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 400)

        if u.path == "/api/hardware/recalibrar":
            try:
                import hardware_tuner
                info = hardware_tuner.calibrar_hardware(forzar=True)
                return self._json({"ok": True, "datos": info})
            except Exception as e:
                return self._json({"ok": False, "msg": str(e)}, 500)
        if u.path == "/api/montar":
            nicho = NICHOS.get(q.get("nicho", [NICHO_DEF])[0], {})
            subs = q.get("subs", [None])[0]
            sfx = q.get("sfx", [None])[0]
            estilo_preset = q.get("estilo_preset", [None])[0]
            ok, msg = lanzar_montaje(nicho, unquote(q.get("ruta", [""])[0]), subs=subs, sfx=sfx, estilo_preset=estilo_preset)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/marcar":
            ruta = Path(unquote(q.get("ruta", [""])[0])).resolve()
            publicar = q.get("publicado", ["1"])[0] == "1"
            if not _dentro_de_nicho(ruta) or not ruta.is_dir():
                return self._json({"ok": False, "msg": "ruta inválida"}, 400)
            marca = ruta / MARCADOR
            if publicar:
                marca.write_text("publicado desde el panel\n", encoding="utf-8")
            elif marca.exists():
                marca.unlink()
            return self._json({"ok": True, "publicado": publicar})
        if u.path == "/api/ebook/generar":
            ok, msg = lanzar_generar_ebook(NICHOS["ebook"], unquote(q.get("ruta", [""])[0]))
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/ebook/nuevo":
            ok, msg, ruta = crear_libro_ebook(NICHOS["ebook"], unquote(q.get("nombre", [""])[0]))
            return self._json({"ok": ok, "msg": msg, "ruta": ruta}, 200 if ok else 400)
        if u.path in ("/api/nicho/crear_guiones", "/api/ecos/crear_guiones", "/api/videos/crear_guiones"):
            body = self._leer_json()
            texto = body.get("texto", "")
            dis_guion_raw = body.get("dis_guion") or ""
            gen_audio = bool(body.get("generar_audio", True))
            segmentar = bool(body.get("segmentar", True))
            gen_prompts = bool(body.get("generar_prompts", True))
            ruta_destino = body.get("ruta_destino") or body.get("carpeta_destino")
            nicho_id = body.get("nicho_id") or body.get("nicho") or "ecos"
            raiz_dest = None
            if ruta_destino:
                p_dest = Path(_limpiar_ruta(ruta_destino)).resolve()
                if p_dest.is_dir(): raiz_dest = p_dest
            elif nicho_id in NICHOS:
                raiz_dest = Path(NICHOS[nicho_id]["raiz"]).resolve()
            else:
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == nicho_id:
                            raiz_dest = Path(nu["ruta"]).resolve()
                            break
                except Exception: pass

            nicho_ref = NICHOS.get(nicho_id, NICHOS["ecos"])
            if raiz_dest:
                for nid, ncfg in NICHOS.items():
                    if Path(ncfg.get("raiz", "")).resolve() == raiz_dest:
                        nicho_ref = ncfg
                        nicho_id = nid
                        break

            ok, msg = lanzar_crear_guiones_lote(nicho_ref, texto, gen_audio, segmentar, raiz_destino=raiz_dest, texto_dis_guion=dis_guion_raw, gen_prompts=gen_prompts)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path in ("/api/ecos/cortar", "/api/videos/cortar"):
            limpiar = q.get("limpiar", ["1"])[0] == "1"
            subtitulos = q.get("subtitulos", ["1"])[0] == "1"
            estilo_sub = q.get("estilo", [None])[0]
            ok, msg = lanzar_cortar_ecos(NICHOS["ecos"], unquote(q.get("ruta", [""])[0]), limpiar, subtitulos, estilo_sub)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/videos/generar_audio_carpeta":
            body = self._leer_json()
            ruta = body.get("ruta") or q.get("ruta", [""])[0]
            p = Path(_limpiar_ruta(ruta)).resolve()
            if not p.is_dir() or not _dentro_de_nicho(p):
                return self._json({"ok": False, "msg": "Carpeta inválida"}, 400)
            guion_f = p / "guion.txt"
            if not guion_f.is_file():
                return self._json({"ok": False, "msg": "No existe guion.txt en esta carpeta"}, 400)
            cfg, _ = resolver_config_ai33(p)
            if not cfg or not cfg.get("API_KEY"):
                return self._json({"ok": False, "msg": "Configura primero tu API_KEY de ai33.pro"}, 400)
            texto = guion_f.read_text(encoding="utf-8", errors="ignore").strip()
            if not texto:
                return self._json({"ok": False, "msg": "El guion.txt está vacío"}, 400)
            clave = str(p)
            log = collections.deque(maxlen=60)
            JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time()}

            def worker_aud():
                log.append(f"Generando audio para {p.name} con IA...")
                try:
                    sys.path.insert(0, str(AQUI / "ai33"))
                    import tts
                    task_id, direct = tts.crear_tarea(cfg, texto)
                    url = direct or tts.esperar_audio(cfg, task_id)
                    aud_p = p / "aud.mp3"
                    tts.descargar(url, str(aud_p))
                    if p.parent.is_dir():
                        shutil.copy2(aud_p, p.parent / f"{p.name}.mp3")
                    log.append(f"¡Audio guardado en {p.name}/aud.mp3!")
                    script_seg = Path(NICHOS["ecos"].get("codigo", AQUI / "ecos")) / "segmentar_guion.py"
                    if script_seg.is_file():
                        subprocess.run([sys.executable, str(script_seg), str(p)], capture_output=True)
                        log.append("Sincronía actualizada.")

                    # Generar prompts con Gemini IA si no existen o están vacíos
                    img_f = p / "imagen.txt"
                    if not img_f.is_file() or img_f.stat().st_size == 0:
                        try:
                            from core.generador_prompts_gemini import generar_prompts_para_proyecto
                            ok_p, msg_p, info_p = generar_prompts_para_proyecto(p, p.parent)
                            if ok_p:
                                log.append(f"¡Prompts generados para {p.name}! (imagen.txt y movimiento.txt)")
                            else:
                                log.append(f"Aviso prompts: {msg_p}")
                        except Exception as ep:
                            log.append(f"Aviso prompts: {ep}")

                    JOBS[clave]["estado"] = "ok"
                except Exception as e:
                    log.append(f"Error generando audio: {e}")
                    JOBS[clave]["estado"] = "error"

            threading.Thread(target=worker_aud, daemon=True).start()
            return self._json({"ok": True, "msg": f"Generando audio para {p.name}..."})

        if u.path == "/api/analizar_nicho":
            body = self._leer_json()
            urls = body.get("urls") or []
            if not urls and body.get("url"):
                urls = [body.get("url")]
            if not urls and body.get("texto"):
                import re
                lineas = str(body.get("texto", "")).splitlines()
                urls = []
                for l in lineas:
                    urls.extend(re.findall(r'https?://[^\s"\'<>]+', l))
            elif not urls and body.get("ruta"):
                p = Path(_limpiar_ruta(body.get("ruta"))).expanduser().resolve()
                from descargar_videos import extraer_urls_de_archivo, buscar_txt_con_enlaces
                if p.is_file():
                    urls = extraer_urls_de_archivo(p)
                elif p.is_dir():
                    _, urls = buscar_txt_con_enlaces(p)

            import analizar_nicho
            import importlib
            importlib.reload(analizar_nicho)
            clave_gemini = body.get("clave_gemini") or body.get("gemini_key")
            res = analizar_nicho.analizar_enlaces(urls, clave_gemini=clave_gemini)
            return self._json(res, 200 if res.get("ok") else 400)

        if u.path == "/api/nicho/generar_guiones_ia":
            body = self._leer_json()
            from core.generador_guiones_ia import generar_tanda_guiones_ia
            nicho_p = Path(_limpiar_ruta(body.get("ruta_nicho") or body.get("ruta") or "")).resolve()
            cant = int(body.get("cantidad", 3))
            dur = int(body.get("duracion_segundos", 60))
            form = body.get("formato", "shorts")
            tema = body.get("tema") or body.get("tema_libre") or ""
            k = body.get("clave_gemini") or body.get("api_key")
            urls_ref = body.get("urls") or body.get("urls_referencia") or []
            ok, msg, guiones, raw = generar_tanda_guiones_ia(nicho_p, cantidad=cant, duracion_segundos=dur, formato=form, tema_libre=tema, api_key=k, urls_referencia=urls_ref)
            return self._json({"ok": ok, "msg": msg, "guiones": guiones, "texto_crudo": raw, "total": len(guiones)}, 200 if ok else 400)

        if u.path == "/api/nicho/guardar_guiones_lote":
            body = self._leer_json()
            from core.generador_guiones_ia import guardar_guiones_en_archivo_nicho, parsear_guiones_generados
            nicho_p = Path(_limpiar_ruta(body.get("ruta_nicho") or body.get("ruta") or "")).resolve()
            texto = body.get("texto") or body.get("guiones_texto") or ""
            modo = body.get("modo", "apendizar")
            crear_proy = bool(body.get("crear_proyectos", False))
            guiones = body.get("guiones")
            if not guiones and texto:
                guiones = parsear_guiones_generados(texto)
            ok, msg = guardar_guiones_en_archivo_nicho(nicho_p, guiones, modo=modo)
            if ok and crear_proy:
                nicho_id = body.get("nicho_id") or "ecos"
                nicho_ref = NICHOS.get(nicho_id, NICHOS["ecos"])
                ok_lote, msg_lote = lanzar_crear_guiones_lote(nicho_ref, texto, gen_audio=True, segmentar=True, raiz_destino=nicho_p, gen_prompts=True)
                return self._json({"ok": ok_lote, "msg": f"{msg}. Proyectos: {msg_lote}"}, 200 if ok_lote else 400)
            return self._json({"ok": ok, "msg": msg, "total": len(guiones)}, 200 if ok else 400)

        if u.path == "/api/nicho/gemini_config":
            try:
                from core.diseccion_multimodal import obtener_info_gemini, guardar_clave_gemini
                if self.command == "GET":
                    info = obtener_info_gemini()
                    return self._json({"ok": True, **info})
                else:
                    body = self._leer_json()
                    k_nueva = (body.get("api_key") or body.get("gemini_api_key") or "").strip()
                    guardar_clave_gemini(k_nueva)
                    info = obtener_info_gemini()
                    return self._json({"ok": True, **info})
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 500)

        if u.path == "/api/fuente/instalar":
            from subtitulos_estilos import instalar_fuente_en_windows
            res = instalar_fuente_en_windows()
            return self._json(res, 200 if res.get("ok") else 400)

        if u.path == "/api/nicho/sugerir_nombre":
            body = self._leer_json()
            canal = body.get("canal", "")
            tipo_nicho = body.get("tipo_nicho", "")
            from gestor_nichos import sugerir_nombre_proyecto
            return self._json({"ok": True, "sugerencia": sugerir_nombre_proyecto(canal, tipo_nicho)})

        if u.path == "/api/nicho/crear_proyecto":
            body = self._leer_json()
            nombre = body.get("nombre", "").strip()
            analisis = body.get("analisis", {})
            formato = body.get("formato", "vertical")
            extraer = bool(body.get("extraer_audio", True))
            estilo_sub = body.get("estilo_subtitulos", "capcut_karaoke")
            api_key = (body.get("api_key") or "").strip().strip("'\"")
            voice_id = (body.get("voice_id") or "").strip().strip("'\"")
            speed = (body.get("speed") or "1.0").strip().strip("'\"")
            import gestor_nichos
            import importlib
            importlib.reload(gestor_nichos)
            res = gestor_nichos.crear_proyecto_nicho(
                nombre, analisis, 
                extraer_audio=extraer, 
                estilo_subtitulos=estilo_sub,
                api_key=api_key,
                voice_id=voice_id,
                speed=speed,
                formato=formato
            )
            return self._json(res, 200 if res.get("ok") else 400)

        if u.path == "/api/nicho/toggle_estado":
            body = self._leer_json()
            nicho_id = body.get("id", "").strip()
            activo = body.get("activo", None)
            import gestor_nichos
            import importlib
            importlib.reload(gestor_nichos)
            ok, msg, canal = gestor_nichos.toggle_estado_nicho(nicho_id, activo)
            return self._json({"ok": ok, "msg": msg, "canal": canal}, 200 if ok else 400)

        if u.path == "/api/nicho/eliminar":
            body = self._leer_json()
            nicho_id = body.get("id", "").strip()
            borrar_archivos = bool(body.get("borrar_archivos", False))
            import gestor_nichos
            import importlib
            importlib.reload(gestor_nichos)
            ok, msg = gestor_nichos.eliminar_nicho_usuario(nicho_id, borrar_archivos=borrar_archivos)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/nicho/subtitulos_config":
            body = self._leer_json()
            n_id = body.get("nicho_id") or body.get("nicho")
            ruta_p = body.get("ruta")
            estilo = body.get("estilo_subtitulos")
            activos = body.get("subtitulos_activos")

            target_dir = None
            if ruta_p:
                p = Path(_limpiar_ruta(ruta_p)).resolve()
                if p.is_dir():
                    target_dir = p
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario, guardar_nicho_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            p = Path(nu.get("ruta", "")).resolve()
                            if p.is_dir():
                                target_dir = p
                            if estilo:
                                nu["estilo_subtitulos"] = estilo
                            if activos is not None:
                                nu["subtitulos_activos"] = bool(activos)
                            guardar_nicho_usuario(nu)
                            break
                except Exception:
                    pass

            cfg_file = (target_dir / "config_nicho.json") if target_dir else (CARPETA_PROYECTOS / "config_canal.json")
            data = {}
            if cfg_file.is_file():
                try:
                    with open(cfg_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except Exception:
                    data = {}
            if estilo:
                data["estilo_subtitulos"] = estilo
            if activos is not None:
                data["subtitulos_activos"] = bool(activos)
            try:
                cfg_file.parent.mkdir(parents=True, exist_ok=True)
                with open(cfg_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
            return self._json({"ok": True, "msg": "Configuracion de subtitulos guardada con exito."})

        if u.path == "/api/dashboard/guardar_cuentas":
            body = self._leer_json()
            try:
                import dashboard_metricas
                dashboard_metricas.guardar_cuentas_redes(body)
                return self._json({"ok": True, "msg": "Cuentas guardadas con exito."})
            except Exception as e:
                return self._json({"ok": False, "msg": str(e)}, 500)

        if u.path == "/api/descargar/guardar":
            body = self._leer_json()
            carpeta = body.get("carpeta") or unquote(q.get("carpeta", [""])[0])
            urls = body.get("urls") if body.get("urls") is not None else body.get("texto", "")
            ok, msg, datos = guardar_enlaces_descarga(carpeta, urls)
            return self._json({"ok": ok, "msg": msg, **datos}, 200 if ok else 400)

        if u.path == "/api/descargar/iniciar":
            body = self._leer_json()
            ruta = body.get("ruta", "")
            ok, msg = lanzar_descarga_videos(ruta)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/transcribir/enlaces":
            body = self._leer_json()
            enlaces = body.get("enlaces", "")
            carpeta = body.get("carpeta_salida", "")
            idioma = body.get("idioma", "es")
            guardar_ind = bool(body.get("guardar_individuales", True))
            guardar_comb = bool(body.get("guardar_combinado", True))
            nom_comb = body.get("nombre_combinado", "_GUIONES.txt")
            try:
                import transcriptor_metadata
                res = transcriptor_metadata.transcribir_lote_enlaces(
                    urls=enlaces,
                    carpeta_salida=carpeta,
                    idioma_pref=idioma,
                    guardar_archivos=True,
                    guardar_individuales=guardar_ind,
                    guardar_combinado=guardar_comb,
                    nombre_combinado=nom_comb
                )
                return self._json(res, 200 if res.get("ok") else 400)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)}, 500)

        if u.path == "/api/transcribir/guardar_guion":
            body = self._leer_json()
            ruta_archivo = body.get("ruta_archivo", "")
            contenido = body.get("contenido", "")
            if not ruta_archivo or not contenido:
                return self._json({"ok": False, "error": "Falta ruta de archivo o contenido"}, 400)
            try:
                p = Path(ruta_archivo).resolve()
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(contenido, encoding="utf-8-sig")
                return self._json({"ok": True, "msg": "Guion guardado correctamente", "ruta": str(p)})
            except Exception as ex:
                return self._json({"ok": False, "error": str(ex)}, 500)

        if u.path == "/api/nicho/voz_config":
            body = self._leer_json()
            n_id = body.get("nicho_id") or body.get("nicho")
            ruta_p = body.get("ruta")
            api_key = (body.get("api_key") or "").strip().strip("'\"")
            voice_id = (body.get("voice_id") or "").strip().strip("'\"")
            speed = (body.get("speed") or "1.0").strip().strip("'\"")
            if not api_key: return self._json({"ok": False, "msg": "La API Key no puede estar vacia."}, 400)
            if not voice_id: return self._json({"ok": False, "msg": "Debes especificar un ID de voz."}, 400)

            target_dir = None
            if ruta_p:
                p_c = Path(_limpiar_ruta(ruta_p)).resolve()
                if p_c.is_dir(): target_dir = p_c
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            target_dir = Path(nu.get("ruta", "")).resolve()
                            break
                except Exception: pass

            txt_cfg = f"""# ============================================================
#  ai33.pro (Text-To-Speech)  -  CONFIGURACION DE VOZ
# ============================================================
API_KEY={api_key}
VOICE_ID={voice_id}
SPEED={speed}
WITH_TRANSCRIPT=false
TTS_URL=https://api.ai33.pro/v3/text-to-speech
TASK_URL=https://api.ai33.pro/v3/task/{{task_id}}
TIMEOUT=300
"""
            if target_dir:
                (target_dir / "ai33_config.txt").write_text(txt_cfg, encoding="utf-8")
                # Actualizar también config_nicho.json si existe
                cfg_n_file = target_dir / "config_nicho.json"
                if cfg_n_file.is_file():
                    try:
                        import json
                        with open(cfg_n_file, "r", encoding="utf-8") as fn:
                            cn = json.load(fn)
                        cn["voice_id"] = voice_id
                        cn["api_key"] = api_key
                        cn["speed"] = speed
                        cn["voz_configurada"] = True
                        with open(cfg_n_file, "w", encoding="utf-8") as fn:
                            json.dump(cn, fn, ensure_ascii=False, indent=2)
                    except Exception: pass
            # Si corresponde a un nicho estándar, actualizar también su archivo específico en ai33/
            if n_id and n_id in AI33_CONFIGS:
                try:
                    AI33_CONFIGS[n_id][1].write_text(txt_cfg, encoding="utf-8")
                except Exception: pass
            elif not target_dir:
                # Solo si no se especificó nicho ni carpeta, se actualiza el fallback central
                (AQUI / "ai33" / "ai33_config.txt").write_text(txt_cfg, encoding="utf-8")
            return self._json({"ok": True, "msg": "Configuracion de voz guardada con exito."})

        if u.path in ("/api/ecos/segmentar", "/api/videos/segmentar"):
            ok, msg = lanzar_segmentar_ecos(NICHOS["ecos"],
                                            unquote(q.get("ruta", [""])[0]))
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path in ("/api/nicho/generar_prompts", "/api/ecos/generar_prompts", "/api/videos/generar_prompts"):
            ruta = unquote(q.get("ruta", [""])[0])
            if not ruta:
                try:
                    body = self._leer_json()
                    ruta = body.get("ruta", "")
                except Exception:
                    pass
            ok, msg = lanzar_generar_prompts_proyecto(ruta)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path in ("/api/ecos/generar_seo", "/api/videos/generar_seo"):
            ruta = unquote(q.get("ruta", [""])[0])
            if not ruta:
                try:
                    body = self._leer_json()
                    ruta = body.get("ruta", "")
                except Exception:
                    pass
            ok, msg = lanzar_generar_seo_proyecto(ruta)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path in ("/api/ecos/unir", "/api/videos/unir"):
            ok, msg = lanzar_unir_ecos(NICHOS["ecos"],
                                       unquote(q.get("ruta", [""])[0]))
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path in ("/api/ecos/subtitulos", "/api/videos/subtitulos"):
            ok, msg = lanzar_subtitulos_ecos(NICHOS["ecos"],
                                             unquote(q.get("ruta", [""])[0]))
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/mapas/bloque":
            bloque_raw = str(q.get("bloque", ["1"])[0]).strip().lower()
            ok, msg = lanzar_bloque_mapas(NICHOS["mapas"],
                                          unquote(q.get("ruta", [""])[0]),
                                          bloque=bloque_raw)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path in ("/api/mapas/segmentar", "/api/mapas/sincronizar"):
            ok, msg = lanzar_sincronizar_mapas(NICHOS["mapas"],
                                               unquote(q.get("ruta", [""])[0]))
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/peliculas/transcribir":
            idioma = unquote(q.get("idioma", ["zh"])[0]) or "zh"
            ok, msg = lanzar_transcribir(NICHOS["peliculas"],
                                         unquote(q.get("ruta", [""])[0]), idioma)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/transcribir_lote":
            body = self._leer_json()
            ok, msg = lanzar_transcribir_lote(
                body.get("carpeta", ""),
                body.get("rutas", []),
                (body.get("idioma") or "es"),
                (body.get("modelo") or "small"),
                bool(body.get("combinar", True)))
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path in ("/api/famosos/clips", "/api/famosos/extraer_clips"):
            aud = unquote(q.get("audio", [""])[0]).strip() or None
            ok, msg = lanzar_famosos_clips(NICHOS["famosos"],
                                           unquote(q.get("ruta", [""])[0]),
                                           aud)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path in ("/api/famosos/generar", "/api/famosos/producir"):
            try:
                dur = float(q.get("dur", ["3"])[0])
                clips = int(q.get("clips", ["3"])[0])
                formato = q.get("formato", ["face_crop"])[0]
                subtitulos = int(q.get("subtitulos", ["1"])[0])
            except ValueError:
                return self._json({"ok": False, "msg": "parámetros inválidos"}, 400)
            ok, msg = lanzar_famosos(NICHOS["famosos"],
                                     unquote(q.get("ruta", [""])[0]),
                                     unquote(q.get("audio", [""])[0]),
                                     dur=dur, clips=clips,
                                     formato=formato, subtitulos=subtitulos)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/voz/probar":
            body = self._leer_json()
            api_key = (body.get("api_key") or "").strip().strip("'\"")
            voice_id = (body.get("voice_id") or "").strip().strip("'\"")
            tts_url = (body.get("tts_url") or "https://api.ai33.pro/v3/text-to-speech").strip()
            if not api_key:
                return self._json({"ok": False, "msg": "La API Key no puede estar vacía."}, 400)
            if not voice_id:
                return self._json({"ok": False, "msg": "Debes especificar un ID de voz."}, 400)
            try:
                import sys
                sys.path.insert(0, str(AQUI / "ai33"))
                import tts
                cfg = {
                    "API_KEY": api_key,
                    "VOICE_ID": voice_id,
                    "TTS_URL": tts_url,
                    "SPEED": str(body.get("speed", "1.0")),
                    "TIMEOUT": "20"
                }
                task_id, direct = tts.crear_tarea(cfg, "Prueba de conexión exitosa.")
                return self._json({"ok": True, "msg": "¡Conexión exitosa con el servicio de voz!", "task_id": task_id})
            except Exception as e:
                return self._json({"ok": False, "msg": str(e)}, 400)

        if u.path == "/api/voz/generar":
            ok, msg = lanzar_voz(unquote(q.get("ruta", [""])[0]),
                                 q.get("nicho", ["ecos"])[0])
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/recorte/generar":
            ok, msg = lanzar_recorte(unquote(q.get("ruta", [""])[0]),
                                     q.get("nicho", ["medio"])[0],
                                     q.get("bordes", ["0"])[0] == "1",
                                     q.get("respiros", ["1"])[0] == "1")
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/personajes/generar":
            try:
                n = int(q.get("n", ["4"])[0])
            except ValueError:
                n = 4
            ok, msg = lanzar_personajes(unquote(q.get("ruta", [""])[0]), n)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/historias/cortar":
            try:
                body = self._leer_json()
                ruta = (body.get("ruta") or body.get("ruta_video") or "").strip()
                dur = float(body.get("duracion") or body.get("duracion_segmento") or 15.0)
                sub = (body.get("subcarpeta") or "historias").strip() or "historias"
                modo = (body.get("modo") or "rapido").strip()
                from core.cortar_historias import dividir_video_historias
                res = dividir_video_historias(ruta, duracion_segmento=dur, subcarpeta=sub, modo=modo)
                return self._json(res, 200 if res.get("ok") else 400)
            except Exception as ex:
                return self._json({"ok": False, "error": str(ex)}, 500)

        if u.path == "/api/historias/abrir_carpeta":
            try:
                body = self._leer_json() if self.command == "POST" else {}
                ruta = (body.get("ruta") or body.get("carpeta") or "").strip()
                if not ruta:
                    ruta = unquote(q.get("ruta", [""])[0])
                if ruta:
                    p = Path(_limpiar_ruta(ruta)).resolve()
                    if p.is_dir() or p.is_file():
                        target = p if p.is_dir() else p.parent
                        if sys.platform.startswith("win"):
                            os.startfile(str(target))
                        elif sys.platform == "darwin":
                            subprocess.run(["open", str(target)])
                        else:
                            subprocess.run(["xdg-open", str(target)])
                        return self._json({"ok": True})
                return self._json({"ok": False, "msg": "Ruta no encontrada"}, 400)
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 500)

        if u.path == "/api/cancelar":
            ok, msg = cancelar_proceso()
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)
        if u.path == "/api/mapas/enviar_flowbatch":
            body = self._leer_json()
            rutas = body.get("rutas") or body.get("proyectos") or []
            if isinstance(rutas, str):
                rutas = [rutas]
            rutas = _ordenar_rutas_numericas_asc(rutas)
            req_profile_id = str(body.get("profile_id") or "").strip()

            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                ext_info = data.get("extension_info", {})
                profile_id = req_profile_id or ext_info.get("last_profile_id", "")

                encolados = []
                omitidos = []
                total_prompts = 0

                for r in rutas:
                    p_proy = Path(_limpiar_ruta(r)).resolve()
                    if not p_proy.is_dir():
                        omitidos.append({"ruta": r, "motivo": "Carpeta no existe"})
                        continue

                    prompts, origen = _fb_parsear_prompts("", None, str(p_proy))
                    if not prompts:
                        omitidos.append({"ruta": r, "nombre": p_proy.name, "motivo": "No se encontró prompts.txt ni prompts válidos"})
                        continue

                    # Carpeta destino veo/ dentro del proyecto
                    dest_veo = p_proy / "veo"
                    dest_veo.mkdir(parents=True, exist_ok=True)

                    user_start_num = body.get("start_num")
                    cant_img_exist = _contar_imagenes_escenas_existentes(dest_veo)
                    if user_start_num is not None and str(user_start_num).strip():
                        try:
                            start_num = max(1, int(user_start_num))
                        except Exception:
                            start_num = (cant_img_exist + 1) if cant_img_exist > 0 else 1
                    else:
                        start_num = (cant_img_exist + 1) if cant_img_exist > 0 else 1
                    if prompts and start_num > len(prompts):
                        start_num = len(prompts)

                    job_id = f"fb_mapa_{int(time.time() * 1000)}_{len(encolados) + 1}"
                    dest_info = _fb_resolver_destino(str(dest_veo), job_id)

                    job = {
                        "job_id": job_id,
                        "profile_id": profile_id,
                        "titulo": f"Mapa: {p_proy.name}",
                        "origen": origen,
                        "prompts": prompts,
                        "total": len(prompts),
                        "start_num": start_num,
                        "folder_rel": dest_info["folder_rel"],
                        "staging_dir": dest_info["staging_dir"],
                        "final_dir": dest_info["final_dir"],
                        "needs_move": dest_info["needs_move"],
                        "prefix": "",
                        "quality": "1k",
                        "gap_sec": 15,
                        "max_retries": 0,
                        "estado": "pendiente",
                        "progreso": {
                            "done": cant_img_exist,
                            "total": len(prompts),
                            "pct": int(round((cant_img_exist / len(prompts)) * 100)) if prompts else 0,
                            "text": f"En cola esperando a FlowBatch Pro (inicia en #{start_num})..." if start_num > 1 else "En cola esperando a FlowBatch Pro...",
                            "num": start_num
                        },
                        "created_at": _fb_ahora(),
                        "logs": [{
                            "hora": datetime.datetime.now().strftime("%H:%M:%S"),
                            "level": "info",
                            "text": f"Lote de mapa encolado ({len(prompts)} prompts desde {origen}, inicia en #{start_num}) -> {dest_info['final_dir']}"
                        }],
                    }
                    data["jobs"].append(job)
                    encolados.append({
                        "job_id": job_id,
                        "nombre": p_proy.name,
                        "prompts": len(prompts),
                        "start_num": start_num,
                        "origen": origen,
                        "destino": dest_info["final_dir"],
                    })
                    total_prompts += len(prompts)

                # Purgar únicamente historial completado antiguo sin tocar jobs activos ni pendientes
                if len(data["jobs"]) > 100:
                    completados_hist = [j for j in data["jobs"] if j.get("estado") in ("completado", "cancelado", "error", "detenido")]
                    activos_o_pend = [j for j in data["jobs"] if j.get("estado") in ("pendiente", "despachado", "en_proceso")]
                    if len(completados_hist) > 30:
                        completados_hist = completados_hist[-30:]
                    data["jobs"] = completados_hist + activos_o_pend
                _fb_guardar_cola(data)

            return self._json({
                "ok": True,
                "profile_id": profile_id,
                "total_jobs": len(encolados),
                "total_prompts": total_prompts,
                "encolados": encolados,
                "omitidos": omitidos,
                "msg": f"Se encolaron {len(encolados)} proyecto(s) con {total_prompts} prompts para FlowBatch Pro."
            })

        if u.path in ("/api/nicho/enviar_flowbatch", "/api/videos/enviar_flowbatch", "/api/ecos/enviar_flowbatch", "/api/flowbatch/enviar_ecos", "/api/ecos/enviar_flowbatch_videos", "/api/flowbatch/enviar_videos"):
            body = self._leer_json()
            rutas = body.get("rutas") or body.get("proyectos") or []
            if isinstance(rutas, str):
                rutas = [rutas]
            rutas = _ordenar_rutas_numericas_asc(rutas)
            req_profile_id = str(body.get("profile_id") or "").strip()
            es_endpoint_videos = "videos" in u.path.lower()
            tipo_contenido = str(body.get("tipo_contenido") or body.get("modo") or ("video" if es_endpoint_videos else "imagen")).strip().lower()

            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                ext_info = data.get("extension_info", {})
                profile_id = req_profile_id or ext_info.get("last_profile_id", "")

                encolados = []
                omitidos = []
                total_prompts = 0

                ahora_base = int(time.time() * 1000)
                idx_counter = 0

                for r in rutas:
                    p_proy = Path(_limpiar_ruta(r)).resolve()
                    if not p_proy.is_dir():
                        omitidos.append({"ruta": r, "motivo": "Carpeta no existe"})
                        continue

                    # Si el usuario solicitó Modo Video exclusivamente
                    if tipo_contenido in ("video", "videos"):
                        p_mov = None
                        for nom_cand in ("movimiento.txt", "prompts_video.txt", "videos.txt"):
                            cand = p_proy / nom_cand
                            if cand.is_file():
                                p_mov = cand
                                break
                        if not p_mov:
                            omitidos.append({"ruta": r, "nombre": p_proy.name, "motivo": "No se encontró movimiento.txt"})
                            continue
                        prompts_mov = [l.strip() for l in p_mov.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip() and not l.strip().startswith(("#", "//", "==="))]
                        if not prompts_mov:
                            omitidos.append({"ruta": r, "nombre": p_proy.name, "motivo": "movimiento.txt no contiene prompts válidos"})
                            continue

                        user_start_num = body.get("start_num")
                        job_vid = enviar_lote_videos_a_flowbatch(
                            carpeta_o_proyecto=p_proy,
                            prompts_movimiento=prompts_mov,
                            project_id=p_proy.name,
                            start_num=user_start_num,
                            quality=body.get("quality", "360p"),
                            gap_sec=body.get("gap_sec", 25),
                            profile_id=profile_id
                        )
                        data["jobs"] = [j for j in data.get("jobs", []) if j.get("job_id") != job_vid["job_id"]]
                        data["jobs"].append(job_vid)
                        encolados.append({
                            "job_id": job_vid["job_id"],
                            "nombre": f"{p_proy.name} (Videos)",
                            "prompts": len(prompts_mov),
                            "start_num": job_vid.get("start_num", 1),
                            "tipo": "video",
                            "destino": job_vid["final_dir"],
                        })
                        total_prompts += len(prompts_mov)
                        continue

                    # Modo Imagen (Referencias y Escenas)
                    dest_img = _determinar_carpeta_destino_medios(p_proy, es_video=False)
                    dest_img.mkdir(parents=True, exist_ok=True)

                    # A) Comprobar Referencias (referencias.txt)
                    p_ref = p_proy / "referencias.txt"
                    prompts_ref = [line.strip() for line in p_ref.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip() and not line.strip().startswith(("#", "//", "==="))] if p_ref.is_file() else []
                    num_refs_req = len(prompts_ref)
                    refs_listas = True
                    if num_refs_req > 0:
                        for idx_ref in range(1, num_refs_req + 1):
                            if not _buscar_referencia_personaje(p_proy, idx_ref):
                                refs_listas = False
                                break

                    if prompts_ref and not refs_listas:
                        idx_counter += 1
                        job_ref_id = f"fb_ref_{ahora_base}_{idx_counter}"
                        dest_info_ref = _fb_resolver_destino(str(dest_img), job_ref_id)
                        job_ref = {
                            "job_id": job_ref_id,
                            "profile_id": profile_id,
                            "titulo": f"Referencias: {p_proy.name}",
                            "tipo_trabajo": "referencias",
                            "carpeta_proyecto": str(p_proy),
                            "origen": str(p_ref),
                            "prompts": prompts_ref,
                            "total": len(prompts_ref),
                            "folder_rel": dest_info_ref["folder_rel"],
                            "staging_dir": dest_info_ref["staging_dir"],
                            "final_dir": dest_info_ref["final_dir"],
                            "needs_move": dest_info_ref["needs_move"],
                            "prefix": "",
                            "quality": "1k",
                            "gap_sec": 15,
                            "max_retries": 0,
                            "autodl": True,
                            "estado": "pendiente",
                            "progreso": {"done": 0, "total": len(prompts_ref), "pct": 0, "text": "En cola esperando a FlowBatch Pro..."},
                            "created_at": _fb_ahora(),
                            "logs": [{
                                "hora": datetime.datetime.now().strftime("%H:%M:%S"),
                                "level": "info",
                                "text": f"Lote de referencias encolado ({len(prompts_ref)} prompts desde {p_ref.name}) -> {dest_info_ref['final_dir']}"
                            }],
                        }
                        data["jobs"].append(job_ref)
                        encolados.append({
                            "job_id": job_ref_id,
                            "nombre": f"{p_proy.name} (Referencias)",
                            "prompts": len(prompts_ref),
                            "tipo": "referencias",
                            "destino": dest_info_ref["final_dir"],
                        })
                        total_prompts += len(prompts_ref)

                    # B) Comprobar Escenas (imagen.txt o prompts.txt)
                    p_escenas = None
                    for nom_cand in ("imagen.txt", "prompts.txt", "prompts_para_chat.txt"):
                        cand = p_proy / nom_cand
                        if cand.is_file():
                            p_escenas = cand
                            break

                    prompts_esc = []
                    if p_escenas:
                        prompts_esc = [line.strip() for line in p_escenas.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip() and not line.strip().startswith(("#", "//", "==="))]

                    if not prompts_esc:
                        if not p_ref.is_file():
                            omitidos.append({"ruta": r, "nombre": p_proy.name, "motivo": "No se encontró imagen.txt, prompts.txt ni referencias.txt"})
                        continue

                    idx_counter += 1
                    job_esc_id = f"fb_escenas_{ahora_base}_{idx_counter}"
                    dest_info_esc = _fb_resolver_destino(str(dest_img), job_esc_id)

                    # ref_images se resuelven en caliente en /api/flowbatch/siguiente al despachar
                    ref_images_existentes = {}

                    # Calcular desde qué prompt empezar según imágenes de escena ya creadas (abierto a todo el guion)
                    user_start_num = body.get("start_num")
                    if user_start_num is not None and str(user_start_num).strip():
                        try:
                            start_num = max(1, int(user_start_num))
                        except Exception:
                            start_num = _calcular_start_num_imagenes(p_proy, len(prompts_esc))
                    else:
                        start_num = _calcular_start_num_imagenes(p_proy, len(prompts_esc))
                    cant_esc_exist = len(_detectar_imagenes_escenas_existentes(p_proy))

                    job_esc = {
                        "job_id": job_esc_id,
                        "profile_id": profile_id,
                        "titulo": f"Escenas: {p_proy.name}",
                        "tipo_trabajo": "escenas",
                        "carpeta_proyecto": str(p_proy),
                        "origen": str(p_escenas),
                        "prompts": prompts_esc,
                        "total": len(prompts_esc),
                        "start_num": start_num,
                        "folder_rel": dest_info_esc["folder_rel"],
                        "staging_dir": dest_info_esc["staging_dir"],
                        "final_dir": dest_info_esc["final_dir"],
                        "needs_move": dest_info_esc["needs_move"],
                        "prefix": "",
                        "quality": "1k",
                        "gap_sec": 15,
                        "max_retries": 0,
                        "autodl": True,
                        "ref_images": ref_images_existentes,
                        "estado": "pendiente",
                        "progreso": {
                            "done": cant_esc_exist,
                            "total": len(prompts_esc),
                            "pct": int(round((cant_esc_exist / len(prompts_esc)) * 100)) if prompts_esc else 0,
                            "text": f"En cola esperando a FlowBatch Pro (inicia en #{start_num})..." if start_num > 1 else "En cola esperando a FlowBatch Pro...",
                            "num": start_num
                        },
                        "created_at": _fb_ahora(),
                        "logs": [{
                            "hora": datetime.datetime.now().strftime("%H:%M:%S"),
                            "level": "info",
                            "text": f"Lote de escenas encolado ({len(prompts_esc)} prompts desde {p_escenas.name}, inicia en #{start_num}) -> {dest_info_esc['final_dir']}"
                        }],
                    }
                    data["jobs"].append(job_esc)
                    encolados.append({
                        "job_id": job_esc_id,
                        "nombre": f"{p_proy.name} (Escenas)",
                        "prompts": len(prompts_esc),
                        "start_num": start_num,
                        "tipo": "escenas",
                        "destino": dest_info_esc["final_dir"],
                    })
                    total_prompts += len(prompts_esc)

                    # Si el usuario eligió "ambos", encolar también los videos inmediatamente detrás
                    if tipo_contenido == "ambos":
                        p_mov = p_proy / "movimiento.txt"
                        if p_mov.is_file():
                            prompts_mov = [l.strip() for l in p_mov.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip() and not l.strip().startswith(("#", "//", "==="))]
                            if prompts_mov:
                                job_vid = enviar_lote_videos_a_flowbatch(
                                    carpeta_o_proyecto=p_proy,
                                    prompts_movimiento=prompts_mov,
                                    project_id=p_proy.name,
                                    start_num=body.get("start_num"),
                                    quality=body.get("quality", "360p"),
                                    gap_sec=body.get("gap_sec", 25),
                                    profile_id=profile_id
                                )
                                data["jobs"] = [j for j in data.get("jobs", []) if j.get("job_id") != job_vid["job_id"]]
                                data["jobs"].append(job_vid)
                                encolados.append({
                                    "job_id": job_vid["job_id"],
                                    "nombre": f"{p_proy.name} (Videos)",
                                    "prompts": len(prompts_mov),
                                    "start_num": job_vid.get("start_num", 1),
                                    "tipo": "video",
                                    "destino": job_vid["final_dir"],
                                })
                                total_prompts += len(prompts_mov)

                # Purgar únicamente historial completado antiguo sin tocar jobs activos ni pendientes
                if len(data["jobs"]) > 100:
                    completados_hist = [j for j in data["jobs"] if j.get("estado") in ("completado", "cancelado", "error", "detenido")]
                    activos_o_pend = [j for j in data["jobs"] if j.get("estado") in ("pendiente", "despachado", "en_proceso")]
                    if len(completados_hist) > 30:
                        completados_hist = completados_hist[-30:]
                    data["jobs"] = completados_hist + activos_o_pend
                _fb_guardar_cola(data)

            return self._json({
                "ok": True,
                "profile_id": profile_id,
                "total_jobs": len(encolados),
                "total_prompts": total_prompts,
                "encolados": encolados,
                "omitidos": omitidos,
                "msg": f"Se encolaron {len(encolados)} trabajo(s) con {total_prompts} prompts para FlowBatch Pro."
            })

        if u.path == "/api/flowbatch/cargar_proyecto":
            body = self._leer_json()
            ruta_proy = _limpiar_ruta(body.get("carpeta_proyecto", ""))
            if not ruta_proy:
                return self._json({"ok": False, "msg": "Indica la carpeta del proyecto."})
            p_proy = Path(ruta_proy)
            if not p_proy.is_dir():
                return self._json({"ok": False, "msg": f"No existe la carpeta: {ruta_proy}"})
            prompts, origen = _fb_parsear_prompts("", None, ruta_proy)
            es_mapa = (p_proy / "config_mapa.json").is_file() or (p_proy / "sincronia.txt").is_file()
            if es_mapa or (p_proy / "veo").is_dir():
                dest_sugerido = str((p_proy / "veo").resolve())
            else:
                dest_sugerido = str((p_proy / "imagen").resolve())
            return self._json({
                "ok": True,
                "prompts": prompts,
                "prompts_texto": "\n".join(prompts),
                "origen": origen or "sin_archivo",
                "carpeta_destino": dest_sugerido,
                "total": len(prompts),
            })

        if u.path == "/api/flowbatch/encolar":
            body = self._leer_json()
            prompts, origen = _fb_parsear_prompts(
                body.get("prompts_texto", ""),
                body.get("prompts"),
                body.get("carpeta_proyecto", ""),
            )
            if not prompts:
                return self._json({"ok": False, "msg": "Escribe al menos un prompt o selecciona una carpeta con imagen.txt."})
            job_id = f"fb_{int(time.time() * 1000)}"
            dest_info = _fb_resolver_destino(body.get("carpeta_destino", ""), job_id)
            if not dest_info["needs_move"]:
                try:
                    Path(dest_info["final_dir"]).mkdir(parents=True, exist_ok=True)
                except Exception:
                    pass
            try:
                gap_sec = max(10, int(body.get("gap_sec", 15) or 15))
            except Exception:
                gap_sec = 15
            try:
                # Contrato: 0 reintentos por defecto para mapas / evitar consumo no deseado de créditos
                max_retries = max(0, min(3, int(body.get("max_retries", 0) if body.get("max_retries") is not None else 0)))
            except Exception:
                max_retries = 0

            profile_id = str(body.get("profile_id") or "").strip()

            job = {
                "job_id": job_id,
                "profile_id": profile_id,
                "titulo": str(body.get("titulo") or f"Lote ({len(prompts)} imgs)").strip(),
                "origen": origen,
                "prompts": prompts,
                "total": len(prompts),
                "folder_rel": dest_info["folder_rel"],
                "staging_dir": dest_info["staging_dir"],
                "final_dir": dest_info["final_dir"],
                "needs_move": dest_info["needs_move"],
                "prefix": str(body.get("prefix") or "").strip(),
                "quality": str(body.get("quality") or "1k").strip(),
                "gap_sec": gap_sec,
                "max_retries": max_retries,
                "estado": "pendiente",
                "progreso": {"done": 0, "total": len(prompts), "pct": 0, "text": "En cola esperando a FlowBatch Pro..."},
                "created_at": _fb_ahora(),
                "logs": [{"hora": datetime.datetime.now().strftime("%H:%M:%S"), "level": "info", "text": f"Lote encolado ({len(prompts)} prompts) -> {dest_info['final_dir']}"}],
            }
            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                data["jobs"].append(job)
                if len(data["jobs"]) > 40:
                    data["jobs"] = data["jobs"][-40:]
                _fb_guardar_cola(data)
            return self._json({"ok": True, "job": job})

        if u.path == "/api/flowbatch/reportar":
            body = self._leer_json()
            job_id = str(body.get("job_id") or "").strip()
            evento = str(body.get("evento") or "").strip().upper()
            rep_profile_id = str(body.get("profile_id") or "").strip()
            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                data["extension_seen_at"] = time.time()
                if rep_profile_id:
                    data.setdefault("extension_info", {})["last_profile_id"] = rep_profile_id

                job = next((j for j in data.get("jobs", []) if j.get("job_id") == job_id), None)
                if not job:
                    _fb_guardar_cola(data)
                    return self._json({"ok": True, "ignored": True})

                if rep_profile_id and not job.get("profile_id"):
                    job["profile_id"] = rep_profile_id

                if evento == "STARTED":
                    job["estado"] = "en_proceso"
                    job["started_at"] = _fb_ahora()
                    job["tab_url"] = body.get("tab_url", "")
                    total_p = body.get("total") or len(job.get("prompts", []))
                    if total_p:
                        job["total"] = total_p
                        job["progreso"]["total"] = total_p
                    job["progreso"]["text"] = f"Ejecutando en Google Flow (0/{job.get('total', total_p)})..."
                    _fb_append_log(job, "ok", f"FlowBatch inició lote ({job.get('total', total_p)} prompts) -> Descargas/{job.get('folder_rel', 'veo')}")
                elif evento == "ERROR_INICIO":
                    job["estado"] = "error"
                    job["error"] = body.get("error") or "Error al iniciar en FlowBatch"
                    job["progreso"]["text"] = job["error"]
                    _fb_append_log(job, "err", job["error"])
                elif evento == "LOG":
                    lvl = str(body.get("level") or "info").lower()
                    if lvl not in ("info", "ok", "warn", "err"):
                        lvl = "info"
                    _fb_append_log(job, lvl, body.get("text", ""))
                elif evento in ("PROGRESS", "ITEM_PROGRESS", "STEP"):
                    pct = body.get("pct")
                    num = body.get("num")
                    total = body.get("total") or job.get("total") or 1
                    state_txt = body.get("text") or body.get("state") or body.get("status") or ""
                    if num is not None:
                        job["progreso"]["num"] = num
                    if total:
                        job["progreso"]["total"] = total
                    if pct is not None:
                        job["progreso"]["pct"] = int(pct)
                    elif num and total:
                        job["progreso"]["pct"] = int(min(100, round((float(num) / float(total)) * 100)))
                    if state_txt:
                        job["progreso"]["text"] = str(state_txt)[:200]
                elif evento == "DONE":
                    stopped = bool(body.get("stopped"))
                    is_ok = bool(body.get("ok", not stopped))
                    success_cnt = int(body.get("successCount") or 0)
                    failed_cnt = int(body.get("failedCount") or 0)
                    failed_indices = body.get("failedIndices") or []
                    job["finished_at"] = _fb_ahora()
                    job["success_count"] = success_cnt
                    job["failed_count"] = failed_cnt
                    job["failed_indices"] = failed_indices
                    moved_cnt = _fb_mover_descargas_job(job)
                    job["moved_count"] = moved_cnt
                    if stopped:
                        job["estado"] = "detenido"
                    elif not is_ok or (failed_cnt > 0 and success_cnt == 0):
                        job["estado"] = "error"
                    else:
                        job["estado"] = "completado"
                    job["progreso"]["pct"] = 100 if job["estado"] == "completado" else job["progreso"].get("pct", 0)
                    resumen = f"Finalizado: {success_cnt} OK, {failed_cnt} fallidos"
                    if moved_cnt:
                        resumen += f" ({moved_cnt} movidas a destino)"
                    job["progreso"]["text"] = resumen
                    _fb_append_log(job, "ok" if job["estado"] == "completado" else ("warn" if stopped else "err"), resumen)
                _fb_guardar_cola(data)
            return self._json({"ok": True})

        if u.path == "/api/flowbatch/cancelar":
            body = self._leer_json()
            job_id = str(body.get("job_id") or "").strip()
            canc_profile_id = str(body.get("profile_id") or "").strip()
            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                cambiados = 0
                for j in data.get("jobs", []):
                    if job_id and j.get("job_id") != job_id:
                        continue
                    if canc_profile_id and j.get("profile_id") and j.get("profile_id") != canc_profile_id:
                        continue
                    if j.get("estado") in ("pendiente", "despachado", "en_proceso"):
                        j["estado"] = "cancelado"
                        j["finished_at"] = _fb_ahora()
                        _fb_append_log(j, "warn", "Lote cancelado desde NEXOR.")
                        cambiados += 1
                _fb_guardar_cola(data)
            return self._json({"ok": True, "cancelados": cambiados})

        if u.path == "/api/flowbatch/limpiar":
            with FLOWBATCH_LOCK:
                data = _fb_cargar_cola()
                data["jobs"] = [j for j in data.get("jobs", []) if j.get("estado") in ("pendiente", "despachado", "en_proceso")]
                _fb_guardar_cola(data)
            return self._json({"ok": True})

        if u.path == "/api/flowbatch/abrir_carpeta":
            body = self._leer_json()
            ruta_raw = _limpiar_ruta(body.get("ruta", ""))
            p_open = Path(ruta_raw).resolve() if ruta_raw else (USER_DOWNLOADS / "nexor_flowbatch").resolve()
            if not p_open.exists():
                p_open.mkdir(parents=True, exist_ok=True)
            self._abrir(p_open)
            return self._json({"ok": True, "ruta": str(p_open)})

        self._json({"error": "no encontrado"}, 404)

    @staticmethod
    def _abrir(p: Path):
        if sys.platform.startswith("win"):
            os.startfile(str(p))          # noqa: S606 (local, ruta validada)
        elif sys.platform == "darwin":
            subprocess.run(["open", str(p)])
        else:
            subprocess.run(["xdg-open", str(p)])

    def log_message(self, *a):
        pass


PAGINA = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Generador de Contenido</title>
<style>
  :root{
    --bg:#0f1115; --panel:#181b22; --line:#2a2f3a; --txt:#e7e9ee; --dim:#9aa3b2;
    --acc:#e5484d; --ok:#3fb950; --wait:#3b82f6; --warn:#d29922; --off:#6b7280;
    --row:#161922; --rowh:#1c2029;
  }
  @media (prefers-color-scheme: light){
    :root{ --bg:#f4f5f7; --panel:#fff; --line:#e2e5ea; --txt:#1a1d23;
           --dim:#5b6470; --row:#fff; --rowh:#f5f6f8; }
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--txt);
       font:14px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
  button{background:var(--panel);color:var(--txt);border:1px solid var(--line);
         padding:7px 12px;border-radius:8px;cursor:pointer;font-size:13px}
  button:hover{border-color:var(--dim)}
  button.pri{background:var(--acc);color:#fff;border-color:var(--acc)}
  button:disabled{opacity:.45;cursor:default}
  /* barra lateral */
  .layout{display:flex;min-height:100vh}
  .side{width:212px;flex:0 0 212px;background:var(--panel);border-right:1px solid var(--line);
        padding:16px 10px;position:sticky;top:0;height:100vh}
  .side h1{font-size:15px;margin:2px 10px 16px;display:flex;gap:8px;align-items:center}
  .side .item{padding:9px 12px;border-radius:8px;color:var(--txt);cursor:pointer;
        font-size:14px;font-weight:600;border:1px solid transparent;margin-bottom:2px}
  .side .item:hover{background:var(--rowh)}
  .side .item.act{background:var(--acc);color:#fff}
  .side .item.off{color:var(--dim);font-weight:500;cursor:default}
  .side .item.off small{display:block;font-size:10px;font-weight:400}
  .navsep{margin:14px 12px 6px;font-size:10px;text-transform:uppercase;
        letter-spacing:.6px;color:var(--dim);font-weight:700}
  /* herramienta transcribir */
  .tr-box{max-width:640px}
  .tr-help{color:var(--dim);font-size:13px;line-height:1.6;margin:0 0 18px}
  .tr-box label{display:block;font-size:12px;color:var(--dim);margin:12px 0 4px}
  .tr-box input[type=text],.tr-box select{width:100%;background:var(--panel);color:var(--txt);
        border:1px solid var(--line);border-radius:8px;padding:9px 11px;font-size:13px}
  .tr-box input[type=text]{font-family:ui-monospace,Consolas,monospace}
  .tr-box .row2{display:flex;gap:12px}
  .tr-box .row2>div{flex:1}
  .tr-est{margin-top:16px;font-size:13px;padding:10px 12px;border-radius:8px;
        border:1px solid var(--line);background:var(--row)}
  .tr-est.act{color:var(--acc)} .tr-est.ok{color:var(--ok)} .tr-est.err{color:#f87171}
  .tr-row{display:flex;gap:8px}
  .tr-row input[type=text]{flex:1}
  .tr-row button{white-space:nowrap}
  .tr-listwrap{margin-top:18px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tr-listhead{display:flex;align-items:center;justify-content:space-between;
        padding:9px 12px;background:var(--panel);border-bottom:1px solid var(--line)}
  .tr-all{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;cursor:pointer}
  .tr-all input{width:auto}
  .tr-count{font-size:12px;color:var(--dim)}
  .tr-list{max-height:360px;overflow-y:auto}
  .tr-item{display:flex;align-items:center;gap:10px;padding:8px 12px;
        border-bottom:1px solid var(--line);font-size:13px;cursor:pointer}
  .tr-item:last-child{border-bottom:0}
  .tr-item:hover{background:var(--rowh)}
  .tr-item.on{background:var(--rowh)}
  .tr-item input{width:auto}
  .tr-name{flex:1;word-break:break-all}
  .tr-tag{font-size:10px;color:var(--dim);border:1px solid var(--line);
        border-radius:20px;padding:1px 8px;white-space:nowrap}
  .content{flex:1;min-width:0;display:flex;flex-direction:column}
  header{padding:16px 24px;border-bottom:1px solid var(--line);
         display:flex;align-items:center;gap:14px}
  .raiz{color:var(--dim);font-size:12px;word-break:break-all}
  header .der{margin-left:auto}
  main{padding:18px 24px;max-width:1200px;width:100%;margin:0 auto}
  .wrap{max-height:calc(100vh - 220px);overflow-y:auto;overflow-x:auto;border:1px solid var(--line);border-radius:12px;position:relative}
  table{width:100%;border-collapse:collapse;min-width:720px}
  th,td{text-align:left;padding:11px 14px;border-bottom:1px solid var(--line);white-space:nowrap}
  th{font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--dim);
     background:var(--panel);position:sticky;top:0;z-index:10;box-shadow:0 1px 0 var(--line)}
  tr{background:var(--row)} tr:hover td{background:var(--rowh)}
  tr:last-child td{border-bottom:0}
  td.video{white-space:normal;font-weight:600;max-width:280px}
  .titu{color:var(--acc);font-size:11px;font-weight:600}
  .chip{font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;color:#fff;display:inline-block}
  .chip.montado{background:var(--ok)} .chip.listo{background:var(--wait)}
  .chip.desactualizado{background:var(--warn)} .chip.pendiente{background:var(--off)}
  .chip.montando{background:var(--acc)} .chip.error{background:#b91c1c} .chip.ok{background:var(--ok)}
  .chip.publicado{background:var(--off);opacity:.7}
  .chip.cortado{background:var(--ok)} .chip.activo{background:var(--acc)}
  tr.pub td{opacity:.5} tr.pub td.acc{opacity:1}
  .banner{background:var(--acc);color:#fff;border-radius:9px;padding:9px 14px;
          margin-bottom:14px;font-size:13px;font-weight:600}
  .falta{color:var(--dim);white-space:normal;font-size:12.5px}
  .falta b{color:var(--warn);font-weight:600}
  .num{color:var(--dim);font-variant-numeric:tabular-nums}
  .acc{display:flex;gap:6px}
  .msg{padding:40px;text-align:center;color:var(--dim)}
  .joblog{font-size:11px;color:var(--dim);white-space:normal;max-width:280px}
  .chk{display:flex;align-items:center;gap:7px;font-size:13px;color:var(--dim);margin-bottom:12px}
  .chk input{width:auto}
  /* tarjetas famosos */
  .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px}
  .card{border:1px solid var(--line);border-radius:12px;background:var(--row);padding:14px}
  .card h3{margin:0 0 4px;font-size:15px}
  .card .meta{color:var(--dim);font-size:12px;margin-bottom:6px}
  .card label{font-size:12px;color:var(--dim);display:block;margin:8px 0 3px}
  .card input,.card select{width:100%;background:var(--panel);color:var(--txt);
        border:1px solid var(--line);border-radius:8px;padding:7px 9px;font-size:13px}
  .card .row2{display:flex;gap:8px}
  .card .row2>div{flex:1}
  .sel{font-size:11px;color:var(--dim);margin-top:8px;word-break:break-all}
  .sel b{color:var(--ok);font-weight:600}
  /* modal de "procesando" que bloquea la pantalla */
  #overlay{display:none;position:fixed;inset:0;z-index:1000;
    background:rgba(6,8,12,.66);backdrop-filter:blur(3px);
    align-items:center;justify-content:center}
  .modal{background:var(--panel);border:1px solid var(--line);border-radius:16px;
    padding:32px 36px;max-width:460px;width:90%;text-align:center;
    box-shadow:0 24px 70px rgba(0,0,0,.55)}
  .spin{width:48px;height:48px;border-radius:50%;margin:0 auto 20px;
    border:4px solid var(--line);border-top-color:var(--acc);animation:sp .9s linear infinite}
  @keyframes sp{to{transform:rotate(360deg)}}
  .ov-t{font-size:19px;font-weight:700;margin-bottom:6px}
  .ov-n{color:var(--acc);font-weight:600;font-size:14px;margin-bottom:12px;word-break:break-word}
  .ov-l{color:var(--dim);font-size:12px;min-height:16px;margin-bottom:22px;
    word-break:break-word;font-variant-numeric:tabular-nums}
  .cancelar{background:#b91c1c;color:#fff;border:none;padding:11px 22px;border-radius:9px;
    font-weight:600;font-size:14px;cursor:pointer}
  .cancelar:hover{background:#991b1b}
  .ov-hint{color:var(--dim);font-size:11px;margin-top:14px}
</style>
</head>
<body>
<div class="layout">
  <nav class="side">
    <h1>🎬 Generador</h1>
    <div id="nav"></div>
  </nav>
  <div class="content">
    <header>
      <span class="raiz" id="raiz"></span>
      <div class="der"><button onclick="render()">↻ Refrescar</button></div>
    </header>
    <main id="main"></main>
  </div>
</div>
<div id="overlay">
  <div class="modal">
    <div class="spin"></div>
    <div class="ov-t">Procesando…</div>
    <div class="ov-n" id="ovNombre"></div>
    <div class="ov-l" id="ovLog"></div>
    <button class="cancelar" onclick="cancelar()">✕ Cancelar proceso</button>
    <div class="ov-hint">No cierres esta ventana. Cancela solo si te faltó subir algún archivo.</div>
  </div>
</div>
<script>
let VISTA=null, NICHOS=[], filas=[], ecosFilas=[], famFilas=[], timer=null, limpiarEcos=true;
let ordenProyectos = localStorage.getItem("ordenProyectos") || "recientes";
let filtroTexto = "";

function enc(s){ return encodeURIComponent(s); }
function main(){ return document.getElementById("main"); }
function setHeader(r){ document.getElementById("raiz").textContent = r||""; }
function poll(activo){ clearTimeout(timer); if(activo) timer=setTimeout(render,2500); }
function chip(est,txt){ return `<span class="chip ${est}">${txt||est}</span>`; }
async function abrir(ruta){ await fetch("/api/abrir?ruta="+ruta); }

function ordenarFilas(items){
  let res = [...(items||[])];
  if(filtroTexto){
    const q = filtroTexto.toLowerCase().trim();
    res = res.filter(f => (f.nombre||"").toLowerCase().includes(q) || (f.titulo||"").toLowerCase().includes(q));
  }
  if(ordenProyectos === "recientes"){
    res.sort((a,b) => (a.publicado?1:0) - (b.publicado?1:0) || (b.t_creacion||0) - (a.t_creacion||0) || (a.nombre||"").localeCompare(b.nombre||""));
  } else if(ordenProyectos === "pendientes"){
    const peso = f => {
      if(f.publicado) return 3;
      if(f.estado==="montado" || f.estado==="generado" || f.estado==="cortado") return 2;
      return 1;
    };
    res.sort((a,b) => peso(a) - peso(b) || (b.t_creacion||0) - (a.t_creacion||0) || (a.nombre||"").localeCompare(b.nombre||""));
  } else if(ordenProyectos === "antiguos"){
    res.sort((a,b) => (a.publicado?1:0) - (b.publicado?1:0) || (a.t_creacion||0) - (b.t_creacion||0) || (a.nombre||"").localeCompare(b.nombre||""));
  } else if(ordenProyectos === "az"){
    res.sort((a,b) => (a.publicado?1:0) - (b.publicado?1:0) || (a.nombre||"").localeCompare(b.nombre||""));
  }
  return res;
}

let selRutas = new Set();
let colaActiva = false;
let colaCancelada = false;

function toggleSel(ruta, on){
  const r = (typeof ruta === "string" && ruta.indexOf("%") >= 0) ? decodeURIComponent(ruta) : (ruta || "");
  const norm = r.replace(/\\/g, "/");
  if(on) selRutas.add(norm);
  else selRutas.delete(norm);
  render();
}

function toggleSelTodos(on, lista){
  if(on){
    (lista||[]).forEach(f => { if(f.ruta) selRutas.add(f.ruta.replace(/\\/g, "/")); });
  } else {
    selRutas.clear();
  }
  render();
}

function limpiarSel(){
  selRutas.clear();
  render();
}

async function ejecutarLoteGenerico(tituloAccion, rutas, endpointFn){
  if(!rutas || !rutas.length){
    alert("No seleccionaste ningún proyecto");
    return;
  }
  colaActiva = true;
  colaCancelada = false;
  setOverlay(true, "Iniciando…", "Preparando cola de procesamiento…", tituloAccion);

  const total = rutas.length;
  let exitosos = 0;
  let errores = [];

  for(let i=0; i<total; i++){
    if(colaCancelada) break;
    const ruta = rutas[i];
    const nombre = ruta.split(/[\\/]/).pop() || ruta;

    setOverlay(true, nombre, "Iniciando proceso en segundo plano…", `${tituloAccion} [${i+1} de ${total}]`);

    let res = null;
    try {
      res = await endpointFn(ruta);
    } catch(err){
      res = { ok: false, msg: err.message };
    }

    if(!res || !res.ok){
      errores.push(`${nombre}: ${res?.msg || "error al iniciar"}`);
      document.getElementById("ovLog").textContent = `Error: ${res?.msg || "falló"}`;
      await new Promise(r => setTimeout(r, 1000));
      continue;
    }

    await new Promise(r => setTimeout(r, 450));

    let terminado = false;
    while(!terminado && !colaCancelada){
      await new Promise(r => setTimeout(r, 600));
      try {
        const job = await (await fetch("/api/job?ruta=" + enc(ruta))).json();
        if(job && job.linea){
          document.getElementById("ovLog").textContent = job.linea;
        }
        if(job && job.estado && job.estado !== "activo" && job.estado !== "montando"){
          if(job.estado === "ok") exitosos++;
          else errores.push(`${nombre}: ${job.linea || "falló"}`);
          terminado = true;
          break;
        }
        const estG = await (await fetch("/api/estado")).json();
        if(!estG.activo && (!job || job.estado !== "activo")){
          exitosos++;
          terminado = true;
          break;
        }
      } catch(e){}
    }
    await new Promise(r => setTimeout(r, 250));
  }

  colaActiva = false;
  setOverlay(false);
  selRutas.clear();
  render();

  if(colaCancelada){
    alert("Proceso detenido. Se completaron " + exitosos + " de " + total + " proyectos.");
  } else if(errores.length){
    alert("Completados " + exitosos + " de " + total + ". Hubo errores en: " + errores.slice(0, 6).join(" | "));
  }
}

function barraOrden(totalOriginal, filtradosCount, tipoVista){
  const nSel = selRutas.size;
  let botonesLote = "";
  if(nSel > 0){
    if(tipoVista === "ecos"){
      botonesLote = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:var(--acc);padding:4px 8px;background:rgba(59,130,246,0.12);border-radius:6px">
            ✓ ${nSel} seleccionados
          </span>
          <button class="pri" style="font-weight:600" onclick="ejecutarColaEcos('segmentar')">📋 Segmentar (${nSel})</button>
          <button style="font-weight:600" onclick="ejecutarColaEcos('unir')">🔗 Unir (${nSel})</button>
          <button style="font-weight:600" onclick="ejecutarColaEcos('subtitular')">💬 Subtitular (${nSel})</button>
          <button style="font-weight:600" onclick="ejecutarColaEcos('cortar')">✂ Cortar (${nSel})</button>
          <button style="color:var(--dim)" onclick="limpiarSel()">✕ Deseleccionar</button>
        </div>`;
    } else if(tipoVista === "peliculas"){
      botonesLote = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:var(--acc);padding:4px 8px;background:rgba(59,130,246,0.12);border-radius:6px">
            ✓ ${nSel} seleccionados
          </span>
          <button class="pri" style="font-weight:600" onclick="ejecutarColaPel('montar')">▶ Montar (${nSel})</button>
          <button style="font-weight:600" onclick="ejecutarColaPel('transcribir')">📝 Transcribir (${nSel})</button>
          <button style="color:var(--dim)" onclick="limpiarSel()">✕ Deseleccionar</button>
        </div>`;
    } else if(tipoVista === "ebook"){
      botonesLote = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:var(--acc);padding:4px 8px;background:rgba(59,130,246,0.12);border-radius:6px">
            ✓ ${nSel} seleccionados
          </span>
          <button class="pri" style="font-weight:600" onclick="ejecutarColaEbook()">📖 Generar (${nSel})</button>
          <button style="color:var(--dim)" onclick="limpiarSel()">✕ Deseleccionar</button>
        </div>`;
    } else if(tipoVista === "famosos"){
      botonesLote = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:var(--acc);padding:4px 8px;background:rgba(59,130,246,0.12);border-radius:6px">
            ✓ ${nSel} seleccionados
          </span>
          <button class="pri" style="background:#059669;border-color:#047857;font-weight:700" onclick="ejecutarColaFamosos('clips')">✂ Extraer Clips (${nSel})</button>
          <button style="font-weight:600" onclick="ejecutarColaFamosos('montar')">▶ Video Completo (${nSel})</button>
          <button style="color:var(--dim)" onclick="limpiarSel()">✕ Deseleccionar</button>
        </div>`;
    } else if(tipoVista === "mapas"){
      botonesLote = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:var(--acc);padding:4px 8px;background:rgba(59,130,246,0.12);border-radius:6px">
            ✓ ${nSel} seleccionados
          </span>
          <button class="pri" style="background:#10b981;border-color:#059669;font-weight:600" onclick="ejecutarColaSegmentarMapas()">📋 Segmentar (${nSel})</button>
          <button class="pri" style="font-weight:600" onclick="ejecutarColaMontar()">▶ Montar (${nSel})</button>
          <button style="font-weight:600" onclick="marcarLote(true)">🔒 Marcar publicados</button>
          <button style="font-weight:600" onclick="marcarLote(false)">🔓 Desmarcar</button>
          <button style="color:var(--dim)" onclick="limpiarSel()">✕ Deseleccionar</button>
        </div>`;
    } else {
      botonesLote = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:var(--acc);padding:4px 8px;background:rgba(59,130,246,0.12);border-radius:6px">
            ✓ ${nSel} seleccionados
          </span>
          <button class="pri" style="font-weight:600" onclick="ejecutarColaMontar()">▶ Montar (${nSel})</button>
          <button style="font-weight:600" onclick="marcarLote(true)">🔒 Marcar publicados</button>
          <button style="font-weight:600" onclick="marcarLote(false)">🔓 Desmarcar</button>
          <button style="color:var(--dim)" onclick="limpiarSel()">✕ Deseleccionar</button>
        </div>`;
    }
  }

  return `<div style="display:flex;align-items:center;gap:12px;margin:0 0 12px;flex-wrap:wrap">
    ${botonesLote}
    <div style="display:flex;align-items:center;gap:7px;${nSel>0?'margin-left:auto':''}">
      <span style="font-size:12px;color:var(--dim);font-weight:600">Ordenar:</span>
      <select style="background:var(--panel);color:var(--txt);border:1px solid var(--line);border-radius:6px;padding:5px 9px;font-size:12px;cursor:pointer;outline:none"
        onchange="ordenProyectos=this.value;localStorage.setItem('ordenProyectos',this.value);render()">
        <option value="recientes" ${ordenProyectos==='recientes'?'selected':''}>🕒 Más recientes (creación) [defecto]</option>
        <option value="pendientes" ${ordenProyectos==='pendientes'?'selected':''}>⏳ Por montar / Pendientes primero</option>
        <option value="az" ${ordenProyectos==='az'?'selected':''}>🔤 Alfabético (A-Z)</option>
        <option value="antiguos" ${ordenProyectos==='antiguos'?'selected':''}>📅 Más antiguos primero</option>
      </select>
    </div>
    <div style="display:flex;align-items:center;gap:8px;${nSel>0?'':'margin-left:auto'}">
      <input type="text" placeholder="🔍 Filtrar proyectos..." value="${filtroTexto}"
        style="background:var(--panel);color:var(--txt);border:1px solid var(--line);border-radius:6px;padding:5px 10px;font-size:12px;width:180px;outline:none"
        oninput="filtroTexto=this.value;render()">
      <span style="font-size:11.5px;color:var(--dim)">(${filtradosCount}${filtradosCount!==totalOriginal?' de '+totalOriginal:''} proyectos)</span>
    </div>
  </div>`;
}

async function init(){
  const d = await (await fetch("/api/nichos")).json();
  NICHOS = d.nichos;
  document.getElementById("nav").innerHTML = NICHOS.map(n =>
    n.configurado
      ? `<div class="item" data-id="${n.id}" onclick="ir('${n.id}')">${n.nombre}</div>`
      : `<div class="item off">${n.nombre}<small>sin configurar</small></div>`
  ).join("")
  + `<div class="navsep">Herramientas</div>`
  + `<div class="item" data-id="transcribir" onclick="ir('transcribir')">🎙️ Transcribir</div>`
  + `<div class="item" data-id="voz" onclick="ir('voz')">🔊 Voz (ai33)</div>`
  + `<div class="item" data-id="recorte" onclick="ir('recorte')">✂️ Recortar audio</div>`
  + `<div class="item" data-id="personajes" onclick="ir('personajes')">🎭 Personajes</div>`;
  ir(d.def);
}
function ir(id){
  VISTA=id;
  selRutas.clear();
  document.querySelectorAll(".side .item").forEach(e=>
    e.classList.toggle("act", e.dataset.id===id));
  render();
}
function render(){
  clearTimeout(timer);
  if(VISTA==="transcribir") return renderTranscribir();   // herramienta, no es nicho
  if(VISTA==="voz") return renderVoz();                    // herramienta, no es nicho
  if(VISTA==="recorte") return renderRecorte();            // herramienta, no es nicho
  if(VISTA==="personajes") return renderPersonajes();      // herramienta, no es nicho
  const n = NICHOS.find(x=>x.id===VISTA) || {};
  if(!n.configurado) return pendiente(n.nombre);
  if(VISTA==="psico")     return renderPsico();
  if(VISTA==="finanzas")  return renderPsico();   // misma tabla, nicho actual
  if(VISTA==="desastres") return renderPsico();   // misma tabla (montaje)
  if(VISTA==="novelas")   return renderPsico();   // misma tabla (montaje)
  if(VISTA==="mapas")     return renderPsico();   // tabla de mapas virales + acceso al Estudio
  if(VISTA==="ecos")      return renderEcos();
  if(VISTA==="ebook")     return renderEbook();
  if(VISTA==="famosos")   return renderFamosos();
  if(VISTA==="peliculas") return renderPeliculas();
  pendiente(n.nombre);
}
function pendiente(nombre){
  setHeader("");
  main().innerHTML = `<div class="msg"><b>${nombre||"Este nicho"}</b> aún no está configurado.<br>
    Pídele a Claude que registre su carpeta y su flujo (sin tocar el resto).</div>`;
}

/* ---------------- PSICO ---------------- */
const etqP={montado:"montado",listo:"listo",desactualizado:"desactualizado",pendiente:"pendiente",
            montando:"montando…",ok:"✓ montado",error:"error",publicado:"🔒 publicado"};
let ACTIVO=null;
let mapasSubs = localStorage.getItem("mapasSubs") !== "0";
let mapasSfx  = localStorage.getItem("mapasSfx") !== "0";
let mapasEstilo = localStorage.getItem("mapasEstilo") || "auto";
async function renderPsico(){
  const d = await (await fetch("/api/proyectos?nicho="+VISTA)).json();
  setHeader(d.raiz); filas=d.filas; ACTIVO=d.montaje_activo||null;
  (filas||[]).forEach(f => { if(f.ruta) f.ruta = f.ruta.replace(/\\/g, "/"); });
  const nom = ACTIVO ? (filas.find(f=>f.ruta===ACTIVO)||{}).nombre : null;
  const banner = ACTIVO ? `<div class="banner">▶ Montando «${nom||''}»… los demás botones esperan.</div>` : "";
  const btnEstudio = d.estudio ? `<button class="pri" onclick="abrir('${enc(d.estudio)}')">🗺️ Abrir Estudio Interactivo de Mapas</button>` : "";
  const btnFinales = (VISTA==="mapas" && d.finales_dir) ? `<button title="Abrir carpeta con los videos finales listos para subir" onclick="abrir('${enc(d.finales_dir)}')">📁 Videos Finales</button>` : "";
  const topMapas = (VISTA==="mapas")
    ? `<div style="margin:0 0 14px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;padding:10px 14px;background:rgba(255,255,255,0.03);border:1px solid var(--borde,#262b36);border-radius:10px">
         <b style="font-size:13px;color:#e2e8f0">Estilo de mapa:</b>
         <select id="selMapasEstilo" style="background:#1a1e26;color:#e2e8f0;border:1px solid var(--borde,#334155);border-radius:6px;padding:6px 10px;font-size:13px;cursor:pointer;outline:none;font-weight:500"
           onchange="mapasEstilo=this.value;localStorage.setItem('mapasEstilo',this.value)">
            <option value="viral" ${mapasEstilo==='viral'?'selected':''}>🔥 Estilo Viral Ganador (03 Apellidos Mexicanos - Sin Fichas HUD)</option>
           <option value="auto" ${mapasEstilo==='auto'?'selected':''}>Auto (Según proyecto / mapa.txt)</option>
           <option value="pequenos" ${mapasEstilo==='pequenos'?'selected':''}>🗺️ Países Pequeños / Ciudades (Zoom Profundo HD - Estilo Belice)</option>
           <option value="normal" ${mapasEstilo==='normal'?'selected':''}>🌍 Países Normales / Rutas (Continental HD - Estilo Pirámides)</option>
           <option value="clasico" ${mapasEstilo==='clasico'?'selected':''}>🏛️ Clásico Tradicional (Fichas Celestes HUD - Estilo Apellidos)</option>
           <option value="hibrido" ${mapasEstilo==='hibrido'?'selected':''}>🎬 Modo Híbrido 3D (Usa Video Base - AnimateMyMap / Earth)</option>
         </select>
         <b style="font-size:13px;color:#e2e8f0;margin-left:4px">Opciones:</b>
         <label class="chk" style="margin:0"><input type="checkbox" ${mapasSubs?'checked':''}
           onchange="mapasSubs=this.checked;localStorage.setItem('mapasSubs',this.checked?'1':'0')">Subtítulos</label>
         <label class="chk" style="margin:0"><input type="checkbox" ${mapasSfx?'checked':''}
           onchange="mapasSfx=this.checked;localStorage.setItem('mapasSfx',this.checked?'1':'0')">Efectos de sonido (Pop / Whoosh)</label>
         <div style="margin-left:auto;display:flex;align-items:center;gap:10px">
           <button class="pri" style="background:#10b981;border-color:#059669" onclick="ejecutarColaSegmentarMapas()" title="Segmentar guiones seleccionados con Whisper y generar mapa.json + prompts">📋 Segmentar Seleccionados</button>
           ${btnFinales}
           ${btnEstudio}
         </div>
       </div>`
    : "";
  const filasVisibles = ordenarFilas(filas);
  const barra = filas.length ? barraOrden(filas.length, filasVisibles.length, VISTA) : "";
  const todosMarcados = filasVisibles.length > 0 && filasVisibles.every(f => selRutas.has(f.ruta));
  main().innerHTML = topMapas + barra + (filas.length ? banner + `<div class="wrap"><table>
    <thead><tr>
      <th style="width:36px;text-align:center"><input type="checkbox" ${todosMarcados?'checked':''} onchange="toggleSelTodos(this.checked, filasVisibles)" title="Seleccionar todos"></th>
      <th style="width:105px">Creado</th><th>Video</th><th>Estado</th><th>Falta</th><th>${VISTA==='mapas'?'Pines':'Clips'}</th><th>${VISTA==='mapas'?'Formato':'Cortes'}</th><th>Acciones</th>
    </tr></thead>
    <tbody>${filasVisibles.map(filaPsico).join("")}</tbody></table></div>`
    : '<div class="msg">No encontré videos.</div>');
  poll(ACTIVO);
}
function faltaPsico(f){
  if(f.job&&f.job.estado==="montando") return `<span class="joblog">${f.job.linea||"montando…"}</span>`;
  if(f.job&&f.job.estado==="error") return `<b style="color:#f87171">falló — ${(f.job.linea||"").slice(0,80)}</b>`;
  if(!f.falta.length) return '<span style="color:var(--ok)">—</span>';
  return f.falta.map(x=>`<b>${x}</b>`).join(", ");
}
function filaPsico(f,i){
  const est=(f.job&&f.job.estado)?f.job.estado:(f.publicado?"publicado":f.estado);
  const veo=(f.clips===0&&f.veo_img>0)?` <span class="num">(veo ${f.veo_img})</span>`:"";
  const montando=f.job&&f.job.estado==="montando";
  const noMontar=!f.montable||montando||(ACTIVO&&ACTIVO!==f.ruta);
  const titu=f.titulo?`<br><span class="titu">▸ ${f.titulo.split('|').join(' / ')}</span>`:'';
  const btnVer = f.video_final ? `<button title="Reproducir MP4 final" onclick="abrir('${enc(f.video_final)}')">🎬</button>` : '';
  const btnSegmentar = (VISTA==="mapas") ? `<button title="Segmentar guion con Whisper, generar mapa.json y sincronia.txt" onclick="segmentarMapas('${enc(f.ruta)}')">📋 Segmentar</button>` : '';
  const btnPrompts = (VISTA==="mapas" && f.tiene_prompts) ? `<button title="Abrir prompts listos para el chat de IA" onclick="abrir('${enc(f.ruta + '/prompts_para_chat.txt')}')">💬 Prompts</button>` : '';
  const idx = filas.indexOf(f);
  const marcado = selRutas.has(f.ruta);
  return `<tr class="${f.publicado?'pub':''}" style="${marcado?'background:rgba(59,130,246,0.08)':''}">
    <td style="text-align:center" onclick="event.stopPropagation()"><input type="checkbox" ${marcado?'checked':''} onchange="toggleSel('${enc(f.ruta)}',this.checked)"></td>
    <td class="num" style="font-size:11.5px;color:var(--dim);white-space:nowrap" title="Fecha de creación">${f.fecha||'—'}</td>
    <td class="video">${f.nombre}${titu}</td>
    <td>${chip(est,etqP[est])}</td>
    <td class="falta">${faltaPsico(f)}</td>
    <td class="num">${f.clips}${veo}</td>
    <td class="num">${f.cortes}</td>
    <td class="acc">
      <button title="Abrir carpeta" onclick="abrir('${enc(f.ruta)}')">📂</button>
      ${btnVer}
      ${btnSegmentar}
      ${btnPrompts}
      <button title="${f.publicado?'Desbloquear':'Marcar publicado'}" onclick="marcar(${idx>=0?idx:i})">${f.publicado?'🔓':'🔒'}</button>
      <button class="pri" ${noMontar?'disabled':''} onclick="montar('${enc(f.ruta)}')">${montando?'…':'▶ Montar'}</button>
    </td></tr>`;
}
function segmentarMapas(ruta){
  const r = (typeof ruta === "string" && ruta.indexOf("%") >= 0) ? decodeURIComponent(ruta) : (ruta || "");
  ejecutarLoteGenerico("📋 Segmentando guion y mapa", [r], item => fetch("/api/mapas/segmentar?ruta="+enc(item),{method:"POST"}).then(x=>x.json()));
}
function sincronizarMapas(ruta){ segmentarMapas(ruta); }
function ejecutarColaSegmentarMapas(){
  const rutas = Array.from(selRutas);
  if(!rutas.length){ alert("Selecciona al menos un proyecto"); return; }
  ejecutarLoteGenerico("📋 Segmentando guiones y mapas", rutas, r => fetch("/api/mapas/segmentar?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function ejecutarColaSincronizarMapas(){ ejecutarColaSegmentarMapas(); }

function montar(ruta){
  const r = (typeof ruta === "string" && ruta.indexOf("%") >= 0) ? decodeURIComponent(ruta) : (ruta || "");
  const extra = (VISTA==="mapas") ? `&subs=${mapasSubs?"1":"0"}&sfx=${mapasSfx?"1":"0"}&estilo_preset=${enc(mapasEstilo)}` : "";
  ejecutarLoteGenerico("▶ Montando video", [r], item => fetch("/api/montar?nicho="+VISTA+"&ruta="+enc(item)+extra,{method:"POST"}).then(x=>x.json()));
}
function ejecutarColaMontar(){
  const rutas = Array.from(selRutas);
  if(!rutas.length){ alert("Selecciona al menos un proyecto"); return; }
  const extra = (VISTA==="mapas") ? `&subs=${mapasSubs?"1":"0"}&sfx=${mapasSfx?"1":"0"}&estilo_preset=${enc(mapasEstilo)}` : "";
  ejecutarLoteGenerico("▶ Montando videos", rutas, r => fetch("/api/montar?nicho="+VISTA+"&ruta="+enc(r)+extra,{method:"POST"}).then(x=>x.json()));
}
async function marcar(i){
  const f=filas[i];
  if(!f.publicado && !confirm("Marcar «"+f.nombre+"» como publicado. Se bloqueará el Montar. ¿Continuar?")) return;
  await fetch("/api/marcar?ruta="+enc(f.ruta)+"&publicado="+(f.publicado?"0":"1"),{method:"POST"});
  render();
}
async function marcarLote(publicar){
  const rutas = Array.from(selRutas);
  if(!rutas.length) return;
  for(const r of rutas){
    await fetch("/api/marcar?ruta="+enc(r)+"&publicado="+(publicar?"1":"0"),{method:"POST"});
  }
  selRutas.clear();
  render();
}

/* ---------------- ECOS ---------------- */
const etqE={cortado:"cortado",listo:"listo",pendiente:"pendiente",activo:"cortando…",ok:"✓ cortado",error:"error"};
async function renderEcos(){
  const d = await (await fetch("/api/ecos")).json();
  setHeader(d.raiz); ecosFilas=d.filas;
  const act=d.montaje_activo||null;
  const nom=act?(ecosFilas.find(f=>f.ruta===act)||{}).nombre:null;
  const banner=act?`<div class="banner">▶ Cortando «${nom||''}»… espera a que termine.</div>`:"";
  const top=`<label class="chk"><input type="checkbox" ${limpiarEcos?'checked':''}
     onchange="limpiarEcos=this.checked">Limpiar silencios (recorta pausas; deja el audio recortado dentro de cortes)</label>`;
  const vis = ordenarFilas(ecosFilas);
  const barra = ecosFilas.length ? barraOrden(ecosFilas.length, vis.length, "ecos") : "";
  const todosMarcados = vis.length > 0 && vis.every(f => selRutas.has(f.ruta));
  main().innerHTML = ecosFilas.length ? top+barra+banner+`<div class="wrap"><table>
    <thead><tr>
      <th style="width:36px;text-align:center"><input type="checkbox" ${todosMarcados?'checked':''} onchange="toggleSelTodos(this.checked, vis)" title="Seleccionar todos"></th>
      <th style="width:105px">Creado</th><th>Guion</th><th>Estado</th><th>Falta</th><th>Clips</th><th>Cortes</th><th>Acciones</th>
    </tr></thead>
    <tbody>${vis.map((f,i)=>filaEcos(f,i,act)).join("")}</tbody></table></div>`
    : '<div class="msg">No encontré guiones (carpetas que empiezan por número) en NUEVOS GUIONES.</div>';
  poll(act);
}
function filaEcos(f,i,act){
  const est=(f.job&&f.job.estado)?f.job.estado:f.estado;
  const cortando=f.job&&f.job.estado==="activo";
  const noCortar=!f.cortable||cortando||(act&&act!==f.ruta);
  let falta;
  if(f.job&&f.job.estado==="activo") falta=`<span class="joblog">${f.job.linea||"cortando…"}</span>`;
  else if(f.job&&f.job.estado==="error") falta=`<b style="color:#f87171">falló — ${(f.job.linea||"").slice(0,80)}</b>`;
  else if(!f.falta.length) falta='<span style="color:var(--ok)">—</span>';
  else falta=f.falta.map(x=>`<b>${x}</b>`).join(", ");
  const lm=f.limpio?' <span class="num">(audio limpio)</span>':'';
  const marcado = selRutas.has(f.ruta);
  return `<tr style="${marcado?'background:rgba(59,130,246,0.08)':''}">
    <td style="text-align:center" onclick="event.stopPropagation()"><input type="checkbox" ${marcado?'checked':''} onchange="toggleSel('${f.ruta}',this.checked)"></td>
    <td class="num" style="font-size:11.5px;color:var(--dim);white-space:nowrap" title="Fecha de creación">${f.fecha||'—'}</td>
    <td class="video">${f.nombre}</td>
    <td>${chip(est,etqE[est])}</td>
    <td class="falta">${falta}</td>
    <td class="num">${f.clips}</td>
    <td class="num">${f.cortes}${lm}</td>
    <td class="acc">
      <button title="Abrir carpeta" onclick="abrir('${enc(f.ruta)}')">📂</button>
      ${f.video_completo ? `<button title="Reproducir video montado (subtitulado si existe)" onclick="abrir('${enc(f.video_completo)}')">▶ Ver Video</button>` : ''}
      ${f.tiene_video ? `<button title="Generar subtítulos karaoke estilo CapCut (Melvins One / #ff0050)" onclick="subtitularEcos('${f.ruta}')">💬 Subtitular</button>` : ''}
      ${f.tiene_guion ? `<button title="Segmentar guion y generar sincronia.txt" onclick="segmentarEcos('${f.ruta}')">📋 Segmentar</button>` : ''}
      ${f.tiene_img ? `<button title="Fusionar imagen.txt en sincronia.txt" onclick="unirEcos('${f.ruta}')">🔗 Unir</button>` : ''}
      <button class="pri" ${noCortar?'disabled':''} onclick="cortarEcos('${f.ruta}')">${cortando?'…':'✂ Cortar'}</button>
    </td></tr>`;
}
function cortarEcos(ruta){
  ejecutarLoteGenerico("✂ Cortando escenas", [ruta], r => fetch("/api/ecos/cortar?ruta="+enc(r)+"&limpiar="+(limpiarEcos?"1":"0"),{method:"POST"}).then(x=>x.json()));
}
function subtitularEcos(ruta){
  ejecutarLoteGenerico("💬 Generando subtítulos karaoke", [ruta], r => fetch("/api/ecos/subtitulos?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function segmentarEcos(ruta){
  ejecutarLoteGenerico("📋 Segmentando guion", [ruta], r => fetch("/api/ecos/segmentar?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function unirEcos(ruta){
  ejecutarLoteGenerico("🔗 Fusionando imagen.txt", [ruta], r => fetch("/api/ecos/unir?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function ejecutarColaEcos(accion){
  const rutas = Array.from(selRutas);
  if(!rutas.length){ alert("Selecciona al menos un proyecto"); return; }
  if(accion === "segmentar"){
    ejecutarLoteGenerico("📋 Segmentando guiones", rutas, r => fetch("/api/ecos/segmentar?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
  } else if(accion === "unir"){
    ejecutarLoteGenerico("🔗 Fusionando imagen.txt", rutas, r => fetch("/api/ecos/unir?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
  } else if(accion === "subtitular"){
    ejecutarLoteGenerico("💬 Generando subtítulos karaoke", rutas, r => fetch("/api/ecos/subtitulos?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
  } else if(accion === "cortar"){
    ejecutarLoteGenerico("✂ Cortando escenas", rutas, r => fetch("/api/ecos/cortar?ruta="+enc(r)+"&limpiar="+(limpiarEcos?"1":"0"),{method:"POST"}).then(x=>x.json()));
  }
}

/* ---------------- EBOOK ---------------- */
const etqB={generado:"✓ generado",listo:"listo",pendiente:"pendiente",desactualizado:"desactualizado",
            activo:"generando…",ok:"✓ generado",error:"error"};
let ebookFilas=[];
async function renderEbook(){
  const d = await (await fetch("/api/ebook")).json();
  setHeader(d.raiz); ebookFilas=d.filas;
  const act=d.montaje_activo||null;
  const nom=act?(ebookFilas.find(f=>f.ruta===act)||{}).nombre:null;
  const banner=act?`<div class="banner">▶ Generando «${nom||''}»… espera a que termine.</div>`:"";
  const top=`<div style="margin:0 0 12px"><button class="pri" onclick="nuevoEbook()">➕ Nuevo libro</button>
     <span class="num" style="margin-left:10px">Cada libro = carpeta con guiones.md + veo/ (imágenes 001, 002…) + libro.txt</span></div>`;
  const vis = ordenarFilas(ebookFilas);
  const barra = ebookFilas.length ? barraOrden(ebookFilas.length, vis.length, "ebook") : "";
  const todosMarcados = vis.length > 0 && vis.every(f => selRutas.has(f.ruta));
  main().innerHTML = top+barra+banner+(ebookFilas.length ? `<div class="wrap"><table>
    <thead><tr>
      <th style="width:36px;text-align:center"><input type="checkbox" ${todosMarcados?'checked':''} onchange="toggleSelTodos(this.checked, vis)" title="Seleccionar todos"></th>
      <th style="width:105px">Creado</th><th>Libro</th><th>Estado</th><th>Falta</th><th>Historias</th><th>Imágenes</th><th>Páginas</th><th>Acciones</th>
    </tr></thead>
    <tbody>${vis.map((f,i)=>filaEbook(f,i,act)).join("")}</tbody></table></div>`
    : '<div class="msg">Aún no hay libros. Pulsa «Nuevo libro», pega los guiones en guiones.md y mete las imágenes en veo.</div>');
  poll(act);
}
function filaEbook(f,i,act){
  const est=(f.job&&f.job.estado)?f.job.estado:f.estado;
  const gen=f.job&&f.job.estado==="activo";
  const noGen=!f.generable||gen||(act&&act!==f.ruta);
  let falta;
  if(gen) falta=`<span class="joblog">${f.job.linea||"generando…"}</span>`;
  else if(f.job&&f.job.estado==="error") falta=`<b style="color:#f87171">falló — ${(f.job.linea||"").slice(0,90)}</b>`;
  else if(!f.falta.length) falta='<span style="color:var(--ok)">—</span>';
  else falta=f.falta.map(x=>`<b>${x}</b>`).join(", ");
  const marcado = selRutas.has(f.ruta);
  return `<tr style="${marcado?'background:rgba(59,130,246,0.08)':''}">
    <td style="text-align:center" onclick="event.stopPropagation()"><input type="checkbox" ${marcado?'checked':''} onchange="toggleSel('${f.ruta}',this.checked)"></td>
    <td class="num" style="font-size:11.5px;color:var(--dim);white-space:nowrap" title="Fecha de creación">${f.fecha||'—'}</td>
    <td class="video">${f.nombre}</td>
    <td>${chip(est,etqB[est])}</td>
    <td class="falta">${falta}</td>
    <td class="num">${f.historias}</td>
    <td class="num">${f.imagenes}</td>
    <td class="num">${f.paginas||"—"}</td>
    <td class="acc">
      <button title="Abrir carpeta" onclick="abrir('${enc(f.ruta)}')">📂</button>
      <button title="Abrir guiones" ${f.guion?'':'disabled'} onclick="abrir('${enc(f.guion)}')">📝</button>
      <button title="Abrir PDF" ${f.pdf?'':'disabled'} onclick="abrir('${enc(f.pdf)}')">📄</button>
      <button class="pri" ${noGen?'disabled':''} onclick="generarEbook('${f.ruta}')">${gen?'…':'📖 Generar'}</button>
    </td></tr>`;
}
function generarEbook(ruta){
  ejecutarLoteGenerico("📖 Generando libro", [ruta], r => fetch("/api/ebook/generar?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function ejecutarColaEbook(){
  const rutas = Array.from(selRutas);
  if(!rutas.length){ alert("Selecciona al menos un libro"); return; }
  ejecutarLoteGenerico("📖 Generando libros", rutas, r => fetch("/api/ebook/generar?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
async function nuevoEbook(){
  const nombre = prompt("Nombre del libro nuevo:");
  if(!nombre) return;
  const d = await (await fetch("/api/ebook/nuevo?nombre="+enc(nombre),{method:"POST"})).json();
  if(!d.ok){ alert(d.msg||"no se pudo crear"); return; }
  abrir(enc(d.ruta)); render();
}

/* ---------------- FAMOSOS ---------------- */
const etqFam={montado:"✓ montado",listo:"listo",sin_audio:"falta audio",sin_videos:"falta videos",pendiente:"pendiente",activo:"montando…",error:"error"};
const clsFam={montado:"listo",listo:"listo",sin_audio:"pendiente",sin_videos:"pendiente",pendiente:"pendiente",activo:"activo",error:"error"};
async function renderFamosos(){
  const d = await (await fetch("/api/famosos")).json();
  setHeader(d.raiz); famFilas=d.filas;
  const act=d.montaje_activo||null;
  const nom=act?(famFilas.find(f=>f.ruta===act)||{}).nombre:null;
  const banner=act?`<div class="banner">▶ Montando «${nom||''}»… espera a que termine.</div>`:"";
  const vis = ordenarFilas(famFilas);
  const barra = famFilas.length ? barraOrden(famFilas.length, vis.length, "famosos") : "";
  const todosMarcados = vis.length > 0 && vis.every(f => selRutas.has(f.ruta));
  main().innerHTML = famFilas.length ? barra+banner+`<div class="wrap"><table>
    <thead><tr>
      <th style="width:36px;text-align:center"><input type="checkbox" ${todosMarcados?'checked':''} onchange="toggleSelTodos(this.checked, vis)" title="Seleccionar todos"></th>
      <th>Proyecto / Famoso</th><th>Estado</th><th style="min-width:220px">Versión / Audio</th><th>Videos</th><th>Clips CapCut</th><th>Acción</th>
    </tr></thead>
    <tbody>${vis.map((f,i)=>filaFamosos(f,i,act)).join("")}</tbody></table></div>`
    : '<div class="msg">No hay carpetas de famosos en FAMOSOS.<br>Crea una con el nombre del famoso y mete dentro los videos + el audio del guion.</div>';
  poll(act);
}
function filaFamosos(f,i,act){
  const est=(f.job&&f.job.estado)?f.job.estado:f.estado;
  const trab=f.job&&f.job.estado==="activo";
  const bloq=act&&act!==f.ruta;
  const marcado = selRutas.has(f.ruta);
  let selectorAudio = "";
  if(f.audios_info && f.audios_info.length){
    const opts = f.audios_info.map((a, idx) => {
      const sel = idx === 0 ? "selected" : "";
      return `<option value="${a.archivo.replace(/"/g, '&quot;')}" ${sel}>${a.etiqueta}</option>`;
    }).join("");
    selectorAudio = `<select id="aud_${i}" class="form-control input-sm" style="font-size:12px; height:28px;" onclick="event.stopPropagation()">${opts}</select>`;
  } else {
    selectorAudio = '<span style="color:#f87171">Sin audio</span>';
  }
  const clipsCapcutHtml = f.clips_capcut > 0
    ? `<span style="color:var(--ok);font-weight:700" title="Guía: ${f.guia_capcut?'✓':''}">🎬 ${f.clips_capcut} clips</span>`
    : (f.cortes > 0 ? `<span style="color:var(--dim)">${f.cortes} cortes</span>` : '<span style="color:var(--dim)">—</span>');

  return `<tr style="${marcado?'background:rgba(59,130,246,0.08)':''}">
    <td style="text-align:center" onclick="event.stopPropagation()"><input type="checkbox" ${marcado?'checked':''} onchange="toggleSel('${f.ruta}',this.checked)"></td>
    <td class="video"><b>${f.nombre}</b></td>
    <td>${chip(est,etqFam[est]||est)}</td>
    <td onclick="event.stopPropagation()">${selectorAudio}</td>
    <td class="num">${f.videos}</td>
    <td class="num">${clipsCapcutHtml}</td>
    <td class="acc" onclick="event.stopPropagation()">
      <button title="Abrir carpeta" onclick="abrir('${enc(f.ruta)}')">📂</button>
      <button class="pri" style="background:#059669;border-color:#047857;" title="Extraer tomas limpias para CapCut (2.5s-3.5s)" ${trab||bloq?'disabled':''} onclick="extraerClipsFamoso(${i})">✂ Clips</button>
      <button title="Generar video completo" ${trab||bloq?'disabled':''} onclick="montarFilaFamoso(${i})">▶</button>
    </td>
  </tr>`;
}
async function extraerClipsFamoso(i){
  const f = famFilas[i];
  if(!f) return;
  const selAud = document.getElementById("aud_" + i);
  const audio = selAud ? selAud.value : (f.audios && f.audios[0] ? f.audios[0] : "");
  ejecutarLoteGenerico("✂ Extrayendo clips CapCut", [f.ruta], r => fetch(`/api/famosos/clips?ruta=${enc(r)}&audio=${enc(audio)}`,{method:"POST"}).then(x=>x.json()));
}

function ejecutarColaFamosos(accion){
  const rutas = Array.from(selRutas);
  if(!rutas.length){ alert("Selecciona al menos un proyecto"); return; }
  if(accion === "clips"){
    ejecutarLoteGenerico("✂ Extrayendo clips CapCut", rutas, r => {
      const f = famFilas.find(x => x.ruta === r);
      const audio = f && f.audios && f.audios.length ? f.audios[0] : "";
      return fetch(`/api/famosos/clips?ruta=${enc(r)}&audio=${enc(audio)}`,{method:"POST"}).then(x=>x.json());
    });
  } else {
    ejecutarLoteGenerico("▶ Montando videos de famosos", rutas, r => {
      const f = famFilas.find(x => x.ruta === r);
      const audio = f && f.audios && f.audios.length ? f.audios[0] : "";
      return fetch(`/api/famosos/producir?ruta=${enc(r)}&audio=${enc(audio)}&formato=face_crop&subtitulos=1`,{method:"POST"}).then(x=>x.json());
    });
  }
}

async function montarFilaFamoso(i){
  const f = famFilas[i];
  if(!f) return;
  const selAud = document.getElementById("aud_" + i);
  const audio = selAud ? selAud.value : (f.audios && f.audios[0] ? f.audios[0] : "");
  if(!audio){ alert("Elige el audio de la narración"); return; }
  const d = await (await fetch(`/api/famosos/producir?ruta=${enc(f.ruta)}&audio=${enc(audio)}&formato=face_crop&subtitulos=1`,{method:"POST"})).json();
  if(!d.ok) alert(d.msg||"no se pudo iniciar el montaje"); render();
}
async function generar(i,ruta){ return montarFilaFamoso(i); }

/* ---------------- PELICULAS (recaps) ---------------- */
const etqPel={montado:"montado",listo:"listo",desactualizado:"desactualizado",
              pendiente:"pendiente",montando:"montando…",ok:"✓ montado",error:"error",
              publicado:"🔒 publicado",sin_transcribir:"sin transcribir",
              transcrito:"transcrito",activo:"transcribiendo…"};
const clsPel={sin_transcribir:"pendiente",transcrito:"listo",activo:"activo"};
let pelFilas=[], ACTPEL=null;
async function renderPeliculas(){
  const d = await (await fetch("/api/peliculas")).json();
  setHeader(d.raiz); pelFilas=d.filas; ACTPEL=d.montaje_activo||null;
  const nom=ACTPEL?(pelFilas.find(f=>f.ruta===ACTPEL)||{}).nombre:null;
  const banner=ACTPEL?`<div class="banner">▶ Montando «${nom||''}»… los demás esperan.</div>`:"";
  const ayuda=`<div class="falta" style="margin-bottom:12px">Flujo (1 largo + 2 anzuelos): sube
     <b>fuente.mp4</b> a su carpeta en <b style="color:var(--acc)">${d.raiz}</b> → <b>📝 Transcribir</b>
     (chino → fuente.srt) → pásale ese SRT a Claude con la skill → te devuelve los guiones + los
     <b>_sync.json</b> → generas el TTS (<b>largo.mp3</b>, <b>P1.mp3</b>, <b>P2.mp3</b>) y guardas los
     <b>*_sync.json</b> → <b>▶ Montar</b> (saca el largo + 2 shorts, sin subs, para CapCut).</div>`;
  const vis = ordenarFilas(pelFilas);
  const barra = pelFilas.length ? barraOrden(pelFilas.length, vis.length, "peliculas") : "";
  const todosMarcados = vis.length > 0 && vis.every(f => selRutas.has(f.ruta));
  main().innerHTML = ayuda + (pelFilas.length ? barra+banner+`<div class="wrap"><table>
    <thead><tr>
      <th style="width:36px;text-align:center"><input type="checkbox" ${todosMarcados?'checked':''} onchange="toggleSelTodos(this.checked, vis)" title="Seleccionar todos"></th>
      <th style="width:105px">Creado</th><th>Recap</th><th>Estado</th><th>Falta</th><th>Fuente</th><th>Videos</th><th>Acciones</th>
    </tr></thead>
    <tbody>${vis.map(filaPel).join("")}</tbody></table></div>`
    : '<div class="msg">No hay recaps todavía. Crea una carpeta en PELICULAS y mete fuente.mp4 (luego largo.mp3 + P1.mp3 + P2.mp3).</div>');
  poll(ACTPEL);
}
function faltaPel(f){
  if(f.job&&f.job.estado==="montando") return `<span class="joblog">${f.job.linea||"montando…"}</span>`;
  if(f.job&&f.job.estado==="activo") return `<span class="joblog">${f.job.linea||"transcribiendo…"}</span>`;
  if(f.job&&f.job.estado==="error") return `<b style="color:#f87171">falló — ${(f.job.linea||"").slice(0,80)}</b>`;
  if(!f.falta.length) return '<span style="color:var(--ok)">—</span>';
  return f.falta.map(x=>`<b>${x}</b>`).join(", ");
}
function filaPel(f,i){
  const est=(f.job&&f.job.estado)?f.job.estado:(f.publicado?"publicado":f.estado);
  const cls=clsPel[est]||est;
  const trabajando=f.job&&(f.job.estado==="montando"||f.job.estado==="activo");
  const otra=ACTPEL&&ACTPEL!==f.ruta;
  const noTrans=!f.transcribible||trabajando||otra;
  const noMontar=!f.montable||trabajando||otra;
  const idx = pelFilas.indexOf(f);
  const marcado = selRutas.has(f.ruta);
  return `<tr class="${f.publicado?'pub':''}" style="${marcado?'background:rgba(59,130,246,0.08)':''}">
    <td style="text-align:center" onclick="event.stopPropagation()"><input type="checkbox" ${marcado?'checked':''} onchange="toggleSel('${f.ruta}',this.checked)"></td>
    <td class="num" style="font-size:11.5px;color:var(--dim);white-space:nowrap" title="Fecha de creación">${f.fecha||'—'}</td>
    <td class="video">${f.nombre}</td>
    <td>${chip(cls,etqPel[est]||est)}</td>
    <td class="falta">${faltaPel(f)}</td>
    <td class="num">${f.fuente?(f.transcrito?'✓ +texto':'✓'):'<b style="color:var(--warn)">falta</b>'}</td>
    <td class="num" style="text-align:left;font-size:12px;line-height:1.5">${(f.videos&&f.videos.length)?f.videos.map(v=>{
        const ic=v.montado?(v.desactualizado?'⟳':'✓'):'⋯';
        const col=v.montado?(v.desactualizado?'var(--warn)':'var(--ok)'):'#888';
        const sy=v.sync?'':' <span style="color:var(--warn)" title="sin mapa de sync: montará con auto-plan">⚠</span>';
        return `<span style="color:${col}">${v.nombre} ${ic}</span>${sy}`;
      }).join('<br>'):'<b style="color:var(--warn)">falta voz</b>'}</td>
    <td class="acc">
      <button title="Abrir carpeta" onclick="abrir('${enc(f.ruta)}')">📂</button>
      <button title="${f.publicado?'Desbloquear':'Marcar publicado'}" onclick="marcarPel(${idx>=0?idx:i})">${f.publicado?'🔓':'🔒'}</button>
      <button title="Transcribir la fuente (chino)" ${noTrans?'disabled':''} onclick="transcribirPel('${f.ruta}')">${f.job&&f.job.estado==="activo"?'…':'📝'}</button>
      <button class="pri" ${noMontar?'disabled':''} onclick="montarPel('${f.ruta}')">${f.job&&f.job.estado==="montando"?'…':'▶ Montar'}</button>
    </td></tr>`;
}
function transcribirPel(ruta){
  ejecutarLoteGenerico("📝 Transcribiendo fuente", [ruta], r => fetch("/api/peliculas/transcribir?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function montarPel(ruta){
  ejecutarLoteGenerico("▶ Montando recap", [ruta], r => fetch("/api/montar?nicho=peliculas&ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
}
function ejecutarColaPel(accion){
  const rutas = Array.from(selRutas);
  if(!rutas.length){ alert("Selecciona al menos un proyecto"); return; }
  if(accion === "montar"){
    ejecutarLoteGenerico("▶ Montando recaps", rutas, r => fetch("/api/montar?nicho=peliculas&ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
  } else {
    ejecutarLoteGenerico("📝 Transcribiendo fuentes", rutas, r => fetch("/api/peliculas/transcribir?ruta="+enc(r),{method:"POST"}).then(x=>x.json()));
  }
}
async function marcarPel(i){
  const f=pelFilas[i];
  if(!f.publicado && !confirm("Marcar «"+f.nombre+"» como publicado. Se bloqueará el Montar. ¿Continuar?")) return;
  await fetch("/api/marcar?ruta="+enc(f.ruta)+"&publicado="+(f.publicado?"0":"1"),{method:"POST"});
  render();
}

/* ---------------- TRANSCRIBIR (herramienta general) ---------------- */
// Sin opciones en pantalla: siempre modelo "medium" (el mas exacto) e idioma
// automatico. Videos cortos (~2 min) -> exacto sin demorar demasiado.
const TR_MODELO="medium", TR_IDIOMA="auto";
let trCarpeta="";
let trVideos=[], trSel={}, trBaseJob="";

async function renderTranscribir(){
  setHeader("Saca el guion de tus videos (uno solo → su .txt/.srt; varios → un único _GUIONES.txt para analizar).");
  // ¿hay un lote en curso / recién terminado en esta carpeta?
  let job=null;
  if(trBaseJob){ try{ job = await (await fetch("/api/job?ruta="+enc(trBaseJob))).json(); }catch(e){} }
  const trabajando = job && (job.estado==="activo" || job.estado==="montando");
  let otro=false;
  if(!trabajando){ try{ otro = !!(await (await fetch("/api/estado")).json()).activo; }catch(e){} }

  let estadoHtml="";
  if(job){
    if(trabajando) estadoHtml=`<div class="tr-est act">▶ ${job.linea||"transcribiendo…"}</div>`;
    else if(job.estado==="ok") estadoHtml=`<div class="tr-est ok">✓ Listo. ${nSel()>1?`Todos los guiones están en un único <b>_GUIONES.txt</b> dentro de la carpeta`:`El video tiene su <b>.txt</b> y <b>.srt</b> junto a él`}. <button onclick="abrir('${enc(trCarpeta)}')" style="margin-left:8px">📂 Abrir carpeta</button></div>`;
    else if(job.estado==="error") estadoHtml=`<div class="tr-est err">✕ Falló — ${(job.linea||"").slice(0,120)}</div>`;
    else if(job.estado==="cancelado") estadoHtml=`<div class="tr-est err">Cancelado.</div>`;
  }

  // ---- lista de videos (si ya se cargó una carpeta) ----
  let lista="";
  if(trVideos.length){
    const marcados=nSel();
    const todos = marcados===trVideos.length && marcados>0;
    lista=`<div class="tr-listwrap">
      <div class="tr-listhead">
        <label class="tr-all"><input type="checkbox" ${todos?'checked':''} onchange="trTodos(this.checked)">
          Seleccionar todos</label>
        <span class="tr-count">${marcados} de ${trVideos.length} marcados</span>
      </div>
      <div class="tr-list">${trVideos.map((v,i)=>`
        <label class="tr-item ${trSel[v.ruta]?'on':''}">
          <input type="checkbox" ${trSel[v.ruta]?'checked':''} onchange="trMarca(${i},this.checked)">
          <span class="tr-name">${v.nombre}</span>
          ${v.txt?'<span class="tr-tag">ya tiene .txt</span>':''}
        </label>`).join("")}</div>
    </div>
    <div style="margin-top:12px">
      <button class="pri" ${(trabajando||otro||marcados===0)?'disabled':''} onclick="transcribirLote()">
        ${trabajando?'…transcribiendo':'🎙️ Transcribir '+(marcados||'')+' seleccionado'+(marcados===1?'':'s')}</button>
      ${otro&&!trabajando?'<span class="tr-est" style="margin-left:10px">Hay otro proceso en curso; espera.</span>':''}
    </div>`;
  }

  main().innerHTML = `<div class="tr-box">
    <p class="tr-help">Pulsa <b>Examinar…</b> y elige la <b>carpeta</b> donde bajaste los videos (de
      cualquier nicho), o pega la ruta. Marca los que quieras (o <b>todos</b>) y saca el guion.
      Si eliges <b>más de un video</b> solo se crea un único <b>_GUIONES.txt</b> con todos (para
      analizar la estructura ganadora); si eliges <b>uno solo</b>, deja su .txt y .srt.</p>
    <label>Carpeta con los videos</label>
    <div class="tr-row">
      <button onclick="examinarCarpeta()">📁 Examinar…</button>
      <input id="trCarpeta" type="text" spellcheck="false"
        placeholder="C:\\\\Users\\\\...\\\\mis_videos_virales"
        value="${(trCarpeta||'').replace(/"/g,'&quot;')}" oninput="trCarpeta=this.value"
        onkeydown="if(event.key==='Enter')cargarVideos()">
      <button onclick="cargarVideos()">📂 Cargar videos</button>
    </div>
    ${lista}
    ${estadoHtml}
  </div>`;
  poll(trabajando);
}
function nSel(){ return trVideos.filter(v=>trSel[v.ruta]).length; }
function trTodos(on){ trVideos.forEach(v=>trSel[v.ruta]=on); render(); }
function trMarca(i,on){ trSel[trVideos[i].ruta]=on; render(); }
async function examinarCarpeta(){
  let d;
  try{ d = await (await fetch("/api/elegir_carpeta?dir="+enc(trCarpeta||""))).json(); }
  catch(e){ alert("No se pudo abrir el explorador"); return; }
  if(!d.ok || !d.ruta) return;                    // canceló
  trCarpeta=d.ruta;
  document.getElementById("trCarpeta").value=d.ruta;
  cargarVideos();
}
async function cargarVideos(){
  const carp=(document.getElementById("trCarpeta").value||"").trim();
  if(!carp){ alert("Pega la ruta de la carpeta"); return; }
  trCarpeta=carp;
  const d = await (await fetch("/api/videos?carpeta="+enc(carp))).json();
  if(!d.ok){ alert(d.msg||"no se pudo leer la carpeta"); return; }
  trVideos=d.videos||[]; trSel={};
  trVideos.forEach(v=>trSel[v.ruta]=true);        // por defecto: todos marcados
  trBaseJob="";                                    // limpia el estado del lote anterior
  if(!trVideos.length) alert("No encontré videos en esa carpeta (ni subcarpetas).");
  render();
}
async function transcribirLote(){
  const rutas=trVideos.filter(v=>trSel[v.ruta]).map(v=>v.ruta);
  if(!rutas.length){ alert("Marca al menos un video"); return; }
  trBaseJob=trCarpeta;
  const d = await (await fetch("/api/transcribir_lote",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({carpeta:trCarpeta, rutas, idioma:TR_IDIOMA, modelo:TR_MODELO, combinar:true})})).json();
  if(!d.ok){ alert(d.msg||"no se pudo transcribir"); return; }
  render();
}

/* ---------------- VOZ (ai33 · Text-To-Speech) ---------------- */
let vozArchivo="", vozJob="", vozNicho="ecos", vozConfigs=[], vozGuiones=null;
async function renderVoz(){
  setHeader("Convierte un .txt de guiones (separados por «GUION: numero») en audios .mp3. Los .mp3 quedan junto al .txt.");
  if(!vozConfigs.length){ try{ vozConfigs=(await (await fetch("/api/voz/configs")).json()).configs||[]; }catch(e){} }
  if(vozConfigs.length && !vozConfigs.some(c=>c.id===vozNicho)) vozNicho=vozConfigs[0].id;
  let job=null;
  if(vozJob){ try{ job = await (await fetch("/api/job?ruta="+enc(vozJob))).json(); }catch(e){} }
  const trabajando = job && (job.estado==="activo" || job.estado==="montando");
  let otro=false;
  if(!trabajando){ try{ otro = !!(await (await fetch("/api/estado")).json()).activo; }catch(e){} }

  let estadoHtml="";
  if(job){
    if(trabajando) estadoHtml=`<div class="tr-est act">▶ ${job.linea||"generando audios…"}</div>`;
    else if(job.estado==="ok") estadoHtml=`<div class="tr-est ok">✓ Listo. Los .mp3 quedaron junto al archivo. <button onclick="abrirCarpetaDe('${enc(vozArchivo)}')" style="margin-left:8px">📂 Abrir carpeta</button></div>`;
    else if(job.estado==="error") estadoHtml=`<div class="tr-est err">✕ Falló — ${(job.linea||"").slice(0,140)}</div>`;
    else if(job.estado==="cancelado") estadoHtml=`<div class="tr-est err">Cancelado.</div>`;
  }

  // info del archivo seleccionado (para verificar antes de generar)
  const selHtml = vozArchivo ? `<div class="sel" style="margin-top:12px">
      Archivo seleccionado: <b>${vozArchivo.split(/[\\/]/).pop()}</b>${
        vozGuiones!=null ? ` <span class="tr-tag">${vozGuiones} guion${vozGuiones===1?'':'es'}</span>` : ''}
      <div class="num" style="margin-top:3px">${vozArchivo}</div>
    </div>` : "";

  main().innerHTML = `<div class="tr-box">
    <p class="tr-help">Pulsa <b>Examinar…</b> y elige tu .txt de guiones desde el explorador de
      Windows. Cada guion empieza con <b>GUION: 1</b>, <b>GUION: 2</b>… y ese número será el nombre
      del audio. Los .mp3 quedan en la misma carpeta del .txt.<br>
      Elige el <b>nicho</b>: cada uno usa su propia voz y clave (archivo <b>ai33_&lt;nicho&gt;.txt</b> dentro del proyecto).</p>
    <label>Nicho (voz a usar)</label>
    <select onchange="vozNicho=this.value" style="max-width:320px">
      ${vozConfigs.map(c=>`<option value="${c.id}" ${c.id===vozNicho?'selected':''}>${c.nombre}${c.listo?'':' — (sin config)'}</option>`).join("")}
    </select>
    <label style="margin-top:12px">Archivo de guiones</label>
    <div class="tr-row">
      <button onclick="examinarTxt()">📁 Examinar…</button>
      ${vozArchivo?'<button onclick="examinarTxt()">Cambiar archivo</button>':''}
    </div>
    ${selHtml}
    <div style="margin-top:14px">
      <button class="pri" ${(trabajando||otro||!vozArchivo)?'disabled':''} onclick="generarVoz()">
        ${trabajando?'…generando':'🔊 Generar audios'}</button>
      ${otro&&!trabajando?'<span class="tr-est" style="margin-left:10px">Hay otro proceso en curso; espera.</span>':''}
    </div>
    ${estadoHtml}
  </div>`;
  poll(trabajando);
}
async function examinarTxt(){
  let d;
  try{ d = await (await fetch("/api/elegir_txt?dir="+enc(vozArchivo.replace(/[\\/][^\\/]*$/,"")||""))).json(); }
  catch(e){ alert("No se pudo abrir el explorador"); return; }
  if(!d.ok || !d.ruta) return;                    // canceló
  vozArchivo = d.ruta; vozGuiones = null;
  try{                                            // cuenta cuántos guiones tiene (solo como info)
    const carp = d.ruta.replace(/[\\/][^\\/]*$/,"");
    const t = await (await fetch("/api/txts?carpeta="+enc(carp))).json();
    if(t.ok){ const m=(t.txts||[]).find(x=>x.ruta===d.ruta); if(m) vozGuiones=m.guiones; }
  }catch(e){}
  render();
}
async function abrirCarpetaDe(archivoEnc){
  // abre la carpeta contenedora del archivo
  const p=decodeURIComponent(archivoEnc);
  const carp=p.replace(/[\\/][^\\/]*$/,"");
  await fetch("/api/abrir?ruta="+enc(carp));
}
async function generarVoz(){
  const f=(vozArchivo||"").trim();
  if(!f){ alert("Pulsa Examinar… y elige un archivo .txt"); return; }
  vozJob=f;
  const d = await (await fetch("/api/voz/generar?ruta="+enc(f)+"&nicho="+enc(vozNicho),{method:"POST"})).json();
  if(!d.ok){ alert(d.msg||"no se pudo iniciar"); return; }
  render();
}

/* ---------------- RECORTAR AUDIO (respiros + silencios, por nicho) ---------------- */
let recArchivo="", recJob="", recNicho="medio", recPresets=[], recBordes=false, recRespiros=true;
async function renderRecorte(){
  setHeader("Limpia respiros y acorta los silencios largos de un audio según el nicho (no cambia la voz). Deja <nombre>_recortado.mp3 junto al original.");
  if(!recPresets.length){ try{ recPresets=(await (await fetch("/api/recorte/presets")).json()).presets||[]; }catch(e){} }
  if(recPresets.length && !recPresets.some(p=>p.id===recNicho)) recNicho=recPresets[0].id;
  let job=null;
  if(recJob){ try{ job = await (await fetch("/api/job?ruta="+enc(recJob))).json(); }catch(e){} }
  const trabajando = job && (job.estado==="activo" || job.estado==="montando");
  let otro=false;
  if(!trabajando){ try{ otro = !!(await (await fetch("/api/estado")).json()).activo; }catch(e){} }

  let estadoHtml="";
  if(job){
    if(trabajando) estadoHtml=`<div class="tr-est act">▶ ${job.linea||"recortando…"}</div>`;
    else if(job.estado==="ok") estadoHtml=`<div class="tr-est ok">✓ Listo. El <b>_recortado.mp3</b> quedó junto al original. <button onclick="abrirCarpetaDe('${enc(recArchivo)}')" style="margin-left:8px">📂 Abrir carpeta</button></div>`;
    else if(job.estado==="error") estadoHtml=`<div class="tr-est err">✕ Falló — ${(job.linea||"").slice(0,140)}</div>`;
    else if(job.estado==="cancelado") estadoHtml=`<div class="tr-est err">Cancelado.</div>`;
  }

  const selHtml = recArchivo ? `<div class="sel" style="margin-top:12px">
      Audio seleccionado: <b>${recArchivo.split(/[\\/]/).pop()}</b>
      <div class="num" style="margin-top:3px">${recArchivo}</div>
    </div>` : "";

  main().innerHTML = `<div class="tr-box">
    <p class="tr-help">Pulsa <b>Examinar…</b> y elige el <b>.mp3</b> de la voz. Elige el <b>nicho</b>
      (cada uno deja más o menos pausa) y recorta. El audio no cambia de tono ni velocidad: primero
      <b>limpia los respiros</b> (los suspiros de tomar aire entre palabras) sustituyéndolos por un
      silencio del mismo largo —sin pegar las palabras—, y luego <b>acorta los silencios largos</b>.
      <br>Siguiente paso: transcribe el audio <b>ya recortado</b> (con tiempos) y pasa esos tiempos a
      la skill de prompts.</p>
    <label>Nicho (cuánta pausa dejar)</label>
    <select onchange="recNicho=this.value" style="max-width:340px">
      ${recPresets.map(p=>`<option value="${p.id}" ${p.id===recNicho?'selected':''}>${p.nombre}</option>`).join("")}
    </select>
    <label class="chk" style="margin-top:12px"><input type="checkbox" ${recRespiros?'checked':''}
        onchange="recRespiros=this.checked">Quitar respiros / suspiros (tomas de aire) — recomendado</label>
    <label class="chk"><input type="checkbox" ${recBordes?'checked':''}
        onchange="recBordes=this.checked">Recortar también el silencio del inicio y del final</label>
    <label style="margin-top:6px">Audio</label>
    <div class="tr-row">
      <button onclick="examinarAudio()">📁 Examinar…</button>
      ${recArchivo?'<button onclick="examinarAudio()">Cambiar audio</button>':''}
    </div>
    ${selHtml}
    <div style="margin-top:14px">
      <button class="pri" ${(trabajando||otro||!recArchivo)?'disabled':''} onclick="generarRecorte()">
        ${trabajando?'…recortando':'✂️ Limpiar respiros y silencios'}</button>
      ${otro&&!trabajando?'<span class="tr-est" style="margin-left:10px">Hay otro proceso en curso; espera.</span>':''}
    </div>
    ${estadoHtml}
  </div>`;
  poll(trabajando);
}
async function examinarAudio(){
  let d;
  try{ d = await (await fetch("/api/elegir_audio?dir="+enc(recArchivo.replace(/[\\/][^\\/]*$/,"")||""))).json(); }
  catch(e){ alert("No se pudo abrir el explorador"); return; }
  if(!d.ok || !d.ruta) return;                    // canceló
  recArchivo = d.ruta;
  render();
}
async function generarRecorte(){
  const f=(recArchivo||"").trim();
  if(!f){ alert("Pulsa Examinar… y elige un audio"); return; }
  recJob=f;
  const d = await (await fetch("/api/recorte/generar?ruta="+enc(f)+"&nicho="+enc(recNicho)+"&bordes="+(recBordes?"1":"0")+"&respiros="+(recRespiros?"1":"0"),{method:"POST"})).json();
  if(!d.ok){ alert(d.msg||"no se pudo iniciar"); return; }
  render();
}

/* ---------------- PERSONAJES (rostros protagonicos del video) ---------------- */
let persVideo="", persJob="", persN=4;
async function renderPersonajes(){
  setHeader("Saca en imágenes a los personajes de un video (caras en primer plano que se repiten). Ideal para captar los personajes de tus novelas habladas.");
  let job=null;
  if(persJob){ try{ job = await (await fetch("/api/job?ruta="+enc(persJob))).json(); }catch(e){} }
  const trabajando = job && (job.estado==="activo" || job.estado==="montando");
  let otro=false;
  if(!trabajando){ try{ otro = !!(await (await fetch("/api/estado")).json()).activo; }catch(e){} }

  let estadoHtml="";
  if(job){
    if(trabajando) estadoHtml=`<div class="tr-est act">▶ ${job.linea||"analizando fotogramas…"}</div>`;
    else if(job.estado==="ok"){
      const carp=persVideo.replace(/\\.[^\\\\/.]+$/,"")+"_personajes";
      estadoHtml=`<div class="tr-est ok">✓ Listo. Los retratos están en <b>${carp.split(/[\\\\/]/).pop()}</b>, junto al video. <button onclick="abrir('${enc(carp)}')" style="margin-left:8px">📂 Abrir carpeta</button></div>`;
    }
    else if(job.estado==="error") estadoHtml=`<div class="tr-est err">✕ Falló — ${(job.linea||"").slice(0,160)}</div>`;
    else if(job.estado==="cancelado") estadoHtml=`<div class="tr-est err">Cancelado.</div>`;
  }

  const selHtml = persVideo ? `<div class="sel" style="margin-top:12px">
      Video seleccionado: <b>${persVideo.split(/[\\\\/]/).pop()}</b>
      <div class="num" style="margin-top:3px">${persVideo}</div>
    </div>` : "";

  main().innerHTML = `<div class="tr-box">
    <p class="tr-help">Pulsa <b>Examinar…</b> y elige el <b>video</b>. La herramienta detecta las caras
      en <b>primer plano</b> (ignora a quien pasa caminando o queda de fondo) y agrupa por persona; se
      queda con los que <b>más se repiten</b> y guarda un retrato de cada uno en la carpeta
      <b>&lt;video&gt;_personajes</b>, junto al video.<br>
      <span class="num">La 1ª vez descarga 2 modelos de OpenCV (~37 MB en total).</span></p>
    <label>¿Cuántos personajes buscar?</label>
    <select onchange="persN=parseInt(this.value)" style="max-width:200px">
      ${[2,3,4,5,6].map(k=>`<option value="${k}" ${k===persN?'selected':''}>${k} personajes</option>`).join("")}
    </select>
    <label style="margin-top:12px">Video</label>
    <div class="tr-row">
      <button onclick="examinarVideo()">📁 Examinar…</button>
      ${persVideo?'<button onclick="examinarVideo()">Cambiar video</button>':''}
    </div>
    ${selHtml}
    <div style="margin-top:14px">
      <button class="pri" ${(trabajando||otro||!persVideo)?'disabled':''} onclick="generarPersonajes()">
        ${trabajando?'…analizando':'🎭 Detectar personajes'}</button>
      ${otro&&!trabajando?'<span class="tr-est" style="margin-left:10px">Hay otro proceso en curso; espera.</span>':''}
    </div>
    ${estadoHtml}
  </div>`;
  poll(trabajando);
}
async function examinarVideo(){
  let d;
  try{ d = await (await fetch("/api/elegir_video?dir="+enc(persVideo.replace(/[\\\\/][^\\\\/]*$/,"")||""))).json(); }
  catch(e){ alert("No se pudo abrir el explorador"); return; }
  if(!d.ok || !d.ruta) return;                    // canceló
  persVideo = d.ruta;
  render();
}
async function generarPersonajes(){
  const f=(persVideo||"").trim();
  if(!f){ alert("Pulsa Examinar… y elige un video"); return; }
  persJob=f;
  const d = await (await fetch("/api/personajes/generar?ruta="+enc(f)+"&n="+enc(persN),{method:"POST"})).json();
  if(!d.ok){ alert(d.msg||"no se pudo iniciar"); return; }
  render();
}

/* ---------------- MODAL "procesando" (bloquea pantalla) ---------------- */
function setOverlay(activo, nombre, linea, titulo){
  const ov=document.getElementById("overlay");
  if(!ov) return;
  if(!activo){ ov.style.display="none"; return; }
  ov.style.display="flex";
  const t = document.querySelector("#overlay .ov-t");
  if(t) t.textContent = titulo || "Procesando…";
  document.getElementById("ovNombre").textContent = nombre||"";
  document.getElementById("ovLog").textContent = linea||"";
}
let _huboJob=false;
async function refrescarEstado(){
  if(colaActiva) return;   // la cola activa controla su propio modal sin interferencias
  try{
    const d = await (await fetch("/api/estado")).json();
    setOverlay(d.activo, d.nombre, d.linea);
    if(d.activo){ _huboJob=true; }
    else if(_huboJob){ _huboJob=false; render(); }   // acaba de terminar -> refresca la vista
  }catch(e){}
}
async function cancelar(){
  if(!confirm("¿Cancelar el proceso en curso? Podrás volver a ejecutarlo cuando quieras.")) return;
  colaCancelada = true;
  document.getElementById("ovLog").textContent = "cancelando…";
  try{ await fetch("/api/cancelar",{method:"POST"}); }catch(e){}
  setTimeout(() => {
    colaActiva = false;
    setOverlay(false);
    render();
  }, 1000);
}
setInterval(refrescarEstado, 1500);

init();
</script>
</body>
</html>"""


SERVIDOR_HTTP = None

class RobustThreadingServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        exc_type, exc_val, _ = sys.exc_info()
        if exc_type in (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            return
        super().handle_error(request, client_address)


def main():
    global SERVIDOR_HTTP

    es_reinicio = "--restarted" in sys.argv

    if not es_reinicio:
        # Comprobación de Instancia Única (solo para arranques directos de usuario)
        try:
            import urllib.request
            req_chk = urllib.request.Request(f"http://127.0.0.1:{PUERTO}/api/estado", headers={"User-Agent": "NEXOR-InstanceCheck/1.0"})
            with urllib.request.urlopen(req_chk, timeout=0.6) as r_chk:
                if r_chk.status == 200:
                    print(f"[INFO] Panel ya activo en http://127.0.0.1:{PUERTO}. Abriendo navegador...")
                    if os.environ.get("PANEL_NO_BROWSER") != "1":
                        webbrowser.open(f"http://127.0.0.1:{PUERTO}")
                    return
        except Exception:
            pass

    RobustThreadingServer.allow_reuse_address = True
    RobustThreadingServer.daemon_threads = True

    # Reintentos de enlace de socket para permitir que el proceso anterior libere el puerto
    srv = None
    max_intentos = 10 if es_reinicio else 3
    for intento in range(max_intentos):
        try:
            srv = RobustThreadingServer(("127.0.0.1", PUERTO), Handler)
            break
        except OSError as e_bind:
            if intento < max_intentos - 1:
                time.sleep(0.5)
            else:
                raise e_bind

    SERVIDOR_HTTP = srv
    url = f"http://127.0.0.1:{PUERTO}"
    print(f"Panel en {url}   (Ctrl+C para parar)")
    if os.environ.get("PANEL_NO_BROWSER") != "1" and not es_reinicio:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nPanel detenido.")
    finally:
        try:
            srv.server_close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
