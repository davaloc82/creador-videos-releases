#!/usr/bin/env python

# -*- coding: utf-8 -*-

"""

panel.py - Panel Web Local para Creador de Videos (Universal)

============================================================

Adaptación agnóstica para cualquier nicho del flujo de cortes y montaje por escenas.

Incluye exclusivamente:

  - Creador de Videos (Segmentación de guión, cortes sincronizados, unión y subtítulos)

  - Herramientas IA:

      1. Transcripción por lote (faster-whisper)

      2. Voz TTS (ai33.pro)

      3. Recortar Audio (limpieza de respiros y acorte de silencios)

Abre http://127.0.0.1:8780 (o siguiente puerto libre).

"""

import collections

import shutil

import datetime

import http.server

import json

import os

import re

import socket

import socketserver

import subprocess

import sys

import threading

import time

import webbrowser

import mimetypes

from pathlib import Path

from urllib.parse import urlparse, parse_qs, unquote

AQUI = Path(__file__).resolve().parent
CORE_DIR = AQUI / "core"
if str(CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CORE_DIR))
if str(AQUI / "herramientas") not in sys.path:
    sys.path.insert(0, str(AQUI / "herramientas"))

ADMINLTE_DIR = AQUI / "AdminLTE" / "AdminLTE"

sys.path.insert(0, str(AQUI / "ai33"))

try:

    import tts

except Exception as e:

    tts = None

PUERTO_DEF = 8780

MARCADOR = ".publicado"

VIDEO_EXTS = (".mp4", ".mov", ".mkv", ".webm")

AUDIO_EXTS = (".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg")

# Carpeta principal de proyectos de video (agnóstico para cualquier nicho y usuario)

CARPETA_PROYECTOS = (Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads" / "PROYECTOS_VIDEO").resolve()

CARPETA_PROYECTOS.mkdir(parents=True, exist_ok=True)

NICHOS = {

    "videos": {

        "nombre": "Creador de Videos",

        "tipo": "videos",

        "raiz": CARPETA_PROYECTOS,

        "codigo": AQUI / "videos",

        "variante": "grok",

        "script": "cortar_escenas.py",

        "configurado": True,

    }

}

NICHO_DEF = "videos"

# --------------------------------------------------------------- utilidades tiempo

def _mtime(p: Path) -> float:

    try:

        return p.stat().st_mtime

    except OSError:

        return 0.0

def _creacion_time(p: Path) -> float:

    try:

        st = p.stat()

        return getattr(st, "st_ctime", st.st_mtime)

    except OSError:

        return 0.0

def _fecha_str(p: Path) -> str:

    try:

        t = _creacion_time(p)

        if t <= 0:

            return ""

        return datetime.datetime.fromtimestamp(t).strftime("%d/%m %H:%M")

    except Exception:

        return ""

def _limpiar_ruta(txt: str) -> str:

    return (txt or "").strip().strip('"').strip("'")

def _raices_configuradas():

    raices = [n["raiz"] for n in NICHOS.values() if n.get("configurado") and n.get("raiz")]

    raices.append(CARPETA_PROYECTOS)

    return raices

def _dentro_de_nicho(p: Path):

    try:

        p = p.resolve()

        for raiz in _raices_configuradas():

            r = Path(raiz).resolve()

            if p == r or r in p.parents:

                return True

        # Permitir rutas en Downloads de forma segura

        dl = Path(os.environ.get("USERPROFILE", "")) / "Downloads"

        if dl.exists() and (p == dl.resolve() or dl.resolve() in p.parents):

            return True

    except Exception:

        pass

    return True

# --------------------------------------------------------------- jobs y procesos

JOBS = {}  # clave -> {"estado": activo|ok|error|cancelado, "log": deque, "inicio": t, "proc": Popen}

def montaje_activo():

    for k, v in JOBS.items():

        if v.get("estado") in ("montando", "activo"):

            return k

    return None

def _job_serial(clave):

    j = JOBS.get(clave)

    if not j:

        return None

    return {

        "estado": j["estado"],

        "linea": j["log"][-1] if j.get("log") else "",

        "dur": int(time.time() - j["inicio"]) if j.get("inicio") else 0,

    }

def _nombre_amable(clave):

    p = Path(clave)

    return p.parent.name if p.name.lower() in ("grok", "veo") else p.name

def estado_actual():

    clave = montaje_activo()

    if not clave:

        return {"activo": False}

    j = JOBS[clave]

    return {

        "activo": True,

        "nombre": _nombre_amable(clave),

        "linea": (j["log"][-1] if j["log"] else ""),

        "estado": j["estado"],

        "dur": int(time.time() - j["inicio"]) if j.get("inicio") else 0,

    }

def cancelar_proceso():

    clave = montaje_activo()

    if not clave:

        return False, "no hay ningún proceso activo"

    j = JOBS.get(clave) or {}

    j["cancelado"] = True

    proc = j.get("proc")

    if proc and proc.poll() is None:

        try:

            if sys.platform.startswith("win"):

                subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],

                               capture_output=True)

            else:

                proc.terminate()

        except Exception as e:

            return False, f"error al cancelar: {e}"

    j["estado"] = "cancelado"

    return True, "proceso cancelado"

def lanzar_proceso(clave, args, cwd=None):

    activo = montaje_activo()

    if activo and activo != clave:

        return False, "ya hay un proceso en curso; espera a que termine"

    if clave in JOBS and JOBS[clave]["estado"] in ("montando", "activo"):

        return False, "ya se está ejecutando"

    log = collections.deque(maxlen=120)

    JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time()}

    entorno = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1"}

    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,

                            text=True, encoding="utf-8", errors="replace",

                            env=entorno, cwd=str(cwd) if cwd else None)

    JOBS[clave]["proc"] = proc

    def seguir():

        for linea in proc.stdout:

            linea = linea.rstrip()

            if linea:

                log.append(linea)

        code = proc.wait()

        JOBS[clave]["estado"] = ("cancelado" if JOBS[clave].get("cancelado")

                                 else ("ok" if code == 0 else "error"))

    threading.Thread(target=seguir, daemon=True).start()

    return True, "proceso iniciado"

# --------------------------------------------------------------- detección proyectos video

def fila_videos(proy: Path, nicho: dict):
    """Estado de un proyecto de video: detecta clips de video (video/grok) + imágenes (imagen/veo) + audio -> cortes."""
    clips_vid = []
    carpetas_vid_cand = [proy / "video", proy / "videos", proy / nicho.get("variante", "grok"), proy / "grok", proy / "clips", proy / "animaciones"]
    for cv in carpetas_vid_cand:
        if cv.is_dir():
            clips_vid.extend(x for x in cv.glob("*.mp4") if re.match(r"^\d", x.name) and x not in clips_vid)
    if not clips_vid and proy.is_dir():
        for x in proy.rglob("*.mp4"):
            if "cortes" not in x.parts and re.match(r"^\d", x.name) and x not in clips_vid:
                clips_vid.append(x)

    clips_img = []
    carpetas_img_cand = [proy / "imagen", proy / "imagenes", proy / "veo", proy / "fotos", proy / "prompts"]
    for ci in carpetas_img_cand:
        if ci.is_dir():
            for ext in (".jpg", ".jpeg", ".png", ".webp"):
                clips_img.extend(x for x in ci.glob(f"*{ext}") if re.match(r"^\d", x.name) and x not in clips_img)
    if not clips_img and proy.is_dir():
        for ext in (".jpg", ".jpeg", ".png", ".webp"):
            for x in proy.rglob(f"*{ext}"):
                if "cortes" not in x.parts and re.match(r"^\d", x.name) and x not in clips_img:
                    clips_img.append(x)

    var = proy / "video" if (proy / "video").is_dir() else (proy / nicho.get("variante", "grok"))
    cand_audios = list(proy.glob("*"))
    for cv in carpetas_vid_cand:
        if cv.is_dir():
            cand_audios.extend(cv.glob("*"))
    audios = [x for x in cand_audios

              if x.is_file() and x.suffix.lower() in AUDIO_EXTS

              and "_limpio" not in x.stem.lower()

              and "_fluido" not in x.stem.lower()]

    cortes_dir = proy / "cortes" if (proy / "cortes").is_dir() else var / "cortes"

    cortes = list(cortes_dir.glob("[0-9][0-9]_*.mp4")) if cortes_dir.is_dir() else []

    limpio = bool(list(cortes_dir.glob("*_limpio.mp3"))) if cortes_dir.is_dir() else False

    tiene_guion = (proy / "guion.txt").is_file() or (proy / "dis_guion.txt").is_file()

    tiene_sinc = (proy / "sincronia.txt").is_file() and (proy / "sincronia.txt").stat().st_size > 0

    tiene_img = (proy / "imagen.txt").is_file() and (proy / "imagen.txt").stat().st_size > 0

    total_tomas = len(clips_vid) + len(clips_img)

    falta = []

    if not audios:

        falta.append("audio")

    if tiene_guion and not tiene_sinc:

        falta.append("segmentar")

    if total_tomas == 0:

        falta.append("clips/imágenes")

    if cortes:

        estado = "cortado"

    elif total_tomas > 0 and audios:

        estado = "listo"

    else:

        estado = "pendiente"

    m = re.match(r"^(\d+)", proy.name)

    num = int(m.group(1)) if m else 0

    etq_clips = f"{len(clips_vid)}v+{len(clips_img)}i" if clips_img else len(clips_vid)

    ruta_ejecutar = proy if any(a.parent == proy for a in audios) else (var if var.is_dir() else proy)

    video_sub = cortes_dir / "video_subtitulado.mp4"

    video_completo = video_sub if video_sub.is_file() else (cortes_dir / "video_completo.mp4")

    if not video_completo.is_file():

        video_completo = proy / "video.mp4" if (proy / "video.mp4").is_file() else None

    return {

        "nombre": proy.name,

        "ruta": str(ruta_ejecutar.resolve()),

        "num": num,

        "t_creacion": _creacion_time(proy),

        "fecha": _fecha_str(proy),

        "estado": estado,

        "falta": falta,

        "clips": etq_clips,

        "cortes": len(cortes),

        "limpio": limpio,

        "tiene_guion": tiene_guion,

        "tiene_sinc": tiene_sinc,

        "tiene_img": tiene_img,

        "tiene_video": bool(video_completo),

        "tiene_sub": video_sub.is_file(),

        "video_completo": str(video_completo.resolve()) if video_completo else "",

        "cortable": total_tomas > 0 and bool(audios),

        "job": _job_serial(str(ruta_ejecutar.resolve())),

    }

def escanear_videos(nicho):
    raiz = Path(nicho["raiz"])
    id_nicho = nicho.get("id", "videos")
    nombre_nicho = nicho.get("nombre", "Creador de Videos")
    base = {"nicho": id_nicho, "nombre": nombre_nicho, "raiz": str(raiz),
            "montaje_activo": montaje_activo(), "configurado": True}
    if not raiz.is_dir():
        return {**base, "filas": []}

    # Carpetas internas del sistema y de referencia que jamás deben listarse como videos
    carpetas_excluir = {"plantilla", "__pycache__", "audio_referencia", "fuentes", "instrucciones"}
    
    # Si estamos en la raíz general de PROYECTOS_VIDEO, excluir también todos los canales replicados
    if raiz == CARPETA_PROYECTOS:
        try:
            from gestor_nichos import cargar_nichos_usuario
            for nu in cargar_nichos_usuario():
                if nu.get("nombre_carpeta"):
                    carpetas_excluir.add(nu["nombre_carpeta"].lower())
                p_r = Path(nu.get("ruta", ""))
                if p_r.is_dir():
                    carpetas_excluir.add(p_r.name.lower())
        except Exception:
            pass

    filas = []
    for d in raiz.iterdir():
        if not d.is_dir() or d.name.startswith(("_", ".")):
            continue
        if d.name.lower() in carpetas_excluir or (d / "config_nicho.json").is_file() or (d / "instrucciones").is_dir() or (raiz == CARPETA_PROYECTOS and (d / "guiones.txt").is_file()):
            continue
        filas.append(fila_videos(d, nicho))

    filas.sort(key=lambda f: (-f.get("t_creacion", 0), f["num"], f["nombre"].lower()))
    return {**base, "filas": filas}

# --------------------------------------------------------------- lanzadores video

def limpiar_texto_guion(lineas):

    """Limpia líneas de títulos, acotaciones y prefijos de personaje para el sintetizador TTS."""

    limpias = []

    for ln in lineas:

        s = ln.strip()

        if re.match(r"^\s*TITULO\s*:", s, re.IGNORECASE):

            continue

        if (s.startswith("[") and s.endswith("]")) or (s.startswith("(") and s.endswith(")")):

            continue

        s = re.sub(r"^\s*(narrador|voz\s+en\s+off|locutor|personaje\s*\d*)\s*:\s*", "", s, flags=re.IGNORECASE)

        s = re.sub(r"\[.*?\]", "", s)

        s = re.sub(r"\*\*(.*?)\*\*", r"\1", s)

        if s:

            limpias.append(s)

    return "\n".join(limpias).strip()

def parse_lote_guiones(texto: str):

    """Parsea texto con bloques 'GUION: <nombre>' seguido del texto del guion."""

    bloques = []

    lineas = (texto or "").splitlines()

    actual, cuerpo = None, []

    for ln in lineas:

        m = re.match(r"^\s*GUION\s*:\s*(.+?)\s*$", ln, re.IGNORECASE)

        if m:

            if actual is not None and cuerpo:

                t = limpiar_texto_guion(cuerpo)

                if t:

                    bloques.append((actual, t))

            nom = re.sub(r'[<>:"/\\|?*]+', "_", m.group(1).strip().strip("."))

            actual = nom or "sin_nombre"

            cuerpo = []

        elif actual is not None:

            cuerpo.append(ln)

    if actual is not None and cuerpo:

        t = limpiar_texto_guion(cuerpo)

        if t:

            bloques.append((actual, t))

    return [(n, t) for n, t in bloques if n and t]

def resolver_config_ai33(raiz_destino: Path = None):

    """

    Busca de manera ultra-resiliente la configuración de ai33.pro en todos los lugares posibles:

    1. En la carpeta del proyecto actual (raiz_destino / "ai33_config.txt")

    2. Subiendo por los directorios padres (raiz_destino.parent, etc.)

    3. En CARPETA_PROYECTOS / "ai33_config.txt"

    4. En todas las carpetas de nichos replicados (roblox, etc.) dentro de CARPETA_PROYECTOS

    5. En la carpeta central de la app: AQUI / "ai33" / "ai33_config.txt"

    6. En cualquier archivo ai33_*.txt dentro de AQUI / "ai33"

    Si encuentra una API_KEY válida en cualquiera de estos lugares:

    - Normaliza comillas y espacios.

    - Sincroniza automáticamente la clave hacia la carpeta central y hacia el proyecto.

    - Devuelve (cfg_dict, ruta_origen).

    """

    sys.path.insert(0, str(AQUI / "ai33"))

    import tts

    candidatos = []

    if raiz_destino:

        r = Path(raiz_destino).resolve()

        if r.is_file():

            r = r.parent

        curr = r

        while True:

            c = curr / "ai33_config.txt"

            if c not in candidatos:

                candidatos.append(c)

            padre = curr.parent

            if padre == curr:

                break

            curr = padre

    # Carpeta base de proyectos

    if CARPETA_PROYECTOS / "ai33_config.txt" not in candidatos:

        candidatos.append(CARPETA_PROYECTOS / "ai33_config.txt")

    # Carpetas de nichos replicados del usuario

    try:

        from gestor_nichos import cargar_nichos_usuario

        for nu in cargar_nichos_usuario():

            nr = Path(nu.get("ruta", "")).resolve()

            if nr.is_dir():

                c = nr / "ai33_config.txt"

                if c not in candidatos:

                    candidatos.append(c)

    except Exception:

        pass

    # Subcarpetas de CARPETA_PROYECTOS

    if CARPETA_PROYECTOS.is_dir():

        for d in CARPETA_PROYECTOS.iterdir():

            if d.is_dir() and not d.name.startswith((".", "_")):

                c = d / "ai33_config.txt"

                if c not in candidatos:

                    candidatos.append(c)

    # Carpeta central de la app

    c_central = AQUI / "ai33" / "ai33_config.txt"

    if c_central not in candidatos:

        candidatos.append(c_central)

    # Cualquier otro ai33_*.txt en ai33/

    if (AQUI / "ai33").is_dir():

        for f in sorted((AQUI / "ai33").glob("ai33_*.txt")):

            if f not in candidatos:

                candidatos.append(f)

    cfg_encontrado = None

    ruta_encontrada = None

    for cand in candidatos:

        if cand.is_file():

            try:

                c = tts.cargar_config(str(cand))

                api_key = (c.get("API_KEY") or "").strip().strip("'\"")

                if api_key and not api_key.startswith(("#", "PEGA_", "TU_")):

                    c["API_KEY"] = api_key

                    if c.get("VOICE_ID"):

                        c["VOICE_ID"] = c["VOICE_ID"].strip().strip("'\"")

                    if c.get("SPEED"):

                        c["SPEED"] = c["SPEED"].strip().strip("'\"")

                    cfg_encontrado = c

                    ruta_encontrada = cand

                    break

            except Exception:

                continue

    if cfg_encontrado:

        # 1. Asegurar que el config central la tenga guardada

        try:

            central_txt = c_central.read_text(encoding="utf-8", errors="ignore") if c_central.is_file() else ""

            m_cent = re.search(r"^\s*API_KEY\s*=\s*(\S+)", central_txt, re.M)

            if not m_cent or m_cent.group(1).startswith(("#", "PEGA_", "TU_")):

                c_central.parent.mkdir(parents=True, exist_ok=True)

                txt_nuevo = f"""# ============================================================

#  ai33.pro (Text-To-Speech)  -  CONFIGURACIÓN DE VOZ

# ============================================================

API_KEY={cfg_encontrado.get('API_KEY', '')}

VOICE_ID={cfg_encontrado.get('VOICE_ID', 'clone_2618875')}

SPEED={cfg_encontrado.get('SPEED', '1.0')}

WITH_TRANSCRIPT=false

TTS_URL=https://api.ai33.pro/v3/text-to-speech

TASK_URL=https://api.ai33.pro/v3/task/{{task_id}}

TIMEOUT=300

"""

                c_central.write_text(txt_nuevo, encoding="utf-8")

        except Exception:

            pass

        # 2. Si hay raiz_destino y no tiene ai33_config.txt o está vacío, sincronizarlo

        if raiz_destino:

            try:

                rd = Path(raiz_destino).resolve()

                if rd.is_file():

                    rd = rd.parent

                if rd.is_dir():

                    loc_cfg = rd / "ai33_config.txt"

                    if not loc_cfg.is_file():

                        shutil.copy2(ruta_encontrada or c_central, loc_cfg)

                    else:

                        loc_txt = loc_cfg.read_text(encoding="utf-8", errors="ignore")

                        m_loc = re.search(r"^\s*API_KEY\s*=\s*(\S+)", loc_txt, re.M)

                        if not m_loc or m_loc.group(1).startswith(("#", "PEGA_", "TU_")):

                            shutil.copy2(ruta_encontrada or c_central, loc_cfg)

            except Exception:

                pass

        return cfg_encontrado, ruta_encontrada

    return None, None

def lanzar_crear_guiones_lote(nicho: dict, texto: str, gen_audio: bool = True, segmentar: bool = True, raiz_destino: Path = None):

    bloques = parse_lote_guiones(texto)

    if not bloques:

        return False, "No se detectaron guiones válidos. Usa el formato 'GUION: <nombre>\n<texto>'."

    if raiz_destino and Path(raiz_destino).is_dir():

        raiz = Path(raiz_destino).resolve()

    else:

        raiz = Path(nicho.get("raiz", "")).resolve()

        if not raiz.is_dir():

            return False, f"La carpeta raíz no existe: {raiz}"

    clave = str(raiz)

    activo = montaje_activo()

    if activo and activo != clave:

        return False, "Ya hay un proceso activo; espera a que termine."

    log = collections.deque(maxlen=120)

    JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time()}

    def worker():

        global tts

        if tts is None:

            sys.path.insert(0, str(AQUI / "ai33"))

            import tts

        plantilla_dir = raiz / "plantilla"

        if not plantilla_dir.is_dir() and (CARPETA_PROYECTOS / "plantilla").is_dir():

            plantilla_dir = CARPETA_PROYECTOS / "plantilla"

        log.append(f"Iniciando creación de {len(bloques)} proyecto(s) en '{raiz.name}'...")

        cfg, ruta_cfg = resolver_config_ai33(raiz)

        if gen_audio:

            if cfg and cfg.get("API_KEY"):

                log.append(f"Voz IA conectada ({cfg.get('VOICE_ID', 'default')}) [origen: {ruta_cfg.name if ruta_cfg else 'ai33_config.txt'}]")

            else:

                log.append("[AVISO] No se encontró API_KEY configurada; se crearán las carpetas y guiones sin audio.")

        total = len(bloques)

        for idx, (nombre, texto_guion) in enumerate(bloques, 1):

            proy_dir = raiz / nombre

            log.append(f"[{idx}/{total}] Preparando '{nombre}'...")

            if not proy_dir.exists():
                proy_dir.mkdir(parents=True, exist_ok=True)
                if plantilla_dir.is_dir():
                    # Copiar solo archivos de plantilla sin crear subdirectorios innecesarios
                    for item in plantilla_dir.iterdir():
                        if item.is_file() and item.name.lower() != "guion.txt":
                            shutil.copy2(item, proy_dir / item.name)
                    log.append(f"  -> Copiados archivos de plantilla a {nombre}/")
                else:
                    log.append(f"  -> Creada carpeta {nombre}/")

            guion_file = proy_dir / "guion.txt"

            guion_file.write_text(texto_guion, encoding="utf-8")

            log.append(f"  -> Guardado guion.txt ({len(texto_guion)} caracteres)")

            if cfg and cfg.get("API_KEY"):

                aud_proy = proy_dir / "aud.mp3"
                if aud_proy.is_file() and aud_proy.stat().st_size > 1000:
                    log.append(f"  -> aud.mp3 ya existe en {nombre}/")
                else:
                    log.append(f"  -> Generando audio con IA...")
                    try:
                        task_id, direct = tts.crear_tarea(cfg, texto_guion)
                        url = direct or tts.esperar_audio(cfg, task_id)
                        tts.descargar(url, str(aud_proy))
                        log.append(f"  [OK] Audio guardado en {nombre}/aud.mp3")
                    except Exception as e:
                        log.append(f"  [ERROR] Falló audio para {nombre}: {e}")

            # 4. Segmentación automática

            if segmentar:

                script_seg = Path(nicho.get("codigo", AQUI / "videos")) / "segmentar_guion.py"

                if not script_seg.is_file():

                    script_seg = AQUI / "videos" / "segmentar_guion.py"

                if not script_seg.is_file():

                    script_seg = AQUI / "ecos" / "segmentar_guion.py"

                if script_seg.is_file() and guion_file.is_file():

                    log.append(f"  -> Segmentando guion ({nombre})...")

                    try:

                        res_seg = subprocess.run(

                            [sys.executable, str(script_seg), str(proy_dir)],

                            capture_output=True, text=True, encoding="utf-8", errors="replace"

                        )

                        sinc_f = proy_dir / "sincronia.txt"

                        if sinc_f.is_file():

                            lineas = [l for l in sinc_f.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip() and not l.startswith("#")]

                            log.append(f"  [OK] Sincronía lista: {len(lineas)} escenas generadas")

                        elif res_seg.returncode == 0:

                            log.append(f"  [OK] Sincronía generada con éxito")

                        else:

                            err_resumen = (res_seg.stderr or res_seg.stdout or "error").strip().splitlines()[-1][:100]

                            log.append(f"  [AVISO] Segmentación: {err_resumen}")

                    except Exception as e:

                        log.append(f"  [ERROR] Falló segmentación para {nombre}: {e}")

            time.sleep(0.2)

        try:

            g_raiz = raiz / "guiones.txt"

            existente = g_raiz.read_text(encoding="utf-8", errors="ignore") if g_raiz.is_file() else ""

            nuevos_bloques = []

            for n, t in bloques:

                if f"GUION: {n}" not in existente and f"GUION:{n}" not in existente:

                    nuevos_bloques.append(f"GUION: {n}\n{t}\n")

            if nuevos_bloques:

                separador = "\n\n" if existente.strip() else ""

                g_raiz.write_text(existente + separador + "\n".join(nuevos_bloques), encoding="utf-8")

        except Exception:

            pass

        log.append(f"¡Listo! {total} proyectos listos en {raiz.name}.")

        JOBS[clave]["estado"] = "ok"

    threading.Thread(target=worker, daemon=True).start()

    return True, f"Creando {len(bloques)} proyectos en '{raiz.name}' en segundo plano..."

def lanzar_cortar_videos(nicho: dict, ruta: str, limpiar: bool = True, subtitulos: bool = True, estilo_sub: str = None):

    grok = Path(ruta).resolve()

    if not grok.is_dir():

        return False, "ruta inválida"

    script = Path(nicho.get("codigo", AQUI / "videos")) / nicho.get("script", "cortar_escenas.py")

    if not script.is_file():

        return False, f"no encuentro {script.name}"

    args = [sys.executable, str(script), str(grok)]

    if limpiar:

        args.append("--limpiar-silencios")

    if subtitulos:

        args.append("--subtitulos")
        if estilo_sub:
            args.extend(["--estilo-subtitulos", estilo_sub])
    else:

        args.append("--sin-subtitulos")

    return lanzar_proceso(str(grok), args)

def lanzar_segmentar_videos(nicho: dict, ruta: str):

    p = Path(ruta).resolve()

    if not p.is_dir():

        return False, "ruta inválida"

    script = Path(nicho.get("codigo", AQUI / "videos")) / "segmentar_guion.py"

    if not script.is_file():

        return False, "no encuentro segmentar_guion.py"

    args = [sys.executable, str(script), str(p)]

    return lanzar_proceso(str(p), args)

def lanzar_unir_videos(nicho: dict, ruta: str):

    p = Path(ruta).resolve()

    if not p.is_dir():

        return False, "ruta inválida"

    script = Path(nicho.get("codigo", AQUI / "videos")) / "segmentar_guion.py"

    if not script.is_file():

        return False, "no encuentro segmentar_guion.py"

    args = [sys.executable, str(script), str(p), "--unir"]

    return lanzar_proceso(str(p), args)

def lanzar_subtitulos_videos(nicho: dict, ruta: str):

    p = Path(ruta).resolve()

    if not p.is_dir():

        return False, "ruta inválida"

    script = Path(nicho.get("codigo", AQUI / "videos")) / "subtitulos_karaoke.py"

    if not script.is_file():

        return False, "no encuentro subtitulos_karaoke.py"

    args = [sys.executable, str(script), str(p)]

    return lanzar_proceso(str(p), args)

# --------------------------------------------------------------- herramienta 1: transcribir

def _lote_script():

    for cand in (AQUI / "herramientas" / "transcribir_lote.py",

                 AQUI / "transcribir_lote.py"):

        if cand.is_file():

            return cand

    return None

def listar_videos(carpeta: str, recursivo: bool = True):

    base = Path(_limpiar_ruta(carpeta)).expanduser()

    try:

        base = base.resolve()

    except OSError:

        return None

    if not base.is_dir():

        return None

    it = base.rglob("*") if recursivo else base.iterdir()

    vids = []

    for x in sorted(it, key=lambda p: str(p).lower()):

        if x.is_file() and x.suffix.lower() in VIDEO_EXTS:

            try:

                rel = str(x.relative_to(base))

            except ValueError:

                rel = x.name

            vids.append({

                "ruta": str(x),

                "nombre": rel,

                "txt": x.with_suffix(".txt").exists()

            })

        if len(vids) >= 800:

            break

    return {"carpeta": str(base), "videos": vids}

def lanzar_transcribir_lote(carpeta: str, rutas, idioma="es", modelo="small", combinar=True):

    files = []

    for r in (rutas or []):

        p = Path(_limpiar_ruta(r)).expanduser()

        try:

            p = p.resolve()

        except OSError:

            continue

        if p.is_file() and p.suffix.lower() in VIDEO_EXTS + AUDIO_EXTS:

            files.append(p)

    if not files:

        return False, "no seleccionaste videos válidos"

    script = _lote_script()

    if not script:

        return False, "no encuentro transcribir_lote.py en herramientas/"

    modelo = modelo if modelo in ("tiny", "base", "small", "medium", "large-v3") else "small"

    base = None

    if carpeta:

        b = Path(_limpiar_ruta(carpeta)).expanduser()

        base = b.resolve() if b.is_dir() else None

    destino = base or files[0].parent

    clave = str(destino)

    args = [sys.executable, str(script), "--idioma", idioma or "auto", "--modelo", modelo]

    if combinar and len(files) > 1:

        args += ["--combinar", str(destino / "_GUIONES.txt")]

    args += [str(f) for f in files]

    return lanzar_proceso(clave, args)

# --------------------------------------------------------------- herramienta 2: voz (ai33 TTS)

CONFIG_VOZ_PATH = AQUI / "ai33" / "ai33_config.txt"

AI33_CONFIGS = {

    "config":    ("Voz IA (ai33.pro)", CONFIG_VOZ_PATH),

    "voz":       ("Voz IA (ai33.pro)", CONFIG_VOZ_PATH),

    "videos":    ("Voz IA (ai33.pro)", CONFIG_VOZ_PATH),

    "reflexion": ("Voz IA (ai33.pro)", CONFIG_VOZ_PATH),

    "ecos":      ("Voz IA (ai33.pro)", CONFIG_VOZ_PATH),

}

# Cargar también cualquier config adicional presente en ai33/

if (AQUI / "ai33").is_dir():

    for f in sorted((AQUI / "ai33").glob("ai33_*.txt")):

        nid = f.stem.replace("ai33_", "")

        if nid not in AI33_CONFIGS:

            AI33_CONFIGS[nid] = (f.stem.replace("ai33_", "").capitalize(), f)

def listar_txts(carpeta: str):

    base = Path(_limpiar_ruta(carpeta)).expanduser()

    try:

        base = base.resolve()

    except OSError:

        return None

    if not base.is_dir():

        return None

    items = []

    for x in sorted(base.glob("*.txt")):

        if not x.is_file():

            continue

        try:

            txt = x.read_text(encoding="utf-8", errors="replace")

            n = len(re.findall(r"^GUION:\s*\d+", txt, re.M | re.I))

        except Exception:

            n = 0

        items.append({"nombre": x.name, "ruta": str(x), "guiones": n, "bytes": x.stat().st_size})

    return {"carpeta": str(base), "archivos": items}

def lanzar_voz(archivo: str, nicho: str):

    p = Path(_limpiar_ruta(archivo)).expanduser()

    try:

        p = p.resolve()

    except OSError:

        return False, "ruta inválida"

    if not p.is_file() or p.suffix.lower() != ".txt":

        return False, "elige un archivo .txt con los guiones"

    # Resolver configuración con máxima resiliencia

    cfg, config = resolver_config_ai33(p.parent)

    if not cfg or not cfg.get("API_KEY"):

        return False, "Configura primero tu API_KEY de ai33.pro (está vacía en ai33_config.txt)"

    if not config or not Path(config).is_file():

        config = AQUI / "ai33" / "ai33_config.txt"

    script = AQUI / "ai33" / "tts.py"

    if not script.is_file():

        return False, "no encuentro ai33/tts.py"

    args = [sys.executable, str(script), str(p), "--config", str(config)]

    return lanzar_proceso(str(p), args)

# --------------------------------------------------------------- herramienta 3: recortar audio

RECORTE_PRESETS = [

    ("reflexion", "Reflexión (pausas 0.4s)"),

    ("videos",    "Creador de Videos (pausas 0.4s)"),

    ("suave",     "Suave (pausas 0.6s)"),

    ("medio",     "Medio (pausas 0.35s)"),

    ("fuerte",    "Rápido / Dinámico (pausas 0.15s)"),

]

RECORTE_IDS = {p[0] for p in RECORTE_PRESETS}

def lanzar_recorte(archivo: str, nicho: str, bordes: bool = False, respiros: bool = True):

    p = Path(_limpiar_ruta(archivo)).expanduser()

    try:

        p = p.resolve()

    except OSError:

        return False, "ruta inválida"

    if not p.is_file() or p.suffix.lower() not in AUDIO_EXTS:

        return False, "elige un archivo de audio (.mp3, .wav, ...)"

    script = AQUI / "recortar_audio.py"

    if not script.is_file():

        return False, "no encuentro recortar_audio.py"

    args = [sys.executable, str(script), str(p), "--nicho", nicho if nicho in RECORTE_IDS else "videos"]

    if bordes:

        args.append("--bordes")

    if not respiros:

        args.append("--no-respiros")

    return lanzar_proceso(str(p), args)

def escanear_enlaces_descarga(ruta: str):

    """Escanea una carpeta o archivo .txt y devuelve los enlaces y estado."""

    limpio = _limpiar_ruta(ruta)

    if not limpio:

        return False, "No se indicó ninguna ruta", {}

    p = Path(limpio).expanduser().resolve()

    if not p.exists():

        return False, f"La ruta indicada no existe: {limpio}", {}

    from descargar_videos import extraer_urls_de_archivo, buscar_txt_con_enlaces

    txt_path = None

    urls = []

    if p.is_file() and p.suffix.lower() == ".txt":

        txt_path = p

        urls = extraer_urls_de_archivo(txt_path)

        directorio = p.parent

    elif p.is_dir():

        directorio = p

        txt_path, urls = buscar_txt_con_enlaces(p)

    else:

        return False, "No es un directorio ni un archivo .txt válido", {}

    videos_existentes = []

    if directorio.is_dir():

        for x in sorted(directorio.iterdir()):

            if x.is_file() and x.suffix.lower() in VIDEO_EXTS:

                tam_mb = round(x.stat().st_size / (1024 * 1024), 1)

                videos_existentes.append({"nombre": x.name, "tam": f"{tam_mb} MB"})

    historial_count = 0

    hist_file = directorio / "_descargas_historial.txt"

    if hist_file.is_file():

        try:

            historial_count = len([l for l in hist_file.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip()])

        except Exception:

            pass

    return True, "Escaneo exitoso", {

        "txt": str(txt_path) if txt_path else "",

        "txt_nombre": txt_path.name if txt_path else "",

        "directorio": str(directorio),

        "urls": urls,

        "videos_existentes": videos_existentes,

        "historial_count": historial_count

    }

def guardar_enlaces_descarga(carpeta_o_txt: str, texto_o_urls):

    """Guarda los enlaces en el archivo .txt dentro de la carpeta correspondiente."""

    p = Path(_limpiar_ruta(carpeta_o_txt)).expanduser().resolve()

    if p.is_file() and p.suffix.lower() == ".txt":

        txt_path = p

    elif p.is_dir():

        txt_path = p / "enlaces.txt"

    else:

        p.mkdir(parents=True, exist_ok=True)

        txt_path = p / "enlaces.txt"

    if isinstance(texto_o_urls, list):

        contenido = "\n".join(str(u).strip() for u in texto_o_urls if str(u).strip()) + "\n"

    else:

        contenido = str(texto_o_urls).strip() + "\n"

    txt_path.write_text(contenido, encoding="utf-8")

    from descargar_videos import extraer_urls_de_archivo

    urls = extraer_urls_de_archivo(txt_path)

    return True, f"Guardados {len(urls)} enlaces en {txt_path.name}", {

        "txt": str(txt_path),

        "txt_nombre": txt_path.name,

        "directorio": str(txt_path.parent),

        "urls": urls

    }

def lanzar_descarga_videos(ruta: str):

    """Ejecuta descargar_videos.py en la carpeta de destino guardando los videos en ella."""

    p = Path(_limpiar_ruta(ruta)).expanduser().resolve()

    if not p.exists():

        return False, "La ruta indicada no existe"

    script = AQUI / "descargar_videos.py"

    if not script.is_file():

        return False, "No se encuentra descargar_videos.py"

    cwd = p.parent if p.is_file() else p

    clave = str(p)

    args = [sys.executable, str(script), str(p)]

    return lanzar_proceso(clave, args, cwd=str(cwd))

# --------------------------------------------------------------- selector de archivos nativo

def elegir_archivo_dialogo(inicio: str = "", tipo: str = "txt"):

    script = AQUI / "ai33" / "elegir.py"

    if not script.is_file():

        return ""

    args = [sys.executable, str(script)]

    ini = _limpiar_ruta(inicio)

    if ini and Path(ini).is_dir():

        args.append(ini)

    if tipo == "audio":

        args.append("--audio")

    elif tipo == "carpeta":

        args.append("--carpeta")

    elif tipo == "video":

        args.append("--video")

    try:

        r = subprocess.run(args, capture_output=True, text=True,

                           encoding="utf-8", errors="replace", timeout=600)

        return (r.stdout or "").strip()

    except Exception:

        return ""

# --------------------------------------------------------------- servidor web local

TEMPLATE_FILE = AQUI / "panel_template.html"

def get_pagina():

    if TEMPLATE_FILE.is_file():

        try:

            return TEMPLATE_FILE.read_text(encoding="utf-8")

        except Exception as e:

            print(f"[ERROR] No se pudo leer {TEMPLATE_FILE}: {e}")

    return "<h1>Error al cargar panel_template.html</h1>"

class Handler(http.server.BaseHTTPRequestHandler):

    def _json(self, obj, code=200):

        cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")

        self.send_response(code)

        self.send_header("Content-Type", "application/json; charset=utf-8")

        self.send_header("Content-Length", str(len(cuerpo)))

        self.end_headers()

        try:

            self.wfile.write(cuerpo)

        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, OSError):

            pass

    def _leer_json(self):

        try:

            n = int(self.headers.get("Content-Length", "0") or 0)

            if n <= 0:

                return {}

            return json.loads(self.rfile.read(n).decode("utf-8"))

        except Exception:

            return {}

    def _html(self, texto):

        cuerpo = texto.encode("utf-8")

        self.send_response(200)

        self.send_header("Content-Type", "text/html; charset=utf-8")

        self.send_header("Content-Length", str(len(cuerpo)))

        self.end_headers()

        try:

            self.wfile.write(cuerpo)

        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, OSError):

            pass

    def do_GET(self):

        u = urlparse(self.path)

        q = parse_qs(u.query)

        if u.path == "/":

            return self._html(get_pagina())

        if u.path.startswith("/adminlte/"):

            rel = unquote(u.path[len("/adminlte/"):].lstrip("/"))

            fpath = (ADMINLTE_DIR / rel).resolve()

            if fpath.is_file() and str(fpath).startswith(str(ADMINLTE_DIR.resolve())):

                mime, _ = mimetypes.guess_type(str(fpath))

                if not mime:

                    ext = fpath.suffix.lower()

                    mime = "font/woff2" if ext == ".woff2" else ("font/woff" if ext == ".woff" else ("font/ttf" if ext == ".ttf" else "application/octet-stream"))

                cuerpo = fpath.read_bytes()

                self.send_response(200)

                self.send_header("Content-Type", mime)

                self.send_header("Content-Length", str(len(cuerpo)))

                self.send_header("Cache-Control", "public, max-age=86400")

                self.end_headers()

                self.wfile.write(cuerpo)

                return

            return self._json({"error": "archivo no encontrado"}, 404)

        if u.path == "/api/sistema/verificar_actualizacion":
            try:
                import actualizador
                res = actualizador.verificar_actualizaciones()
                return self._json({"ok": True, **res})
            except Exception as e:
                return self._json({"ok": False, "error": str(e)}, 500)

        if u.path == "/api/licencia/estado":

            import licencia

            import importlib

            importlib.reload(licencia)

            return self._json(licencia.verificar_licencia())

        if u.path == "/api/dashboard/metricas":

            nicho_id = q.get("nicho", ["ecos"])[0]

            plataforma = q.get("plataforma", ["todas"])[0]

            periodo = q.get("periodo", ["28d"])[0]

            import dashboard_metricas

            import importlib

            importlib.reload(dashboard_metricas)

            datos = dashboard_metricas.obtener_metricas_dashboard(nicho_id, plataforma, periodo)

            return self._json(datos)

        if u.path == "/api/nicho/voz_config":
            n_id = q.get("nicho", [None])[0] or q.get("id", [None])[0]
            ruta_p = q.get("ruta", [None])[0]
            target_dir = None
            if ruta_p:
                p = Path(_limpiar_ruta(unquote(ruta_p))).resolve()
                if p.is_dir():
                    target_dir = p
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            p = Path(nu.get("ruta", "")).resolve()
                            if p.is_dir():
                                target_dir = p
                            break
                except Exception:
                    pass

            api_key = ""
            voice_id = "clone_2618875"
            speed = "1.0"
            ruta_usada = ""

            cfg_cand = []
            if target_dir:
                cfg_cand.append(target_dir / "ai33_config.txt")
            cfg_cand.append(AQUI / "ai33" / "ai33_config.txt")
            cfg_cand.append(CARPETA_PROYECTOS / "ai33_config.txt")

            for f_cfg in cfg_cand:
                if f_cfg.is_file():
                    try:
                        txt_c = f_cfg.read_text(encoding="utf-8", errors="ignore")
                        m_api = re.search(r"^\s*API_KEY\s*=\s*(\S+)", txt_c, re.M)
                        if m_api and not m_api.group(1).startswith(("#", "PEGA_", "TU_")):
                            if not api_key:
                                api_key = m_api.group(1).strip().strip("'\"")
                        m_v = re.search(r"^\s*VOICE_ID\s*=\s*(\S+)", txt_c, re.M)
                        if m_v:
                            if voice_id == "clone_2618875" or f_cfg == cfg_cand[0]:
                                voice_id = m_v.group(1).strip().strip("'\"")
                        m_s = re.search(r"^\s*SPEED\s*=\s*(\S+)", txt_c, re.M)
                        if m_s:
                            speed = m_s.group(1).strip().strip("'\"")
                        if not ruta_usada:
                            ruta_usada = str(f_cfg)
                    except Exception:
                        pass

            return self._json({
                "ok": True,
                "api_key": api_key,
                "voice_id": voice_id,
                "speed": speed,
                "ruta_config": ruta_usada,
                "carpeta": str(target_dir or CARPETA_PROYECTOS)
            })

        if u.path == "/api/nichos":

            from gestor_nichos import cargar_nichos_usuario

            nichos_usr = cargar_nichos_usuario()

            lista = [{"id": k, "nombre": v["nombre"], "configurado": bool(v.get("configurado"))}

                     for k, v in NICHOS.items()]

            return self._json({"nichos": lista, "nichos_usuario": nichos_usr, "def": NICHO_DEF})

        if u.path in ("/api/videos", "/api/ecos", "/api/proyectos"):

            if u.path == "/api/videos" and q.get("carpeta"):

                carpeta = unquote(q.get("carpeta", [""])[0])

                rec = q.get("rec", ["1"])[0] != "0"

                datos = listar_videos(carpeta, rec)

                if datos is None:

                    return self._json({"ok": False, "msg": "esa carpeta no existe"}, 400)

                return self._json({"ok": True, **datos})

            # Soporte para escanear nicho replicado o carpeta específica

            n_solicitado = q.get("nicho", [None])[0]

            raiz_solicitada = q.get("raiz", [None])[0]

            nicho_usar = NICHOS.get("videos").copy()

            if raiz_solicitada:

                p_r = Path(_limpiar_ruta(unquote(raiz_solicitada))).resolve()

                if p_r.is_dir():

                    nicho_usar["raiz"] = p_r

                    nicho_usar["nombre"] = p_r.name

            elif n_solicitado and n_solicitado.startswith("nicho_"):

                try:

                    from gestor_nichos import cargar_nichos_usuario

                    for nu in cargar_nichos_usuario():

                        if nu.get("id") == n_solicitado and Path(nu.get("ruta", "")).is_dir():

                            nicho_usar["raiz"] = Path(nu["ruta"]).resolve()

                            nicho_usar["nombre"] = nu["nombre"]

                            break

                except Exception:

                    pass

            return self._json(escanear_videos(nicho_usar))

        if u.path == "/api/elegir_txt":

            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "txt")

            return self._json({"ok": bool(ruta), "ruta": ruta})

        if u.path == "/api/elegir_audio":

            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "audio")

            return self._json({"ok": bool(ruta), "ruta": ruta})

        if u.path == "/api/elegir_carpeta":

            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "carpeta")

            return self._json({"ok": bool(ruta), "ruta": ruta})

        if u.path == "/api/elegir_video":

            ruta = elegir_archivo_dialogo(unquote(q.get("dir", [""])[0]), "video")

            return self._json({"ok": bool(ruta), "ruta": ruta})

        if u.path == "/api/historias/videos":
            try:
                from core.cortar_historias import escanear_videos_disponibles
                return self._json({"ok": True, "videos": escanear_videos_disponibles()})
            except Exception as ex:
                return self._json({"ok": False, "videos": [], "error": str(ex)})

        if u.path == "/api/txts":

            carpeta = unquote(q.get("carpeta", [""])[0])

            datos = listar_txts(carpeta)

            if datos is None:

                return self._json({"ok": False, "msg": "esa carpeta no existe"}, 400)

            return self._json({"ok": True, **datos})

        if u.path == "/api/voz/credenciales":

            cfg_p = AQUI / "ai33" / "ai33_config.txt"

            api_key, voice_id, speed = "", "clone_2618875", "1.0"

            if cfg_p.is_file():

                try:

                    txt = cfg_p.read_text(encoding="utf-8", errors="ignore")

                    m_api = re.search(r"^\s*API_KEY\s*=\s*(\S+)", txt, re.M)

                    if m_api and not m_api.group(1).startswith(("#", "PEGA_", "TU_")):

                        api_key = m_api.group(1).strip()

                    m_v = re.search(r"^\s*VOICE_ID\s*=\s*(\S+)", txt, re.M)

                    if m_v:

                        voice_id = m_v.group(1).strip()

                    m_s = re.search(r"^\s*SPEED\s*=\s*(\S+)", txt, re.M)

                    if m_s:

                        speed = m_s.group(1).strip()

                except Exception:

                    pass

            return self._json({

                "ok": True,

                "api_key": api_key,

                "voice_id": voice_id,

                "speed": speed,

                "listo": bool(api_key and voice_id)

            })

        if u.path == "/api/voz/configs":

            vistos = set()

            lista = []

            for k, v in AI33_CONFIGS.items():

                if k in ("voz", "videos", "reflexion", "ecos") and "config" in AI33_CONFIGS:

                    continue

                if v[0] in vistos:

                    continue

                vistos.add(v[0])

                listo = False

                if v[1].is_file():

                    try:

                        txt = v[1].read_text(encoding="utf-8", errors="ignore")

                        m = re.search(r"^\s*API_KEY\s*=\s*(\S+)", txt, re.M)

                        if m and not m.group(1).startswith(("#", "PEGA_", "TU_")):

                            listo = True

                    except Exception:

                        pass

                lista.append({"id": k, "nombre": v[0], "listo": listo})

            return self._json({"configs": lista})

        if u.path == "/api/recorte/presets":

            return self._json({"presets": [{"id": p, "nombre": n}

                                           for p, n in RECORTE_PRESETS]})

        if u.path == "/api/estado":

            return self._json(estado_actual())

        if u.path == "/api/job":

            clave = unquote(q.get("ruta", [""])[0])

            j = _job_serial(clave)

            return self._json(j or {"estado": None, "linea": ""})

        if u.path == "/api/archivos_video":

            carpeta = unquote(q.get("carpeta", [""])[0])

            rec = q.get("rec", ["1"])[0] != "0"

            datos = listar_videos(carpeta, rec)

            if datos is None:

                return self._json({"ok": False, "msg": "esa carpeta no existe"}, 400)

            return self._json({"ok": True, **datos})

        if u.path == "/api/descargar/scan":

            ruta = unquote(q.get("ruta", [""])[0])

            ok, msg, datos = escanear_enlaces_descarga(ruta)

            return self._json({"ok": ok, "msg": msg, **datos}, 200 if ok else 400)

        if u.path == "/api/nicho/subtitulos_config":
            n_id = q.get("nicho", [None])[0] or q.get("id", [None])[0]
            ruta_p = q.get("ruta", [None])[0]
            target_dir = None
            if ruta_p:
                p = Path(_limpiar_ruta(unquote(ruta_p))).resolve()
                if p.is_dir():
                    target_dir = p
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            p = Path(nu.get("ruta", "")).resolve()
                            if p.is_dir():
                                target_dir = p
                            break
                except Exception:
                    pass

            cfg_file = (target_dir / "config_nicho.json") if target_dir else (CARPETA_PROYECTOS / "config_canal.json")
            estilo = "capcut_karaoke"
            activos = True
            if cfg_file.is_file():
                try:
                    with open(cfg_file, "r", encoding="utf-8") as f:
                        d = json.load(f)
                        estilo = d.get("estilo_subtitulos", estilo)
                        activos = d.get("subtitulos_activos", activos)
                except Exception:
                    pass
            return self._json({"ok": True, "estilo_subtitulos": estilo, "subtitulos_activos": activos})

        if u.path == "/api/subtitulos/estilos":

            from subtitulos_estilos import listar_estilos

            return self._json({"estilos": listar_estilos()})

        if u.path == "/api/nicho/gemini_config":
            try:
                from core.diseccion_multimodal import obtener_clave_gemini
                k = obtener_clave_gemini()
                masked = f"{k[:6]}...{k[-4:]}" if len(k) > 10 else ("Configurada" if k else "")
                return self._json({"ok": True, "has_key": bool(k), "masked_key": masked})
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 500)

        if u.path == "/api/audio":

            ruta_audio = Path(unquote(q.get("ruta", [""])[0])).resolve()

            if ruta_audio.is_file() and ruta_audio.suffix.lower() in (".mp3", ".wav", ".ogg", ".m4a"):

                mime = "audio/mpeg" if ruta_audio.suffix.lower() == ".mp3" else "audio/wav"

                cuerpo = ruta_audio.read_bytes()

                self.send_response(200)

                self.send_header("Content-Type", mime)

                self.send_header("Content-Length", str(len(cuerpo)))

                self.send_header("Accept-Ranges", "bytes")

                self.end_headers()

                self.wfile.write(cuerpo)

                return

            return self._json({"error": "archivo de audio no encontrado"}, 404)

        if u.path == "/api/abrir":

            ruta = Path(unquote(q.get("ruta", [""])[0]))

            if ruta.exists():

                self._abrir(ruta)

                return self._json({"ok": True})

            return self._json({"ok": False}, 400)

        if u.path in ("/nexor.png", "/favicon.ico", "/nexor.ico"):
            f_img = AQUI / ("nexor.png" if "png" in u.path else "nexor.ico")
            if f_img.is_file():
                mime = "image/png" if "png" in u.path else "image/x-icon"
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(f_img.stat().st_size))
                self.end_headers()
                try:
                    with open(f_img, "rb") as fi:
                        self.wfile.write(fi.read())
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                return

        self._json({"error": "no encontrado"}, 404)

    def do_POST(self):

        u = urlparse(self.path)

        if u.path == "/api/sistema/aplicar_actualizacion":
            try:
                import actualizador
                body = self._leer_json()
                url = body.get("download_url") or ""
                res = actualizador.aplicar_actualizacion(url)
                return self._json(res, 200 if res.get("ok") else 400)
            except Exception as e:
                return self._json({"ok": False, "msg": str(e)}, 500)

        if u.path == "/api/licencia/activar":

            body = self._leer_json()

            email = body.get("email", "").strip()

            cliente = body.get("cliente", "").strip()

            codigo = body.get("codigo", body.get("clave", "")).strip()

            import licencia

            import importlib

            importlib.reload(licencia)

            ok, msg = licencia.registrar_licencia_cliente(email, cliente, codigo)

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/dashboard/guardar_cuentas":

            body = self._leer_json()

            nicho_id = body.get("nicho_id", "ecos")

            cuentas = body.get("cuentas", {})

            nombre = body.get("nombre", "")

            import dashboard_metricas

            import importlib

            importlib.reload(dashboard_metricas)

            ok = dashboard_metricas.guardar_cuentas_nicho(nicho_id, cuentas, nombre)

            return self._json({"ok": ok, "msg": "Cuentas guardadas con éxito" if ok else "Error al guardar cuentas"})

        # Comprobación de seguridad de licencia para acciones del sistema

        rutas_protegidas = ("/api/cortar", "/api/nicho/crear_proyecto", "/api/nicho/eliminar", "/api/audio", "/api/whisper/lote", "/api/descargar")

        if u.path in rutas_protegidas:

            try:

                import licencia

                st = licencia.verificar_licencia()

                if not st.get("valida"):

                    return self._json({

                        "ok": False,

                        "msg": "Licencia no activada en este equipo. Ingresa tu clave oficial para desbloquear las funciones de creación."

                    }, 403)

            except Exception:

                pass

        q = parse_qs(u.query)

        if u.path in ("/api/videos/crear_guiones", "/api/ecos/crear_guiones"):

            body = self._leer_json()

            texto = body.get("texto", "")

            gen_audio = bool(body.get("generar_audio", True))

            segmentar = bool(body.get("segmentar", True))

            nicho_id = q.get("nicho", [None])[0] or body.get("nicho") or "videos"

            nicho = NICHOS.get(nicho_id) or NICHOS.get("videos")

            # Resolver carpeta destino (nicho replicado o carpeta personalizada)

            destino_str = body.get("carpeta_destino") or body.get("ruta_destino")

            raiz_dest = None

            if destino_str:

                p_dest = Path(_limpiar_ruta(destino_str)).resolve()

                if p_dest.is_dir():

                    raiz_dest = p_dest

            elif nicho_id and nicho_id.startswith("nicho_"):

                try:

                    from gestor_nichos import cargar_nichos_usuario

                    for nu in cargar_nichos_usuario():

                        if nu.get("id") == nicho_id and Path(nu.get("ruta", "")).is_dir():

                            raiz_dest = Path(nu.get("ruta")).resolve()

                            break

                except Exception:

                    pass

            ok, msg = lanzar_crear_guiones_lote(nicho, texto, gen_audio, segmentar, raiz_destino=raiz_dest)

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/videos/generar_audio_carpeta":

            body = self._leer_json()

            ruta = body.get("ruta") or q.get("ruta", [""])[0]

            p = Path(_limpiar_ruta(ruta)).resolve()

            if not p.is_dir():

                return self._json({"ok": False, "msg": "Carpeta inválida"}, 400)

            guion_f = p / "guion.txt"

            if not guion_f.is_file():

                return self._json({"ok": False, "msg": "No existe guion.txt en esta carpeta"}, 400)

            cfg, _ = resolver_config_ai33(p)

            if not cfg or not cfg.get("API_KEY"):

                return self._json({"ok": False, "msg": "Configura primero tu API_KEY de ai33.pro"}, 400)

            texto = guion_f.read_text(encoding="utf-8", errors="ignore").strip()

            if not texto:

                return self._json({"ok": False, "msg": "El guion.txt está vacío"}, 400)

            clave = str(p)

            log = collections.deque(maxlen=60)

            JOBS[clave] = {"estado": "activo", "log": log, "inicio": time.time()}

            def worker_aud():

                log.append(f"Generando audio para {p.name} con IA...")

                try:

                    sys.path.insert(0, str(AQUI / "ai33"))

                    import tts

                    task_id, direct = tts.crear_tarea(cfg, texto)

                    url = direct or tts.esperar_audio(cfg, task_id)

                    aud_p = p / "aud.mp3"

                    tts.descargar(url, str(aud_p))

                    if p.parent.is_dir():

                        shutil.copy2(aud_p, p.parent / f"{p.name}.mp3")

                    log.append(f"¡Audio guardado exitosamente en {p.name}/aud.mp3!")

                    script_seg = Path(nicho.get("codigo", AQUI / "videos")) / "segmentar_guion.py"

                    if not script_seg.is_file():

                        script_seg = AQUI / "videos" / "segmentar_guion.py"

                    if script_seg.is_file():

                        subprocess.run([sys.executable, str(script_seg), str(p)], capture_output=True)

                        log.append("Sincronía actualizada.")

                    JOBS[clave]["estado"] = "ok"

                except Exception as e:

                    log.append(f"Error generando audio: {e}")

                    JOBS[clave]["estado"] = "error"

            threading.Thread(target=worker_aud, daemon=True).start()

            return self._json({"ok": True, "msg": f"Generando audio para {p.name}..."})

        if u.path == "/api/videos/mover_a_nicho":

            body = self._leer_json()

            carpetas = body.get("carpetas", [])

            nicho_id = body.get("nicho_id", "")

            ruta_destino = body.get("ruta_destino", "")

            p_dest = None

            if ruta_destino and Path(ruta_destino).is_dir():

                p_dest = Path(ruta_destino).resolve()

            elif nicho_id:

                try:

                    from gestor_nichos import cargar_nichos_usuario

                    for nu in cargar_nichos_usuario():

                        if nu.get("id") == nicho_id and Path(nu.get("ruta", "")).is_dir():

                            p_dest = Path(nu.get("ruta")).resolve()

                            break

                except Exception:

                    pass

            if not p_dest:

                return self._json({"ok": False, "msg": "Destino no encontrado"}, 400)

            movidas = 0

            for c_nom in carpetas:

                orig = CARPETA_PROYECTOS / c_nom

                if orig.is_dir() and orig != p_dest:

                    dst = p_dest / c_nom

                    if not dst.exists():

                        shutil.move(str(orig), str(dst))

                        movidas += 1

            return self._json({"ok": True, "msg": f"Se movieron {movidas} carpetas a {p_dest.name}."})

        if u.path in ("/api/videos/cortar", "/api/ecos/cortar"):

            limpiar = q.get("limpiar", ["1"])[0] == "1"

            subtitulos = q.get("subtitulos", ["1"])[0] == "1"

            estilo_sub = q.get("estilo", [None])[0]
            ok, msg = lanzar_cortar_videos(NICHOS["videos"], unquote(q.get("ruta", [""])[0]), limpiar, subtitulos, estilo_sub)

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path in ("/api/videos/segmentar", "/api/ecos/segmentar"):

            ok, msg = lanzar_segmentar_videos(NICHOS["videos"], unquote(q.get("ruta", [""])[0]))

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path in ("/api/videos/unir", "/api/ecos/unir"):

            ok, msg = lanzar_unir_videos(NICHOS["videos"], unquote(q.get("ruta", [""])[0]))

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path in ("/api/videos/subtitulos", "/api/ecos/subtitulos"):

            ok, msg = lanzar_subtitulos_videos(NICHOS["videos"], unquote(q.get("ruta", [""])[0]))

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/transcribir/metadata":
            body = self._leer_json()
            enlaces = body.get("enlaces", [])
            formato = body.get("formato", "txt")
            guardar_ind = bool(body.get("guardar_individuales", True))
            guardar_comb = bool(body.get("guardar_combinado", True))
            nom_comb = body.get("nombre_combinado", "guiones_metadata_combinados.txt")

            if not enlaces:
                return self._json({"ok": False, "error": "No se enviaron enlaces"}, 400)

            try:
                import transcriptor_metadata
                res = transcriptor_metadata.procesar_lote_urls(
                    enlaces=enlaces,
                    carpeta_salida=CARPETA_PROYECTOS / "transcripciones_metadata",
                    formato=formato,
                    guardar_individuales=guardar_ind,
                    guardar_combinado=guardar_comb,
                    nombre_combinado=nom_comb
                )
                return self._json(res, 200 if res.get("ok") else 400)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)}, 500)

        if u.path == "/api/transcribir_lote":

            body = self._leer_json()

            ok, msg = lanzar_transcribir_lote(

                body.get("carpeta", ""),

                body.get("rutas", []),

                (body.get("idioma") or "es"),

                (body.get("modelo") or "small"),

                bool(body.get("combinar", True)))

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/nicho/voz_config":
            body = self._leer_json()
            n_id = body.get("nicho_id") or body.get("nicho")
            ruta_p = body.get("ruta")
            api_key = (body.get("api_key") or "").strip().strip("'\"")
            voice_id = (body.get("voice_id") or "").strip().strip("'\"")
            speed = (body.get("speed") or "1.0").strip().strip("'\"")

            if not api_key:
                return self._json({"ok": False, "msg": "La API Key no puede estar vacía."}, 400)
            if not voice_id:
                return self._json({"ok": False, "msg": "Debes especificar un ID de voz (ej: clone_2618875)."}, 400)

            target_dir = None
            if ruta_p:
                p = Path(_limpiar_ruta(ruta_p)).resolve()
                if p.is_dir():
                    target_dir = p
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            p = Path(nu.get("ruta", "")).resolve()
                            if p.is_dir():
                                target_dir = p
                            break
                except Exception:
                    pass

            txt_cfg = f"""# ============================================================
#  ai33.pro (Text-To-Speech)  -  CONFIGURACIÓN DE VOZ DEL CANAL
# ============================================================
API_KEY={api_key}
VOICE_ID={voice_id}
SPEED={speed}
WITH_TRANSCRIPT=false
TTS_URL=https://api.ai33.pro/v3/text-to-speech
TASK_URL=https://api.ai33.pro/v3/task/{{task_id}}
TIMEOUT=300
"""
            if target_dir:
                cfg_local = target_dir / "ai33_config.txt"
                cfg_local.write_text(txt_cfg, encoding="utf-8")

            cfg_central = AQUI / "ai33" / "ai33_config.txt"
            cfg_central.parent.mkdir(parents=True, exist_ok=True)
            cfg_central.write_text(txt_cfg, encoding="utf-8")

            # Mantener sincronizada la raiz de proyectos para que no cargue credenciales obsoletas
            try:
                cfg_proy = CARPETA_PROYECTOS / "ai33_config.txt"
                cfg_proy.parent.mkdir(parents=True, exist_ok=True)
                cfg_proy.write_text(txt_cfg, encoding="utf-8")
            except Exception:
                pass

            return self._json({"ok": True, "msg": "Configuración de voz guardada correctamente para este canal."})

        if u.path == "/api/voz/probar":
            body = self._leer_json()
            api_key = (body.get("api_key") or "").strip().strip("'\"")
            voice_id = (body.get("voice_id") or "clone_2618875").strip().strip("'\"")
            speed = (body.get("speed") or "1.0").strip().strip("'\"")

            if api_key.lower().startswith("api_key="):
                api_key = api_key.split("=", 1)[1].strip().strip("'\"")
            if api_key.lower().startswith("bearer "):
                api_key = api_key[7:].strip().strip("'\"")

            if not api_key:
                return self._json({"ok": False, "msg": "Por favor ingresa tu API Key de ai33.pro antes de probar."}, 400)
            if not voice_id:
                return self._json({"ok": False, "msg": "Debes especificar un ID de voz (ej: clone_2618875)."}, 400)

            cfg_test = {
                "API_KEY": api_key,
                "VOICE_ID": voice_id,
                "SPEED": speed,
                "WITH_TRANSCRIPT": "false",
                "TTS_URL": "https://api.ai33.pro/v3/text-to-speech",
                "TASK_URL": "https://api.ai33.pro/v3/task/{task_id}",
                "TIMEOUT": "30"
            }
            try:
                sys.path.insert(0, str(AQUI / "ai33"))
                import tts
                import importlib
                importlib.reload(tts)
                task_id, direct = tts.crear_tarea(cfg_test, "Prueba de conexion con tu generador de videos.")
                return self._json({
                    "ok": True,
                    "msg": f"¡Conexión exitosa con ai33.pro! Servidor respondio correctamente. Tu clave y voz funcionan."
                })
            except Exception as e:
                return self._json({"ok": False, "msg": f"Error de conexion con ai33.pro: {e}"}, 400)

        if u.path == "/api/voz/guardar_credenciales":

            body = self._leer_json()

            api_key = (body.get("api_key") or "").strip()

            voice_id = (body.get("voice_id") or "clone_2618875").strip()

            speed = (body.get("speed") or "1.0").strip()

            ruta_proy = (body.get("ruta_proyecto") or "").strip()

            if not api_key:

                return self._json({"ok": False, "msg": "La API Key no puede estar vacía."}, 400)

            cfg_p = AQUI / "ai33" / "ai33_config.txt"

            cfg_p.parent.mkdir(parents=True, exist_ok=True)

            txt_cfg = f"""# ============================================================

#  ai33.pro (Text-To-Speech)  -  CONFIGURACIÓN DE VOZ

# ============================================================

API_KEY={api_key}

VOICE_ID={voice_id}

SPEED={speed}

WITH_TRANSCRIPT=false

TTS_URL=https://api.ai33.pro/v3/text-to-speech

TASK_URL=https://api.ai33.pro/v3/task/{{task_id}}

TIMEOUT=300

"""

            cfg_p.write_text(txt_cfg, encoding="utf-8")

            try:
                cfg_proy = CARPETA_PROYECTOS / "ai33_config.txt"
                cfg_proy.parent.mkdir(parents=True, exist_ok=True)
                cfg_proy.write_text(txt_cfg, encoding="utf-8")
            except Exception:
                pass

            if ruta_proy:

                p_proy = Path(_limpiar_ruta(ruta_proy)).resolve()

                if p_proy.is_dir():

                    (p_proy / "ai33_config.txt").write_text(txt_cfg, encoding="utf-8")

                elif p_proy.is_file():

                    (p_proy.parent / "ai33_config.txt").write_text(txt_cfg, encoding="utf-8")

            return self._json({"ok": True, "msg": "Credenciales de ai33.pro guardadas correctamente."})

        if u.path == "/api/voz/generar":

            ok, msg = lanzar_voz(unquote(q.get("ruta", [""])[0]), q.get("nicho", ["videos"])[0])

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/recorte/generar":

            ok, msg = lanzar_recorte(unquote(q.get("ruta", [""])[0]),

                                     q.get("nicho", ["videos"])[0],

                                     q.get("bordes", ["0"])[0] == "1",

                                     q.get("respiros", ["1"])[0] == "1")

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/descargar/guardar":

            body = self._leer_json()

            carpeta = body.get("carpeta") or unquote(q.get("carpeta", [""])[0])

            urls = body.get("urls") if body.get("urls") is not None else body.get("texto", "")

            ok, msg, datos = guardar_enlaces_descarga(carpeta, urls)

            return self._json({"ok": ok, "msg": msg, **datos}, 200 if ok else 400)

        if u.path == "/api/descargar/iniciar":

            body = self._leer_json()

            ruta = body.get("ruta") or unquote(q.get("ruta", [""])[0])

            texto = body.get("texto")

            if texto and str(texto).strip():

                guardar_enlaces_descarga(ruta, texto)

            ok, msg = lanzar_descarga_videos(ruta)

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/analizar_nicho":

            body = self._leer_json()

            urls = body.get("urls") or []

            if not urls and body.get("texto"):

                import re

                lineas = str(body.get("texto", "")).splitlines()

                urls = []

                for l in lineas:

                    urls.extend(re.findall(r"https?://[^\s\"'<>]+", l))

            elif not urls and body.get("ruta"):

                p = Path(_limpiar_ruta(body.get("ruta"))).expanduser().resolve()

                from descargar_videos import extraer_urls_de_archivo, buscar_txt_con_enlaces

                if p.is_file():

                    urls = extraer_urls_de_archivo(p)

                elif p.is_dir():

                    _, urls = buscar_txt_con_enlaces(p)

            import analizar_nicho
            import importlib
            importlib.reload(analizar_nicho)
            clave_gemini = body.get("clave_gemini") or body.get("gemini_key")
            res = analizar_nicho.analizar_enlaces(urls, clave_gemini=clave_gemini)
            return self._json(res, 200 if res.get("ok") else 400)

        if u.path == "/api/nicho/gemini_config":
            try:
                from core.diseccion_multimodal import obtener_clave_gemini, guardar_clave_gemini
                if self.command == "GET":
                    k = obtener_clave_gemini()
                    masked = f"{k[:6]}...{k[-4:]}" if len(k) > 10 else ("Configurada" if k else "")
                    return self._json({"ok": True, "has_key": bool(k), "masked_key": masked})
                else:
                    body = self._leer_json()
                    k_nueva = (body.get("api_key") or body.get("gemini_api_key") or "").strip()
                    guardar_clave_gemini(k_nueva)
                    return self._json({"ok": True, "has_key": bool(k_nueva)})
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 500)

        if u.path == "/api/fuente/instalar":

            from subtitulos_estilos import instalar_fuente_en_windows

            res = instalar_fuente_en_windows()

            return self._json(res, 200 if res.get("ok") else 400)

        if u.path == "/api/nicho/sugerir_nombre":

            body = self._leer_json()

            canal = body.get("canal", "")

            tipo_nicho = body.get("tipo_nicho", "")

            from gestor_nichos import sugerir_nombre_proyecto

            return self._json({"ok": True, "sugerencia": sugerir_nombre_proyecto(canal, tipo_nicho)})

        if u.path == "/api/nicho/crear_proyecto":

            body = self._leer_json()

            nombre = body.get("nombre", "").strip()

            analisis = body.get("analisis", {})

            extraer = bool(body.get("extraer_audio", True))

            estilo_sub = body.get("estilo_subtitulos", "capcut_karaoke")

            import gestor_nichos

            import importlib

            importlib.reload(gestor_nichos)

            res = gestor_nichos.crear_proyecto_nicho(nombre, analisis, extraer_audio=extraer, estilo_subtitulos=estilo_sub)

            return self._json(res, 200 if res.get("ok") else 400)

        if u.path == "/api/nicho/toggle_estado":
            body = self._leer_json()
            nicho_id = body.get("id", "").strip()
            activo = body.get("activo", None)
            import gestor_nichos
            import importlib
            importlib.reload(gestor_nichos)
            ok, msg, canal = gestor_nichos.toggle_estado_nicho(nicho_id, activo)
            return self._json({"ok": ok, "msg": msg, "canal": canal}, 200 if ok else 400)

        if u.path == "/api/nicho/eliminar":
            body = self._leer_json()
            nicho_id = body.get("id", "").strip()
            borrar_archivos = bool(body.get("borrar_archivos", False))
            import gestor_nichos
            import importlib
            importlib.reload(gestor_nichos)
            ok, msg = gestor_nichos.eliminar_nicho_usuario(nicho_id, borrar_archivos=borrar_archivos)
            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path == "/api/nicho/subtitulos_config":
            body = self._leer_json()
            n_id = body.get("nicho_id") or body.get("nicho")
            ruta_p = body.get("ruta")
            estilo = body.get("estilo_subtitulos")
            activos = body.get("subtitulos_activos")

            target_dir = None
            if ruta_p:
                p = Path(_limpiar_ruta(ruta_p)).resolve()
                if p.is_dir():
                    target_dir = p
            elif n_id and n_id.startswith("nicho_"):
                try:
                    from gestor_nichos import cargar_nichos_usuario, guardar_nicho_usuario
                    for nu in cargar_nichos_usuario():
                        if nu.get("id") == n_id:
                            p = Path(nu.get("ruta", "")).resolve()
                            if p.is_dir():
                                target_dir = p
                            if estilo:
                                nu["estilo_subtitulos"] = estilo
                            if activos is not None:
                                nu["subtitulos_activos"] = bool(activos)
                            guardar_nicho_usuario(nu)
                            break
                except Exception:
                    pass

            cfg_file = (target_dir / "config_nicho.json") if target_dir else (CARPETA_PROYECTOS / "config_canal.json")
            data = {}
            if cfg_file.is_file():
                try:
                    with open(cfg_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except Exception:
                    data = {}
            if estilo:
                data["estilo_subtitulos"] = estilo
            if activos is not None:
                data["subtitulos_activos"] = bool(activos)
            try:
                cfg_file.parent.mkdir(parents=True, exist_ok=True)
                with open(cfg_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
            return self._json({"ok": True, "msg": "Configuracion de subtitulos guardada con exito."})

        if u.path == "/api/historias/cortar":
            try:
                body = self._leer_json()
                ruta = (body.get("ruta") or body.get("ruta_video") or "").strip()
                dur = float(body.get("duracion") or body.get("duracion_segmento") or 15.0)
                sub = (body.get("subcarpeta") or "historias").strip() or "historias"
                modo = (body.get("modo") or "rapido").strip()
                from core.cortar_historias import dividir_video_historias
                res = dividir_video_historias(ruta, duracion_segmento=dur, subcarpeta=sub, modo=modo)
                return self._json(res, 200 if res.get("ok") else 400)
            except Exception as ex:
                return self._json({"ok": False, "error": str(ex)}, 500)

        if u.path == "/api/historias/abrir_carpeta":
            try:
                body = self._leer_json() if self.command == "POST" else {}
                ruta = (body.get("ruta") or body.get("carpeta") or "").strip()
                if not ruta:
                    ruta = unquote(q.get("ruta", [""])[0])
                if ruta:
                    p = Path(_limpiar_ruta(ruta)).resolve()
                    if p.is_dir() or p.is_file():
                        target = p if p.is_dir() else p.parent
                        if sys.platform.startswith("win"):
                            os.startfile(str(target))
                        elif sys.platform == "darwin":
                            subprocess.run(["open", str(target)])
                        else:
                            subprocess.run(["xdg-open", str(target)])
                        return self._json({"ok": True})
                return self._json({"ok": False, "msg": "Ruta no encontrada"}, 400)
            except Exception as ex:
                return self._json({"ok": False, "msg": str(ex)}, 500)

        if u.path == "/api/cancelar":

            ok, msg = cancelar_proceso()

            return self._json({"ok": ok, "msg": msg}, 200 if ok else 400)

        if u.path in ("/nexor.png", "/favicon.ico", "/nexor.ico"):
            f_img = AQUI / ("nexor.png" if "png" in u.path else "nexor.ico")
            if f_img.is_file():
                mime = "image/png" if "png" in u.path else "image/x-icon"
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(f_img.stat().st_size))
                self.end_headers()
                try:
                    with open(f_img, "rb") as fi:
                        self.wfile.write(fi.read())
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                return

        self._json({"error": "no encontrado"}, 404)

    @staticmethod

    def _abrir(p: Path):

        if sys.platform.startswith("win"):

            os.startfile(str(p))

        elif sys.platform == "darwin":

            subprocess.run(["open", str(p)])

        else:

            subprocess.run(["xdg-open", str(p)])

    def log_message(self, *a):

        pass

def main():
    try:
        import verificar_entorno
        verificar_entorno.verificar_y_reparar()
    except Exception as _e_ent:
        print(f"[Aviso] Verificación de entorno: {_e_ent}")

    http.server.ThreadingHTTPServer.allow_reuse_address = True
    http.server.ThreadingHTTPServer.daemon_threads = True

    srv = None
    puerto = None
    for p in range(PUERTO_DEF, PUERTO_DEF + 30):
        try:
            srv = http.server.ThreadingHTTPServer(('127.0.0.1', p), Handler)
            puerto = p
            break
        except OSError:
            continue

    if not srv or not puerto:
        print(f'[ERROR] No se pudo vincular ningun puerto entre {PUERTO_DEF} y {PUERTO_DEF + 30}.')
        return

    url = f'http://127.0.0.1:{puerto}'
    print('=' * 60)
    print('   CREADOR DE VIDEOS  -  SISTEMA UNIVERSAL DE CONTENIDO')
    print('=' * 60)
    print(f'Panel disponible en: {url}')
    print(f'Carpeta de proyectos: {CARPETA_PROYECTOS}')
    print('Presiona Ctrl+C o cierra esta ventana para detener el servidor.')
    print('=' * 60)

    if os.environ.get('PANEL_NO_BROWSER') != '1':
        def _lanzar_navegador():
            time.sleep(0.5)
            try:
                webbrowser.open(url)
            except Exception as e:
                print(f'[Aviso] No se pudo abrir automaticamente el navegador: {e}')
        threading.Thread(target=_lanzar_navegador, daemon=True).start()

    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nPanel detenido.')
    finally:
        try:
            srv.server_close()
        except Exception:
            pass

if __name__ == '__main__':
    main()
