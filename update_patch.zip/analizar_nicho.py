# -*- coding: utf-8 -*-
"""
analizar_nicho.py
-----------------
Analizador de Canales y Nichos Virales para Creador de Videos.
Evalúa la viabilidad de replicar un canal (Facebook, YouTube, TikTok)
sin descargar videos pesados, extrayendo guiones, estructura viral,
identidad visual (prompts de estilo y personajes) y generando la
instrucción maestra para IA.
"""

import json
import re
import subprocess
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


ESTILOS_VISUALES = {
    "zack_d_films": {
        "id": "zack_d_films",
        "nombre": "Animación 3D Estilo Zack D. Films (Curiosidades y Simulaciones)",
        "sufijo": "Stylized 3D character animation in signature Zack D Films style, expressive stylized 3D human character, clean digital CGI animation render, vibrant studio rim lighting, Unreal Engine 5 render, Blender simulation aesthetic, highly detailed object and anatomy demonstration, smooth textures, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact stylized 3D Zack D Films animation style, smooth character gestures, and educational demonstration simulation of the original image. Dynamic realistic motion. No text.",
        "descripcion": "Animación 3D estilizada de alta retención al estilo Zack D. Films y YouandAngel. Personajes expresivos explicando curiosidades insólitas, ciencia, anatomía, inventos y simulaciones de alto impacto visual."
    },
    "roblox_3d": {
        "id": "roblox_3d",
        "nombre": "Roblox 3D / Bloques Cartoon (Estilo SoyGelo / Gaming)",
        "sufijo": "Low-poly 3D blocky cartoon character animation style, modular Roblox-inspired avatar aesthetic, smooth plastic toy texture, minimalist facial decal expression, vibrant isometric studio lighting, clean solid surfaces, 3D CGI animation render, Unreal Engine 5 render, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact 3D blocky cartoon character animation style, plastic toy texture, and aesthetic of the original image. Smooth natural character movement. No text.",
        "descripcion": "Personajes cúbicos estilo Roblox con texturas plásticas limpias, caras expresivas con calcomanías y render 3D caricaturesco. Ideal para historias virales de comedia, gaming y animación."
    },
    "minecraft_voxel": {
        "id": "minecraft_voxel",
        "nombre": "Minecraft / Voxel Art Cúbico",
        "sufijo": "Voxel art style, Minecraft blocky aesthetic, cubic geometry, vibrant pixelated textures, soft volumetric shader lighting, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact voxel blocky art style, cubic geometry, and pixelated shader lighting of the original image. Smooth natural movement. No text.",
        "descripcion": "Estilo cúbico y voxel con texturas pixeladas e iluminación suave de shaders volumétricos."
    },
    "dark_noir": {
        "id": "dark_noir",
        "nombre": "Dark Noir / Misterio Cinematográfico (Estilo Ojos de Lobo)",
        "sufijo": "Cinematic dark mystery documentary style, moody dramatic rim lighting, deep atmospheric shadows, film noir graphic aesthetic, hyperdetailed textures, 8k resolution, cinematic frame --ar 9:16 --v 6 --style raw",
        "sufijo_movimiento": "Maintain the exact cinematic dark mystery style, moody dramatic rim lighting, deep atmospheric shadows, and film noir aesthetic of the original image. Smooth natural cinematic motion. No text.",
        "descripcion": "Estilo oscuro, intrigante y premium. Ideal para curiosidades, secretos comerciales, marketing oculto, marcas y psicología."
    },
    "pixar_3d": {
        "id": "pixar_3d",
        "nombre": "3D Pixar / Render Cinematográfico Digital",
        "sufijo": "3D Pixar animation style render, cute and expressive character design, soft subsurface scattering, vibrant warm studio lighting, Unreal Engine 5 octane render, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact 3D Pixar animation style, warm studio lighting, and expressive character design of the original image. Smooth natural character animation. No text.",
        "descripcion": "Animación 3D amigable y expresiva. Ideal para fábulas con animales humanizados y público familiar amplio."
    },
    "realismo_cinematografico": {
        "id": "realismo_cinematografico",
        "nombre": "Realismo Cinematográfico / Drama 35mm",
        "sufijo": "Hyperrealistic cinematic film still, dramatic emotional expression, 35mm lens, depth of field, natural realistic textures, raw photography, 8k UHD --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact hyperrealistic cinematic film still style, 35mm depth of field, and natural textures of the original image. Smooth natural realistic motion. No text.",
        "descripcion": "Fotografía cinematográfica con iluminación dramática. Ideal para historias humanas maduras, lecciones de vida y dramas sociales."
    },
    "anime_moderno": {
        "id": "anime_moderno",
        "nombre": "Anime Moderno / Shonen Cinematográfico",
        "sufijo": "Modern anime cinematic style, Makoto Shinkai aesthetic, clean linework, vibrant expressive lighting, detailed anime background, cel shading, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact modern anime cinematic style, clean linework, vibrant lighting, and cel shading of the original image. Smooth natural anime motion. No text.",
        "descripcion": "Estilo anime contemporáneo con iluminación vibrante, fondos detallados y sombreado cel."
    },
    "comic": {
        "id": "comic",
        "nombre": "Comic Book / Graphic Novel (Línea Definida - Ecos del Alma)",
        "sufijo": "Highly detailed comic book illustration style with clean bold line art, vibrant colors, flat color fills, graphic novel aesthetic, masterpiece, 8k --ar 9:16 --v 6 --stylize 250 --style raw",
        "sufijo_movimiento": "Maintain the exact illustration style, clean bold line art, vibrant colors, flat color fills, and graphic novel aesthetic of the original image. Smooth natural cinematic motion. No text.",
        "descripcion": "Estilo cómic/novela gráfica de alto impacto. Trazo negro limpio, colores vivos y estética gráfica definida."
    },
    "plastilina_stopmotion": {
        "id": "plastilina_stopmotion",
        "nombre": "Plastilina / Claymation Stop-Motion",
        "sufijo": "Claymation stop-motion animation style, sculpted plasticine texture, visible handcrafted fingerprint details, warm soft studio lighting, Aardman inspired, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact claymation stop-motion style, sculpted plasticine textures, and warm lighting of the original image. Smooth stop-motion animation. No text.",
        "descripcion": "Estilo artesanal de muñecos de plastilina modelada con textura táctil e iluminación cálida."
    }
}



def contiene_palabra(texto: str, palabras: list) -> bool:
    """Busca palabras o frases completas con límites de palabra para evitar falsos positivos
    como 'oso' en 'peligroso', 'lobo' en 'globo', o 'rico' en 'historico'."""
    for p in palabras:
        p_clean = p.strip().lower()
        if not p_clean:
            continue
        if " " in p_clean or "¿" in p_clean or "?" in p_clean:
            if p_clean in texto:
                return True
        else:
            patron = r"(?<![a-záéíóúüñ0-9])" + re.escape(p_clean) + r"(?![a-záéíóúüñ0-9])"
            if re.search(patron, texto):
                return True
    return False

def _asegurar_ytdlp():
    """Verifica si yt_dlp está instalado y si no, lo instala automáticamente."""
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        try:
            print("[*] Librería yt-dlp no encontrada en este entorno Python. Instalando automáticamente...")
            subprocess.run([sys.executable, "-m", "pip", "install", "yt-dlp", "curl-cffi", "--quiet"], check=False)
            import yt_dlp
            return yt_dlp
        except Exception as ex:
            print(f"[ERROR] No se pudo auto-instalar yt-dlp: {ex}")
            return None


def extraer_info_url(url: str) -> dict:
    """Extrae metadatos y texto del video con yt-dlp directamente en Python o por subproceso."""
    url = url.strip()
    if not url:
        return None

    yt_dlp_mod = _asegurar_ytdlp()

    # Intento 1: Directamente a través del módulo de Python (más rápido, sin problemas de terminal)
    if yt_dlp_mod:
        try:
            ydl_opts = {
                'skip_download': True,
                'quiet': True,
                'no_warnings': True,
                'extract_flat': False,
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
            }
            with yt_dlp_mod.YoutubeDL(ydl_opts) as ydl:
                data = ydl.extract_info(url, download=False)
                if not data:
                    return {"url": url, "ok": False, "error": "No se recibieron datos del video"}

                # Si es un playlist o perfil con entries
                if "entries" in data and not data.get("title"):
                    entries = [e for e in data.get("entries", []) if e]
                    if entries:
                        data = entries[0]

                titulo = data.get("title", "")
                descripcion = data.get("description", "")
                duracion = data.get("duration", 0)
                canal = data.get("uploader", "") or data.get("channel", "") or "Desconocido"
                canal_id = data.get("uploader_id", "") or ""
                vistas = data.get("view_count", 0)
                likes = data.get("like_count", 0)
                aspect = data.get("aspect_ratio")
                thumb = data.get("thumbnail", "")
                categories = data.get("categories", []) or []
                tags = data.get("tags", []) or []

                tiene_guion_en_desc = len(descripcion) > 180 and (
                    "reflexión" in descripcion.lower() or 
                    "historia" in descripcion.lower() or 
                    "¿por qué" in descripcion.lower() or 
                    len(descripcion.split()) > 40
                )
                guion_detectado = descripcion if tiene_guion_en_desc else ""

                es_vertical = False
                if aspect and aspect < 0.9:
                    es_vertical = True
                elif duracion and duracion <= 90:
                    es_vertical = True

                return {
                    "url": url,
                    "ok": True,
                    "titulo": titulo,
                    "canal": canal,
                    "canal_id": canal_id,
                    "duracion": duracion,
                    "duracion_fmt": f"{int(duracion//60)}:{int(duracion%60):02d}" if duracion else "N/D",
                    "vistas": vistas,
                    "likes": likes,
                    "es_vertical": es_vertical,
                    "aspect": aspect,
                    "thumbnail": thumb,
                    "descripcion": descripcion,
                    "guion": guion_detectado,
                    "categories": categories,
                    "tags": tags
                }
        except Exception as e:
            # Continuar con fallback por si fue error transitorio del wrapper
            pass

    # Intento 2: Subproceso
    cmd = [
        sys.executable, "-m", "yt_dlp",
        "--dump-json",
        "--no-warnings",
        "--skip-download",
        "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        url
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=35)
        if res.returncode != 0 or not res.stdout.strip():
            err_msg = res.stderr[:180] or "No se pudo extraer información del enlace"
            return {"url": url, "ok": False, "error": err_msg}

        data = json.loads(res.stdout.splitlines()[0])

        titulo = data.get("title", "")
        descripcion = data.get("description", "")
        duracion = data.get("duration", 0)
        canal = data.get("uploader", "") or data.get("channel", "") or "Desconocido"
        canal_id = data.get("uploader_id", "") or ""
        vistas = data.get("view_count", 0)
        likes = data.get("like_count", 0)
        aspect = data.get("aspect_ratio")
        thumb = data.get("thumbnail", "")
        categories = data.get("categories", []) or []
        tags = data.get("tags", []) or []

        tiene_guion_en_desc = len(descripcion) > 180 and (
            "reflexión" in descripcion.lower() or 
            "historia" in descripcion.lower() or 
            "¿por qué" in descripcion.lower() or 
            len(descripcion.split()) > 40
        )
        guion_detectado = descripcion if tiene_guion_en_desc else ""

        es_vertical = False
        if aspect and aspect < 0.9:
            es_vertical = True
        elif duracion and duracion <= 90:
            es_vertical = True

        return {
            "url": url,
            "ok": True,
            "titulo": titulo,
            "canal": canal,
            "canal_id": canal_id,
            "duracion": duracion,
            "duracion_fmt": f"{int(duracion//60)}:{int(duracion%60):02d}" if duracion else "N/D",
            "vistas": vistas,
            "likes": likes,
            "es_vertical": es_vertical,
            "aspect": aspect,
            "thumbnail": thumb,
            "descripcion": descripcion,
            "guion": guion_detectado,
            "categories": categories,
            "tags": tags
        }
    except Exception as e:
        return {"url": url, "ok": False, "error": str(e)}


def diagnosticar_nicho(videos_info: list) -> dict:
    """Evalúa la lista de videos y genera la ficha de replicabilidad, identidad visual y prompts."""
    validos = [v for v in videos_info if v.get("ok")]
    if not validos:
        errores = [v.get("error", "") for v in videos_info if v.get("error")]
        detalle_err = (" " + errores[0]) if errores else ""
        if "No module named yt_dlp" in detalle_err or "No module named 'yt_dlp'" in detalle_err:
            msg = "Faltan instalar las librerías en tu nuevo Python. Por favor haz doble clic en 'instalar_dependencias.bat' para instalarlas automáticamente con 1 clic."
        elif "tiktok:user" in detalle_err.lower() or "unable to extract" in detalle_err.lower():
            msg = "Parece que ingresaste el enlace de un perfil de usuario (ej: @canal). Por favor ingresa enlaces de videos individuales (ej: https://www.tiktok.com/@usuario/video/12345... o de YouTube Shorts)."
        else:
            msg = f"No se pudo obtener información válida de los enlaces proporcionados.{detalle_err}"
        return {
            "ok": False,
            "msg": msg
        }

    total_videos = len(validos)
    canales = list({v["canal"] for v in validos if v.get("canal")})
    canal_principal = canales[0] if canales else "Nicho Analizado"

    duraciones = [v["duracion"] for v in validos if v.get("duracion")]
    dur_prom = sum(duraciones) / len(duraciones) if duraciones else 60
    formato_vert = sum(1 for v in validos if v.get("es_vertical")) >= (total_videos / 2)

    # Detección exhaustiva de temática y palabras clave
    textos_lista = []
    for v in validos:
        textos_lista.append(v.get("titulo", "") or "")
        textos_lista.append(v.get("descripcion", "") or "")
        textos_lista.append(v.get("canal", "") or "")
        textos_lista.append(v.get("canal_id", "") or "")
        textos_lista.extend(v.get("categories", []) or [])
        textos_lista.extend(v.get("tags", []) or [])

    texto_combinado = " ".join(textos_lista).lower()

        # Detección exhaustiva de temática con palabras completas
    # 1. Gaming / Roblox / 3D Cartoon (Ej: SoyGelo)
    es_roblox_o_gaming = (
        contiene_palabra(texto_combinado, ["roblox", "gelo", "gelozmc", "bloxd", "lego"]) or
        ("gaming" in texto_combinado and contiene_palabra(texto_combinado, ["animacion", "animación", "short", "avatar", "bloque", "skin", "llegué", "todos llegan"]))
    )

    # 2. Minecraft / Voxel
    es_minecraft = contiene_palabra(texto_combinado, ["minecraft", "voxel"])

    # 3. Animación 3D Zack D. Films / Simulaciones y Curiosidades (Ej: Zack D. Films, YouandAngel)
    es_zack_d_films = (
        contiene_palabra(texto_combinado, ["zack", "zackdfilms", "zack d films", "youandangel"]) or
        contiene_palabra(canal_principal.lower(), ["zack", "youandangel"]) or
        (
            any(h in texto_combinado for h in ["¿esto podría", "esto podria", "¿este podría", "este podria", "¿qué pasaría", "que pasaria", "¿sabías qué", "sabias que", "¿por qué ocurre", "por que ocurre", "¿cómo funciona", "como funciona"]) and
            contiene_palabra(texto_combinado, ["invento", "mutación", "mutacion", "peligroso", "experimento", "anatomía", "anatomia", "simulación", "simulacion", "ciencia", "científico", "cientifico", "medicina", "educativo", "magia"])
        ) or
        (
            contiene_palabra(texto_combinado, ["animación 3d", "animacion 3d", "simulacion 3d", "simulación 3d"]) and
            contiene_palabra(texto_combinado, ["curiosidad", "curiosidades", "educativo", "invento", "ciencia", "cuerpo", "peligro"])
        )
    )

    # 4. Secretos de la Industria / Ojos de Lobo (Curiosidades y Marketing)
    es_ojos_de_lobo = (
        "ojos de lobo" in texto_combinado or
        "ojosdelobo" in canal_principal.lower() or
        contiene_palabra(texto_combinado, ["marketing", "truco", "secreto", "salmón", "precio", "marca", "valor", "¿por qué", "comprar", "psicología", "industria", "fraude"])
    )

    # 5. Fábulas de Animales (Requiere contexto explícito de fábula o reflexión, NUNCA por palabras sueltas como 'peligroso')
    es_animales = (
        not es_zack_d_films and
        contiene_palabra(texto_combinado, ["toro", "toros", "perro", "perros", "lobo", "lobos", "león", "leon", "leones", "caballo", "caballos", "gato", "gatos", "águila", "aguila", "oso", "osos", "fábula", "fabula", "fábulas", "animales"]) and
        (
            contiene_palabra(texto_combinado, ["fábula", "fabula", "fábulas", "reflexión", "reflexion", "lección", "leccion", "sabio", "moraleja", "humilde", "arrogante"]) or
            contiene_palabra(canal_principal.lower(), ["sabiduria", "eterna", "fabula", "reflexion"])
        )
    )

    # 6. Anime / Manga
    es_anime = contiene_palabra(texto_combinado, ["anime", "manga", "otaku", "shonen", "manhwa", "webtoon"])

    # 7. Cómic / Novela Gráfica
    es_comic_explicito = contiene_palabra(texto_combinado, ["comic", "novela gráfica", "novela grafica", "viñeta", "viñetas", "historieta", "bold line art", "ecos del alma"])

    # 8. Historias de Negocios y Finanzas
    es_finanzas = contiene_palabra(texto_combinado, ["dinero", "millonario", "negocio", "pobre", "deudas", "empresa", "éxito", "inversión", "inversiones"])

    # 1. Gaming / Roblox / 3D Cartoon (Ej: SoyGelo)
    if es_roblox_o_gaming:
        tipo_nicho = "Comedia y Animación en Bloques 3D (Estilo Roblox / Gaming)"
        estilo_id = "roblox_3d"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Bloque (Avatar estilo Roblox con traje marrón y corbata)"
        personaje_1_base = "Character reference portrait: A Roblox-style blocky cartoon avatar, modular cubic anatomy, brown combed hair on a cylindrical block head, simple painted smile decal face with big expressive cartoon eyes, wearing a brown blocky suit jacket with dark buttons, white collared shirt and green tie, rectangular gray block trousers, smooth plastic toy finish, bright room interior background"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['roblox_3d']['sufijo']}"

        personaje_2_desc = "Compañero / Segundo Personaje Bloque (Avatar casual con sudadera)"
        personaje_2_base = "Character reference portrait: A Roblox-style blocky cartoon avatar, modular cubic anatomy, cylindrical head with expressive facial decals, wearing a casual colorful hoodie and blocky denim pants, smooth plastic toy finish, bright room background"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['roblox_3d']['sufijo']}"

    # 2. Minecraft / Voxel
    elif es_minecraft:
        tipo_nicho = "Historias y Aventuras en Bloques (Minecraft / Voxel)"
        estilo_id = "minecraft_voxel"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Aventurero Cúbico (Estilo Minero Pixelado)"
        personaje_1_base = "Character reference portrait: A Minecraft-style blocky adventurer character, pixelated cubic head and body, wearing a classic blue shirt and dark blue pants, expressive pixel-art face, clean voxel geometry"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['minecraft_voxel']['sufijo']}"

        personaje_2_desc = "Aldeano / Compañero Cúbico"
        personaje_2_base = "Character reference portrait: A voxel-style cubic companion character in rustic brown robes, blocky geometry, soft volumetric ambient lighting"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['minecraft_voxel']['sufijo']}"

    # 3. Animación 3D Zack D. Films / Simulaciones y Curiosidades
    elif es_zack_d_films:
        tipo_nicho = "Curiosidades, Ciencia y Simulaciones 3D (Estilo Zack D. Films)"
        estilo_id = "zack_d_films"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista / Sujeto 3D (Joven explicador estilo Zack D. Films)"
        personaje_1_base = "Character reference portrait: A stylized 3D animated young man in signature Zack D. Films style, expressive curious face with big emotive eyes, short neat brown hair, wearing a casual vibrant blue t-shirt or hoodie, clean stylized anatomy, neutral educational studio backdrop, 3D CGI character portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['zack_d_films']['sufijo']}"

        personaje_2_desc = "Especialista / Demostrador 3D (Científico, Cirujano o Asistente)"
        personaje_2_base = "Character reference portrait: A stylized 3D animated secondary character / demonstrator in signature Zack D. Films style, wearing a clean professional lab coat or instructor uniform, holding scientific demonstration tools, expressive instructional posture, neutral educational background, 3D CGI character portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['zack_d_films']['sufijo']}"

    # 4. Secretos de la Industria / Curiosidades (Ojos de Lobo)
    elif es_ojos_de_lobo:
        tipo_nicho = "Secretos de la Industria, Curiosidades y Marketing Oculto"
        estilo_id = "dark_noir"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Joven curioso (El que pregunta en el gancho)"
        personaje_1_base = "Character reference portrait: A 25-year-old curious man with dark messy hair, observant eyes, wearing a dark oversized modern hoodie, expressive inquisitive face, neutral studio background, consistent character design"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['dark_noir']['sufijo']}"

        personaje_2_desc = "Figura Enigmática / El Mentor (El que revela el secreto)"
        personaje_2_base = "Character reference portrait: A 38-year-old charismatic man with short neat beard, piercing analytical gaze, wearing a minimalist black coat (or anthropomorphic stylish dark wolf in coat), mysterious knowing smirk, neutral studio background, consistent character design"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['dark_noir']['sufijo']}"

    # 4. Fábulas de Animales
    elif es_animales:
        tipo_nicho = "Fábulas de Animales y Reflexión Humana"
        estilo_id = "pixar_3d"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Animal Sabio / Noble (Trabajador humilde)"
        personaje_1_base = "Character reference sheet: An anthropomorphic noble bull / elderly craftsman with warm expressive eyes, wearing humble working clothes, dignified humble posture, clean character design portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

        personaje_2_desc = "Animal Antagonista (Arrogante o egoísta)"
        personaje_2_base = "Character reference sheet: An arrogant antagonist animal character with sharp condescending expression, wearing stylish expensive clothes, proud boastful posture, clean character design portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

    # 5. Anime / Manga
    elif es_anime:
        tipo_nicho = "Historias y Leyendas en Estilo Anime"
        estilo_id = "anime_moderno"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Shonen (Joven determinado)"
        personaje_1_base = "Character reference portrait: A young anime protagonist with determined sharp eyes, modern stylish jacket, clean anime character design"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['anime_moderno']['sufijo']}"

        personaje_2_desc = "Mentor o Rival Anime"
        personaje_2_base = "Character reference portrait: An experienced anime mentor with calm stoic expression, dark coat, dramatic anime rim lighting"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['anime_moderno']['sufijo']}"

    # 6. Cómic / Novela Gráfica (Solo cuando sea explícitamente cómic)
    elif es_comic_explicito:
        tipo_nicho = "Reflexión en Estilo Novela Gráfica (Cómic)"
        estilo_id = "comic"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Humilde (Línea Cómic)"
        personaje_1_base = "Character reference portrait: A gentle humble person with expressive emotional gaze, simple everyday clothing, clean character design portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['comic']['sufijo']}"

        personaje_2_desc = "Antagonista (Línea Cómic)"
        personaje_2_base = "Character reference portrait: A proud person in luxurious clothing, dismissive facial expression, clean character design portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['comic']['sufijo']}"

    # 7. Historias de Negocios y Finanzas
    elif es_finanzas:
        tipo_nicho = "Historias de Negocios y Finanzas Personales"
        estilo_id = "realismo_cinematografico"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "El Emprendedor Humilde"
        personaje_1_base = "Character reference portrait: A hardworking young entrepreneur in simple modest attire, focused determined expression, natural realistic textures"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

        personaje_2_desc = "El Inversor / Corporativo Arrogante"
        personaje_2_base = "Character reference portrait: A wealthy corporate executive in luxury tailored suit, smug cynical expression, realistic depth of field"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

    # 8. Fallback general: Realismo Cinematográfico (NUNCA cómic a menos que se solicite)
    else:
        tipo_nicho = "Reflexión Emocional y Lecciones de Vida"
        estilo_id = "realismo_cinematografico"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Humilde (Persona trabajadora y digna)"
        personaje_1_base = "Character reference portrait: A gentle humble person with expressive emotional gaze, simple everyday clothing, dignified natural posture"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

        personaje_2_desc = "Antagonista (Persona vanidosa o arrogante)"
        personaje_2_base = "Character reference portrait: A proud person in luxurious clothing, dismissive haughty facial expression, dramatic contrast"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

    estilo_sel = ESTILOS_VISUALES[estilo_id]

    score = 95
    puntos_fuertes = [
        "Voz en off y diálogos: Compatibles al 100% con la clonación y síntesis de voz.",
        "Visuales basados en escenas de alta retención: Se generan con Veo, Grok, Midjourney o Flow (~3 a 5s por toma).",
        "Formato y subtítulos: Compatible 100% con el creador y subtitulador dinámico del sistema."
    ]

    if formato_vert:
        puntos_fuertes.append("Formato vertical 9:16 (Reels/TikTok/Shorts): Máximo alcance y retención.")
    else:
        puntos_fuertes.append("Formato horizontal o historias largas: Excelente para monetización en Facebook/YouTube.")

    recomendaciones = [
        f"Estilo Visual: Mantén el sufijo '{estilo_sel['nombre']}' en todos tus prompts para darle una identidad de marca coherente a tu canal.",
        "Consistencia de Personajes: Genera primero la 'imagen madre' de tus 2 personajes y úsala como referencia visual (--cref) en cada escena.",
        "Gancho de inicio: Si usas la fórmula de diálogo, haz que los primeros 5 a 6 segundos planteen el conflicto o la pregunta clave de inmediato."
    ]

    ejemplos_guiones = []
    for v in validos:
        txt = v.get("guion") or v.get("descripcion") or v.get("titulo")
        if txt:
            ejemplos_guiones.append({
                "titulo": v.get("titulo", "Video"),
                "extracto": txt[:450].strip() + ("..." if len(txt) > 450 else ""),
                "vistas": v.get("vistas", 0)
            })

    # GUION MAESTRO 1: Voz en Off Continua (Predeterminado para ai33.pro)
    prompt_voz_en_off = f"""Actúa como un Guionista de Élite y Experto en Retención Viral para videos cortos (Shorts, Reels, TikTok) en el nicho: "{tipo_nicho}".
Quiero que crees 3 guiones virales de alta retención basados en la fórmula y estilo de "{canal_principal}".

REGLAS FUNDAMENTALES DE VOZ EN OFF (LOCUCIÓN CONTINUA):
1. NARRADOR ÚNICO (VOZ EN OFF): El guion es 100% narración continua de un solo locutor. PROHIBIDO incluir nombres de personajes, PROHIBIDO escribir "Narrador:", PROHIBIDO escribir "Personaje 1:", PROHIBIDO agregar acotaciones entre paréntesis o corchetes [como música, risas o efectos].
2. LECTURA DIRECTA PARA SINTETIZADOR TTS (ai33.pro): Cada palabra debe ser texto pronunciable en voz alta. Cero palabras de relleno o metadatos dentro de la locución.
3. INGENIERÍA DE RETENCIÓN VIRAL:
   - Segundo 0 a 4 (Gancho explosivo): Inicia de inmediato en las primeras 5 a 8 palabras con la premisa, dilema o curiosidad ("Aquí todos cometen este error...", "¿Sabías que...", "Esto parece imposible pero..."). Cero saludos ni rodeos.
   - Segundo 5 a 45 (Desarrollo dinámico): Oraciones cortas de ~4 segundos, ritmo continuo de alta tensión o intriga.
   - Segundo 45 a 60 (Desenlace y Cierre Viral): Revelación o moraleja rápida + Llamado a la acción para comentar una palabra clave en MAYÚSCULAS.
4. EXTENSIÓN: Entre 115 y 145 palabras por guion (~50 a 60 segundos hablados).

FORMATO ESTRICTO DE ENTREGA (TEXTO PLANO, SIN MARKDOWN, SIN NEGRITAS):
Entrega exactamente este formato para cada guion (solo GUION: número y abajo el texto del guion, sin fila de título):

GUION: 01
[Texto completo de la narración en voz en off continua del primer video]

GUION: 02
[Texto completo de la narración en voz en off continua del segundo video]

GUION: 03
[Texto completo de la narración en voz en off continua del tercer video]
"""

    # GUION MAESTRO 2: Historia Emocional o Curiosidad Zack D. Films
    if es_zack_d_films:
        prompt_historia = f"""Actúa como un guionista de élite experto en videos virales de curiosidades, ciencia y simulaciones 3D (estilo Zack D. Films, YouandAngel).
Quiero que crees 3 guiones originales de 45 a 65 segundos basados en la fórmula: "{tipo_nicho}".

ESTRUCTURA OBLIGATORIA DE CADA GUION (ALTA RETENCIÓN Y SIMULACIÓN 3D):
1. GANCHO EXPLOSIVO (0 a 4 segundos): Pregunta o premisa insólita en las primeras 5 a 8 palabras. Cero introducciones ni rodeos.
2. LA HIPÓTESIS / EL PROBLEMA (5 a 20 segundos): Planteamiento directo de cómo funciona o el peligro inminente con lenguaje sencillo y visual.
3. LA SIMULACIÓN VISUAL (20 a 45 segundos): Explicación paso a paso de lo que ocurre dentro del objeto o cuerpo, diseñada para representarse con simulación 3D dinámica.
4. LA REVELACIÓN / RESULTADO SORPRENDENTE (45 a 55 segundos): El desenlace fáctico real que subvierte la expectativa.
5. REMATE Y LLAMADO A LA ACCIÓN (55 a 60 segundos): Comenta INVENTO.

FORMATO ESTRICTO DE ENTREGA (TEXTO PLANO, SIN MARKDOWN, SIN NEGRITAS):
GUION: 01
[Texto completo de la narración en voz en off continua del primer video]

GUION: 02
[Texto completo de la narración en voz en off continua del segundo video]

GUION: 03
[Texto completo de la narración en voz en off continua del tercer video]
"""
    else:
        prompt_historia = f"""Actúa como un guionista profesional experto en videos virales de reflexión y fábulas.
Quiero que crees 3 guiones originales de alta retención basados en la fórmula: "{tipo_nicho}".

ESTRUCTURA OBLIGATORIA DE CADA GUION (VOZ EN OFF NARRATIVA):
1. GANCHO (0 a 4 segundos): Injusticia inicial o contraste flagrante en las primeras 5 a 8 palabras.
2. CONFLICTO / NUDO (5 a 35 segundos): El protagonista afronta la situación manteniendo su dignidad.
3. GIRO / JUSTICIA (35 a 50 segundos): Un acontecimiento pone a cada quien en su lugar.
4. MORALEJA (50 a 55 segundos): Frase memorable que sintetice la enseñanza.
5. LLAMADO A LA ACCIÓN (55 a 60 segundos): Una orden clara y emotiva (ej: "Comenta JUSTICIA").

FORMATO ESTRICTO DE ENTREGA (TEXTO PLANO, SIN MARKDOWN, SIN NEGRITAS):
GUION: 01
[Texto completo de la narración en voz en off continua del primer video]

GUION: 02
[Texto completo de la narración en voz en off continua del segundo video]

GUION: 03
[Texto completo de la narración en voz en off continua del tercer video]
"""

    # GUION MAESTRO 3: Diálogo de 2 Personajes (Opcional)
    prompt_dialogo = f"""Actúa como un guionista experto en videos virales de alta retención (TikTok, Instagram Reels, Shorts).
Quiero que crees 3 guiones originales basados en la fórmula de diálogo del nicho: "{tipo_nicho}".

ESTRUCTURA:
1. GANCHO DE DIÁLOGO (0 a 6 segundos): Dos personajes conversan frente a frente planteando el conflicto.
2. DESARROLLO NARRATIVO (7 a 50 segundos): Escenas dinámicas divididas en oraciones de ~4 segundos.
3. REMATE Y LLAMADO A LA ACCIÓN (50 a 60 segundos): Remate memorable y llamado a seguir el canal.

FORMATO ESTRICTO DE ENTREGA:
GUION: 01
[Texto del primer guion]

GUION: 02
[Texto del segundo guion]

GUION: 03
[Texto del tercer guion]
"""

    def _leer_instruccion(nombre_archivo: str) -> str:
        rutas = [
            Path(__file__).resolve().parent / "instrucciones_maestras" / nombre_archivo,
            Path(__file__).resolve().parent.parent / "Generador_Contenido" / "instrucciones_maestras" / nombre_archivo,
            Path(__file__).resolve().parent.parent / "Generador_Universal" / "instrucciones_maestras" / nombre_archivo
        ]
        for r in rutas:
            if r.is_file():
                try:
                    return r.read_text(encoding="utf-8")
                except Exception:
                    pass
        return ""

    base_shorts = _leer_instruccion("INSTRUCCION_MAESTRA_SHORTS.md")
    base_largos = _leer_instruccion("INSTRUCCION_MAESTRA_LARGOS.md")
    base_prompts = _leer_instruccion("INSTRUCCION_MAESTRA_PROMPTS.md")

    cabecera_shorts_voz_off = f"""# INSTRUCCIÓN MAESTRA ADAPTADA — GUIONES SHORTS PARA "{tipo_nicho.upper()}"
> **Canal de Referencia:** {canal_principal} | **Formato:** Narración Continua en Voz en Off (ai33.pro) | **Estilo Visual:** {estilo_sel['nombre']}

Actúa como un Guionista de Élite especializado en videos virales de alta retención para Facebook Reels, YouTube Shorts y TikTok.
Crea 3 guiones originales de 45 a 65 segundos basados en la fórmula exacta del canal "{canal_principal}" ({tipo_nicho}).

REGLAS OBLIGATORIAS DE VOZ EN OFF (UN SOLO NARRADOR CONTINUO):
1. CERO NOMBRES DE PERSONAJES: Todo el texto debe ser la narración leída por una sola voz. PROHIBIDO escribir "Narrador:", "Personaje 1:", "Voz en off:".
2. CERO ACOTACIONES NI CORCHETES: PROHIBIDO poner [música de fondo], (pausa dramática), [sonido de campana]. Cada palabra debe ser texto pronunciable para el sintetizador de voz ai33.pro.
3. GANCHO EN PRIMERAS 5-8 PALABRAS: El conflicto, curiosidad o paradoja arranca de golpe en el segundo 0. Cero saludos o presentaciones.
4. CIERRE CON COMPARTIR Y PALABRA CLAVE: Termina con una verdad moral o fáctica + invitación a comentar una sola PALABRA en MAYÚSCULAS.
5. LONGITUD: 115 a 145 palabras por guion (~50 a 60 segundos hablados).

FORMATO ESTRICTO DE ENTREGA (TEXTO PLANO, SIN MARKDOWN NI NEGRITAS):
Entrega exactamente este formato para cada guion (solo GUION: número y abajo el texto del guion, sin fila de título):

GUION: 01
[Texto completo de la narración en voz en off continua del primer video]

GUION: 02
[Texto completo de la narración en voz en off continua del segundo video]

GUION: 03
[Texto completo de la narración en voz en off continua del tercer video]

---
"""
    instruccion_shorts_voz_off = cabecera_shorts_voz_off + (base_shorts if base_shorts else prompt_voz_en_off)
    instruccion_shorts_historia = cabecera_shorts_voz_off + prompt_historia
    instruccion_shorts_dialogo = cabecera_shorts_voz_off + prompt_dialogo
    instruccion_shorts = instruccion_shorts_voz_off

    cabecera_largos = f"""# INSTRUCCIÓN MAESTRA ADAPTADA — GUIONES LARGOS PARA "{tipo_nicho.upper()}"
> **Canal de Referencia:** {canal_principal} | **Formato:** Multi-Acto / 6 Bloques | **Objetivo:** 4 a 10+ minutos (Alto RPM)

Actúa como un Dramaturgo Audiovisual y Maestro de Narrativa de Larga Duración para videos verticales (9:16) y horizontales.
Crea un guion completo de formato largo (4 a 8 minutos) para el nicho "{tipo_nicho}" basado en la fórmula de retención de "{canal_principal}".

MÉTRICA OBJETIVO: Máximo tiempo total reproducido y alto RPM, manteniendo la tensión dramática segundo a segundo sin relleno artificial.

FORMATO ESTRICTO DE ENTREGA (TEXTO PLANO PARA AI33.PRO):
GUION: 01
[Texto completo de la narración en voz en off continua de todo el video, listo para ai33.pro]

---
"""
    instruccion_largos = cabecera_largos + (base_largos if base_largos else "")

    cabecera_prompts = f"""# INSTRUCCIÓN MAESTRA ADAPTADA — PROMPTS DE IMAGEN Y MOVIMIENTO PARA "{tipo_nicho.upper()}"
> **Canal de Referencia:** {canal_principal} | **Estilo Visual:** {estilo_sel['nombre']}

Actúa como Director de Arte e Ingeniero de Prompts de IA para producción visual (Nano Banana, Midjourney, Grok, Veo 3.1, Flow Automation).
Genera los prompts de imagen, movimiento y sincronía temporal para el guion del nicho "{tipo_nicho}".

ESTILO VISUAL Y SUFIJOS:
- Sufijo para IMAGEN: {estilo_sel['sufijo']}
- Sufijo para MOVIMIENTO: {estilo_sel['sufijo_movimiento']}

PERSONAJES BASE (ADN INMUTABLE):
- Personaje 1 ({personaje_1_desc}): {personaje_1_prompt}
- Personaje 2 ({personaje_2_desc}): {personaje_2_prompt}

REGLA MAESTRA DE DIÁLOGOS Y LIP-SYNC:
- En MOVIMIENTO: speaking in Latin American Spanish, his/her mouth moving precisely to say "[LÍNEA EXACTA DEL GUION]"
- En IMAGEN: his/her mouth open speaking words, textless, without words.
- En EDICIÓN: La columna `cubre` en sincronia.txt es procesada por cortar_escenas.py (Whisper) para cortar la toma donde el diálogo termina.

REGLA ANTI-ALUCINACIÓN (VEO 3.1):
- Prohibido generar planos detalle aislados de "solo manos" o "solo objetos". Todo en Plano Medio (Medium Shot) con rostro y cuerpo visibles.

FORMATO DE ENTREGA OBLIGATORIO:
1. prompts_imagen.txt (prompts en inglés separados por exactamente una línea en blanco)
2. prompts_movimiento.txt (prompts en inglés con lip-sync, separados por una línea en blanco)
3. sincronia.txt (tabla con # | inicio-fin | dur | cubre)
4. prompt_portada.txt (miniatura híbrida: reacción en primer plano + acción de conflicto de fondo + título en blanco y rosa)

---
"""
    instruccion_prompts = cabecera_prompts + (base_prompts if base_prompts else "")

    prompt_activo = prompt_voz_en_off

    estilos_disponibles = [
        {
            "id": k,
            "nombre": v["nombre"],
            "sufijo": v["sufijo"],
            "sufijo_movimiento": v["sufijo_movimiento"],
            "descripcion": v["descripcion"]
        }
        for k, v in ESTILOS_VISUALES.items()
    ]

    return {
        "ok": True,
        "canal": canal_principal,
        "total_analizados": total_videos,
        "tipo_nicho": tipo_nicho,
        "formato": "Vertical (9:16)" if formato_vert else "Horizontal (16:9)",
        "duracion_promedio": f"{int(dur_prom//60)}m {int(dur_prom%60)}s" if dur_prom >= 60 else f"{int(dur_prom)}s",
        "score_replicabilidad": score,
        "veredicto": "TOTALMENTE REPLICABLE CON TU SISTEMA",
        "puntos_fuertes": puntos_fuertes,
        "recomendaciones": recomendaciones,
        "videos": validos,
        "ejemplos": ejemplos_guiones,
        "estilo_id": estilo_id,
        "estilos_disponibles": estilos_disponibles,
        # Identidad Visual y Prompts de Personajes
        "identidad_visual": {
            "estilo_id": estilo_id,
            "estilo_nombre": estilo_sel["nombre"],
            "sufijo_estilo": estilo_sel["sufijo"],
            "sufijo_movimiento": estilo_sel["sufijo_movimiento"],
            "descripcion": estilo_sel["descripcion"],
            "personaje_1_desc": personaje_1_desc,
            "personaje_1_base": personaje_1_base,
            "personaje_1_prompt": personaje_1_prompt,
            "personaje_2_desc": personaje_2_desc,
            "personaje_2_base": personaje_2_base,
            "personaje_2_prompt": personaje_2_prompt,
            "instruccion_consistencia": "Genera primero el retrato de cada personaje (imagen madre). Luego en Grok, Midjourney (--cref) o Veo, adjunta esa imagen como referencia visual para que mantenga exactamente el mismo rostro, peinado y ropa en todas las escenas del video."
        },
        "formula_recomendada": formula_recomendada,
        "prompt_maestro": prompt_activo,
        "prompt_voz_en_off": prompt_voz_en_off,
        "prompt_dialogo": prompt_dialogo,
        "prompt_historia": prompt_historia,
        # Las 3 Instrucciones Maestras Adaptadas
        "instruccion_shorts": instruccion_shorts,
        "instruccion_shorts_voz_off": instruccion_shorts_voz_off,
        "instruccion_shorts_historia": instruccion_shorts_historia,
        "instruccion_shorts_dialogo": instruccion_shorts_dialogo,
        "instruccion_largos": instruccion_largos,
        "instruccion_prompts": instruccion_prompts
    }


def analizar_enlaces(urls: list) -> dict:
    """Función principal llamada desde el backend: analiza una lista de URLs."""
    info_videos = []
    for u in urls:
        u_str = str(u).strip()
        if u_str and (u_str.startswith("http://") or u_str.startswith("https://")):
            info = extraer_info_url(u_str)
            if info:
                info_videos.append(info)

    if not info_videos:
        return {"ok": False, "msg": "No se encontraron URLs válidas para analizar."}

    return diagnosticar_nicho(info_videos)


if __name__ == "__main__":
    test_urls = [
        "https://www.youtube.com/shorts/auBCKkY4oK4"
    ]
    diag = analizar_enlaces(test_urls)
    print("Canal:", diag.get("canal"))
    print("Nicho:", diag.get("tipo_nicho"))
    print("Estilo visual detectado:", diag.get("identidad_visual", {}).get("estilo_nombre"))
    print("\nSufijo Estilo:\n", diag.get("identidad_visual", {}).get("sufijo_estilo"))
    print("\nPrompt Personaje 1:\n", diag.get("identidad_visual", {}).get("personaje_1_prompt"))
    print("\nPrompt Personaje 2:\n", diag.get("identidad_visual", {}).get("personaje_2_prompt"))
