"""
SISTEMA MAESTRO DE LICENCIAS MONOPUESTO Y PROTECCIÓN ANTIPIRATERÍA
Ecos del Alma & Redes Sociales © 2026 - David

Características:
1. Auto-activación directa en la máquina del cliente en el primer inicio.
2. Vinculación estricta de Hardware (Windows MachineGuid + BIOS/Placa + CPU).
3. Detección de duplicación: Si el cliente copia o revende la carpeta a otra PC,
   el sistema detecta el cambio de hardware y se bloquea automáticamente.
4. Notificación remota: Envía los datos de la máquina y comprador a David (Webhook/Google Sheets/Email).
5. Verificación remota / Killswitch (Google Drive / Google Sheets):
   Permite revocar o bloquear licencias a distancia.
6. Código protegido y ofuscable para el cliente.
"""

import os
import sys
import json
import hmac
import hashlib
import threading
import urllib.request
import urllib.parse
import subprocess
from pathlib import Path
from datetime import datetime

# =====================================================================
# CONFIGURACIÓN MAESTRA DE DAVID
# =====================================================================
_SALT_MAESTRO = b"ECOS_DEL_ALMA_DAVID_2026_UNIVERSAL_MASTER_KEY_SEC_99812"

# Códigos de compra o acceso válidos (puedes añadir o modificar según tus ventas)
CODIGOS_ACCESO_VALIDOS = ["ECOS-2026-VIP", "ECOS-UNIVERSAL", "DAVID-PRO-2026", "FLOW-AI-2026"]

# URL Webhook de Notificación (opcional pero muy recomendado):
# Puede ser un Google Apps Script Webhook (envía a Google Sheet + Email automático a David)
# o un Webhook de Formspree, Discord o Telegram.
WEBHOOK_NOTIFICACION_URL = "https://script.google.com/macros/s/AKfycbwxb06DcgNAYtQ3gnujF9MD4D8cDODq7HgdZ9CpJO-I7QFcz1GPKxRAQz6zhRsVEuqLAQ/exec"

# URL de Lista Remota de Control (Google Sheets CSV público o Google Drive JSON):
# Permite consultar remotamente si un cliente ha sido revocado o bloqueado.
URL_LISTA_REMOTA = ""

AQUI = Path(__file__).resolve().parent
ARCHIVO_LICENCIA = AQUI / "licencia.lic"
LOG_LOCAL_REGISTROS = AQUI / "licencias_registradas.json"


# =====================================================================
# EXTRACCIÓN DE IDENTIFICADOR DE HARDWARE ÚNICO
# =====================================================================
def obtener_machine_id() -> str:
    """
    Obtiene la huella digital única, persistente y no duplicable del hardware.
    Combina MachineGuid de Windows, UUID de la placa base y Processor ID de CPU.
    """
    componentes = []

    # 1. Windows MachineGuid (del registro de Windows)
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
            guid, _ = winreg.QueryValueEx(key, "MachineGuid")
            if guid:
                componentes.append(str(guid).strip().upper())
    except Exception:
        pass

    # 2. Motherboard / BIOS UUID
    try:
        out = subprocess.check_output("wmic csproduct get uuid", shell=True, text=True, stderr=subprocess.DEVNULL)
        lines = [l.strip() for l in out.splitlines() if l.strip() and "UUID" not in l.upper()]
        if lines and lines[0]:
            componentes.append(lines[0].upper())
    except Exception:
        pass

    # Fallback CIM si wmic falla
    if len(componentes) < 2:
        try:
            ps_cmd = "(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID"
            out = subprocess.check_output(["powershell", "-NoProfile", "-Command", ps_cmd], text=True, stderr=subprocess.DEVNULL)
            val = out.strip().upper()
            if val and val not in componentes:
                componentes.append(val)
        except Exception:
            pass

    # 3. CPU Processor ID
    try:
        ps_cpu = "(Get-CimInstance -ClassName Win32_Processor).ProcessorId"
        out_cpu = subprocess.check_output(["powershell", "-NoProfile", "-Command", ps_cpu], text=True, stderr=subprocess.DEVNULL)
        val_cpu = out_cpu.strip().upper()
        if val_cpu:
            componentes.append(val_cpu)
    except Exception:
        pass

    # 4. Fallback final
    if not componentes:
        import platform
        componentes.append(platform.node().upper())

    semilla = "|".join(componentes)
    h = hashlib.sha256(semilla.encode("utf-8")).hexdigest().upper()
    return f"ECOS-{h[0:4]}-{h[4:8]}-{h[8:12]}-{h[12:16]}"


def _calcular_firma(machine_id: str, email: str, cliente: str) -> str:
    """Calcula la firma criptográfica HMAC que asegura la autenticidad del archivo de licencia."""
    payload = f"{machine_id.strip().upper()}|{email.strip().lower()}|{cliente.strip()}".encode("utf-8")
    return hmac.new(_SALT_MAESTRO, payload, hashlib.sha256).hexdigest().upper()


# =====================================================================
# ENVÍO ASÍNCRONO DE NOTIFICACIONES A DAVID (WEBHOOK / EMAIL)
# =====================================================================
def _notificar_david_async(datos: dict):
    """Envía la notificación a David en segundo plano para no demorar al cliente."""
    def worker():
        # 1. Guardar siempre copia en el registro local
        try:
            registros = []
            if LOG_LOCAL_REGISTROS.is_file():
                try:
                    registros = json.loads(LOG_LOCAL_REGISTROS.read_text(encoding="utf-8"))
                except Exception:
                    registros = []
            registros.append(datos)
            LOG_LOCAL_REGISTROS.write_text(json.dumps(registros, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

        # 2. Enviar a Webhook remoto si está configurado y no es el placeholder
        if WEBHOOK_NOTIFICACION_URL and "script.google.com" in WEBHOOK_NOTIFICACION_URL and "placeholder" not in WEBHOOK_NOTIFICACION_URL:
            try:
                payload_json = json.dumps(datos).encode("utf-8")
                req = urllib.request.Request(
                    WEBHOOK_NOTIFICACION_URL,
                    data=payload_json,
                    headers={"Content-Type": "application/json", "User-Agent": "CreadorVideos-License/2.3.0"}
                )
                with urllib.request.urlopen(req, timeout=8) as resp:
                    pass
            except Exception:
                pass

    threading.Thread(target=worker, daemon=True).start()


def calcular_codigo_licencia_cliente(email: str, cliente: str) -> str:
    """Calcula el código de activación único basado en el nombre y correo del comprador."""
    e_limpio = (email or "").strip().lower()
    c_limpio = (cliente or "").strip().upper()
    payload = f"{e_limpio}|{c_limpio}".encode("utf-8")
    sig = hmac.new(_SALT_MAESTRO, payload, hashlib.sha256).hexdigest().upper()
    return f"ECOS-{sig[0:4]}-{sig[4:8]}-{sig[8:12]}-{sig[12:16]}"

# =====================================================================
# REGISTRO Y ACTIVACIÓN DIRECTA DESDE LA PC DEL CLIENTE
# =====================================================================
def registrar_licencia_cliente(email: str, cliente: str, codigo_acceso: str = "") -> tuple[bool, str]:
    """
    Registra y vincula de por vida el software a la máquina del cliente.
    Se ejecuta desde el sistema del cliente en su primera instalación.
    """
    e_limpio = (email or "").strip().lower()
    c_limpio = (cliente or "").strip()
    cod_limpio = (codigo_acceso or "").strip().upper()

    if not e_limpio or "@" not in e_limpio:
        return False, "Por favor ingresa un correo electrónico válido con el que realizaste tu compra."

    if not c_limpio:
        return False, "Por favor ingresa tu nombre o el nombre de tu canal."

    # Validación de código de licencia personalizado (asociado a Nombre + Correo)
    codigo_esperado = calcular_codigo_licencia_cliente(e_limpio, c_limpio)
    codigos_maestros = ["ECOS-2026-VIP", "DAVID-PRO-2026", "FLOW-AI-2026"]

    if cod_limpio != codigo_esperado and cod_limpio not in codigos_maestros:
        return False, "El Código de Licencia no coincide con el Nombre y Correo registrados. Por favor verifica tus datos de compra o contacta con el creador del sistema."

    mid_actual = obtener_machine_id()
    firma = _calcular_firma(mid_actual, e_limpio, c_limpio)
    ahora_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Obtener nombre de equipo
    import platform
    nombre_equipo = platform.node()

    payload = {
        "software": "Creador de Videos Universal",
        "version": "2.3.0",
        "cliente": c_limpio,
        "email": e_limpio,
        "codigo_acceso": cod_limpio,
        "machine_id_original": mid_actual,
        "fecha_activacion": ahora_str,
        "equipo_nombre": nombre_equipo,
        "firma": firma,
        "estado": "activa"
    }

    try:
        ARCHIVO_LICENCIA.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        return False, f"No se pudo guardar el archivo de licencia: {e}"

    # Notificar a David del nuevo cliente registrado
    _notificar_david_async({
        "evento": "NUEVA_LICENCIA_ACTIVADA",
        "cliente": c_limpio,
        "email": e_limpio,
        "codigo_acceso": cod_limpio,
        "machine_id": mid_actual,
        "fecha": ahora_str,
        "equipo": nombre_equipo,
        "software": "Creador de Videos Universal v2.3.0"
    })

    return True, f"¡Software registrado y activado con éxito para {c_limpio}! Este equipo ha quedado autorizado."


# =====================================================================
# VERIFICACIÓN DE LICENCIA (ANTI-COPIA & KILLSWITCH REMOTO)
# =====================================================================
def verificar_licencia() -> dict:
    """
    Verifica si el software está legalmente activado en el equipo actual.
    Detecta automáticamente si la carpeta fue copiada o revendida a otra computadora.
    """
    mid_actual = obtener_machine_id()

    if not ARCHIVO_LICENCIA.is_file():
        return {
            "valida": False,
            "machine_id": mid_actual,
            "cliente": "",
            "email": "",
            "motivo": "no_registrada",
            "msg": "Este software aún no ha sido registrado. Ingresa tus datos de compra para activarlo en este equipo."
        }

    try:
        datos = json.loads(ARCHIVO_LICENCIA.read_text(encoding="utf-8"))
        mid_original = datos.get("machine_id_original", "").strip().upper()
        cliente = datos.get("cliente", "").strip()
        email = datos.get("email", "").strip().lower()
        firma_guardada = datos.get("firma", "").strip().upper()

        # 1. Comprobación de Machine ID (Anti-Copia / Anti-Reventa)
        if mid_original != mid_actual:
            # Se detectó una copia no autorizada en otro equipo
            _notificar_david_async({
                "evento": "ALERTA_COPIA_NO_AUTORIZADA",
                "cliente": cliente,
                "email": email,
                "machine_id_original": mid_original,
                "machine_id_infractor": mid_actual,
                "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            return {
                "valida": False,
                "machine_id": mid_actual,
                "machine_id_original": mid_original,
                "cliente": cliente,
                "email": email,
                "motivo": "copia_no_autorizada",
                "msg": f"[ALERTA COPIA NO AUTORIZADA] Se detectó que este software fue activado originalmente en otro equipo ({mid_original}). Esta copia está vinculada exclusivamente a esa máquina. Para usarlo en este nuevo equipo, contacta con el creador del sistema."
            }

        # 2. Comprobación de Firma Criptográfica (Anti-Manipulación del archivo)
        firma_esperada = _calcular_firma(mid_original, email, cliente)
        if firma_guardada != firma_esperada:
            return {
                "valida": False,
                "machine_id": mid_actual,
                "cliente": cliente,
                "email": email,
                "motivo": "archivo_adulterado",
                "msg": "El archivo de licencia ha sido modificado o está corrupto. Vuelve a registrar tu software con tus datos originales."
            }

        # 3. Comprobación Remota / Killswitch (si hay URL de control y conexión a internet)
        if URL_LISTA_REMOTA:
            try:
                req = urllib.request.Request(URL_LISTA_REMOTA, headers={"User-Agent": "LicenseCheck"})
                with urllib.request.urlopen(req, timeout=3) as resp:
                    contenido_remoto = resp.read().decode("utf-8", errors="ignore")
                    if f"{email}:bloqueado" in contenido_remoto.lower() or f"{mid_actual}:bloqueado" in contenido_remoto.lower():
                        return {
                            "valida": False,
                            "machine_id": mid_actual,
                            "cliente": cliente,
                            "email": email,
                            "motivo": "licencia_revocada",
                            "msg": "Esta licencia ha sido suspendida o revocada por el administrador. Contacta a soporte oficial."
                        }
            except Exception:
                pass

        return {
            "valida": True,
            "machine_id": mid_actual,
            "cliente": cliente or "Cliente Oficial",
            "email": email,
            "fecha_activacion": datos.get("fecha_activacion", ""),
            "motivo": "ok",
            "msg": f"Licencia oficial activa para {cliente}."
        }

    except Exception as e:
        return {
            "valida": False,
            "machine_id": mid_actual,
            "cliente": "",
            "email": "",
            "motivo": f"error_lectura: {str(e)}",
            "msg": f"Error leyendo archivo de licencia: {e}"
        }


if __name__ == "__main__":
    st = verificar_licencia()
    print("=" * 65)
    print("  ESTADO DE LICENCIA MONOPUESTO")
    print("=" * 65)
    print(f"  Machine ID actual : {st.get('machine_id')}")
    print(f"  Estado            : {'VALIDA' if st.get('valida') else 'BLOQUEADA / NO ACTIVADA'}")
    print(f"  Cliente           : {st.get('cliente', '-')}")
    print(f"  Email             : {st.get('email', '-')}")
    print(f"  Motivo            : {st.get('motivo')}")
    print(f"  Mensaje           : {st.get('msg')}")
    print("=" * 65)
