# REGLA: SOPORTE DE EMERGENCIA Y CLIENTE EN ESPERA

Cuando el usuario mencione "cliente", "urgencia", "soporte", "rápido" o frustración por demoras:
1. NO escanear carpetas ni correr diagnósticos globales.
2. NO lanzar tareas pesadas en segundo plano.
3. Ir en 1 sola llamada al archivo puntual, eliminar el bloqueo o aplicar la corrección mínima y responder en menos de 1 minuto.
4. Si algo reciente se rompió, revertir con git (`git checkout -- <archivo>`) antes de acumular errores.
5. El único objetivo es dejar al usuario o cliente trabajando de inmediato.
