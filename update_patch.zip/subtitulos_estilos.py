# -*- coding: utf-8 -*-
"""
subtitulos_estilos.py
---------------------
Catálogo de Estilos de Subtítulos Dinámicos e Instalador de Fuentes.
Permite seleccionar presets idénticos a los canales virales (CapCut Karaoke,
TikTok Amarillo/Ojos de Lobo, Verde Finanzas, Blanco Minimal, etc.)
e instala la fuente Melvins One automáticamente en Windows para CapCut.
"""

import os
import shutil
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent

# Presets de estilos visuales de subtítulos
ESTILOS_SUBTITULOS = {
    "capcut_karaoke": {
        "id": "capcut_karaoke",
        "nombre": "CapCut Karaoke (Caja Rosa/Roja #ff0050)",
        "fuente": "MelvinsoneRegular-d9mvR.otf",
        "fuente_nombre": "Melvins One",
        "font_size": 54,
        "box_color": (255, 0, 80, 255),       # #ff0050
        "text_color": (255, 255, 255, 255),   # Blanco
        "stroke_color": (0, 0, 0, 255),       # Negro
        "stroke_width": 3,
        "box_radius": 12,
        "pad_x": 12,
        "pad_top": 8,
        "pad_bottom": 6,
        "con_caja": True,
        "descripcion": "El clásico estilo viral de historias y reflexiones emocionales. Resalta palabra por palabra con caja redondeada vibrante."
    },
    "tiktok_amarillo": {
        "id": "tiktok_amarillo",
        "nombre": "TikTok Viral Amarillo (Estilo Ojos de Lobo)",
        "fuente": "MelvinsoneRegular-d9mvR.otf",
        "fuente_nombre": "Melvins One",
        "font_size": 54,
        "box_color": (255, 220, 0, 255),      # Amarillo intenso #ffdc00
        "text_color": (0, 0, 0, 255),         # Texto negro de alto contraste
        "stroke_color": (255, 255, 255, 255), # Borde blanco
        "stroke_width": 1,
        "box_radius": 12,
        "pad_x": 12,
        "pad_top": 8,
        "pad_bottom": 6,
        "con_caja": True,
        "descripcion": "Ideal para misterio, curiosidades y secretos. Resalta en amarillo brillante con texto oscuro de máximo impacto visual."
    },
    "verde_neon": {
        "id": "verde_neon",
        "nombre": "Verde Neón (Finanzas, Dinero y Negocios)",
        "fuente": "MelvinsoneRegular-d9mvR.otf",
        "fuente_nombre": "Melvins One",
        "font_size": 54,
        "box_color": (16, 185, 129, 255),     # Verde esmeralda #10b981
        "text_color": (255, 255, 255, 255),   # Blanco
        "stroke_color": (0, 0, 0, 255),       # Negro
        "stroke_width": 3,
        "box_radius": 12,
        "pad_x": 12,
        "pad_top": 8,
        "pad_bottom": 6,
        "con_caja": True,
        "descripcion": "Especialmente efectivo en contenido de educación financiera, emprendimiento, éxito y temas monetarios."
    },
    "azul_electrico": {
        "id": "azul_electrico",
        "nombre": "Azul Eléctrico (Misterio y Psicología)",
        "fuente": "MelvinsoneRegular-d9mvR.otf",
        "fuente_nombre": "Melvins One",
        "font_size": 54,
        "box_color": (14, 165, 233, 255),     # Sky Blue #0ea5e9
        "text_color": (255, 255, 255, 255),   # Blanco
        "stroke_color": (0, 0, 0, 255),       # Negro
        "stroke_width": 3,
        "box_radius": 12,
        "pad_x": 12,
        "pad_top": 8,
        "pad_bottom": 6,
        "con_caja": True,
        "descripcion": "Perfecto para psicología, filosofía, tecnología e intriga."
    },
    "blanco_minimal": {
        "id": "blanco_minimal",
        "nombre": "Blanco Cinematográfico (Sin Caja, Borde Grueso)",
        "fuente": "MelvinsoneRegular-d9mvR.otf",
        "fuente_nombre": "Melvins One",
        "font_size": 56,
        "box_color": (0, 0, 0, 0),             # Transparente
        "text_color": (255, 255, 255, 255),   # Blanco puro
        "stroke_color": (0, 0, 0, 255),       # Borde negro sólido
        "stroke_width": 5,
        "box_radius": 0,
        "pad_x": 0,
        "pad_top": 0,
        "pad_bottom": 0,
        "con_caja": False,
        "descripcion": "Estética limpia y elegante tipo documental de Netflix o cine. Sin caja de color, máxima legibilidad sobre cualquier fondo."
    }
}


def resolver_ruta_fuente(nombre_fuente: str = "MelvinsoneRegular-d9mvR.otf") -> Path:
    """Busca la fuente en carpetas locales antes de recurrir a fuentes del sistema."""
    candidatos = [
        AQUI / "fonts" / nombre_fuente,
        AQUI / "ecos" / "fonts" / nombre_fuente,
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts" / nombre_fuente,
        Path(r"C:\Windows\Fonts") / nombre_fuente
    ]
    for c in candidatos:
        if c.is_file():
            return c
    return AQUI / "fonts" / nombre_fuente


def instalar_fuente_en_windows(nombre_fuente: str = "MelvinsoneRegular-d9mvR.otf") -> dict:
    """
    Instala la fuente en el perfil del usuario de Windows sin requerir permisos de administrador.
    Esto permite que CapCut, Premiere, Photoshop y cualquier app de Windows la use de inmediato.
    """
    origen = resolver_ruta_fuente(nombre_fuente)
    if not origen.is_file():
        # Buscar en ecos/fonts
        alt = AQUI / "ecos" / "fonts" / nombre_fuente
        if alt.is_file():
            origen = alt
        else:
            return {"ok": False, "msg": f"Archivo de fuente no encontrado: {nombre_fuente}"}

    local_fonts = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts"
    local_fonts.mkdir(parents=True, exist_ok=True)
    destino = local_fonts / origen.name

    ya_existia = destino.exists()
    if not ya_existia:
        try:
            shutil.copy2(origen, destino)
        except Exception as e:
            # Si el archivo está bloqueado es porque ya está cargado por el sistema
            pass

    # Registrar en HKCU (Registro de Windows para el usuario actual, sin elevación)
    reg_ok = False
    try:
        import winreg
        key_path = r"Software\Microsoft\Windows NT\CurrentVersion\Fonts"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, f"Melvins One (TrueType)", 0, winreg.REG_SZ, str(destino))
        reg_ok = True
    except Exception as e:
        pass

    return {
        "ok": True,
        "msg": "Fuente 'Melvins One' instalada y registrada con éxito en Windows (lista para CapCut y el sistema).",
        "ruta": str(destino),
        "registrada": reg_ok or ya_existia
    }


def obtener_estilo(estilo_id: str = "capcut_karaoke") -> dict:
    """Retorna la configuración completa del estilo de subtítulo."""
    return ESTILOS_SUBTITULOS.get(estilo_id, ESTILOS_SUBTITULOS["capcut_karaoke"])


def listar_estilos() -> list:
    """Retorna la lista de estilos disponibles para el frontend."""
    return [
        {
            "id": v["id"],
            "nombre": v["nombre"],
            "fuente_nombre": v["fuente_nombre"],
            "con_caja": v["con_caja"],
            "descripcion": v["descripcion"]
        }
        for v in ESTILOS_SUBTITULOS.values()
    ]
