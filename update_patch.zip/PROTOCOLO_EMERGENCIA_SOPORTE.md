# PROTOCOLO DE EMERGENCIA Y SOPORTE EN VIVO (REGLA DE ORO)

> **ESTADO:** OBLIGATORIO Y VINCULANTE PARA EL ASISTENTE DE IA.
> **ÁMBITO:** Aplica automáticamente ante cualquier mención de "cliente", "urgente", "soporte", "rápido" o frustración del usuario por demoras.

---

## 1. ACTIVACIÓN AUTOMÁTICA
Este protocolo se activa de forma inmediata y sin requerir confirmación cuando:
- El usuario menciona que está con un **cliente** (llamada, chat, AnyDesk o soporte).
- El usuario pide resolver algo de **urgencia**, pide **quitar una condición**, o expresa molestia por demoras.
- Hay un fallo bloqueante en producción que impide que el usuario o cliente continúe su trabajo.

---

## 2. REGLAS INQUEBRANTABLES DE EJECUCIÓN

### Regla 1: Acción Quirúrgica (Máximo 1 o 2 llamadas de herramienta)
- **PROHIBIDO:** Ejecutar escaneos de todo el proyecto, búsquedas globales recursivas lentas o auditorías no solicitadas.
- **PROHIBIDO:** Iniciar tareas pesadas de fondo o empaquetamientos si no fueron explícitamente pedidos.
- **OBLIGATORIO:** Ir directamente al archivo y línea exacta del problema (`panel.py`, `gestor_nichos.py`, etc.), aplicar la edición precisa (`edit_file`) y responder de inmediato.

### Regla 2: Desbloquear Primero, Pulir Después
- Si una condición (licencia, validación, verificación) está trabando al cliente, **se elimina o desactiva de inmediato**.
- No se intenta "arreglar toda la arquitectura" en medio de la emergencia. El objetivo número 1 es que el cliente pueda dar clic y avanzar.
- Cualquier refinamiento estructural se posterga para cuando el cliente ya no esté en línea.

### Regla 3: Uso de Git para Reversión Rápida
- Si una edición reciente rompió algo que antes funcionaba, no se improvisan parches sobre parches: se recurre al estado limpio anterior de Git para ese archivo específico (`git checkout -- <archivo>`) y se aplica únicamente el cambio mínimo necesario.

### Regla 4: Aislamiento Absoluto de Módulos
- Si la petición es sobre **crear nichos**, NO se toca el generador de audios, ni los prompts, ni los subtítulos.
- Si la petición es sobre **audios**, NO se tocan los nichos ni la interfaz general.
- Cero efectos colaterales.

---

## 3. CHECKLIST DE RESPUESTA EN EMERGENCIA
1. Identificar el archivo exacto y la función causante.
2. Quitar el bloqueo o aplicar la corrección directa.
3. Confirmar en 2 líneas claras qué se hizo y que ya pueden probar.
