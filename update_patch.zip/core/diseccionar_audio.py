# -*- coding: utf-8 -*-
"""
diseccionar_audio.py
--------------------
Diseccionador Profesional de Audio de Videos Virales.
Separa y extrae:
1. Muestra limpia de voz en off (máximo 29.5s) sin música para clonación en ai33.pro o cualquier TTS.
2. Música de fondo aislada (sin voz) para usar como fondo en la edición.
3. Efectos de sonido y marcadores de atmósfera.
Incluye soporte resiliente cuando FFmpeg no está instalado en Windows.
"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

AQUI = Path(__file__).resolve().parent

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def run_cmd(cmd, timeout=120):
    """Ejecuta un comando en subproceso con timeout y captura de errores."""
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)


def detectar_ffmpeg():
    """Busca el binario ffmpeg en PATH y rutas habituales de Windows."""
    p = shutil.which("ffmpeg")
    if p:
        return p
    rutas_candidatas = [
        AQUI / "bin" / "ffmpeg.exe",
        AQUI.parent / "bin" / "ffmpeg.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet" / "Packages",
        Path("C:/ffmpeg/bin/ffmpeg.exe"),
        Path(os.environ.get("PROGRAMFILES", "")) / "ffmpeg" / "bin" / "ffmpeg.exe"
    ]
    for r in rutas_candidatas:
        if r.is_file():
            return str(r)
        if r.is_dir():
            for f in r.rglob("ffmpeg.exe"):
                if f.is_file():
                    return str(f)
    return None


def detectar_ffprobe():
    """Busca ffprobe en PATH o junto al ejecutable de ffmpeg."""
    p = shutil.which("ffprobe")
    if p:
        return p
    ff = detectar_ffmpeg()
    if ff:
        cand = Path(ff).parent / "ffprobe.exe"
        if cand.is_file():
            return str(cand)
    return None


def ffprobe_dur(audio_path: str) -> float:
    """Devuelve la duración exacta de un archivo de audio en segundos."""
    probe = detectar_ffprobe()
    if not probe:
        return 0.0
    cmd = [
        probe, "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)
    ]
    try:
        res = run_cmd(cmd, timeout=15)
        return float(res.stdout.strip())
    except Exception:
        return 0.0


def extraer_audio_fuente(fuente: str, carpeta_salida: Path) -> Path:
    """Extrae el audio de una URL con yt-dlp o de un archivo local de video con ffmpeg."""
    carpeta_salida.mkdir(parents=True, exist_ok=True)
    audio_completo = carpeta_salida / "audio_original.mp3"

    ff_exe = detectar_ffmpeg()
    if ff_exe:
        dir_ff = str(Path(ff_exe).parent)
        if dir_ff not in os.environ.get("PATH", ""):
            os.environ["PATH"] = dir_ff + os.pathsep + os.environ.get("PATH", "")

    fuente_str = str(fuente).strip()
    if fuente_str.startswith("http://") or fuente_str.startswith("https://"):
        # Verificación ultrarrápida: Reusar video o audio si ya fue descargado en el análisis de nicho
        import hashlib
        url_hash = hashlib.md5(fuente_str.encode("utf-8")).hexdigest()[:10]
        dir_cache = Path(tempfile.gettempdir()) / "nexor_diseccion" / url_hash
        if dir_cache.is_dir():
            cand_audio = dir_cache / "audio.wav"
            cand_video = dir_cache / "muestra.mp4"
            if cand_audio.is_file() and cand_audio.stat().st_size > 5000:
                print(f"  Reusando audio previamente descargado en caché: {cand_audio.name}", flush=True)
                if ff_exe:
                    cmd_c = [ff_exe, "-y", "-i", str(cand_audio), "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k", str(audio_completo)]
                    run_cmd(cmd_c, timeout=15)
                    if audio_completo.is_file() and audio_completo.stat().st_size > 1000:
                        return audio_completo
                dest_w = carpeta_salida / "audio_original.wav"
                shutil.copy2(cand_audio, dest_w)
                return dest_w
            elif cand_video.is_file() and cand_video.stat().st_size > 50000:
                print(f"  Extrayendo audio de video en caché: {cand_video.name}", flush=True)
                if ff_exe:
                    cmd_c = [ff_exe, "-y", "-i", str(cand_video), "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k", str(audio_completo)]
                    run_cmd(cmd_c, timeout=15)
                    if audio_completo.is_file() and audio_completo.stat().st_size > 1000:
                        return audio_completo

        print(f"  Descargando audio de URL: {fuente_str[:60]}...", flush=True)
        if ff_exe:
            cmd = [
                sys.executable, "-m", "yt_dlp",
                "--ffmpeg-location", str(Path(ff_exe).parent),
                "-x", "--audio-format", "mp3",
                "--audio-quality", "0",
                "--no-warnings",
                "-o", str(carpeta_salida / "%(id)s.%(ext)s"),
                fuente_str
            ]
        else:
            print("  [INFO] Descargando flujo de audio directo (sin FFmpeg)...", flush=True)
            cmd = [
                sys.executable, "-m", "yt_dlp",
                "-f", "ba/b",
                "--no-warnings",
                "-o", str(carpeta_salida / "%(id)s.%(ext)s"),
                fuente_str
            ]

        res = run_cmd(cmd, timeout=60)
        archivos = [p for p in carpeta_salida.glob("*.*") if p.suffix.lower() in (".mp3", ".webm", ".m4a", ".aac", ".ogg", ".wav", ".opus")]
        if archivos:
            orig = archivos[0]
            if orig.suffix.lower() == ".mp3":
                if orig != audio_completo:
                    shutil.move(str(orig), str(audio_completo))
                return audio_completo
            elif ff_exe:
                cmd_c = [ff_exe, "-y", "-i", str(orig), "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k", str(audio_completo)]
                run_cmd(cmd_c, timeout=30)
                if audio_completo.is_file() and audio_completo.stat().st_size > 1000:
                    try:
                        orig.unlink()
                    except Exception:
                        pass
                    return audio_completo
            dest_nativo = carpeta_salida / f"audio_original{orig.suffix.lower()}"
            if orig != dest_nativo:
                shutil.move(str(orig), str(dest_nativo))
            return dest_nativo
        raise RuntimeError(f"yt-dlp no generó archivo de audio: {res.stderr[:200]}")
    else:
        p_local = Path(fuente_str).resolve()
        if not p_local.is_file():
            raise FileNotFoundError(f"El archivo fuente no existe: {fuente_str}")
        print(f"  Extrayendo audio de archivo local: {p_local.name}...", flush=True)
        if not ff_exe:
            return p_local
        cmd = [
            ff_exe, "-y", "-i", str(p_local),
            "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
            str(audio_completo)
        ]
        res = run_cmd(cmd, timeout=45)
        if not audio_completo.is_file() or audio_completo.stat().st_size < 1000:
            raise RuntimeError(f"Error extrayendo audio con ffmpeg: {res.stderr[:200]}")
        return audio_completo


def detectar_segmento_voz_optimo(audio_path: Path, max_dur: float = 29.5, min_dur: float = 14.0) -> tuple:
    """
    Usa faster-whisper para identificar dónde habla la voz en off de forma continua
    y selecciona el mejor segmento de duración <= max_dur segundos.
    Devuelve (inicio_segundos, duracion_segundos, texto_transcrito).
    """
    dur_total = ffprobe_dur(str(audio_path))
    if dur_total <= 0:
        return 0.0, min(29.0, dur_total if dur_total > 0 else 29.0), ""

    if dur_total <= max_dur:
        return 0.0, dur_total, ""

    try:
        from faster_whisper import WhisperModel
        print("  Analizando marcas de voz en off con faster-whisper...", flush=True)
        model = WhisperModel("base", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(str(audio_path), language="es", vad_filter=True)
        seg_list = list(segments)
    except Exception as e:
        print(f"  Aviso: Whisper no disponible ({e}), usando segmento central por defecto.")
        inicio = max(2.0, (dur_total - max_dur) / 2.0)
        return inicio, max_dur, ""

    if not seg_list:
        inicio = max(2.0, (dur_total - max_dur) / 2.0)
        return inicio, max_dur, ""

    mejor_inicio = seg_list[0].start
    mejor_dur = min(max_dur, dur_total)
    mejor_texto = ""
    mejor_densidad = 0.0

    for i in range(len(seg_list)):
        t_ini = seg_list[i].start
        t_fin = seg_list[i].end
        txt_acum = [seg_list[i].text]
        for j in range(i + 1, len(seg_list)):
            cand_fin = seg_list[j].end
            if (cand_fin - t_ini) > max_dur:
                break
            t_fin = cand_fin
            txt_acum.append(seg_list[j].text)

        dur_ventana = t_fin - t_ini
        palabras = sum(len(t.split()) for t in txt_acum)
        densidad = palabras / dur_ventana if dur_ventana > 0 else 0

        if min_dur <= dur_ventana <= max_dur and densidad > mejor_densidad:
            mejor_densidad = densidad
            mejor_inicio = t_ini
            mejor_dur = dur_ventana
            mejor_texto = " ".join(txt_acum).strip()

    mejor_dur = min(mejor_dur, max_dur)
    if mejor_inicio + mejor_dur > dur_total:
        mejor_inicio = max(0.0, dur_total - mejor_dur)

    return round(mejor_inicio, 2), round(mejor_dur, 2), mejor_texto


def aislar_stems_demucs(audio_snippet: Path, carpeta_trabajo: Path) -> dict:
    """
    Ejecuta Demucs con '--two-stems vocals' sobre el snippet de audio.
    Genera vocals.mp3 (voz pura sin música) y no_vocals.mp3 (música pura sin voz).
    """
    print("  Separando voz y música con Demucs AI (htdemucs)...", flush=True)
    out_dir = carpeta_trabajo / "demucs_stems"
    cmd = [
        sys.executable, "-m", "demucs",
        "--two-stems", "vocals",
        "--mp3",
        "-d", "cpu",
        "-o", str(out_dir),
        str(audio_snippet)
    ]
    t0 = time.time()
    try:
        res = run_cmd(cmd, timeout=75)
        print(f"  Demucs finalizado en {time.time()-t0:.1f}s (código: {res.returncode})", flush=True)
    except subprocess.TimeoutExpired:
        print(f"  Aviso: Demucs superó el tiempo máximo de 75s en CPU. Usando muestra directa filtrada.", flush=True)
        return {"ok": False, "vocals": None, "no_vocals": None, "log": "Timeout Demucs 75s"}
    except Exception as e:
        print(f"  Aviso: Excepción en Demucs: {e}", flush=True)
        return {"ok": False, "vocals": None, "no_vocals": None, "log": str(e)}

    vocals_file = None
    no_vocals_file = None
    for p in out_dir.rglob("*.mp3"):
        if "vocals" in p.name.lower() and "no_vocals" not in p.name.lower():
            vocals_file = p
        elif "no_vocals" in p.name.lower():
            no_vocals_file = p

    return {
        "ok": bool(vocals_file and vocals_file.is_file()),
        "vocals": vocals_file,
        "no_vocals": no_vocals_file,
        "log": res.stderr[:300] if res.returncode != 0 else ""
    }


def masterizar_muestra_clonacion(vocals_raw: Path, salida_final: Path, max_dur: float = 29.5) -> Path:
    """
    Aplica normalización, corte exacto <= 29.5s y micro-fades para que el archivo
    sea 100% aceptado por ai33.pro, MiniMax y ElevenLabs sin errores de duración.
    """
    ff_exe = detectar_ffmpeg() or "ffmpeg"
    dur_real = ffprobe_dur(str(vocals_raw))
    dur_corte = min(dur_real, max_dur - 0.1) if dur_real > 0 else (max_dur - 0.2)
    dur_corte = round(dur_corte, 2)

    fade_out_st = max(0.5, dur_corte - 0.25)
    filtro = f"afade=t=in:ss=0:d=0.15,afade=t=out:st={fade_out_st:.2f}:d=0.20,loudnorm=I=-16:TP=-1.0:LRA=11"

    cmd = [
        ff_exe, "-y", "-i", str(vocals_raw),
        "-t", str(dur_corte),
        "-af", filtro,
        "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(salida_final)
    ]
    run_cmd(cmd, timeout=30)
    return salida_final


def masterizar_musica_fondo(no_vocals_raw: Path, salida_final: Path) -> Path:
    """
    Normaliza la música de fondo a -22 LUFS para que al colocarse en la edición
    quede a un volumen agradable de fondo sin tapar la voz del nuevo narrador.
    """
    ff_exe = detectar_ffmpeg() or "ffmpeg"
    cmd = [
        ff_exe, "-y", "-i", str(no_vocals_raw),
        "-af", "loudnorm=I=-22:TP=-2.0:LRA=14",
        "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(salida_final)
    ]
    run_cmd(cmd, timeout=30)
    return salida_final


def diseccionar_video_para_proyecto(fuente: str, carpeta_destino: Path) -> dict:
    """
    Función Principal:
    Procesa el video o URL, separa los stems, produce la muestra para clonar (<=29.5s)
    y la música de fondo, dejándolos listos en 'carpeta_destino/audio_referencia/'.
    Si FFmpeg no está disponible en el equipo del usuario, guarda el audio original
    de referencia con 100% de tolerancia y sin generar errores.
    """
    carpeta_destino = Path(carpeta_destino).resolve()
    dir_audio = carpeta_destino / "audio_referencia"
    dir_audio.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="diseccion_") as tmp_dir:
        tmp_path = Path(tmp_dir)

        # 1. Extraer audio original
        audio_orig = extraer_audio_fuente(fuente, tmp_path)
        ff_exe = detectar_ffmpeg()

        # Si FFmpeg no está disponible o el audio es nativo sin conversión, guardar audio de referencia
        if not ff_exe or audio_orig.suffix.lower() != ".mp3":
            ext = audio_orig.suffix.lower() or ".mp3"
            out_audio = dir_audio / f"audio_original_referencia{ext}"
            if audio_orig.is_file():
                shutil.copy2(audio_orig, out_audio)

            reporte = {
                "ok": True,
                "sin_ffmpeg": True,
                "muestra_voz": str(out_audio),
                "muestra_voz_nombre": out_audio.name,
                "duracion_muestra": 0,
                "duracion_fmt": "Audio completo",
                "musica_fondo": "",
                "musica_fondo_nombre": "",
                "audio_original": str(out_audio),
                "transcripcion_muestra": "",
                "instrucciones_clonacion": (
                    f"Se descargó el audio de referencia original '{out_audio.name}'. "
                    "Puedes escucharlo o subirlo directamente a ai33.pro para clonar la voz del canal. "
                    "(Opcional: Si deseas que el sistema recorte los 29s y separe la música automáticamente con IA, puedes instalar FFmpeg)."
                )
            }
            with open(dir_audio / "reporte_diseccion.json", "w", encoding="utf-8") as f:
                json.dump(reporte, f, ensure_ascii=False, indent=2)
            return reporte

        # 2. Con FFmpeg disponible: Detectar el segmento óptimo de narración (<= 29.5s)
        t_ini, dur_seg, transcripcion = detectar_segmento_voz_optimo(audio_orig, max_dur=29.5)
        print(f"  Segmento seleccionado para clonación: {t_ini}s a {t_ini+dur_seg}s ({dur_seg}s)", flush=True)

        # 3. Recortar ese segmento para procesar con Demucs rápidamente
        snippet_raw = tmp_path / "snippet_para_demucs.mp3"
        cmd_cut = [
            ff_exe, "-y", "-ss", str(t_ini), "-t", str(dur_seg),
            "-i", str(audio_orig),
            "-ar", "44100", "-ac", "2", "-b:a", "192k",
            str(snippet_raw)
        ]
        run_cmd(cmd_cut, timeout=20)

        # 4. Separación Demucs
        stems = aislar_stems_demucs(snippet_raw, tmp_path)

        # Salidas finales en la carpeta del proyecto
        out_voz_clonacion = dir_audio / "muestra_voz_clonacion_29s.mp3"
        out_musica_fondo = dir_audio / "musica_fondo.mp3"
        out_audio_completo = dir_audio / "audio_original_completo.mp3"

        if audio_orig.is_file():
            shutil.copy2(audio_orig, out_audio_completo)

        if stems.get("ok") and stems.get("vocals"):
            masterizar_muestra_clonacion(stems["vocals"], out_voz_clonacion, max_dur=29.5)
            if stems.get("no_vocals"):
                masterizar_musica_fondo(stems["no_vocals"], out_musica_fondo)
        else:
            print("  Aviso: Demucs no devolvió stems, usando recorte directo filtrado.", flush=True)
            cmd_fallback = [
                ff_exe, "-y", "-i", str(snippet_raw),
                "-af", "highpass=f=120,lowpass=f=6000,loudnorm=I=-16:TP=-1.0",
                str(out_voz_clonacion)
            ]
            run_cmd(cmd_fallback, timeout=20)

        dur_final_voz = ffprobe_dur(str(out_voz_clonacion))

        reporte = {
            "ok": True,
            "muestra_voz": str(out_voz_clonacion),
            "muestra_voz_nombre": out_voz_clonacion.name,
            "duracion_muestra": dur_final_voz,
            "duracion_fmt": f"{dur_final_voz:.1f}s",
            "musica_fondo": str(out_musica_fondo) if out_musica_fondo.is_file() else "",
            "musica_fondo_nombre": out_musica_fondo.name if out_musica_fondo.is_file() else "",
            "audio_original": str(out_audio_completo),
            "transcripcion_muestra": transcripcion,
            "instrucciones_clonacion": (
                f"Sube '{out_voz_clonacion.name}' ({dur_final_voz:.1f}s) a ai33.pro o tu herramienta TTS favorita. "
                "Al estar 100% aislada de música de fondo y durar menos de 29.5s, la clonación conservará el timbre, "
                "pausas y entonación exacta del narrador analizado sin cortes inesperados."
            )
        }

        with open(dir_audio / "reporte_diseccion.json", "w", encoding="utf-8") as f:
            json.dump(reporte, f, ensure_ascii=False, indent=2)

        return reporte
