# -*- coding: utf-8 -*-
"""
analizar_nicho.py
-----------------
Analizador de Canales y Nichos Virales para Creador de Videos.
Evalúa la viabilidad de replicar un canal (Facebook, YouTube, TikTok)
sin descargar videos pesados, extrayendo guiones, estructura viral,
identidad visual (prompts de estilo y personajes) y generando la
instrucción maestra para IA.
"""

import json
import re
import subprocess
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


ESTILOS_VISUALES = {
    "codigo_motion": {
        "id": "codigo_motion",
        "nombre": "Animación Programada por Código (Motion Graphics / HTML / Canvas / Python)",
        "sufijo": "Clean vector motion graphics, minimalist technical illustration, programmatic visual demonstration, dark sleek background, high contrast --ar 9:16",
        "sufijo_movimiento": "Programmatic visual animation, continuous smooth dynamic motion, zero AI hallucination.",
        "descripcion": "Animación 100% basada en código (HTML5 Canvas, Python PIL/FFmpeg, Manim o HyperFrames). No requiere generación de imágenes con IA."
    },

    "tech_moderno": {
        "id": "tech_moderno",
        "nombre": "Tecnología Moderna / Motion Graphics & UI Tech",
        "sufijo": "Modern sleek tech aesthetic, clean futuristic digital interface overlay, subtle glowing HUD elements, high-tech studio backdrop, soft cinematic rim lighting, modern minimalist developer workspace, 8k resolution, cinematic frame --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact sleek tech aesthetic, clean lighting, subtle UI motion, and modern digital atmosphere of the original image. Dynamic realistic motion. No text.",
        "descripcion": "Estilo tecnológico, vanguardista y digital. Diseñado para Inteligencia Artificial, herramientas de software, código, tutoriales tech y motion graphics."
    },
    "zack_d_films": {
        "id": "zack_d_films",
        "nombre": "Animación 3D Didáctica / Simulaciones Visuales",
        "sufijo": "Stylized 3D character animation in signature educational demonstration style, expressive stylized 3D human character, clean digital CGI animation render, vibrant studio rim lighting, Unreal Engine 5 render, Blender simulation aesthetic, highly detailed object and anatomy demonstration, smooth textures, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact stylized 3D animation style, smooth character gestures, and educational demonstration simulation of the original image. Dynamic realistic motion. No text.",
        "descripcion": "Animación 3D estilizada de alta retención. Personajes expresivos explicando curiosidades insólitas, ciencia, anatomía, inventos y simulaciones de alto impacto visual."
    },
    "dark_noir": {
        "id": "dark_noir",
        "nombre": "Dark Noir / Documental de Investigación y Misterio",
        "sufijo": "Cinematic dark mystery documentary style, moody dramatic rim lighting, deep atmospheric shadows, film noir graphic aesthetic, hyperdetailed textures, 8k resolution, cinematic frame --ar 9:16 --v 6 --style raw",
        "sufijo_movimiento": "Maintain the exact cinematic dark mystery style, moody dramatic rim lighting, deep atmospheric shadows, and film noir aesthetic of the original image. Smooth natural cinematic motion. No text.",
        "descripcion": "Estilo oscuro, intrigante y cinematográfico. Ideal para investigaciones analíticas, psicología de consumo, secretos comerciales y documentales de impacto."
    },
    "documental_historico": {
        "id": "documental_historico",
        "nombre": "Documental Histórico / Cinematográfico Épico",
        "sufijo": "Epic historical documentary still, authentic period atmosphere, warm atmospheric cinematic lighting, Rembrandt lighting, rich authentic textures, vintage lens characteristics, 8k cinematic frame --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact historical atmosphere, authentic period textures, and cinematic lighting of the original image. Smooth natural motion. No text.",
        "descripcion": "Estilo solemne, atmosférico y fotorrealista. Ideal para historia universal, civilizaciones antiguas, imperios y relatos biográficos."
    },
    "terror_misterio": {
        "id": "terror_misterio",
        "nombre": "Terror Psicológico / Misterio y Suspenso",
        "sufijo": "Eerie psychological thriller film still, deep atmospheric shadows, desaturated cool color palette, haunting ambient fog, unsettling cinematic composition, 8k cinematic frame --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact eerie atmospheric tension, deep shadows, and psychological thriller style of the original image. Slow tense cinematic motion. No text.",
        "descripcion": "Estilo oscuro, inquietante y cinematográfico. Ideal para leyendas urbanas, casos reales, misterios sin resolver y creepypastas."
    },
    "roblox_3d": {
        "id": "roblox_3d",
        "nombre": "Animación 3D Bloques / Estilo Gaming & Cartoon",
        "sufijo": "Low-poly 3D blocky cartoon character animation style, modular blocky avatar aesthetic, smooth plastic toy texture, minimalist facial decal expression, vibrant isometric studio lighting, clean solid surfaces, 3D CGI animation render, Unreal Engine 5 render, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact 3D blocky cartoon character animation style, plastic toy texture, and aesthetic of the original image. Smooth natural character movement. No text.",
        "descripcion": "Personajes cúbicos con texturas plásticas limpias, caras expresivas y render 3D caricaturesco. Ideal para historias virales de comedia, gaming y animación."
    },
    "minecraft_voxel": {
        "id": "minecraft_voxel",
        "nombre": "Minecraft / Voxel Art Cúbico",
        "sufijo": "Voxel art style, Minecraft blocky aesthetic, cubic geometry, vibrant pixelated textures, soft volumetric shader lighting, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact voxel blocky art style, cubic geometry, and pixelated shader lighting of the original image. Smooth natural movement. No text.",
        "descripcion": "Estilo cúbico y voxel con texturas pixeladas e iluminación suave de shaders volumétricos."
    },
        "cartoon_hibrido": {
        "id": "cartoon_hibrido",
        "nombre": "3D Cartoon Híbrido / Mascota Antropomórfica en Entorno Realista",
        "sufijo": "Cinematic 3D hybrid cartoon animation style, vibrant stylized anthropomorphic character integrated seamlessly into photorealistic cinematic business environment, dramatic warm volumetric lighting, Octane render 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact stylized 3D anthropomorphic cartoon character and its seamless integration into the realistic environment. Dynamic natural motion. No text.",
        "descripcion": "Estilo híbrido viral: avatar o mascota antropomórfica 3D vistiendo trajes de lujo e interactuando en escenarios fotorrealistas de negocios, dinero, finanzas y oficinas ejecutivas."
    },
"pixar_3d": {
        "id": "pixar_3d",
        "nombre": "3D Pixar / Render Cinematográfico Digital",
        "sufijo": "3D Pixar animation style render, cute and expressive character design, soft subsurface scattering, vibrant warm studio lighting, Unreal Engine 5 octane render, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact 3D Pixar animation style, warm studio lighting, and expressive character design of the original image. Smooth natural character animation. No text.",
        "descripcion": "Animación 3D amigable y expresiva. Ideal para fábulas con animales humanizados y público familiar amplio."
    },
    "realismo_cinematografico": {
        "id": "realismo_cinematografico",
        "nombre": "Realismo Cinematográfico / Drama 35mm",
        "sufijo": "Hyperrealistic cinematic film still, dramatic emotional expression, 35mm lens, depth of field, natural realistic textures, raw photography, 8k UHD --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact hyperrealistic cinematic film still style, 35mm depth of field, and natural textures of the original image. Smooth natural realistic motion. No text.",
        "descripcion": "Fotografía cinematográfica con iluminación dramática. Ideal para historias humanas maduras, lecciones de vida y dramas sociales."
    },
    "anime_moderno": {
        "id": "anime_moderno",
        "nombre": "Anime Moderno / Shonen Cinematográfico",
        "sufijo": "Modern anime cinematic style, Makoto Shinkai aesthetic, clean linework, vibrant expressive lighting, detailed anime background, cel shading, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact modern anime cinematic style, clean linework, vibrant lighting, and cel shading of the original image. Smooth natural anime motion. No text.",
        "descripcion": "Estilo anime contemporáneo con iluminación vibrante, fondos detallados y sombreado cel."
    },
    "comic": {
        "id": "comic",
        "nombre": "Novela Gráfica / Cómic Ilustrado",
        "sufijo": "Highly detailed comic book illustration style with clean bold line art, vibrant colors, flat color fills, graphic novel aesthetic, masterpiece, 8k --ar 9:16 --v 6 --stylize 250 --style raw",
        "sufijo_movimiento": "Maintain the exact illustration style, clean bold line art, vibrant colors, flat color fills, and graphic novel aesthetic of the original image. Smooth natural cinematic motion. No text.",
        "descripcion": "Estilo cómic/novela gráfica de alto impacto. Trazo negro limpio, colores vivos y estética gráfica definida."
    },
    "plastilina_stopmotion": {
        "id": "plastilina_stopmotion",
        "nombre": "Plastilina / Claymation Stop-Motion",
        "sufijo": "Claymation stop-motion animation style, sculpted plasticine texture, visible handcrafted fingerprint details, warm soft studio lighting, Aardman inspired, 8k --ar 9:16 --v 6",
        "sufijo_movimiento": "Maintain the exact claymation stop-motion style, sculpted plasticine textures, and warm lighting of the original image. Smooth stop-motion animation. No text.",
        "descripcion": "Estilo artesanal de muñecos de plastilina modelada con textura táctil e iluminación cálida."
    }
}


def contiene_palabra(texto: str, palabras: list) -> bool:
    """Busca palabras o frases completas con límites de palabra para evitar falsos positivos
    como 'oso' en 'peligroso', 'lobo' en 'globo', o 'rico' en 'historico'."""
    for p in palabras:
        p_clean = p.strip().lower()
        if not p_clean:
            continue
        if " " in p_clean or "¿" in p_clean or "?" in p_clean:
            if p_clean in texto:
                return True
        else:
            patron = r"(?<![a-záéíóúüñ0-9])" + re.escape(p_clean) + r"(?![a-záéíóúüñ0-9])"
            if re.search(patron, texto):
                return True
    return False

def _asegurar_ytdlp():
    """Verifica si yt_dlp está instalado y si no, lo instala automáticamente."""
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        try:
            print("[*] Librería yt-dlp no encontrada en este entorno Python. Instalando automáticamente...")
            subprocess.run([sys.executable, "-m", "pip", "install", "yt-dlp", "curl-cffi", "--quiet"], check=False)
            import yt_dlp
            return yt_dlp
        except Exception as ex:
            print(f"[ERROR] No se pudo auto-instalar yt-dlp: {ex}")
            return None


def extraer_info_url(url: str) -> dict:
    """Extrae metadatos y texto del video con yt-dlp directamente en Python o por subproceso."""
    url = url.strip()
    if not url:
        return None

    yt_dlp_mod = _asegurar_ytdlp()

    # Intento 1: Directamente a través del módulo de Python (más rápido, sin problemas de terminal)
    if yt_dlp_mod:
        try:
            ydl_opts = {
                'skip_download': True,
                'quiet': True,
                'no_warnings': True,
                'extract_flat': False,
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
            }
            with yt_dlp_mod.YoutubeDL(ydl_opts) as ydl:
                data = ydl.extract_info(url, download=False)
                if not data:
                    return {"url": url, "ok": False, "error": "No se recibieron datos del video"}

                # Si es un playlist o perfil con entries
                if "entries" in data and not data.get("title"):
                    entries = [e for e in data.get("entries", []) if e]
                    if entries:
                        data = entries[0]

                titulo = data.get("title", "")
                descripcion = data.get("description", "")
                duracion = data.get("duration", 0)
                canal = data.get("uploader", "") or data.get("channel", "") or "Desconocido"
                canal_id = data.get("uploader_id", "") or ""
                vistas = data.get("view_count", 0)
                likes = data.get("like_count", 0)
                aspect = data.get("aspect_ratio")
                thumb = data.get("thumbnail", "")
                categories = data.get("categories", []) or []
                tags = data.get("tags", []) or []

                guion_detectado = ""
                try:
                    from transcriptor_metadata import extraer_transcripcion_url
                    tr_res = extraer_transcripcion_url(url, idioma_pref="es")
                    if tr_res.get("ok") and tr_res.get("transcripcion"):
                        guion_detectado = tr_res.get("transcripcion")
                except Exception:
                    pass
                if not guion_detectado:
                    tiene_guion_en_desc = len(descripcion) > 180 and (
                        "reflexión" in descripcion.lower() or 
                        "historia" in descripcion.lower() or 
                        "¿por qué" in descripcion.lower() or 
                        len(descripcion.split()) > 40
                    )
                    guion_detectado = descripcion if tiene_guion_en_desc else ""

                es_vertical = False
                if aspect and aspect < 0.9:
                    es_vertical = True
                elif duracion and duracion <= 90:
                    es_vertical = True

                return {
                    "url": url,
                    "ok": True,
                    "titulo": titulo,
                    "canal": canal,
                    "canal_id": canal_id,
                    "duracion": duracion,
                    "duracion_fmt": f"{int(duracion//60)}:{int(duracion%60):02d}" if duracion else "N/D",
                    "vistas": vistas,
                    "likes": likes,
                    "es_vertical": es_vertical,
                    "aspect": aspect,
                    "thumbnail": thumb,
                    "descripcion": descripcion,
                    "guion": guion_detectado,
                    "categories": categories,
                    "tags": tags
                }
        except Exception as e:
            # Continuar con fallback por si fue error transitorio del wrapper
            pass

    # Intento 2: Subproceso
    cmd = [
        sys.executable, "-m", "yt_dlp",
        "--dump-json",
        "--no-warnings",
        "--skip-download",
        "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        url
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=35)
        if res.returncode != 0 or not res.stdout.strip():
            err_msg = res.stderr[:180] or "No se pudo extraer información del enlace"
            return {"url": url, "ok": False, "error": err_msg}

        data = json.loads(res.stdout.splitlines()[0])

        titulo = data.get("title", "")
        descripcion = data.get("description", "")
        duracion = data.get("duration", 0)
        canal = data.get("uploader", "") or data.get("channel", "") or "Desconocido"
        canal_id = data.get("uploader_id", "") or ""
        vistas = data.get("view_count", 0)
        likes = data.get("like_count", 0)
        aspect = data.get("aspect_ratio")
        thumb = data.get("thumbnail", "")
        categories = data.get("categories", []) or []
        tags = data.get("tags", []) or []

        guion_detectado = ""
        try:
            from transcriptor_metadata import extraer_transcripcion_url
            tr_res = extraer_transcripcion_url(url, idioma_pref="es")
            if tr_res.get("ok") and tr_res.get("transcripcion"):
                guion_detectado = tr_res.get("transcripcion")
        except Exception:
            pass
        if not guion_detectado:
            tiene_guion_en_desc = len(descripcion) > 180 and (
                "reflexión" in descripcion.lower() or 
                "historia" in descripcion.lower() or 
                "¿por qué" in descripcion.lower() or 
                len(descripcion.split()) > 40
            )
            guion_detectado = descripcion if tiene_guion_en_desc else ""

        es_vertical = False
        if aspect and aspect < 0.9:
            es_vertical = True
        elif duracion and duracion <= 90:
            es_vertical = True

        return {
            "url": url,
            "ok": True,
            "titulo": titulo,
            "canal": canal,
            "canal_id": canal_id,
            "duracion": duracion,
            "duracion_fmt": f"{int(duracion//60)}:{int(duracion%60):02d}" if duracion else "N/D",
            "vistas": vistas,
            "likes": likes,
            "es_vertical": es_vertical,
            "aspect": aspect,
            "thumbnail": thumb,
            "descripcion": descripcion,
            "guion": guion_detectado,
            "categories": categories,
            "tags": tags
        }
    except Exception as e:
        return {"url": url, "ok": False, "error": str(e)}


def generar_kit_lanzamiento_canal(
    canal_ref: str,
    tipo_nicho: str,
    estilo_id: str,
    estilo_nombre: str,
    personaje_1_desc: str,
    personaje_1_prompt: str,
    formula_recomendada: str,
    texto_pantalla_ej: str = "",
    personaje_sugerido_desc: str = "",
    personaje_sugerido_prompt: str = ""
) -> dict:
    """
    Genera el Kit Completo de Lanzamiento para Redes Sociales:
    - Opciones de nombres atractivos para el canal (YouTube, TikTok, Facebook, Instagram).
    - Biografías listas para copiar y pegar en cada red.
    - Super-Prompt para ChatGPT/Claude/Gemini para generar 30 ideas y calendario de 30 días.
    - Consejos de diferenciación anti-copyright y anclaje de personaje.
    - Texto plano descargable (.txt).
    """
    nicho_low = (tipo_nicho or "").lower()
    canal_low = (canal_ref or "").lower()

    # 1. Sugerencias de Nombres y Bios según temática
    if "pato" in nicho_low or "pato" in canal_low or estilo_id == "cartoon_hibrido" or "finanza" in nicho_low or "negocio" in nicho_low:
        nombres = [
            "El Magnate Sabio",
            "Capital Mental",
            "El Pato Inversor",
            "Mente de Billetes",
            "Imperio Estratégico",
            "Código Riqueza",
            "Patrón Financiero",
            "Billonario Oculto"
        ]
        cat_fb = "Educación Financiera / Creador de Contenido Digital"
        bio_tt = "🎯 Psicología de negocios y verdades incómodas sobre el dinero | 🚀 Domina tu mente financiera | 👇 Sígueme para subir de nivel"
        bio_ig = "🎩 Mentalidad de Élite & Psicología Financiera\n💡 Lo que los ricos aprenden y nunca te enseñaron\n👇 Nuevos episodios diarios"
        bio_yt = f"""Bienvenido a un espacio diseñado para transformar tu mentalidad sobre el dinero, los negocios y el éxito personal.

Aquí analizamos patrones psicológicos, secretos de magnates y estrategias accionables contadas de forma dinámica y visual. Publicamos lecciones y Shorts de alto impacto para ayudarte a construir tu libertad financiera y tomar decisiones estratégicas.

🔔 Suscríbete y activa la campana para no perderte ningún episodio."""
        bio_fb = "Página oficial de lecciones de negocios, psicología de riqueza y mentalidad estratégica con avatares y producción visual de élite."
        consejos_anti_copy = [
            "🎨 Paleta de Vestimenta Diferenciada: En lugar del clásico frac rojo, viste a tu avatar con saco azul marino medianoche, verde esmeralda o borgoña profundo con botones plateados.",
            "🕶️ Accesorios Distintivos: Agrégale un monóculo de titanio, gafas circulares estilo intelectual o un reloj de bolsillo con cadena de oro.",
            "👞 Calzado y Detalles: Equípalo con zapatos oxford café bruñido o un pañuelo de seda en el bolsillo de solapa.",
            "🔒 Anclaje en Instrucción Maestra: Mantén esta descripción idéntica en todos tus guiones para que la IA nunca deforme la identidad de tu personaje."
        ]

    elif "curiosidad" in nicho_low or "ciencia" in nicho_low or estilo_id == "zack_d_films":
        nombres = [
            "Curiosidad 3D",
            "Efecto Oculto",
            "Anatomía Visual",
            "Mente Curiosa 3D",
            "¿Sabías Qué? 3D",
            "Ciencia Explicada",
            "El Laboratorio 3D",
            "Dimensión Visual"
        ]
        cat_fb = "Ciencia y Tecnología / Entretenimiento Educativo"
        bio_tt = "🔬 Curiosidades, ciencia y simulaciones 3D que nadie te enseñó | 🧠 Explora lo invisible | 👇 Sígueme para aprender más"
        bio_ig = "🔬 Simulaciones 3D & Curiosidades Fascinantes\n🧬 La ciencia detrás de lo que nunca imaginaste\n👇 Nuevo video todos los días"
        bio_yt = f"""Bienvenido al canal donde la ciencia, la anatomía y las curiosidades más insólitas del mundo cobran vida mediante simulaciones y animaciones 3D de alta precisión.

Descubre qué le ocurre realmente a tu cuerpo, cómo funcionan los inventos y experimentos más extremos explicados de forma clara, directa y visualmente impactante.

🔔 Suscríbete para descubrir algo nuevo en cada video."""
        bio_fb = "Simulaciones visuales 3D, ciencia y respuestas a las preguntas más curiosas del cuerpo humano y el universo."
        consejos_anti_copy = [
            "🎨 Paleta de Color: Viste a tu explicador con una sudadera técnica gris grafito o polo verde oliva en lugar de los colores del referente.",
            "👓 Accesorios: Agrégale lentes de montura moderna o audífonos de diadema.",
            "🔒 Anclaje en Instrucción Maestra: Fija su anatomía 3D y peinado en la instrucción para que todas las simulaciones se sientan parte de una misma serie."
        ]

    elif "misterio" in nicho_low or "terror" in nicho_low or estilo_id == "terror_misterio" or estilo_id == "dark_noir":
        nombres = [
            "Ojos de Lobo",
            "Crónicas del Umbral",
            "Expediente Enigma",
            "Mente en Sombras",
            "Relatos Inexplicables",
            "El Ojo del Misterio",
            "Voces Ocultas",
            "Archivo Nocturno"
        ]
        cat_fb = "Misterio y Paranormal / Cine y Series"
        bio_tt = "👁️ Casos inexplicables, misterios reales y relatos oscuros | 🕯️ ¿Te atreves a mirar? | 👇 Sígueme en las sombras"
        bio_ig = "🕯️ Casos Inexplicables & Misterios Reales\n🌑 La verdad que nadie se atreve a contar\n👇 Relatos nocturnos diarios"
        bio_yt = f"""Bienvenido al archivo de los casos más intrigantes, desapariciones sin resolver y sucesos que desafían la lógica humana.

Relatos narrados con atmósfera cinematográfica envolvente, sonido inmersivo y visuales oscuros diseñados para mantenerte al borde de tu asiento de principio a fin.

🔔 Suscríbete y enciende la campanita para escuchar cada expediente."""
        bio_fb = "Relatos cinematográficos de misterio, casos reales sin resolver y enigmas psicológicos."
        consejos_anti_copy = [
            "🎨 Diferenciación de Personaje: Si usas una figura como lobo o narrador, dale ojos color ámbar profundo, una bufanda desgastada o una cicatriz sutil.",
            "🕯️ Atrezzo y Ambiente: Incluye un farol de latón antiguo o un diario de cuero envejecido como ancla visual recurrente.",
            "🔒 Anclaje en Instrucción Maestra: Mantén la misma iluminación de claroscuro (Rembrandt/Noir) fija en cada prompt."
        ]

    elif "pareja" in nicho_low or "ternura" in nicho_low or "suricata" in nicho_low or estilo_id == "pixar_3d":
        nombres = [
            "Rinconcito de Amor",
            "Momentos de Dos",
            "Amor en Miniatura",
            "Patitas Juntas",
            "Pucheros & Abrazos",
            "Historias de Novios",
            "Amor Relatable 3D",
            "Nido de Dos"
        ]
        cat_fb = "Comedia y Relaciones / Creador de Contenido Digital"
        bio_tt = "🤍 Momentos tiernos y cómicos de pareja que todos vivimos | 🧸 Etiqueta a tu persona favorita | 👇 Síguenos para sonreír"
        bio_ig = "🧸 Micro-animaciones 3D de amor y ternura\n🤍 Para enviarle a esa persona especial\n👇 Nuevas historias diarias"
        bio_yt = f"""Un rincón dedicado a celebrar los pequeños momentos, los pucheros, las reconciliaciones y el cariño cotidiano entre parejas a través de entrañables micro-animaciones 3D.

Cada video está diseñado para sacarte una sonrisa, calentarte el corazón y recordarte el valor de los abrazos sinceros.

🔔 Suscríbete y comparte con esa persona que alegra tus días."""
        bio_fb = "Micro-animaciones 3D de amor, ternura y humor de pareja para compartir y etiquetar."
        consejos_anti_copy = [
            "🎨 Especie o Atuendo: Puedes optar por otra especie tierna (nutrias, ardillas, conejitos) o personalizar sus accesorios (un lazo lila, una bufanda tejida a rayas).",
            "🤍 Dinámica de Gestos: Fija en la instrucción maestra la flor en la oreja o el collar de semillas como sello único de tu canal.",
            "🔒 Anclaje en Instrucción Maestra: Asegura que los personajes tengan la misma textura de pelaje y ojos brillantes en todas las tomas modulares."
        ]

    elif "historia" in nicho_low or estilo_id == "documental_historico":
        nombres = [
            "Imperios en Llamas",
            "Crónicas de la Historia",
            "Estrategia Ancestral",
            "Legados del Pasado",
            "El Gran Imperio",
            "Historia Sin Filtro",
            "Relatos de Conquista",
            "Ecos del Tiempo"
        ]
        cat_fb = "Historia y Cultura / Creador de Contenido"
        bio_tt = "⚔️ Los sucesos, batallas y secretos que no te enseñaron en la escuela | 🏛️ Historia viva | 👇 Sígueme para viajar en el tiempo"
        bio_ig = "🏛️ Historia Universal, Imperios y Grandes Batallas\n⚔️ Lo que los libros de texto omitieron\n👇 Nuevos relatos épicos"
        bio_yt = f"""Explora los eventos que forjaron la civilización humana: batallas épicas, emperadores audaces, traiciones decisivas y misterios históricos contados con pasión y rigor.

🔔 Suscríbete para sumergirte en las historias más fascinantes de la humanidad."""
        bio_fb = "Documentales históricos cortos sobre batallas, emperadores y momentos que cambiaron el mundo."
        consejos_anti_copy = [
            "🎨 Estilo Fotográfico: Utiliza paleta cálida con grano de 35mm y mantén una insignia o medallón de época distintivo.",
            "🔒 Anclaje en Instrucción Maestra: Fija la voz en off solemne y los mapas de época en tus prompts."
        ]

    else:
        nombres = [
            "Historias que Inspiran",
            "Lecciones de Vida",
            "El Despertar Diario",
            "Ecos de Vida",
            "Mundo de Historias",
            "Reflexión Activa",
            "Sabiduría Diaria",
            "Relatos de Impacto"
        ]
        cat_fb = "Reflexión y Motivación / Creador de Contenido"
        bio_tt = "💡 Historias con propósito y lecciones que transforman tu día | 🌱 Crece cada día | 👇 Sígueme para más reflexiones"
        bio_ig = "🌱 Historias de Vida & Crecimiento Personal\n✨ Reflexiones para tu mente y corazón\n👇 Nuevos episodios diarios"
        bio_yt = f"""Historias humanas conmovedoras, fábulas y lecciones de vida para inspirarte y reflexionar en un mundo acelerado.

🔔 Suscríbete para nutrir tu mente cada semana."""
        bio_fb = "Relatos de vida, fábulas morales y reflexiones profundas para compartir con la familia."
        consejos_anti_copy = [
            "🎨 Diseño de Personajes: Define claramente la edad, expresión serena y ropa sencilla y digna de tus protagonistas.",
            "🔒 Anclaje en Instrucción Maestra: Conserva la misma fisonomía en cada escena variando solo acciones y fondos."
        ]

    # 2. Super-Prompt de Arranque para ChatGPT / Claude / Gemini
    super_prompt_ia = f"""Actúa como un Director Creativo y Estratega de Crecimiento para Redes Sociales (YouTube Shorts, TikTok, Instagram Reels y Facebook).
Estoy creando un canal desde cero en el siguiente nicho y necesito un plan maestro de despegue:

================================================================================
FICHA DEL CANAL A LANZAR
================================================================================
- Nicho Temático: {tipo_nicho}
- Canal de Referencia Inspiracional: {canal_ref}
- Estilo Visual de Producción: {estilo_nombre}
- Personaje Original Detectado: {personaje_1_desc}
- Personaje Sugerido para mi Marca (Diferenciado): {personaje_sugerido_desc or personaje_1_desc}
- Formato Audiovisual: {formula_recomendada}
- Prompt de Imagen Sugerido Base (--cref):
  {personaje_sugerido_prompt or personaje_1_prompt}

================================================================================
LO QUE DEBES ENTREGARME:
================================================================================
1. 30 IDEAS DE VIDEOS VIRALES CON GANCHOS DE RETENCIÓN DE 3 SEGUNDOS:
   - Para cada video, escribe:
     * Título impactante con gancho de curiosidad (ej: "La verdad incómoda sobre...").
     * Primera frase del gancho hablado o texto en pantalla (0 a 3s) que impida deslizar el video.
     * Conflicto central en 1 oración.
     * Pregunta clave al final para detonar cientos de comentarios y debate.

2. ESTRATEGIA DE DIFERENCIACIÓN VISUAL Y PROTECCIÓN ANTI-COPYRIGHT:
   - Para evitar problemas de derechos de autor con "{canal_ref}" y garantizar que Midjourney, Flux y DALL-E nunca bloqueen mis prompts por marcas registradas:
     * 3 combinaciones de colores elegantes y distintivas para la vestimenta de mi personaje.
     * 3 accesorios característicos únicos (ej: reloj de bolsillo, gafas, calzado, bastón con tallado propio).
     * 1 rasgo de personalidad que lo vuelva un ícono propio e inolvidable.

3. PLAN DE PUBLICACIÓN PARA LOS PRIMEROS 30 DÍAS:
   - Calendario sugerido (1 a 2 publicaciones por día).
   - Mejores horarios de publicación para TikTok, Reels y Shorts.
   - Recomendación para reutilizar el mismo video vertical en las 4 plataformas sin penalización.

4. 5 PLANTILLAS DE GANCHOS (HOOKS) DE ALTA CONVERSIÓN:
   - Fórmulas de apertura psicológica adaptadas específicamente al nicho "{tipo_nicho}".
"""

    lista_nombres_txt = "\n".join(f"  • {n}" for n in nombres)
    lista_consejos_txt = "\n".join(f"  • {c}" for c in consejos_anti_copy)

    # 3. Texto exportable completo para descarga (.txt)
    texto_exportable = f"""================================================================================
🚀 KIT DE LANZAMIENTO PARA REDES SOCIALES (YOUTUBE, TIKTOK, FACEBOOK, INSTAGRAM)
Canal de Referencia: {canal_ref}
Nicho Temático: {tipo_nicho}
Estilo Visual: {estilo_nombre}
================================================================================

CASILLERO 1 - PERSONAJE DETECTADO EN EL CANAL:
{personaje_1_desc}
Prompt: {personaje_1_prompt}

CASILLERO 2 - PERSONAJE SUGERIDO (TU MARCA PROPIA DIFERENCIADA):
{personaje_sugerido_desc or personaje_1_desc}
Prompt: {personaje_sugerido_prompt or personaje_1_prompt}
================================================================================

1. OPCIONES DE NOMBRES PARA TU CANAL Y REDES:
--------------------------------------------------------------------------------
{lista_nombres_txt}

2. BIOGRAFÍAS Y DESCRIPCIONES OPTIMIZADAS (LISTAS PARA PEGAR):
--------------------------------------------------------------------------------
[TIKTOK] (Gancho directo y llamada a la acción en < 80 caracteres)
{bio_tt}

[INSTAGRAM] (Formato limpio de 3 líneas con emojis)
{bio_ig}

[FACEBOOK] (Categoría sugerida: {cat_fb})
{bio_fb}

[YOUTUBE - PESTAÑA INFORMACIÓN / ACERCA DE]
{bio_yt}

3. CONSEJOS CLAVE DE ORIGINALIDAD Y ANTI-COPYRIGHT:
--------------------------------------------------------------------------------
{lista_consejos_txt}

4. SUPER-PROMPT DE ARRANQUE PARA CUALQUIER IA (CHATGPT / CLAUDE / GEMINI):
--------------------------------------------------------------------------------
(Copia y pega el siguiente bloque en tu IA favorita para obtener 30 guiones e ideas de inmediato)

{super_prompt_ia}
================================================================================
"""

    return {
        "nombres_sugeridos": nombres,
        "bios": {
            "tiktok": bio_tt,
            "instagram": bio_ig,
            "youtube": bio_yt,
            "facebook": bio_fb,
            "categoria_facebook": cat_fb
        },
        "consejos_anti_copy": consejos_anti_copy,
        "prompt_ia_arranque": super_prompt_ia,
        "texto_exportable": texto_exportable
    }


def diagnosticar_nicho(videos_info: list, diseccion: dict = None) -> dict:
    """Evalúa la lista de videos y genera la ficha de replicabilidad, identidad visual y prompts."""
    validos = [v for v in videos_info if v.get("ok")]
    if not validos:
        errores = [v.get("error", "") for v in videos_info if v.get("error")]
        detalle_err = (" " + errores[0]) if errores else ""
        if "No module named yt_dlp" in detalle_err or "No module named 'yt_dlp'" in detalle_err:
            msg = "Faltan instalar las librerías en tu nuevo Python. Por favor haz doble clic en 'instalar_dependencias.bat' para instalarlas automáticamente con 1 clic."
        elif "tiktok:user" in detalle_err.lower() or "unable to extract" in detalle_err.lower():
            msg = "Parece que ingresaste el enlace de un perfil de usuario (ej: @canal). Por favor ingresa enlaces de videos individuales (ej: https://www.tiktok.com/@usuario/video/12345... o de YouTube Shorts)."
        else:
            msg = f"No se pudo obtener información válida de los enlaces proporcionados.{detalle_err}"
        return {
            "ok": False,
            "msg": msg
        }

    total_videos = len(validos)
    canales = list({v["canal"] for v in validos if v.get("canal")})
    canal_principal = canales[0] if canales else "Nicho Analizado"

    duraciones = [v["duracion"] for v in validos if v.get("duracion")]
    dur_prom = sum(duraciones) / len(duraciones) if duraciones else 60
    formato_vert = sum(1 for v in validos if v.get("es_vertical")) >= (total_videos / 2)

    # Datos de disección audiovisual profunda
    dd = (diseccion or {}).get("datos_diseccion", {}) if diseccion else {}
    fotogramas = (diseccion or {}).get("fotogramas", []) if diseccion else []
    tiene_locucion = (diseccion or {}).get("tiene_locucion", True) if diseccion else True
    tipo_audio_desc = (diseccion or {}).get("tipo_audio_desc", "") if diseccion else ""
    uso_gemini = (diseccion or {}).get("uso_gemini", False) if diseccion else False
    titulo_es = (diseccion or {}).get("titulo_es", "") if diseccion else ""
    texto_pantalla_ej = dd.get("texto_pantalla_ejemplo", "")
    formato_guion_dis = dd.get("formato_guion", "")

    # Detección exhaustiva de temática y palabras clave
    textos_lista = []
    for v in validos:
        textos_lista.append(v.get("titulo", "") or "")
        textos_lista.append(v.get("descripcion", "") or "")
        textos_lista.append(v.get("canal", "") or "")
        textos_lista.append(v.get("canal_id", "") or "")
        textos_lista.extend(v.get("categories", []) or [])
        textos_lista.extend(v.get("tags", []) or [])

    texto_combinado = " ".join(textos_lista).lower()

            # Detección exhaustiva de temática con palabras completas
    # 1. Tecnología, Inteligencia Artificial, Software y Motion Graphics (Ej: IAdeGuardia, Dev, Tech)
    es_tech_ia = (
        contiene_palabra(texto_combinado, [
            "ia", "inteligencia artificial", "ai", "github", "claude", "chatgpt", "software",
            "programación", "programacion", "codigo", "código", "desarrollo", "tech", "tecnología",
            "tecnologia", "app", "herramienta", "herramientas", "prompt", "prompts", "motiongraphics",
            "plugin", "python", "html", "repo", "hyperframes", "algoritmo", "automatización",
            "automatizacion", "bot", "web dev", "developer", "deepseek", "gemini", "cursor", "copilot"
        ]) or
        contiene_palabra(canal_principal.lower(), ["ia", "ai", "tech", "code", "dev", "guardia", "bot"])
    )

    # 2. Terror, Misterio, Paranormal y Casos Inexplicables
    es_terror = contiene_palabra(texto_combinado, [
        "terror", "paranormal", "misterio", "fantasma", "fantasmas", "creepypasta",
        "inquietante", "perturbador", "maldición", "maldicion", "caso real", "desaparición", "asesino"
    ])

    # 3. Historia Universal, Civilizaciones y Grandes Batallas
    es_historia = contiene_palabra(texto_combinado, [
        "historia", "imperio", "romano", "egipto", "guerra", "batalla", "rey", "reina",
        "antiguo", "antigua", "siglo", "edad media", "conquista", "emperador", "civilización", "civilizacion"
    ])

    # 4. Gaming / Roblox / 3D Cartoon
    es_roblox_o_gaming = (
        contiene_palabra(texto_combinado, ["roblox", "bloxd", "lego"]) or
        ("gaming" in texto_combinado and contiene_palabra(texto_combinado, ["avatar", "bloque", "skin"]))
    )

    # 5. Minecraft / Voxel
    es_minecraft = contiene_palabra(texto_combinado, ["minecraft", "voxel"])

    # 6. Animación 3D Didáctica / Simulaciones y Curiosidades
    es_simulaciones_3d = (
        contiene_palabra(texto_combinado, ["zack", "zackdfilms", "youandangel"]) or
        contiene_palabra(canal_principal.lower(), ["zack", "youandangel"]) or
        (
            any(h in texto_combinado for h in ["¿qué pasaría", "que pasaria", "¿sabías qué", "sabias que", "¿por qué ocurre", "por que ocurre", "¿cómo funciona", "como funciona"]) and
            contiene_palabra(texto_combinado, ["invento", "mutación", "mutacion", "experimento", "anatomía", "anatomia", "simulación", "simulacion", "ciencia", "científico", "cientifico", "medicina", "cuerpo humano"])
        ) or
        (
            contiene_palabra(texto_combinado, ["animación 3d", "animacion 3d", "simulacion 3d", "simulación 3d"]) and
            contiene_palabra(texto_combinado, ["curiosidad", "curiosidades", "invento", "ciencia", "cuerpo"])
        )
    )

    # 7. Estrategias de Marketing, Psicología de Consumo y Negocios
    es_marketing_negocios = (
        contiene_palabra(texto_combinado, [
            "estrategia de marketing", "psicología de precios", "psicologia de precios",
            "secreto comercial", "trampa publicitaria", "neuromarketing", "truco de marketing",
            "estrategia oculta", "secreto de ventas", "engaño publicitario"
        ])
    )

    # 8. Fábulas de Animales (Requiere animales + contexto explícito de fábula o lección moral)
    es_animales = (
        not es_simulaciones_3d and
        contiene_palabra(texto_combinado, ["toro", "toros", "perro", "perros", "lobo", "lobos", "león", "leon", "leones", "caballo", "caballos", "gato", "gatos", "águila", "aguila", "oso", "osos", "animales"]) and
        (
            contiene_palabra(texto_combinado, ["fábula", "fabula", "fábulas", "reflexión", "reflexion", "lección", "leccion", "sabio", "moraleja", "humilde", "arrogante"]) or
            contiene_palabra(canal_principal.lower(), ["sabiduria", "eterna", "fabula", "reflexion"])
        )
    )

    # 9. Anime / Manga
    es_anime = contiene_palabra(texto_combinado, ["anime", "manga", "otaku", "shonen", "manhwa", "webtoon"])

    # 10. Cómic / Novela Gráfica
    es_comic_explicito = contiene_palabra(texto_combinado, ["comic", "novela gráfica", "novela grafica", "viñeta", "viñetas", "historieta", "bold line art"])

    # 11. Historias de Negocios y Finanzas
    es_finanzas = contiene_palabra(texto_combinado, ["dinero", "millonario", "negocio", "pobre", "deudas", "empresa", "éxito", "inversión", "inversiones"])

    # 0. Detección de Canales de Animación por Código / Motion Graphics (Ej: Acertijos, Lógica, Diagramas)
    es_acertijos_logica = (
        contiene_palabra(texto_combinado, [
            "acertijo", "acertijos", "paradoja", "paradojas", "problema matemático", "teoría de grafos",
            "espacio de estados", "geometría", "geometria", "pentágonos", "pentagonos",
            "granjero", "cajas", "canicas", "acertijos visuales", "matemática", "matemático", "lógica"
        ]) or
        contiene_palabra(canal_principal.lower(), ["acertijo", "paradoja", "puzzle", "math", "logic", "pixel"])
    )

    es_codigo_motion = (
        es_tech_ia or
        es_acertijos_logica or
        contiene_palabra(texto_combinado, ["hyperframes", "motiongraphics", "canvas", "css animation", "three.js", "manim", "programado"])
    )

        # ASIGNACIÓN DE PIPELINE DE PRODUCCIÓN, IDENTIDAD Y PERSONAJES
    # 0. Prioridad Máxima: Disección Audiovisual Multimodal / Visión IA
    # 0. Prioridad Máxima: Avatar / Mascota Antropomórfica (Mr. Pato / Rico McPato)
    if dd.get("estilo_visual_id") == "cartoon_hibrido" or any(k in canal_principal.lower() for k in ["pato", "mrpato", "mr.pato", "duck", "scrooge", "mcduck"]):
        tipo_nicho = dd.get("tipo_nicho") or "Historias de Negocios, Mentalidad y Psicología Financiera con Avatar Animado"
        estilo_id = "cartoon_hibrido"
        tipo_produccion = "ia_generativa"
        requiere_prompts_imagen = True
        pipeline_nombre = "Producción 3D Híbrida (Midjourney / Flux + Veo / Kling / Flow)"
        pipeline_descripcion = "Animación híbrida con mascota antropomórfica 3D integrada en escenarios fotorrealistas de negocios y figuras de autoridad. La consistencia se fija con la imagen madre del personaje (--cref) y los clips de video se animan con Veo o Kling."
        formula_recomendada = "voz_en_off"
        # Casillero 1: Personaje Detectado (Referencia del Canal analizado)
        personaje_1_desc = dd.get("personaje_1_desc") or "Mascota Detectada (Referencia): Pato Antropomórfico en Chaqueta Roja de Terciopelo (Red Suit Jacket), Chistera y Bastón"
        personaje_1_base = dd.get("personaje_1_prompt") or "Character reference portrait of an anthropomorphic white cartoon duck in Victorian haute couture, wearing a luxury tailored red suit jacket with polished gold buttons, tall black silk top hat with crimson band, white spats, holding a polished golden walking stick, sharp confident and wealthy expression, vibrant cinematic 3D CGI stylized render composited in photorealistic luxury office, dramatic warm lighting, 8k resolution"
        personaje_1_prompt = personaje_1_base if "--ar" in personaje_1_base else f"{personaje_1_base}, {ESTILOS_VISUALES['cartoon_hibrido']['sufijo']}"

        # Casillero 2: Personaje Sugerido Diferenciado (Tu Marca Propia Anti-Copyright)
        personaje_sugerido_desc = dd.get("personaje_sugerido_desc") or "Mascota Sugerida (Marca Propia): Pato Ejecutivo en Traje Sastre Azul Medianoche, Chaleco Plateado, Monóculo Dorado y Reloj de Bolsillo"
        personaje_sugerido_base = dd.get("personaje_sugerido_prompt") or "Character reference portrait of an anthropomorphic white cartoon duck in bespoke modern executive attire, wearing an elegant tailored midnight navy blue suit jacket with charcoal satin lapels, silver silk waistcoat, polished gold pocket watch chain, sophisticated golden monocle, sharp ambitious expression, vibrant cinematic 3D CGI stylized render integrated into a photorealistic modern high-rise penthouse office, dramatic atmospheric lighting, 8k resolution"
        personaje_sugerido_prompt = personaje_sugerido_base if "--ar" in personaje_sugerido_base else f"{personaje_sugerido_base}, {ESTILOS_VISUALES['cartoon_hibrido']['sufijo']}"

        # Personaje Secundario / Mentor de Apoyo
        personaje_2_desc = dd.get("personaje_2_desc") or "Mentor de Negocios / Figura de Autoridad (Inversionista Realista)"
        personaje_2_base = dd.get("personaje_2_prompt") or "Character reference portrait of a distinguished elderly billionaire mentor in classic dark grey business suit and glasses, sitting in an opulent mahogany executive office filled with stacks of cash, realistic cinematic lighting, 35mm lens"
        personaje_2_prompt = personaje_2_base if "--ar" in personaje_2_base else f"{personaje_2_base}, {ESTILOS_VISUALES['cartoon_hibrido']['sufijo']}"

    elif dd.get("estilo_visual_id") == "pixar_3d":
        tipo_nicho = dd.get("tipo_nicho") or "Micro-momentos de Parejas, Ternura y Humor Relatable (Animación 3D)"
        estilo_id = "pixar_3d"
        tipo_produccion = "ia_generativa"
        requiere_prompts_imagen = True
        pipeline_nombre = "Producción Cinematográfica 3D (Flux / Midjourney + Veo / Kling)"
        pipeline_descripcion = "Animación 3D gestual y diseño sonoro. Cero voz en off hablada; la narrativa se transmite mediante texto en pantalla (POV) y efectos Foley naturales (pasos, abrazos, besos, cubiertos) sobre música cálida de fondo."
        formula_recomendada = "foley_diegetico" if not tiene_locucion else "voz_en_off"
        # Casillero 1
        personaje_1_desc = dd.get("personaje_1_desc") or "Personaje Detectado (Referencia): Suricata Hembra en Animación 3D con Flor Rosada en la Oreja"
        personaje_1_base = dd.get("personaje_1_prompt") or "Character reference portrait of an adorable female meerkat in 3D stylized animation studio render, big glossy expressive eyes, soft fine cream and light grey fur, tiny pink flower behind her left ear, warm cinematic lighting, octane render, 8k"
        personaje_1_prompt = personaje_1_base if "--ar" in personaje_1_base else f"{personaje_1_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

        # Casillero 2
        personaje_sugerido_desc = dd.get("personaje_sugerido_desc") or "Personaje Sugerido (Marca Propia): Mascota Femenina Tierna con Chaleco Lavanda Artesanal o Lazo Aguamarina"
        personaje_sugerido_base = dd.get("personaje_sugerido_prompt") or "Character reference portrait of an adorable fluffy animal character in 3D stylized animation studio render, big emotive glossy eyes, soft warm cream and caramel fur, wearing a tiny handcrafted lavender knit vest, warm cozy studio lighting, octane render, 8k"
        personaje_sugerido_prompt = personaje_sugerido_base if "--ar" in personaje_sugerido_base else f"{personaje_sugerido_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

        # Personaje Secundario
        personaje_2_desc = dd.get("personaje_2_desc") or "Compañero Tierno (Suricata Macho en Animación 3D)"
        personaje_2_base = dd.get("personaje_2_prompt") or "Character reference portrait of a cute male meerkat in 3D stylized animation studio render, warm golden brown fluffy fur, big curious expressive eyes, animated playful affectionate expression, octane render, 8k"
        personaje_2_prompt = personaje_2_base if "--ar" in personaje_2_base else f"{personaje_2_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

    elif dd.get("es_codigo_motion"):
        tipo_produccion = "codigo_motion"
        requiere_prompts_imagen = False
        pipeline_nombre = "Animación Programada por Código (Motion Graphics / Librerías)"
        pipeline_descripcion = "Este canal no utiliza imágenes generadas por IA ni modelos como Midjourney o Veo. Toda la visualización se construye dinámicamente mediante código y librerías gráficas (HTML5 Canvas, animaciones CSS o scripts en Python con FFmpeg)."
        estilo_id = "codigo_motion"
        formula_recomendada = "voz_en_off"
        tipo_nicho = dd.get("tipo_nicho") or "Tecnología, Inteligencia Artificial y Herramientas Digitales (Motion Graphics)"
        personaje_1_desc = "Cero Personajes de Imagen IA (Elementos visuales generados por código)"
        personaje_1_base = "Visualización programática."
        personaje_1_prompt = "N/A - Producción 100% por código."
        personaje_2_desc = "Cero Personajes de Imagen IA"
        personaje_2_base = "Visualización programática."
        personaje_2_prompt = "N/A - Producción 100% por código."

    elif es_codigo_motion:
        tipo_produccion = "codigo_motion"
        requiere_prompts_imagen = False
        pipeline_nombre = "Animación Programada por Código (Motion Graphics / Librerías)"
        pipeline_descripcion = "Este canal no utiliza imágenes generadas por IA ni modelos como Midjourney o Veo. Toda la visualización se construye dinámicamente mediante código y librerías gráficas (HTML5 Canvas, animaciones CSS o scripts en Python con FFmpeg)."
        estilo_id = "codigo_motion"
        formula_recomendada = "voz_en_off"

        if es_acertijos_logica:
            tipo_nicho = "Acertijos Lógicos, Geometría y Paradojas Visuales (Animación por Código)"
        else:
            tipo_nicho = "Tecnología, Inteligencia Artificial y Herramientas Digitales (Motion Graphics)"

        personaje_1_desc = "Cero Personajes de Imagen IA (Elementos visuales generados por código)"
        personaje_1_base = "Visualización programática: vectores, diagramas, gráficas o interfaces dibujadas mediante código o librerías gráficas."
        personaje_1_prompt = "N/A - Producción 100% por código."
        personaje_2_desc = "Cero Personajes de Imagen IA"
        personaje_2_base = "Visualización programática."
        personaje_2_prompt = "N/A - Producción 100% por código."

    # 1. Tecnología, IA y Software (Fallback generativo)
    elif es_tech_ia:
        tipo_nicho = "Tecnología, Inteligencia Artificial y Herramientas Digitales"
        estilo_id = "tech_moderno"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Especialista Tech / Creador Digital (Presentador de innovaciones y software)"
        personaje_1_base = "Character reference portrait: A modern tech creator in their late 20s, observant confident gaze, wearing a clean minimalist charcoal hoodie or tech jacket, surrounded by subtle glowing digital UI elements, sleek modern workspace backdrop, 8k cinematic portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['tech_moderno']['sufijo']}"

        personaje_2_desc = "Consultor / Desarrollador Senior (Experto en programación y sistemas)"
        personaje_2_base = "Character reference portrait: A senior software architect with analytical expression, minimalist stylish dark glasses, clean tech casual attire, modern high-tech studio environment, 8k portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['tech_moderno']['sufijo']}"

    # 2. Terror y Suspenso
    elif es_terror:
        tipo_nicho = "Misterios, Casos Inexplicables y Suspenso"
        estilo_id = "terror_misterio"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Narrador de Misterio / Investigador Paranormal"
        personaje_1_base = "Character reference portrait: An investigative journalist with intense focused gaze, dark vintage trench coat, moody atmospheric ambient lighting, cinematic mystery composition"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['terror_misterio']['sufijo']}"

        personaje_2_desc = "Figura Enigmática / Testigo del Suceso"
        personaje_2_base = "Character reference portrait: A shadowy enigmatic figure with pale features, observant chilling expression, shrouded in cool mist, dramatic low-key rim lighting"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['terror_misterio']['sufijo']}"

    # 3. Historia Universal
    elif es_historia:
        tipo_nicho = "Historia Universal, Civilizaciones y Grandes Batallas"
        estilo_id = "documental_historico"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Cronista Histórico / Estratega de Época"
        personaje_1_base = "Character reference portrait: An authoritative historical narrator or general with weathered determined expression, authentic historical attire, warm dramatic cinematic lighting, rich textures"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['documental_historico']['sufijo']}"

        personaje_2_desc = "Gobernante / Líder Histórico"
        personaje_2_base = "Character reference portrait: A dignified imperial ruler with stoic commanding posture, intricate classical royal vestments, Rembrandt atmospheric lighting, 8k portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['documental_historico']['sufijo']}"

    # 4. Gaming / Bloques Cartoon
    elif es_roblox_o_gaming:
        tipo_nicho = "Comedia y Animación en Bloques 3D (Gaming & Cartoon)"
        estilo_id = "roblox_3d"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Bloque (Avatar cúbico con traje marrón)"
        personaje_1_base = "Character reference portrait: A blocky cartoon avatar, modular cubic anatomy, brown combed hair on a cylindrical block head, simple painted smile decal face with big expressive cartoon eyes, wearing a brown blocky suit jacket with dark buttons, white collared shirt, smooth plastic toy finish, bright room interior background"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['roblox_3d']['sufijo']}"

        personaje_2_desc = "Compañero / Segundo Personaje Bloque (Avatar casual con sudadera)"
        personaje_2_base = "Character reference portrait: A blocky cartoon avatar, modular cubic anatomy, cylindrical head with expressive facial decals, wearing a casual colorful hoodie and blocky denim pants, smooth plastic toy finish, bright room background"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['roblox_3d']['sufijo']}"

    # 5. Minecraft / Voxel
    elif es_minecraft:
        tipo_nicho = "Historias y Aventuras en Bloques (Minecraft / Voxel)"
        estilo_id = "minecraft_voxel"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Aventurero Cúbico (Estilo Minero Pixelado)"
        personaje_1_base = "Character reference portrait: A blocky adventurer character, pixelated cubic head and body, wearing a classic blue shirt and dark blue pants, expressive pixel-art face, clean voxel geometry"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['minecraft_voxel']['sufijo']}"

        personaje_2_desc = "Aldeano / Compañero Cúbico"
        personaje_2_base = "Character reference portrait: A voxel-style cubic companion character in rustic brown robes, blocky geometry, soft volumetric ambient lighting"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['minecraft_voxel']['sufijo']}"

    # 6. Animación 3D Didáctica / Simulaciones Científicas
    elif es_simulaciones_3d:
        tipo_nicho = "Curiosidades, Ciencia y Simulaciones 3D Didácticas"
        estilo_id = "zack_d_films"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista / Sujeto 3D (Joven explicador)"
        personaje_1_base = "Character reference portrait: A stylized 3D animated young man, expressive curious face with big emotive eyes, short neat brown hair, wearing a casual vibrant blue t-shirt or hoodie, clean stylized anatomy, neutral educational studio backdrop, 3D CGI character portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['zack_d_films']['sufijo']}"

        personaje_2_desc = "Especialista / Demostrador 3D (Científico, Cirujano o Asistente)"
        personaje_2_base = "Character reference portrait: A stylized 3D animated secondary character / demonstrator, wearing a clean professional lab coat or instructor uniform, holding scientific demonstration tools, expressive instructional posture, neutral educational background, 3D CGI character portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['zack_d_films']['sufijo']}"

    # 7. Estrategias de Marketing y Secretos Comerciales
    elif es_marketing_negocios:
        tipo_nicho = "Estrategias de Marketing, Psicología de Consumo y Negocios"
        estilo_id = "dark_noir"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Analista de Mercado / Investigador (El que plantea la revelación)"
        personaje_1_base = "Character reference portrait: A sharp 28-year-old market investigator with observant eyes, wearing a modern dark blazer, neutral studio backdrop with dramatic contrast, consistent character design portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['dark_noir']['sufijo']}"

        personaje_2_desc = "Estratega Comercial / El Mentor de Negocios"
        personaje_2_base = "Character reference portrait: A 40-year-old seasoned business strategist with piercing analytical gaze, tailored minimalist charcoal coat, dramatic rim lighting, neutral studio background, consistent character design portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['dark_noir']['sufijo']}"

    # 8. Fábulas de Animales
    elif es_animales:
        tipo_nicho = "Fábulas de Animales y Reflexión Humana"
        estilo_id = "pixar_3d"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Animal Sabio / Noble (Trabajador humilde)"
        personaje_1_base = "Character reference sheet: An anthropomorphic noble bull / elderly craftsman with warm expressive eyes, wearing humble working clothes, dignified humble posture, clean character design portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

        personaje_2_desc = "Animal Antagonista (Arrogante o egoísta)"
        personaje_2_base = "Character reference sheet: An arrogant antagonist animal character with sharp condescending expression, wearing stylish expensive clothes, proud boastful posture, clean character design portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['pixar_3d']['sufijo']}"

    # 9. Anime / Manga
    elif es_anime:
        tipo_nicho = "Historias y Leyendas en Estilo Anime"
        estilo_id = "anime_moderno"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Shonen (Joven determinado)"
        personaje_1_base = "Character reference portrait: A young anime protagonist with determined sharp eyes, modern stylish jacket, clean anime character design"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['anime_moderno']['sufijo']}"

        personaje_2_desc = "Mentor o Rival Anime"
        personaje_2_base = "Character reference portrait: An experienced anime mentor with calm stoic expression, dark coat, dramatic anime rim lighting"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['anime_moderno']['sufijo']}"

    # 10. Cómic / Novela Gráfica
    elif es_comic_explicito:
        tipo_nicho = "Reflexión en Estilo Novela Gráfica (Cómic)"
        estilo_id = "comic"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Humilde (Línea Cómic)"
        personaje_1_base = "Character reference portrait: A gentle humble person with expressive emotional gaze, simple everyday clothing, clean character design portrait"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['comic']['sufijo']}"

        personaje_2_desc = "Antagonista (Línea Cómic)"
        personaje_2_base = "Character reference portrait: A proud person in luxurious clothing, dismissive facial expression, clean character design portrait"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['comic']['sufijo']}"

    # 11. Historias de Negocios y Finanzas
    elif es_finanzas:
        tipo_nicho = "Historias de Negocios y Finanzas Personales"
        estilo_id = "realismo_cinematografico"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "El Emprendedor Humilde"
        personaje_1_base = "Character reference portrait: A hardworking young entrepreneur in simple modest attire, focused determined expression, natural realistic textures"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

        personaje_2_desc = "El Inversor / Corporativo Arrogante"
        personaje_2_base = "Character reference portrait: A wealthy corporate executive in luxury tailored suit, smug cynical expression, realistic depth of field"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

    # 12. Fallback general: Realismo Cinematográfico
    else:
        tipo_nicho = "Reflexión Emocional, Historias Humanas y Lecciones de Vida"
        estilo_id = "realismo_cinematografico"
        formula_recomendada = "voz_en_off"
        personaje_1_desc = "Protagonista Humilde (Persona trabajadora y digna)"
        personaje_1_base = "Character reference portrait: A gentle humble person with expressive emotional gaze, simple everyday clothing, dignified natural posture"
        personaje_1_prompt = f"{personaje_1_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

        personaje_2_desc = "Antagonista (Persona vanidosa o arrogante)"
        personaje_2_base = "Character reference portrait: A proud person in luxurious clothing, dismissive haughty facial expression, dramatic contrast"
        personaje_2_prompt = f"{personaje_2_base}, {ESTILOS_VISUALES['realismo_cinematografico']['sufijo']}"

    # Asegurar Casillero 2: Personaje Sugerido Diferenciado para Marca Propia
    if "personaje_sugerido_desc" not in locals() or not personaje_sugerido_desc:
        if dd.get("personaje_sugerido_desc"):
            personaje_sugerido_desc = dd.get("personaje_sugerido_desc")
            personaje_sugerido_base = dd.get("personaje_sugerido_prompt") or personaje_1_base
        else:
            p1_limpio = personaje_1_desc.replace("Personaje Detectado (Referencia): ", "").replace("Mascota Detectada (Referencia): ", "")
            personaje_sugerido_desc = f"Personaje Sugerido (Marca Propia): {p1_limpio} con Vestimenta Personalizada y Estilo Propio"
            personaje_sugerido_base = f"{personaje_1_base}, customized original wardrobe variation, distinctive signature styling, unique personal branding"
        personaje_sugerido_prompt = personaje_sugerido_base if "--ar" in personaje_sugerido_base else f"{personaje_sugerido_base}, {ESTILOS_VISUALES[estilo_id]['sufijo']}"

    # Sanitización estricta anti-copyright para evitar bloqueos en Midjourney, Flux y DALL-E
    try:
        from core.diseccion_multimodal import sanitizar_prompts_copyright
        personaje_1_prompt = sanitizar_prompts_copyright(personaje_1_prompt)
        personaje_1_base = sanitizar_prompts_copyright(personaje_1_base)
        personaje_1_desc = sanitizar_prompts_copyright(personaje_1_desc)
        personaje_sugerido_prompt = sanitizar_prompts_copyright(personaje_sugerido_prompt)
        personaje_sugerido_base = sanitizar_prompts_copyright(personaje_sugerido_base)
        personaje_sugerido_desc = sanitizar_prompts_copyright(personaje_sugerido_desc)
        personaje_2_prompt = sanitizar_prompts_copyright(personaje_2_prompt)
        personaje_2_base = sanitizar_prompts_copyright(personaje_2_base)
        personaje_2_desc = sanitizar_prompts_copyright(personaje_2_desc)
    except Exception:
        pass

    estilo_sel = ESTILOS_VISUALES[estilo_id]

    score = 95
    puntos_fuertes = [
        "Voz en off y diálogos: Compatibles al 100% con la clonación y síntesis de voz.",
        "Visuales basados en escenas de alta retención: Se generan con Veo, Grok, Midjourney o Flow (~3 a 5s por toma).",
        "Formato y subtítulos: Compatible 100% con el creador y subtitulador dinámico del sistema."
    ]

    if formato_vert:
        puntos_fuertes.append("Formato vertical 9:16 (Reels/TikTok/Shorts): Máximo alcance y retención.")
    else:
        puntos_fuertes.append("Formato horizontal o historias largas: Excelente para monetización en Facebook/YouTube.")

    recomendaciones = [
        f"Estilo Visual: Mantén el sufijo '{estilo_sel['nombre']}' en todos tus prompts para darle una identidad de marca coherente a tu canal.",
        "Consistencia de Personajes: Genera primero la 'imagen madre' de tus 2 personajes y úsala como referencia visual (--cref) en cada escena.",
        "Gancho de inicio: Si usas la fórmula de diálogo, haz que los primeros 5 a 6 segundos planteen el conflicto o la pregunta clave de inmediato."
    ]

    ejemplos_guiones = []
    for v in validos:
        txt = v.get("guion") or v.get("descripcion") or v.get("titulo")
        if txt:
            ejemplos_guiones.append({
                "titulo": v.get("titulo", "Video"),
                "extracto": txt[:450].strip() + ("..." if len(txt) > 450 else ""),
                "vistas": v.get("vistas", 0)
            })

        # =========================================================================
    # GENERACIÓN DE INSTRUCCIONES MAESTRAS 100% ADAPTADAS AL NICHO ESPECÍFICO
    # (Cero acotaciones, cero marcas privadas, cero menciones a herramientas privadas ni proyectos ajenos)
    # =========================================================================

    # 1. Estructura de retención específica según temática del canal
    if es_acertijos_logica:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO Y DILEMA VISUAL): Plantea de inmediato el acertijo, problema o paradoja en las primeras 5 a 8 palabras ("El 99% responde mal este acertijo...", "Parece imposible pero tiene una solución lógica...", "¿Puedes resolver este dilema antes de que termine el video?").
2. SEGUNDO 5 A 25 (LA TRAMPA COGNITIVA): Muestra la respuesta intuitiva que casi todos darían y explica con claridad por qué esa intuición falla.
3. SEGUNDO 25 A 45 (DEMOSTRACIÓN Y SOLUCIÓN LÓGICA): Desarrolla el paso a paso matemático o geométrico que resuelve el problema de forma irrefutable.
4. SEGUNDO 45 A 55 (CIERRE Y RETO): "Comenta tu respuesta y comparte este video para retar a tus amigos"."""
        rol_especialista = "Experto en Acertijos Lógicos, Paradojas Visuales y Desafíos Matemáticos"

    elif es_tech_ia:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO EXPLOSIVO): Inicia de inmediato con el descubrimiento o herramienta ("Alguien acaba de publicar una herramienta que...", "Si usas IA para trabajar, esto te va a ahorrar horas...", "Acaban de lanzar un método que casi nadie conoce...").
2. SEGUNDO 5 A 25 (CÓMO FUNCIONA EN 3 PASOS): Explicación dinámica, clara y visual de la función clave, sin tecnicismos innecesarios.
3. SEGUNDO 25 A 40 (CASO DE USO REAL): El tip exacto o aplicación práctica para utilizarlo hoy mismo.
4. SEGUNDO 40 A 50 (LLAMADO A LA ACCIÓN): "Guarda este video antes de que lo pierdas y comenta IA para enviarte el enlace directo"."""
        rol_especialista = "Especialista en Retención Viral sobre Inteligencia Artificial, Software y Tecnología"

    elif es_simulaciones_3d:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO EXTREMO): Pregunta impactante sobre un fenómeno físico, médico o biológico ("¿Qué le pasa exactamente a tu cuerpo si...?", "¿Por qué nunca debes...?").
2. SEGUNDO 5 A 25 (EL MECANISMO INTERNO): Explicación visual paso a paso de lo que ocurre dentro del organismo u objeto con lenguaje claro y directo.
3. SEGUNDO 25 A 45 (LA REVELACIÓN INESPERADA): El desenlace fáctico y real que subvierte lo que la mayoría cree.
4. SEGUNDO 45 A 55 (CIERRE): "Comenta qué otra simulación quieres ver en el siguiente video"."""
        rol_especialista = "Experto en Videos Virales de Curiosidades, Ciencia y Simulaciones 3D"

    elif es_finanzas or es_marketing_negocios:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO Y CONTRASTE): Revela el secreto comercial o la trampa invisible ("La estrategia psicológica que usan las empresas para que gastes el doble...", "La diferencia exacta entre cómo piensa un millonario y el 90%...").
2. SEGUNDO 5 A 25 (DESMONTE DE LA ESTRATEGIA): Explicación del mecanismo oculto o sesgo cognitivo detrás de la decisión.
3. SEGUNDO 25 A 45 (EL PRINCIPIO APLICABLE): La lección accionable para proteger tu dinero o potenciar tus resultados.
4. SEGUNDO 45 A 55 (CIERRE): "Comenta NEGOCIO si quieres una segunda parte analizando este caso"."""
        rol_especialista = "Especialista en Psicología de Negocios, Finanzas y Estrategias Comerciales"

    elif es_historia:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO HISTÓRICO): El hecho o la paradoja más insólita en las primeras 5 a 8 palabras ("En 1453, una sola puerta abierta decidió el destino de un imperio...", "El hombre que engañó a un ejército completo sin disparar una bala...").
2. SEGUNDO 5 A 30 (LA ESCALADA DE LOS HECHOS): Tensión creciente y decisiones críticas de los protagonistas.
3. SEGUNDO 30 A 45 (EL GIRO INESPERADO): El desenlace real y su impacto histórico.
4. SEGUNDO 45 A 55 (CIERRE): "Comenta HISTORIA para descubrir más sucesos que no te contaron en los libros"."""
        rol_especialista = "Narrador Documental de Historia Oculta, Civilizaciones y Estrategia Militar"

    elif es_terror:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO INQUIETANTE): Advertencia o premisa perturbadora ("Si alguna vez encuentras esto en tu puerta, jamás lo toques...", "Lo que descubrieron en esa cabaña abandonada nadie ha podido explicarlo...").
2. SEGUNDO 5 A 30 (CONSTRUCCIÓN DE TENSIÓN): Detalles sensoriales concretos que aceleran la intriga.
3. SEGUNDO 30 A 45 (EL CLÍMAX): El momento cumbre del suceso inexplicable.
4. SEGUNDO 45 A 55 (CIERRE): "Comenta MISTERIO si te atreves a conocer el caso completo"."""
        rol_especialista = "Guionista Audiovisual de Misterio, Relatos Psicológicos y Casos Inexplicables"

    elif es_animales:
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO / CONFLICTO DETONANTE): Confrontación directa entre dos fuerzas o actitudes opuestas.
2. SEGUNDO 5 A 35 (NUDO Y DESARROLLO): La respuesta serena o astuta ante la arrogancia o la adversidad.
3. SEGUNDO 35 A 45 (REVELACIÓN O MORALEJA VIVA): El resultado que equilibra la balanza sin necesidad de discursos largos.
4. SEGUNDO 45 A 55 (CIERRE): "Comparte esta enseñanza con quien necesite recordar este valor"."""
        rol_especialista = "Maestro Narrador de Fábulas y Sabiduría Animal"
    elif estilo_id == "cartoon_hibrido" or dd.get("estilo_visual_id") == "cartoon_hibrido":
        estructura_retencion = """1. SEGUNDO 0 A 4 (GANCHO Y CONTRASTE VISUAL): El personaje abre con una verdad incómoda o revelación psicológica contundente sobre dinero, éxito o patrones familiares ("La persona que mejor le va en la familia es la que se atrevió a...", "La diferencia exacta entre cómo piensa un millonario y el 90%...").
2. SEGUNDO 5 A 25 (DESMONTE DEL PATRÓN / ESTRATEGIA): El personaje principal interactúa en la escena con el mentor de negocios explicando el mecanismo psicológico o sesgo cognitivo.
3. SEGUNDO 25 A 45 (LA LECCIÓN ACCIONABLE): El principio práctico para romper el molde o proteger tu patrimonio.
4. SEGUNDO 45 A 55 (CIERRE VIRAL): Pregunta incómoda y llamado a la acción ("¿Estás construyendo la vida que elegiste o repitiendo el guion que heredaste? Comenta RIQUEZA si estás listo para cambiarlo")."""
        rol_especialista = "Director Creativo y Guionista de Psicología de Negocios y Finanzas con Avatar Animado"
    elif estilo_id == "pixar_3d" or dd.get("estilo_visual_id") == "pixar_3d":
        estructura_retencion = f"""1. SEGUNDO 0 A 3 (TEXTO GANCHO EN PANTALLA): Frase relatable o cómica que active identificación inmediata (ej: "{texto_pantalla_ej or 'Cuando finge estar molesta pero sabe que la harás sonreír en 3 segundos'}").
2. SEGUNDO 3 A 20 (INTERACCIÓN EXPRESIVA 3D): Micro-acción tierna entre los personajes (cosquillas, miradas pícaras, acercamiento o gestos exagerados de ternura).
3. SEGUNDO 20 A 30 (DESENLACE Y REMATE EMOCIONAL): La sonrisa cómplice o abrazo que desarma la situación + llamado a etiquetar a esa persona especial en comentarios."""
        rol_especialista = "Director de Arte y Creador de Micro-Animaciones 3D Virales (Estilo Pixar / Parejas y Ternura)"

    else:
        estructura_retencion = f"""1. SEGUNDO 0 A 4 (GANCHO INSTANTÁNEO): Arranca directamente en las primeras 5 a 8 palabras con la premisa, curiosidad o dilema clave del canal "{canal_principal}". Cero introducciones ni saludos.
2. SEGUNDO 5 A 35 (DESARROLLO DINÁMICO): Oraciones breves de 3 a 5 segundos con avance constante de información novedosa.
3. SEGUNDO 35 A 45 (EL DESENLACE O REVELACIÓN): El remate más potente o giro culminante.
4. SEGUNDO 45 A 55 (LLAMADO A LA ACCIÓN): Llamado directo a compartir o comentar una palabra clave relacionada con el video."""
        rol_especialista = f'Guionista de Élite y Experto en Retención Viral para el nicho "{tipo_nicho}"'

    # 2. Instrucción Maestra para Shorts (15s a 30s) — Protocolo Modular de 5.00s
    if estilo_id == "pixar_3d" and not tiene_locucion:
        instruccion_shorts = f"""# INSTRUCCIÓN MAESTRA PARA IA — PROTOCOLO SHORTS SIN VOZ EN OFF (FOLEY DIEGÉTICO)
> **Canal de Referencia:** {canal_principal} | **Nicho:** {tipo_nicho} | **Formato:** Visual Storytelling en Bloques de 5.00s + Foley + Texto POV (CERO Voz en Off) | **Estilo Visual:** {estilo_sel['nombre']}

Eres un director cinematográfico especializado en animación 3D corta y narrativa silente (estilo Pixar/Illumination con diseño de sonido Foley diegético).
Tu misión es crear un Storyboard técnico para 3 Shorts de 15 a 20 segundos sin voz en off, estructurados en tomas modulares de 5.00 segundos exactos (óptimo para Google Flow / Veo).

Para el canal de referencia "{canal_principal}" con los personajes:
- Personaje 1 (P1): {personaje_1_desc}
- Personaje 2 (P2): {personaje_2_desc}

REGLAS DE PRODUCCIÓN:
1. CERO LOCUCIÓN NI SÍNTESIS TTS: Los personajes no hablan con palabras; se comunican mediante miradas, gestos corporales tiernos, sonrisas, pucheros y caricias.
2. FRASE GANCHO (POV): Una sola frase breve, empática y viral para proyectar en pantalla durante los primeros 4 segundos (ej: "{texto_pantalla_ej or 'POV: Los abrazos son más importantes que cualquier quehacer 🤍'}").
3. BLOQUES TEMPORALES DE 5.00s: Cada toma dura 5.00 segundos exactos para montaje matemático inmediato en sincronia.txt.
4. DISEÑO DE SONIDO (FOLEY DIEGÉTICO): Efectos naturales y orgánicos de las acciones físicas sincronizadas (pasos de patitas, cubiertos, cojín de sofá, beso suave 'muah', fricción de pelaje).

FORMATO ESTRICTO DE ENTREGA (STORYBOARD TÉCNICO MODULAR):
==========================================================
SHORT: 01
FRASE GANCHO (POV): [Frase breve y viral para proyectar de 00:00 a 00:04]

DESGLOSE SECUENCIAL (TOMAS DE 5.00s):
- TOMA 1 (00:00 - 00:05 | Introducción):
  * Acción Visual 3D: [Acción cotidiana con P1 y P2 en entorno base]
  * Plano de Cámara: [Ej: Plano medio con ligero push-in suave]
  * Efecto Foley Clave: [Ej: Tac-tac-tac suave de cubiertos, patitas en el piso]
- TOMA 2 (00:05 - 00:10 | Desarrollo / Tensión cómica o puchero):
  * Acción Visual 3D: [Reacción expresiva de reclamo, puchero o sorpresa]
  * Plano de Cámara: [Ej: Primer plano con ángulo contrapicado suave]
  * Efecto Foley Clave: [Ej: Cojín que cede 'puff', suspiro tierno 'hmpf']
- TOMA 3 (00:10 - 00:15 | Clímax y Reconciliación tierna):
  * Acción Visual 3D: [Gesto resolutivo: beso en la nariz/mejilla, abrazo apretado]
  * Plano de Cámara: [Ej: Primer plano íntimo con bokeh y luz cálida]
  * Efecto Foley Clave: [Ej: Beso suave 'muah', fricción de pelaje esponjoso]

PISTA MUSICAL RECOMENDADA: [Piano acústico dulce, ukelele lo-fi o cuerdas cálidas]
CALL TO ACTION (COMENTARIOS): [Llamado para etiquetar a su persona especial]

SHORT: 02
[Misma estructura modular con otra situación cotidiana]

SHORT: 03
[Misma estructura modular con otra situación cotidiana]
"""
    else:
        instruccion_shorts = f"""# INSTRUCCIÓN MAESTRA PARA IA — GUIONES VIRALES SHORTS (30s – 75s)
> **Canal de Referencia:** {canal_principal} | **Nicho:** {tipo_nicho} | **Formato:** Narración Continua en Voz en Off | **Estilo Visual:** {estilo_sel['nombre']}

Actúa como un {rol_especialista} para videos verticales (TikTok, YouTube Shorts, Reels).
Tu misión es redactar 3 guiones originales de alta retención basados en la fórmula y estilo del canal "{canal_principal}" ({tipo_nicho}).

ESTRUCTURA OBLIGATORIA DE CADA GUION:
{estructura_retencion}

🔒 REGLA DE ORO: CONSISTENCIA DEL PERSONAJE PRINCIPAL (FIJO EN CADA ESCENA):
Si tu canal utiliza un avatar, mascota o protagonista recurrente (como Mr. Pato, Ojos de Lobo o tu avatar 3D):
- Personaje Original Detectado: {personaje_1_desc}
- Personaje Sugerido para tu Canal (Marca Propia): {personaje_sugerido_desc}
  Prompt Base Sugerido: {personaje_sugerido_prompt}
(Esta definición visual vive de forma fija y permanente en esta instrucción maestra. Recomendamos utilizar el Personaje Sugerido para crear tu propia identidad sin copiar al creador original. En cada guion o prompt de escena, la fisonomía, vestimenta y rasgos base del personaje se repiten idénticos palabra por palabra. Solo varían sus micro-acciones, expresiones y fondos. Prohibido usar marcas comerciales o nombres con copyright en los prompts para que Midjourney, Flux y DALL-E no censuren la generación).

REGLAS FUNDAMENTALES DE VOZ EN OFF (LOCUCIÓN CONTINUA):
1. NARRADOR ÚNICO: Todo el guion es narración hablada continua de un solo locutor. PROHIBIDO incluir "Narrador:", nombres de personajes o acotaciones entre corchetes.
2. LOCUCIÓN LIMPIA: Escribe únicamente el texto continuo que dirá el narrador en voz alta. Prohibido agregar acotaciones teatrales, notas entre paréntesis, indicaciones técnicas ni efectos de sonido.
3. RITMO Y RETENCIÓN: Oraciones ágiles de 3 a 5 segundos con progresión constante de información.
4. EXTENSIÓN: Entre 110 y 140 palabras por guion (~45 a 60 segundos hablados).

FORMATO ESTRICTO DE ENTREGA (TEXTO PLANO, SIN MARKDOWN NI NEGRITAS):
GUION: 01
[Texto completo de la narración en voz en off continua del primer video]

GUION: 02
[Texto completo de la narración en voz en off continua del segundo video]

GUION: 03
[Texto completo de la narración en voz en off continua del tercer video]
"""

    prompt_voz_en_off = instruccion_shorts
    prompt_historia = instruccion_shorts
    prompt_dialogo = instruccion_shorts
    instruccion_shorts_voz_off = instruccion_shorts
    instruccion_shorts_historia = instruccion_shorts
    instruccion_shorts_dialogo = instruccion_shorts

    # 3. Instrucción Maestra para Videos Largos (3 a 8 minutos)
    if estilo_id == "pixar_3d" and not tiene_locucion:
        instruccion_largos = f"""# INSTRUCCIÓN MAESTRA PARA IA — COMPILACIÓN DE MICRO-EPISODIOS TEMÁTICOS (3 A 8 MINUTOS)
> **Canal de Referencia:** {canal_principal} | **Nicho:** {tipo_nicho} | **Formato:** Compilación de Sketches Silentes en Bloques de 20-30s | **Estilo Visual:** {estilo_sel['nombre']}

Actúa como Director Cinematográfico de Series Cortas de Animación 3D para YouTube y Facebook.
En este formato SIN voz en off, un video largo NO es un monólogo, sino una **Compilación de Micro-Episodios Temáticos** (ej: "10 Momentos tiernos que todas las parejas viven", "Un día completo de convivencia: Mañana, Tarde y Noche").

ESTRUCTURA DE LA COMPILACIÓN (8 A 12 MICRO-EPISODIOS):
- Cada micro-episodio dura entre 20 y 30 segundos (4 a 6 clips de 5.00s).
- Cada micro-episodio tiene su propio Título/Separador en pantalla ("Momento 1: La alarma mañanera", "Momento 2: Cocinando juntos").
- Cada sketch tiene su propio arco: Introducción -> Pequeña discordancia/puchero -> Reconciliación con beso/abrazo.
- La música de fondo modula entre sketches para mantener la retención alta.

FORMATO DE ENTREGA:
EPISODIO 01: [Título del sketch]
- POV en Pantalla: [Texto]
- Tomas 1 a 4 (5s cada una): Acción + Foley + Plano de cámara

EPISODIO 02: [Título del sketch]
...
"""
    else:
        instruccion_largos = f"""# INSTRUCCIÓN MAESTRA PARA IA — GUIONES DE FORMATO LARGO (4 A 8 MINUTOS)
> **Canal de Referencia:** {canal_principal} | **Nicho:** {tipo_nicho} | **Objetivo:** Alto Tiempo de Reproducción y RPM

Actúa como un Guionista Audiovisual Senior especializado en narrativa de larga duración para YouTube y Facebook.
Crea un guion completo de formato largo (4 a 8 minutos / 600 a 1100 palabras) para el nicho "{tipo_nicho}", basado en la fórmula y estilo de "{canal_principal}".

ESTRUCTURA DE RETENCIÓN EN 5 BLOQUES:
1. EL GANCHO Y LA PROMESA (0 a 30s): Detonante inicial de alta intriga y la pregunta central que se resolverá al final.
2. CONTEXTO Y DETONANTE (30s a 2m): Planteamiento del problema con ejemplos concretos y ritmo ágil.
3. ESCALADA Y PUNTOS DE GIRO (2m a 4m): Picos de tensión o nuevos descubrimientos cada 60 segundos para evitar que el espectador abandone.
4. EL CLÍMAX Y LA REVELACIÓN (4m a 6m): La pieza clave o explicación definitiva que resuelve la intriga principal.
5. CONCLUSIÓN Y LLAMADO A LA ACCIÓN (6m en adelante): Reflexión final o conclusión memorable + invitación a suscribirse.

REGLAS DE VOZ EN OFF:
1. Locución continua para un solo narrador, sin acotaciones ni corchetes.
2. Lenguaje fluido, inmersivo y directo.

FORMATO DE ENTREGA (TEXTO PLANO):
GUION: 01
[Texto completo de la narración en voz en off continua de todo el video]
"""

    # 4. Instrucción para Prompts de Imagen y Movimiento (Canales de IA Generativa)
    if estilo_id == "pixar_3d" and not tiene_locucion:
        instruccion_prompts = f"""# INSTRUCCIÓN MAESTRA — PROMPTS 3D Y MOVIMIENTO CONTINUO (GOOGLE FLOW / VEO)
> **Canal de Referencia:** {canal_principal} | **Nicho:** {tipo_nicho} | **Estilo Visual:** {estilo_sel['nombre']}

Actúa como Director de Arte 3D y Diseñador de Prompts especializado en la arquitectura de **Google Flow / Veo / Kling**.
Genera los prompts optimizados para la técnica de **Imagen Semilla Única + Prompts de Movimiento Encadenados**.

ESTILO VISUAL BASE:
- Sufijo para IMAGEN: {estilo_sel['sufijo']}
- Sufijo para MOVIMIENTO: {estilo_sel['sufijo_movimiento']}

ADN DE PERSONAJES:
- Personaje 1 (Detectado en Canal - {personaje_1_desc}): {personaje_1_prompt}
- Personaje Sugerido (Recomendado para Marca Propia - {personaje_sugerido_desc}): {personaje_sugerido_prompt}
- Personaje Secundario / Mentor ({personaje_2_desc}): {personaje_2_prompt}

REGLAS DE ORO PARA PROMPTS DE MOVIMIENTO EN FLOW / VEO:
1. NO RE-DESCRIBIR ROPA NI ANATOMÍA: Flow ya tiene la imagen de entrada en el Fotograma Inicial. Si vuelves a escribir "A meerkat with brown fur wearing clothes...", el motor intentará redibujarlo y causará deformidades o glitches.
2. DESCRIBIR EXCLUSIVAMENTE ACCIÓN Y CÁMARA: Escribe verbos de acción física, micro-expresiones y trayectoria de cámara.
   - Correcto: "The character smiles playfully, tilts head, and reaches forward. Subtle push-in camera, warm studio lighting, 3D Pixar animation, smooth 60fps."
3. CERO LIP-SYNC HABLADO: Prohibido "speaking words, mouth open talking". Los personajes son silentes y expresivos.
4. REGLA DE CORTE DE CÁMARA (ENCADENAMIENTO): Máximo 2 a 3 tomas encadenadas por último fotograma. En la toma 4 aplicar un corte de plano (nuevo plano detalle o contraplano) para resetear la nitidez y evitar el generative drift (degradación acumulada).

ARCHIVOS DE SALIDA GENERADOS:
1. `prompts_imagen.txt`: Prompt Semilla en inglés para fijar el escenario y personajes en Modo Imagen (Midjourney / Flux / Flow Imagen).
2. `prompts_movimiento.txt`: Prompts de acción pura en inglés para clips de 5.00s en Modo Vídeo de FlowBatch Pro.
3. `sincronia.txt`: Guía temporal matemática a pasos de 5.00s (# | inicio | fin | dur | cubre).
4. `pov_hook.txt`: Frase gancho para proyectar en los primeros 4 segundos.
5. `prompt_portada.txt`: Miniatura emotiva en primer plano de los dos personajes.
"""
    else:
        instruccion_prompts = f"""# INSTRUCCIÓN MAESTRA — PROMPTS DE IMAGEN Y MOVIMIENTO PARA "{tipo_nicho.upper()}"
> **Canal de Referencia:** {canal_principal} | **Estilo Visual:** {estilo_sel['nombre']}

Actúa como Director de Arte e Ingeniero de Prompts de IA para producción visual (Midjourney, Flux, Grok, Veo 3.1).
Genera los prompts de imagen, movimiento y sincronía temporal para el guion del nicho "{tipo_nicho}".

ESTILO VISUAL Y SUFIJOS:
- Sufijo para IMAGEN: {estilo_sel['sufijo']}
- Sufijo para MOVIMIENTO: {estilo_sel['sufijo_movimiento']}

PERSONAJES BASE (ADN VISUAL):
- Personaje 1 (Detectado en Canal - {personaje_1_desc}): {personaje_1_prompt}
- Personaje Sugerido (Recomendado para Marca Propia - {personaje_sugerido_desc}): {personaje_sugerido_prompt}
- Personaje Secundario / Mentor ({personaje_2_desc}): {personaje_2_prompt}

🔒 REGLA DE ORO DE CONSISTENCIA Y ANTI-COPYRIGHT:
1. ANCLAJE VISUAL PERMANENTE: Para tu canal, utiliza el 'Personaje Sugerido (Marca Propia)' como el protagonista visual principal para evitar reclamos de derechos de autor con el creador original y construir un activo de marca único. En cada escena del video se debe usar exactamente la misma descripción física y de vestuario para garantizar coherencia (--cref en Midjourney o imagen de referencia en Flow/Veo/Kling).
2. PROTECCIÓN ANTI-COPYRIGHT: Los prompts no deben contener nombres comerciales ni marcas protegidas (Disney, Scrooge, etc.) para que los modelos generativos de IA no bloqueen la generación. Utiliza siempre atributos físicos, telas y colores neutros.

REGLAS DE SINCRONIZACIÓN Y LIP-SYNC:
- En MOVIMIENTO: speaking in Latin American Spanish, his/her mouth moving precisely to say "[LÍNEA EXACTA DEL GUION]"
- En IMAGEN: his/her mouth open speaking words, textless, without words.
- En EDICIÓN: La columna `cubre` en sincronia.txt es procesada para cortar la toma donde el diálogo termina.

FORMATO DE ENTREGA OBLIGATORIO:
1. prompts_imagen.txt (prompts en inglés separados por exactamente una línea en blanco)
2. prompts_movimiento.txt (prompts en inglés con lip-sync, separados por una línea en blanco)
3. sincronia.txt (tabla con # | inicio-fin | dur | cubre)
4. prompt_portada.txt (miniatura híbrida: reacción en primer plano + acción de fondo)
"""

    prompt_activo = instruccion_shorts

    estilos_disponibles = [
        {
            "id": k,
            "nombre": v["nombre"],
            "sufijo": v["sufijo"],
            "sufijo_movimiento": v["sufijo_movimiento"],
            "descripcion": v["descripcion"]
        }
        for k, v in ESTILOS_VISUALES.items()
    ]

    # 5. Instrucción para Agente de Código (Animación Vectorial / Motion Graphics)
    instruccion_produccion_codigo = f"""# INSTRUCCIÓN MAESTRA PARA AGENTE DE CÓDIGO (ANTIGRAVITY / CLAUDE CODE / CODEX)
> **Canal:** {canal_principal} | **Nicho:** {tipo_nicho} | **Pipeline:** Animación por Código / Librerías (Sin Imágenes IA)

Actúa como un Ingeniero de Software Creativo y Animador Audiovisual (HTML5 Canvas / CSS Animation / Python PIL & MoviePy / FFmpeg).
Tu misión es generar el código fuente que renderiza la animación visual para el siguiente guion de voz en off.

REGLAS FUNDAMENTALES DE PRODUCCIÓN POR CÓDIGO (ANIMACIÓN VECTORIAL / MOTION GRAPHICS):
1. CERO PROMPTS DE IMAGEN: No generes imágenes estáticas con modelos generativos. Toda la escena se dibuja dinámicamente mediante código vectorial (círculos, nodos, grafos, texto dinámico, interfaces, cajas o demostraciones geométricas).
2. SINCRONIZACIÓN DE AUDIO:
   - Formato de salida: 1080x1920 (Vertical 9:16) a 30 FPS.
   - El código lee el archivo de locución (voz_en_off.mp3) y anima cada elemento en el segundo exacto en que la voz lo explica.
3. MOTOR DE RENDERIZADO RECOMENDADO:
   - Opción A (Python): Script en Python utilizando PIL/OpenCV para dibujar fotogramas y enviarlos por tubería (pipe) directamente a `ffmpeg` con `-c:v libx264` y `-shortest`.
   - Opción B (Web): Archivo HTML5 Canvas / Three.js animado que se captura headless con Playwright/Chromium y se exporta a MP4 con FFmpeg.

GUION DE VOZ EN OFF A ILUSTRAR CON CÓDIGO:
{instruccion_shorts}
"""

    return {
        "ok": True,
        "canal": canal_principal,
        "total_analizados": total_videos,
        "tipo_nicho": tipo_nicho,
        "tipo_produccion": tipo_produccion if "tipo_produccion" in locals() else "ia_generativa",
        "requiere_prompts_imagen": requiere_prompts_imagen if "requiere_prompts_imagen" in locals() else True,
        "pipeline_nombre": pipeline_nombre if "pipeline_nombre" in locals() else "Producción Cinematográfica IA",
        "pipeline_descripcion": pipeline_descripcion if "pipeline_descripcion" in locals() else "Generación visual con modelos generativos (Midjourney/Veo) y montaje dinámico.",
        "instruccion_produccion_codigo": instruccion_produccion_codigo if "instruccion_produccion_codigo" in locals() else "",
        "total_analizados": total_videos,
        "tipo_nicho": tipo_nicho,
        "formato": "Vertical (9:16)" if formato_vert else "Horizontal (16:9)",
        "duracion_promedio": f"{int(dur_prom//60)}m {int(dur_prom%60)}s" if dur_prom >= 60 else f"{int(dur_prom)}s",
        "score_replicabilidad": score,
        "veredicto": "TOTALMENTE COMPATIBLE CON TU GENERADOR",
        "puntos_fuertes": puntos_fuertes,
        "recomendaciones": recomendaciones,
        "videos": validos,
        "ejemplos": ejemplos_guiones,
        "estilo_id": estilo_id,
        "estilos_disponibles": estilos_disponibles,
        # Identidad Visual y Prompts de Personajes
        "identidad_visual": {
            "estilo_id": estilo_id,
            "estilo_nombre": estilo_sel["nombre"],
            "sufijo_estilo": estilo_sel["sufijo"],
            "sufijo_movimiento": estilo_sel["sufijo_movimiento"],
            "descripcion": estilo_sel["descripcion"],
            # Casillero 1: Personaje Principal Detectado (Referencia del Canal analizado)
            "personaje_1_desc": personaje_1_desc,
            "personaje_1_base": personaje_1_base,
            "personaje_1_prompt": personaje_1_prompt,
            # Casillero 2: Personaje Sugerido Diferenciado (Tu Marca Propia)
            "personaje_sugerido_desc": personaje_sugerido_desc,
            "personaje_sugerido_base": personaje_sugerido_base,
            "personaje_sugerido_prompt": personaje_sugerido_prompt,
            # Personaje Secundario / Mentor de Apoyo
            "personaje_2_desc": personaje_2_desc,
            "personaje_2_base": personaje_2_base,
            "personaje_2_prompt": personaje_2_prompt,
            "alerta_copyright": "Para evitar censura en Midjourney v6, Flux y DALL-E, los prompts no usan marcas registradas ni personajes comerciales protegidos (ej. Scrooge McDuck o Disney). Describe únicamente atributos visuales, fisonómicos y textiles puros.",
            "consejos_diferenciacion": "Recomendación de Originalidad: Diferencia a tu mascota cambiando la paleta de colores de su vestimenta (ej. azul marino o verde esmeralda) y agregando accesorios únicos (gafas redondas, reloj de bolsillo de oro, zapatos oxford).",
            "anclaje_personaje_fijo": "Consistencia Fija: La descripción del personaje principal reside fija dentro de tu Instrucción Maestra en todos tus guiones para que la IA conserve siempre el mismo rostro y ropa en cada escena.",
            "instruccion_consistencia": "Genera primero el retrato de cada personaje (imagen madre). Luego en Grok, Midjourney (--cref) o Veo, adjunta esa imagen como referencia visual para que mantenga exactamente el mismo rostro, peinado y ropa en todas las escenas del video."
        },
        "formula_recomendada": formula_recomendada,
        "prompt_maestro": prompt_activo,
        "prompt_voz_en_off": prompt_voz_en_off,
        "prompt_dialogo": prompt_dialogo,
        "prompt_historia": prompt_historia,
        # Las 3 Instrucciones Maestras Adaptadas
        "instruccion_shorts": instruccion_shorts,
        "instruccion_shorts_voz_off": instruccion_shorts_voz_off,
        "instruccion_shorts_historia": instruccion_shorts_historia,
        "instruccion_shorts_dialogo": instruccion_shorts_dialogo,
        "instruccion_largos": instruccion_largos,
        "instruccion_prompts": instruccion_prompts,
        # Kit de Lanzamiento Completo para Redes Sociales
        "kit_lanzamiento": generar_kit_lanzamiento_canal(
            canal_ref=canal_principal,
            tipo_nicho=tipo_nicho,
            estilo_id=estilo_id,
            estilo_nombre=estilo_sel["nombre"],
            personaje_1_desc=personaje_1_desc,
            personaje_1_prompt=personaje_1_prompt,
            formula_recomendada=formula_recomendada,
            texto_pantalla_ej=texto_pantalla_ej,
            personaje_sugerido_desc=personaje_sugerido_desc,
            personaje_sugerido_prompt=personaje_sugerido_prompt
        ),
        # Disección Audiovisual Multimodal
        "fotogramas": fotogramas,
        "tiene_locucion": tiene_locucion,
        "tipo_audio_desc": tipo_audio_desc,
        "analisis_vision_gemini": uso_gemini,
        "titulo_es": titulo_es,
        "formato_guion": formato_guion_dis,
        "texto_pantalla_ejemplo": texto_pantalla_ej
    }


def analizar_enlaces(urls: list, clave_gemini: str = None) -> dict:
    """Función principal llamada desde el backend: analiza una lista de URLs con disección profunda."""
    info_videos = []
    for u in urls:
        u_str = str(u).strip()
        if u_str and (u_str.startswith("http://") or u_str.startswith("https://")):
            info = extraer_info_url(u_str)
            if info:
                info_videos.append(info)

    if not info_videos:
        return {"ok": False, "msg": "No se encontraron URLs válidas para analizar."}

    # Disección audiovisual profunda (muestra descargada, fotogramas y audio)
    diseccion = {}
    try:
        from core.diseccion_multimodal import diseccionar_video_completo
        diseccion = diseccionar_video_completo(info_videos[0]["url"], info_videos[0], clave_gemini=clave_gemini)
    except Exception as ex:
        print(f"Nota: Disección multimodal omitida: {ex}")

    return diagnosticar_nicho(info_videos, diseccion=diseccion)




def analizar_canal(url_o_urls, plataforma="auto", clave_gemini=None, **kwargs) -> tuple:
    """Alias de compatibilidad para llamadas legacy: analiza canal o lista de URLs."""
    if isinstance(url_o_urls, str):
        urls = [url_o_urls]
    else:
        urls = list(url_o_urls)
    res = analizar_enlaces(urls, clave_gemini=clave_gemini)
    ok = res.get("ok", False)
    msg = res.get("msg", "Analisis completado" if ok else "Error al analizar")
    return ok, msg, res


if __name__ == "__main__":
    test_urls = [
        "https://www.youtube.com/shorts/auBCKkY4oK4"
    ]
    diag = analizar_enlaces(test_urls)
    print("Canal:", diag.get("canal"))
    print("Nicho:", diag.get("tipo_nicho"))
    print("Estilo visual detectado:", diag.get("identidad_visual", {}).get("estilo_nombre"))
    print("\nSufijo Estilo:\n", diag.get("identidad_visual", {}).get("sufijo_estilo"))
    print("\nPrompt Personaje 1:\n", diag.get("identidad_visual", {}).get("personaje_1_prompt"))
    print("\nPrompt Personaje 2:\n", diag.get("identidad_visual", {}).get("personaje_2_prompt"))
