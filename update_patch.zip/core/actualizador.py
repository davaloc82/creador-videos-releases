# -*- coding: utf-8 -*-
"""
actualizador.py
----------------
Sistema de Auto-Actualización Silenciosa y en 1 Clic para Clientes.
Permite a David distribuir actualizaciones de código a cientos de usuarios
sin necesidad de que los clientes tengan Git instalado ni pierdan sus licencias.

Reglas de Oro:
1. JAMÁS sobreescribe 'licencia.lic' (la licencia activada del cliente persiste de por vida).
2. JAMÁS sobreescribe 'ai33_config.txt' ni 'nichos_usuario.json' (sus claves y canales se respetan).
3. JAMÁS toca 'PROYECTOS_VIDEO/' (sus proyectos y renders permanecen intactos).
4. Reemplaza únicamente archivos del motor y la interfaz (panel.py, templates, scripts de IA).
"""

import importlib
import io
import json
import os
import shutil
import ssl
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent if AQUI.name == "core" else AQUI
ARCHIVO_VERSION = RAIZ / "version.json"

_CHROME_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

ARCHIVOS_SAGRADOS_USUARIO = {
    "licencia.lic",
    "DATOS_DE_TU_LICENCIA.txt",
    "ai33_config.txt",
    "nichos_usuario.json",
    "licencias_registradas.json",
    "licencias_emitidas.json",
    "config_gemini.json",
    "gemini_config.json",
    "cuentas_redes.json",
    "historial_analisis_nichos.json",
    "hardware_config.json",
}


def _descargar_con_reintentos(url: str, timeout: int = 15) -> bytes:
    """
    Descarga una URL agregando cache-buster para evitar cachés de Fastly/GitHub
    e implementa bypass de certificados SSL si el antivirus del cliente interfiere.
    """
    sep = "&" if "?" in url else "?"
    url_fresca = f"{url}{sep}_t={int(time.time() * 1000)}"

    req = urllib.request.Request(
        url_fresca,
        headers={
            "User-Agent": _CHROME_UA,
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Accept": "*/*"
        }
    )

    # 1. Intentar primero con SSL estándar
    try:
        ctx_std = ssl.create_default_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx_std) as resp:
            return resp.read()
    except Exception as e1:
        # 2. Si falla por SSL/antivirus, reintentar con SSL no verificado
        try:
            ctx_unv = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=timeout, context=ctx_unv) as resp:
                return resp.read()
        except Exception as e2:
            raise RuntimeError(f"Error al conectar con el servidor: {e1} | Reintento: {e2}")


def obtener_version_local() -> dict:
    """Lee la versión instalada actualmente en la máquina."""
    if ARCHIVO_VERSION.is_file():
        try:
            return json.loads(ARCHIVO_VERSION.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "version": "2.5.1",
        "fecha": "2026-11-11",
        "url_servidor_versiones": "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/version.json"
    }


def _parse_version(v_str: str) -> tuple:
    """Convierte '2.4.2' en tupla (2, 4, 2) para comparación numérica segura."""
    try:
        numeros = [int(x) for x in v_str.replace("v", "").replace("V", "").strip().split(".")]
        return tuple(numeros)
    except Exception:
        return (0, 0, 0)


def verificar_actualizaciones() -> dict:
    """
    Comprueba si existe una versión superior en el servidor remoto de GitHub.
    Usa cache-buster y SSL resiliente contra antivirus.
    """
    local = obtener_version_local()
    ver_local = local.get("version", "2.5.1")
    url_remota = local.get("url_servidor_versiones", "")

    if not url_remota or "placeholder" in url_remota:
        url_remota = "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/version.json"

    try:
        contenido = _descargar_con_reintentos(url_remota, timeout=10)
        data_remota = json.loads(contenido.decode("utf-8"))

        ver_remota = data_remota.get("version", ver_local)
        hay_nueva = _parse_version(ver_remota) > _parse_version(ver_local)

        return {
            "hay_actualizacion": hay_nueva,
            "version_actual": ver_local,
            "version_remota": ver_remota,
            "novedades": data_remota.get("novedades") or data_remota.get("notas", "Mejoras de rendimiento y estabilidad."),
            "download_url": data_remota.get("download_url", ""),
            "fecha": data_remota.get("fecha", "")
        }
    except Exception as e:
        return {
            "hay_actualizacion": False,
            "version_actual": ver_local,
            "version_remota": ver_local,
            "error": str(e),
            "novedades": "No se pudo conectar con el servidor de actualizaciones."
        }


def aplicar_actualizacion(download_url: str) -> dict:
    """
    Descarga el paquete de actualización y lo aplica de forma segura,
    respetando estrictamente los datos de usuario y licencias.
    Al finalizar, ejecuta la auto-auditoría de dependencias.
    """
    if not download_url:
        return {"ok": False, "msg": "No se especificó la URL de descarga del paquete de actualización."}

    try:
        print(f"[*] Descargando actualización desde: {download_url}...", flush=True)
        zip_bytes = _descargar_con_reintentos(download_url, timeout=90)

        # Abrir el ZIP en memoria
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            archivos_actualizados = 0
            for info in zf.infolist():
                if info.is_dir():
                    continue

                partes = Path(info.filename).parts
                # Normalizar si viene dentro de una subcarpeta raíz (ej: Creador_de_Videos/panel.py)
                if partes and partes[0].lower() in ("creador_de_videos", "generador_universal", "repo-main"):
                    partes = partes[1:]

                if not partes:
                    continue

                rel_path = Path(*partes)
                nombre_base = rel_path.name.lower()

                # REGLA SAGRADA: Jamás sobreescribir licencias ni configuraciones privadas del cliente
                if nombre_base in {x.lower() for x in ARCHIVOS_SAGRADOS_USUARIO}:
                    continue
                if "proyectos_video" in [p.lower() for p in rel_path.parts]:
                    continue

                destino = RAIZ / rel_path
                destino.parent.mkdir(parents=True, exist_ok=True)

                with zf.open(info) as src, open(destino, "wb") as dst:
                    shutil.copyfileobj(src, dst)

                archivos_actualizados += 1

        print(f"[OK] Actualización completada: {archivos_actualizados} archivos actualizados.", flush=True)

        # Ejecutar auditoría y auto-reparación del entorno para nuevas dependencias
        try:
            core_dir = str(RAIZ / "core")
            if core_dir not in sys.path:
                sys.path.insert(0, core_dir)
            import verificar_entorno
            importlib.reload(verificar_entorno)
            verificar_entorno.verificar_y_reparar()
        except Exception:
            pass

        return {
            "ok": True,
            "msg": f"¡Sistema actualizado con éxito ({archivos_actualizados} archivos aplicados)! Por favor reinicia o recarga la página.",
            "archivos_actualizados": archivos_actualizados
        }

    except Exception as e:
        return {"ok": False, "msg": f"Error aplicando la actualización: {e}"}


if __name__ == "__main__":
    if "--auto" in sys.argv or "--aplicar" in sys.argv:
        try:
            res = verificar_actualizaciones()
            if res.get("hay_actualizacion") or "--aplicar" in sys.argv:
                r_ap = aplicar_actualizacion(res.get("download_url"))
                print(r_ap.get("msg", "Actualizacion completada."))
            else:
                print("El sistema ya esta actualizado.")
        except Exception as e:
            print(f"Error en auto-actualizacion: {e}")
    else:
        print("=" * 60)
        print("  VERIFICADOR DE ACTUALIZACIONES")
        print("=" * 60)
        res = verificar_actualizaciones()
        print("  Versión actual :", res.get("version_actual"))
        print("  Versión remota :", res.get("version_remota"))
        print("  Hay nueva      :", res.get("hay_actualizacion"))
        print("  Novedades      :", res.get("novedades"))
        if res.get("error"):
            print("  Error          :", res.get("error"))
        print("=" * 60)
