# -*- coding: utf-8 -*-
"""
cortar_historias.py
--------------------
Módulo especializado para dividir videos de proyectos en historias de 15 segundos
(estándar universal compatible con Facebook Stories, Instagram Stories, TikTok Stories y WhatsApp Status).

Guarda automáticamente los clips generados en una subcarpeta 'historias/' dentro
del mismo directorio donde reside el video original seleccionado.
"""

import os
import re
import sys
import json
import shutil
import subprocess
from pathlib import Path

# Importar resolutor de ffmpeg universal
AQUI = Path(__file__).resolve().parent
if str(AQUI) not in sys.path:
    sys.path.insert(0, str(AQUI))

try:
    from ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion
except ImportError:
    def detectar_ffmpeg():
        return shutil.which("ffmpeg") or "ffmpeg"
    def detectar_ffprobe():
        return shutil.which("ffprobe") or "ffprobe"
    def obtener_duracion(ruta):
        return None


def obtener_duracion_video(ruta_archivo: str) -> float:
    """Obtiene la duración en segundos del video."""
    dur = obtener_duracion(ruta_archivo)
    if dur is not None and dur > 0:
        return dur

    # Fallback con ffprobe directo
    probe = detectar_ffprobe()
    if probe:
        try:
            r = subprocess.run(
                [probe, "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(ruta_archivo)],
                capture_output=True, text=True, timeout=30
            )
            v = float(r.stdout.strip())
            if v > 0:
                return v
        except Exception:
            pass

    # Fallback con ffmpeg parseando stderr
    ff = detectar_ffmpeg()
    try:
        r = subprocess.run([ff, "-hide_banner", "-i", str(ruta_archivo)],
                           capture_output=True, text=True, errors="replace", timeout=30)
        m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr)
        if m:
            h, mins, s = m.groups()
            return int(h) * 3600 + int(mins) * 60 + float(s)
    except Exception:
        pass

    return 0.0


def dividir_video_historias(
    ruta_video: str,
    duracion_segmento: float = 15.0,
    subcarpeta: str = "historias",
    modo: str = "rapido"
) -> dict:
    """
    Divide el video en segmentos de 'duracion_segmento' segundos (defecto: 15s).
    Guarda los clips en una subcarpeta dentro del directorio del video original.

    Argumentos:
        ruta_video: Ruta absoluta o relativa al video .mp4.
        duracion_segmento: Duración máxima de cada clip (default 15s).
        subcarpeta: Nombre de la subcarpeta destino (default 'historias').
        modo: 'rapido' (stream copy sin pérdida en <1s) o 'exacto' (re-encode con GOP exacto).

    Retorna:
        dict con resultado, listado de clips, ruta de carpeta y metadatos.
    """
    p_video = Path(ruta_video).resolve()
    if not p_video.is_file():
        return {
            "ok": False,
            "error": f"El archivo de video no existe o no se pudo acceder: {p_video}"
        }

    ff = detectar_ffmpeg()
    if not ff:
        return {
            "ok": False,
            "error": "No se encontró el ejecutable FFmpeg en el sistema."
        }

    duracion_total = obtener_duracion_video(str(p_video))
    if duracion_total <= 0:
        return {
            "ok": False,
            "error": "No se pudo determinar la duración del video (archivo dañado o sin pista de video válida)."
        }

    # Definir carpeta de salida en la MISMA carpeta del video original
    carpeta_destino = p_video.parent / subcarpeta
    carpeta_destino.mkdir(parents=True, exist_ok=True)

    dur_seg = max(5.0, float(duracion_segmento))
    clips = []
    seg_num = 1
    t_inicio = 0.0

    while t_inicio < duracion_total:
        t_fin = min(t_inicio + dur_seg, duracion_total)
        dur_actual = t_fin - t_inicio

        # Si el remanente es menor a 1 segundo y ya tenemos clips, no generar un clip residual insignificante
        if dur_actual < 1.0 and seg_num > 1:
            break

        nombre_clip = f"H{seg_num:02d}_{int(t_inicio):02d}-{int(t_fin):02d}s.mp4"
        ruta_salida = carpeta_destino / nombre_clip

        # Estrategia 1: Modo rápido (stream copy)
        exito = False
        if modo == "rapido":
            cmd_rapido = [
                ff, "-y",
                "-ss", f"{t_inicio:.3f}",
                "-to", f"{t_fin:.3f}",
                "-i", str(p_video),
                "-c", "copy",
                "-avoid_negative_ts", "make_zero",
                str(ruta_salida)
            ]
            try:
                res = subprocess.run(cmd_rapido, capture_output=True, text=True, errors="replace", timeout=60)
                if res.returncode == 0 and ruta_salida.is_file() and ruta_salida.stat().st_size > 1024:
                    exito = True
            except Exception:
                exito = False

        # Estrategia 2: Fallback o modo exacto (re-encode ultrafast calibrado)
        if not exito:
            cmd_exacto = [
                ff, "-y",
                "-ss", f"{t_inicio:.3f}",
                "-to", f"{t_fin:.3f}",
                "-i", str(p_video),
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "18",
                "-c:a", "aac",
                "-b:a", "192k",
                "-movflags", "+faststart",
                str(ruta_salida)
            ]
            try:
                res = subprocess.run(cmd_exacto, capture_output=True, text=True, errors="replace", timeout=120)
                if res.returncode == 0 and ruta_salida.is_file() and ruta_salida.stat().st_size > 1024:
                    exito = True
            except Exception as e:
                return {
                    "ok": False,
                    "error": f"Error al cortar el segmento {nombre_clip}: {str(e)}"
                }

        if not exito or not ruta_salida.is_file():
            return {
                "ok": False,
                "error": f"No se pudo generar el segmento {nombre_clip}. Verifica el espacio en disco o formato."
            }

        tamano_mb = round(ruta_salida.stat().st_size / (1024 * 1024), 2)
        clips.append({
            "numero": seg_num,
            "nombre": nombre_clip,
            "ruta": str(ruta_salida),
            "inicio_seg": round(t_inicio, 2),
            "fin_seg": round(t_fin, 2),
            "duracion_seg": round(dur_actual, 2),
            "tamano_mb": tamano_mb
        })

        seg_num += 1
        t_inicio = t_fin

    return {
        "ok": True,
        "video_origen": str(p_video),
        "nombre_video": p_video.name,
        "duracion_total": round(duracion_total, 2),
        "duracion_segmento": dur_seg,
        "total_clips": len(clips),
        "carpeta_destino": str(carpeta_destino),
        "clips": clips
    }


def escanear_videos_disponibles() -> list:
    """
    Escanea carpetas de proyectos conocidas en busca de archivos final.mp4 u otros videos
    para presentarlos de forma rápida y cómoda en la interfaz.
    """
    encontrados = []
    rutas_base = []

    user_home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    candidatos = [
        user_home / "Downloads" / "PROYECTOS_VIDEO",
        user_home / "Downloads" / "NUEVOS GUIONES",
        user_home / "Downloads" / "GUIONES PSICO OSCURA",
        user_home / "Downloads" / "reflexiones_canal",
        user_home / "Downloads",
        AQUI.parent / "videos"
    ]

    for c in candidatos:
        if c.is_dir():
            rutas_base.append(c)

    vistos = set()

    for base in rutas_base:
        try:
            # Buscar final.mp4 primero
            for f in base.glob("**/final.mp4"):
                if f.is_file() and str(f) not in vistos:
                    vistos.add(str(f))
                    proyecto = f.parent.name
                    canal = f.parent.parent.name
                    encontrados.append({
                        "titulo": f"{canal} / {proyecto} (final.mp4)",
                        "ruta": str(f.resolve()),
                        "mtime": f.stat().st_mtime
                    })
                    if len(encontrados) >= 40:
                        break

            # Si no hay suficientes, buscar cualquier .mp4 en proyectos
            if len(encontrados) < 30:
                for f in base.glob("**/*.mp4"):
                    if f.is_file() and str(f) not in vistos and "historias" not in f.parent.name.lower():
                        vistos.add(str(f))
                        encontrados.append({
                            "titulo": f"{f.parent.name} / {f.name}",
                            "ruta": str(f.resolve()),
                            "mtime": f.stat().st_mtime
                        })
                        if len(encontrados) >= 50:
                            break
        except Exception:
            continue

    # Ordenar por fecha de modificación descendente (los más recientes primero)
    encontrados.sort(key=lambda x: x.get("mtime", 0), reverse=True)
    return encontrados[:40]


if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = dividir_video_historias(sys.argv[1], 15.0)
        print(json.dumps(res, indent=2))
    else:
        vids = escanear_videos_disponibles()
        print(f"Videos encontrados: {len(vids)}")

