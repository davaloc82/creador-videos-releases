import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.analizar_nicho import extraer_info_url

urls = [
    "https://vm.tiktok.com/ZN8P3Jr77/",
    "https://vm.tiktok.com/ZN8P3hV3T/",
    "https://vm.tiktok.com/ZN8PcWXga/",
    "https://vm.tiktok.com/ZN8PvnrQM/",
    "https://www.tiktok.com/@nuncateloexplicaron/video/7699173041116318999?is_from_webapp=1&sender_device=pc&web_id=7681101996422399508",
    "https://www.tiktok.com/@nuncateloexplicaron/video/7699861952469814550?is_from_webapp=1&sender_device=pc&web_id=7681101996422399508",
    "https://www.tiktok.com/@nuncateloexplicaron/video/7700354979973942550?is_from_webapp=1&sender_device=pc&web_id=7681101996422399508",
    "https://www.tiktok.com/@nuncateloexplicaron/video/7701113803362045206?is_from_webapp=1&sender_device=pc&web_id=7681101996422399508",
    "https://www.tiktok.com/@nuncateloexplicaron/video/7703658515789040899?is_from_webapp=1&sender_device=pc&web_id=7681101996422399508"
]

resultados = []
for i, u in enumerate(urls):
    print(f"Extrayendo [{i+1}/{len(urls)}]: {u}...", flush=True)
    try:
        info = extraer_info_url(u)
        if info:
            resultados.append(info)
            print(f"  OK: {info.get('canal')} | {info.get('titulo')[:50]} | {info.get('duracion')}s | {len(info.get('guion', ''))} chars guion")
        else:
            print("  Fallo al extraer info.")
    except Exception as e:
        print(f"  Error: {e}")

Path("core/analisis_obra_ciencia_urls.json").write_text(json.dumps(resultados, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"\nFinalizado. {len(resultados)} videos extraídos y guardados en core/analisis_obra_ciencia_urls.json")
