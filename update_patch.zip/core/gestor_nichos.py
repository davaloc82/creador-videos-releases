# -*- coding: utf-8 -*-
"""
gestor_nichos.py
----------------
Gestor de Proyectos de Nichos Replicados.
Cuando el usuario decide replicar un canal analizado:
1. Crea la carpeta estructurada del proyecto con nombre sugerido personalizable.
2. Guarda las 3 instrucciones maestras adaptadas y la identidad visual.
3. Extrae la muestra de voz (<= 29.5s) y la música de fondo con Demucs.
4. Incluye las fuentes locales (Melvins One) y registra el proyecto en el menú del sistema.
"""

import json
import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent if AQUI.name == "core" else AQUI
ARCHIVO_NICHOS_USUARIO = RAIZ / "nichos_usuario.json"

# Carpeta base para proyectos replicados
CARPETA_PROYECTOS_DEF = (Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads" / "PROYECTOS_VIDEO").resolve()


def slugify(texto: str, max_len: int = 40) -> str:
    """Convierte texto a un nombre de carpeta seguro y limpio."""
    texto = unicodedata.normalize("NFD", str(texto))
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    texto = re.sub(r"[^A-Za-z0-9]+", "_", texto).strip("_")
    return texto[:max_len] or "Proyecto_Nicho"


def sugerir_nombre_proyecto(canal: str, tipo_nicho: str = "") -> str:
    """Genera una sugerencia inteligente y legible para la carpeta del nuevo proyecto."""
    c_limpio = slugify(canal, 25).title()
    n_limpio = slugify(tipo_nicho, 25).title()

    if "Ojosdelobo" in c_limpio or "Ojos_De_Lobo" in c_limpio:
        return "Ojos_de_Lobo_Curiosidades"
    elif "Sabiduria" in c_limpio or "Eterna" in c_limpio:
        return "Sabiduria_Eterna_Reflexion"
    elif "Zack" in c_limpio or "Youandangel" in c_limpio or "Zack" in n_limpio or "Simulacion" in n_limpio:
        return f"{c_limpio}_Curiosidades_3D"
    elif "Gelo" in c_limpio or "Roblox" in c_limpio or "Gaming" in n_limpio or "Bloque" in n_limpio:
        return f"{c_limpio}_Animacion_3D"
    elif "Finanz" in n_limpio or "Dinero" in n_limpio:
        return f"{c_limpio}_Finanzas"
    elif "Animal" in n_limpio or "Fabula" in n_limpio:
        return f"{c_limpio}_Fabulas"
    elif c_limpio and c_limpio != "Nicho_Analizado":
        return f"{c_limpio}_Contenido"
    return f"Nicho_{n_limpio or 'Replicado'}"


def cargar_nichos_usuario(solo_activos: bool = False) -> list:
    """
    Carga los nichos replicados creados y registrados por el usuario.
    NO auto-detecta carpetas huerfanas: solo carga los proyectos que el usuario
    decidio analizar y replicar explicitamente.
    """
    registrados = []
    rutas_vistas = set()
    if ARCHIVO_NICHOS_USUARIO.is_file():
        try:
            with open(ARCHIVO_NICHOS_USUARIO, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    for n in data:
                        p_r = Path(n.get("ruta", "")).resolve()
                        if p_r.is_dir() and str(p_r).lower() not in rutas_vistas:
                            if "activo" not in n:
                                n["activo"] = True
                            if solo_activos and not n.get("activo", True):
                                continue

                            # Enriquecer con config_nicho.json si existe en la carpeta
                            cfg_path = p_r / "config_nicho.json"
                            if cfg_path.is_file():
                                try:
                                    with open(cfg_path, "r", encoding="utf-8") as fc:
                                        cfg_data = json.load(fc)
                                        for k, v in cfg_data.items():
                                            if k not in n or not n[k]:
                                                n[k] = v
                                except Exception:
                                    pass

                            # Enriquecer con IDENTIDAD_VISUAL.json si no está en n
                            iv_path = p_r / "instrucciones" / "IDENTIDAD_VISUAL.json"
                            if ("identidad_visual" not in n or not n["identidad_visual"]) and iv_path.is_file():
                                try:
                                    with open(iv_path, "r", encoding="utf-8") as fiv:
                                        n["identidad_visual"] = json.load(fiv)
                                except Exception:
                                    pass

                            # Enriquecer con KIT_LANZAMIENTO.json si no está en n
                            kit_j_path = p_r / "instrucciones" / "KIT_LANZAMIENTO.json"
                            if ("kit_lanzamiento" not in n or not n["kit_lanzamiento"]) and kit_j_path.is_file():
                                try:
                                    with open(kit_j_path, "r", encoding="utf-8") as fkj:
                                        n["kit_lanzamiento"] = json.load(fkj)
                                except Exception:
                                    pass

                            # Enriquecer con configuración de Voz IA (ai33_config.txt)
                            ai33_p = p_r / "ai33_config.txt"
                            n_api_key = ""
                            n_voice_id = ""
                            n_speed = "1.0"
                            if ai33_p.is_file():
                                try:
                                    with open(ai33_p, "r", encoding="utf-8") as fv:
                                        for linea in fv:
                                            linea = linea.strip()
                                            if linea.startswith("API_KEY="):
                                                n_api_key = linea.split("=", 1)[1].strip().strip("'\"")
                                            elif linea.startswith("VOICE_ID="):
                                                n_voice_id = linea.split("=", 1)[1].strip().strip("'\"")
                                            elif linea.startswith("SPEED="):
                                                n_speed = linea.split("=", 1)[1].strip().strip("'\"")
                                except Exception:
                                    pass

                            # Si el proyecto no tiene api_key, buscar en la clave global de ai33/
                            if not n_api_key:
                                ai33_global = RAIZ / "ai33" / "ai33_config.txt"
                                if ai33_global.is_file():
                                    try:
                                        with open(ai33_global, "r", encoding="utf-8") as fg:
                                            for linea in fg:
                                                linea = linea.strip()
                                                if linea.startswith("API_KEY="):
                                                    val = linea.split("=", 1)[1].strip().strip("'\"")
                                                    if val and not val.startswith(("#", "PEGA_", "TU_")):
                                                        n_api_key = val
                                                elif linea.startswith("SPEED=") and not n_speed:
                                                    n_speed = linea.split("=", 1)[1].strip().strip("'\"")
                                    except Exception:
                                        pass

                            n["api_key"] = n_api_key
                            n["voice_id"] = n_voice_id
                            n["speed"] = n_speed or "1.0"
                            n["voz_configurada"] = bool(
                                n_api_key and 
                                not n_api_key.startswith(("#", "PEGA_", "TU_")) and 
                                n_voice_id and 
                                not n_voice_id.startswith(("#", "PEGA_", "TU_"))
                            )

                            registrados.append(n)
                            rutas_vistas.add(str(p_r).lower())
        except Exception:
            pass

    return registrados


def guardar_nicho_usuario(nicho_info: dict):
    """Agrega o actualiza un nicho en el registro de nichos del usuario."""
    existentes = cargar_nichos_usuario(solo_activos=False)
    existentes = [n for n in existentes if n.get("id") != nicho_info.get("id") and n.get("ruta") != nicho_info.get("ruta")]
    if "activo" not in nicho_info:
        nicho_info["activo"] = True
    existentes.insert(0, nicho_info)
    try:
        with open(ARCHIVO_NICHOS_USUARIO, "w", encoding="utf-8") as f:
            json.dump(existentes, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error guardando nichos_usuario.json: {e}")


def toggle_estado_nicho(nicho_id: str, activo=None) -> tuple[bool, str, dict]:
    """Activa o desactiva un canal replicado para mostrarlo u ocultarlo en el menu."""
    existentes = cargar_nichos_usuario(solo_activos=False)
    encontrado = None
    for n in existentes:
        if n.get("id") == nicho_id:
            if activo is None:
                n["activo"] = not n.get("activo", True)
            else:
                n["activo"] = bool(activo)
            encontrado = n
            break

    if not encontrado:
        return False, "Canal no encontrado.", {}

    try:
        with open(ARCHIVO_NICHOS_USUARIO, "w", encoding="utf-8") as f:
            json.dump(existentes, f, ensure_ascii=False, indent=2)
        estado_txt = "activado" if encontrado.get("activo") else "desactivado"
        return True, f"Canal '{encontrado.get('nombre')}' {estado_txt} con exito.", encontrado
    except Exception as e:
        return False, f"Error actualizando estado del canal: {e}", {}


def eliminar_nicho_usuario(nicho_id: str, borrar_archivos: bool = False) -> tuple[bool, str]:
    """Elimina un canal replicado del registro y opcionalmente su carpeta de archivos."""
    existentes = cargar_nichos_usuario(solo_activos=False)
    encontrado = None
    nuevos = []
    for n in existentes:
        if n.get("id") == nicho_id:
            encontrado = n
        else:
            nuevos.append(n)

    if not encontrado:
        return False, "Canal no encontrado en la lista de proyectos."

    if borrar_archivos and encontrado.get("ruta"):
        try:
            ruta_p = Path(encontrado["ruta"]).resolve()
            if ruta_p.is_dir() and CARPETA_PROYECTOS_DEF in ruta_p.parents:
                shutil.rmtree(ruta_p, ignore_errors=True)
        except Exception as e:
            print(f"Aviso al borrar carpeta de canal: {e}")

    try:
        with open(ARCHIVO_NICHOS_USUARIO, "w", encoding="utf-8") as f:
            json.dump(nuevos, f, ensure_ascii=False, indent=2)
        return True, f"Canal '{encontrado.get('nombre', nicho_id)}' eliminado correctamente."
    except Exception as e:
        return False, f"Error al eliminar registro del canal: {e}"


def crear_proyecto_nicho(
    nombre_proyecto: str,
    analisis_datos: dict,
    extraer_audio: bool = True,
    estilo_subtitulos: str = "capcut_karaoke",
    carpeta_base: str = None,
    api_key: str = "",
    voice_id: str = "",
    speed: str = "1.0",
    formato: str = "vertical",
    **kwargs
) -> dict:
    """
    Crea la carpeta completa del proyecto y estructura todos los recursos.
    """
    nombre_seguro = slugify(nombre_proyecto, 50)
    base = Path(carpeta_base).resolve() if carpeta_base else CARPETA_PROYECTOS_DEF
    base.mkdir(parents=True, exist_ok=True)

    ruta_proyecto = base / nombre_seguro
    ruta_proyecto.mkdir(parents=True, exist_ok=True)

    # Subcarpetas del proyecto
    dir_instrucciones = ruta_proyecto / "instrucciones"
    dir_instrucciones.mkdir(parents=True, exist_ok=True)

    dir_audio_ref = ruta_proyecto / "audio_referencia"
    dir_audio_ref.mkdir(parents=True, exist_ok=True)

    dir_fuentes = ruta_proyecto / "fuentes"
    dir_fuentes.mkdir(parents=True, exist_ok=True)

    # 1. Guardar las 3 Instrucciones Maestras Adaptadas
    shorts_md = analisis_datos.get("instruccion_shorts") or analisis_datos.get("prompt_maestro", "")
    largos_md = analisis_datos.get("instruccion_largos") or ""
    prompts_md = analisis_datos.get("instruccion_prompts") or ""
    iv = analisis_datos.get("identidad_visual", {})

    with open(dir_instrucciones / "INSTRUCCION_SHORTS.md", "w", encoding="utf-8") as f:
        f.write(shorts_md)

    with open(dir_instrucciones / "INSTRUCCION_LARGOS.md", "w", encoding="utf-8") as f:
        f.write(largos_md)

    with open(dir_instrucciones / "INSTRUCCION_PROMPTS.md", "w", encoding="utf-8") as f:
        f.write(prompts_md)

    # 1.1 Guardar Instrucción Maestra de SEO
    seo_src = RAIZ / "virales ecos" / "SEO ECOS MASTER v2.md"
    if not seo_src.is_file():
        seo_src = RAIZ / "instrucciones_maestras" / "INSTRUCCION_MAESTRA_SEO.md"
    if seo_src.is_file():
        try:
            shutil.copy2(seo_src, dir_instrucciones / "INSTRUCCION_SEO.md")
        except Exception:
            pass

    # 1.2 Crear archivo maestro de personajes en la raíz del nicho (Tío Rico Mac Pato, Lobo, etc.)
    p1_p = iv.get("personaje_sugerido_prompt") or iv.get("personaje_1_prompt") or ""
    p2_p = iv.get("personaje_2_prompt") or ""
    lineas_ref = []
    if p1_p:
        lineas_ref.append(f"(P1): {p1_p.strip()}")
    if p2_p and p2_p != "N/A" and not p2_p.startswith("#"):
        lineas_ref.append(f"(P2): {p2_p.strip()}")
    if lineas_ref:
        txt_ref_maestra = "# ============================================================\n# PERSONAJES MAESTROS DEL NICHO (Consistencia Visual Absoluta)\n# ============================================================\n\n" + "\n\n".join(lineas_ref) + "\n"
        (ruta_proyecto / "referencias_maestras.txt").write_text(txt_ref_maestra, encoding="utf-8")
        (ruta_proyecto / "personajes_nicho.txt").write_text(txt_ref_maestra, encoding="utf-8")

    # 1.3 Crear carpetas estándar para imágenes y videos (imagen y video para clientes/replicados)
    (ruta_proyecto / "imagen").mkdir(parents=True, exist_ok=True)
    (ruta_proyecto / "video").mkdir(parents=True, exist_ok=True)

    kit = analisis_datos.get("kit_lanzamiento") or {}
    texto_kit = kit.get("texto_exportable") or ""
    if texto_kit:
        with open(dir_instrucciones / "KIT_LANZAMIENTO_REDES.txt", "w", encoding="utf-8") as f:
            f.write(texto_kit)
    if kit:
        with open(dir_instrucciones / "KIT_LANZAMIENTO.json", "w", encoding="utf-8") as f:
            json.dump(kit, f, ensure_ascii=False, indent=2)

    with open(dir_instrucciones / "IDENTIDAD_VISUAL.json", "w", encoding="utf-8") as f:
        json.dump(iv, f, ensure_ascii=False, indent=2)

    # 2. Copiar fuente Melvins One
    fuente_src = RAIZ / "fonts" / "MelvinsoneRegular-d9mvR.otf"
    if not fuente_src.is_file():
        fuente_src = RAIZ / "ecos" / "fonts" / "MelvinsoneRegular-d9mvR.otf"

    if fuente_src.is_file():
        shutil.copy2(fuente_src, dir_fuentes / fuente_src.name)
        # Intentar registrar en Windows
        try:
            from subtitulos_estilos import instalar_fuente_en_windows
            instalar_fuente_en_windows(fuente_src.name)
        except Exception:
            pass

    # 2.1 Configurar ai33_config.txt para el proyecto
    cfg_src = RAIZ / "ai33" / "ai33_config.txt"
    cfg_dst = ruta_proyecto / "ai33_config.txt"
    if api_key or voice_id:
        txt_cfg = f"""# ============================================================
#  ai33.pro (Text-To-Speech)  -  CONFIGURACION DE VOZ
# ============================================================
API_KEY={api_key}
VOICE_ID={voice_id}
SPEED={speed or '1.0'}
WITH_TRANSCRIPT=false
TTS_URL=https://api.ai33.pro/v3/text-to-speech
TASK_URL=https://api.ai33.pro/v3/task/{{task_id}}
TIMEOUT=300
"""
        cfg_dst.write_text(txt_cfg, encoding="utf-8")
        # Si vino una API Key válida, actualizar también la global para futuros proyectos
        if api_key and not api_key.startswith(("#", "PEGA_", "TU_")) and cfg_src.is_file():
            try:
                cfg_src.write_text(txt_cfg, encoding="utf-8")
            except Exception:
                pass
    elif cfg_src.is_file() and not cfg_dst.exists():
        shutil.copy2(cfg_src, cfg_dst)

    # 3. Crear plantilla de guiones inicial
    guiones_txt = ruta_proyecto / "guiones.txt"
    if not guiones_txt.exists():
        ejemplos = analisis_datos.get("ejemplos", [])
        contenido_guiones = f"""# GUIONES PARA EL PROYECTO: {nombre_proyecto}
# Nicho: {analisis_datos.get('tipo_nicho', '')}
# Canal de Referencia: {analisis_datos.get('canal', '')}
# Formato: GUION: [Numero] y la narración en voz en off limpia.

GUION: 01
[Pega aquí el texto de tu primer guion en voz en off continua...]

GUION: 02
[Pega aquí el texto de tu segundo guion en voz en off continua...]
"""
        guiones_txt.write_text(contenido_guiones, encoding="utf-8")

    # 4. Guardar configuración completa del nicho y registrarlo DE INMEDIATO
    # Esto garantiza que el proyecto quede 100% creado y visible en el panel aunque la disección tarde o falle.
    estilo_id = iv.get("estilo_id") or analisis_datos.get("estilo_id", "")
    tipo_prod = analisis_datos.get("tipo_produccion") or ("codigo_motion" if estilo_id in ("motion_graphics_2d", "voxel_lowpoly_3d") else "prompts_imagen")
    req_img = analisis_datos.get("requiere_prompts_imagen", False if tipo_prod == "codigo_motion" else True)
    modo_montaje = "motion_graphics" if tipo_prod == "codigo_motion" else "hibrido_clips"

    formato_param = formato or analisis_datos.get("formato", "vertical")
    formato_final = "Largo (16:9 / Dual)" if any(k in str(formato_param).lower() for k in ("largo", "16:9", "horizontal")) else "Vertical (9:16)"

    nicho_id = f"nicho_{nombre_seguro.lower()}"
    config_nicho = {
        "id": nicho_id,
        "nombre": nombre_proyecto,
        "nombre_carpeta": nombre_seguro,
        "ruta": str(ruta_proyecto),
        "canal_origen": analisis_datos.get("canal", ""),
        "tipo_nicho": analisis_datos.get("tipo_nicho", ""),
        "formato": formato_final,
        "tipo_produccion": tipo_prod,
        "carpeta_imagenes": "imagen",
        "carpeta_videos": "video",
        "requiere_imagenes": req_img,
        "requiere_videos": False,
        "modo_montaje": modo_montaje,
        "estilo_visual": iv.get("estilo_nombre", "Comic"),
        "sufijo_estilo": iv.get("sufijo_estilo", ""),
        "estilo_subtitulos": estilo_subtitulos,
        "fecha_creacion": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "audio_clonacion": "",
        "audio_clonacion_ruta": "",
        "duracion_muestra": 0,
        "musica_fondo": "",
        "musica_fondo_ruta": "",
        "kit_lanzamiento": kit,
        "identidad_visual": iv,
        "configurado": True
    }

    with open(ruta_proyecto / "config_nicho.json", "w", encoding="utf-8") as f:
        json.dump(config_nicho, f, ensure_ascii=False, indent=2)

    guardar_nicho_usuario(config_nicho)

    # 5. Diseccionar y extraer audios del video de referencia si se solicitó
    datos_diseccion = {}
    if extraer_audio:
        # Extraer URL candidata de videos o urls
        videos = analisis_datos.get("videos", []) or []
        url_a_procesar = None
        for v in videos:
            if isinstance(v, dict):
                u = v.get("url")
            elif isinstance(v, str):
                u = v
            else:
                u = None
            if u:
                url_a_procesar = u
                break

        if not url_a_procesar:
            urls = analisis_datos.get("urls", []) or []
            for u in urls:
                if u and isinstance(u, str):
                    url_a_procesar = u
                    break

        if url_a_procesar:
            try:
                from diseccionar_audio import diseccionar_video_para_proyecto
                print(f"  Iniciando disección de audio desde {url_a_procesar}...", flush=True)
                datos_diseccion = diseccionar_video_para_proyecto(url_a_procesar, ruta_proyecto)

                # Actualizar proyecto con los audios generados
                if datos_diseccion.get("muestra_voz_nombre"):
                    config_nicho["audio_clonacion"] = datos_diseccion.get("muestra_voz_nombre", "")
                    config_nicho["audio_clonacion_ruta"] = datos_diseccion.get("muestra_voz", "")
                    config_nicho["duracion_muestra"] = datos_diseccion.get("duracion_muestra", 0)
                    config_nicho["musica_fondo"] = datos_diseccion.get("musica_fondo_nombre", "")
                    config_nicho["musica_fondo_ruta"] = datos_diseccion.get("musica_fondo", "")

                    with open(ruta_proyecto / "config_nicho.json", "w", encoding="utf-8") as f:
                        json.dump(config_nicho, f, ensure_ascii=False, indent=2)

                    guardar_nicho_usuario(config_nicho)
            except Exception as e:
                print(f"  Aviso: Error durante la disección de audio: {e}", flush=True)
                datos_diseccion = {"error": str(e)}

    return {
        "ok": True,
        "msg": f"¡Proyecto '{nombre_proyecto}' creado y configurado con éxito!",
        "proyecto": config_nicho,
        "diseccion": datos_diseccion
    }
