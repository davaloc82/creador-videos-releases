# -*- coding: utf-8 -*-
"""
hardware_tuner.py
------------------
Sistema Inteligente de Detección y Calibración de Hardware (Auto-Tuning).
Analiza las capacidades de la computadora del usuario y ajusta automáticamente
los motores de renderizado (FFmpeg) y de inteligencia artificial (Whisper/Torch)
para aprovechar al 100% las PC Gamer/Workstation sin colgar las PC básicas.

Perfiles:
  - 'gamer_pro': GPU NVIDIA/AMD con NVENC/AMF, alta RAM y muchos hilos.
  - 'estandar': CPU y gráficos integrados (Intel UHD/AMD Vega), seguro y fluido.
"""

import os
import sys
import json
import ctypes
import shutil
import subprocess
from pathlib import Path

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent if AQUI.name == "core" else AQUI
ARCHIVO_CONFIG_HW = RAIZ / "hardware_config.json"


def _obtener_ram_gb() -> float:
    """Obtiene la memoria RAM física total instalada en GB usando ctypes estándar."""
    try:
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)
            ]
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return round(stat.ullTotalPhys / (1024 ** 3), 1)
    except Exception:
        pass
    return 8.0


def _obtener_info_gpus() -> list:
    """Detecta los controladores gráficos instalados mediante PowerShell / WMI."""
    gpus = []
    try:
        cmd = ["powershell", "-NoProfile", "-Command",
               "Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM | ConvertTo-Json -Compress"]
        kw_ps = {"capture_output": True, "text": True, "timeout": 8}
        if sys.platform.startswith("win"): kw_ps["creationflags"] = 0x08000000
        res = subprocess.run(cmd, **kw_ps)
        if res.returncode == 0 and res.stdout.strip():
            data = json.loads(res.stdout)
            if isinstance(data, dict):
                data = [data]
            for item in data:
                nom = item.get("Name", "").strip()
                vram_bytes = item.get("AdapterRAM", 0) or 0
                vram_gb = round(vram_bytes / (1024 ** 3), 1) if vram_bytes > 0 else 0
                if nom:
                    gpus.append({"nombre": nom, "vram_gb": vram_gb})
    except Exception:
        pass

    if not gpus:
        gpus.append({"nombre": "Controlador de pantalla estándar", "vram_gb": 0})
    return gpus


def _probar_encoder_ffmpeg(ffmpeg_bin: str, encoder: str) -> bool:
    """
    Prueba en 0.05 segundos si el encoder de hardware puede inicializar un fotograma real.
    Garantiza que nunca falle con 'Cannot load nvcuda.dll' ni 'amfrt64.dll'.
    """
    if not ffmpeg_bin or not os.path.isfile(ffmpeg_bin):
        return False
    cmd = [
        ffmpeg_bin, "-v", "error",
        "-f", "lavfi", "-i", "color=c=black:s=64x64:d=0.05",
        "-c:v", encoder,
        "-f", "null", "-"
    ]
    try:
        kw_ff = {"capture_output": True, "text": True, "timeout": 5}
        if sys.platform.startswith("win"): kw_ff["creationflags"] = 0x08000000
        r = subprocess.run(cmd, **kw_ff)
        return r.returncode == 0
    except Exception:
        return False


def calibrar_hardware(forzar: bool = False) -> dict:
    """
    Analiza la máquina, prueba encoders por hardware y genera la configuración óptima.
    Guarda el resultado en hardware_config.json para reutilización instantánea.
    """
    if not forzar and ARCHIVO_CONFIG_HW.is_file():
        try:
            cfg = json.loads(ARCHIVO_CONFIG_HW.read_text(encoding="utf-8"))
            if cfg.get("calibrado"):
                return cfg
        except Exception:
            pass

    cores = os.cpu_count() or 4
    ram_gb = _obtener_ram_gb()
    gpus = _obtener_info_gpus()

    # Resolver FFmpeg para probar aceleración
    try:
        from ffmpeg_resolver import detectar_ffmpeg
        ff = detectar_ffmpeg()
    except Exception:
        ff = shutil.which("ffmpeg")

    # Pruebas activas de codificación por hardware (Solo GPU dedicada Gamer)
    soporta_nvenc = _probar_encoder_ffmpeg(ff, "h264_nvenc")
    soporta_amf = _probar_encoder_ffmpeg(ff, "h264_amf") if not soporta_nvenc else False
    soporta_qsv = False  # Desactivado: Intel QuickSync satura procesadores de gama media/oficina

    # Probar si PyTorch con CUDA está presente para Whisper
    soporta_cuda_ia = False
    try:
        import torch
        soporta_cuda_ia = torch.cuda.is_available()
    except Exception:
        soporta_cuda_ia = False

    # Determinar si la máquina califica como Gamer / Pro
    nombres_gpu = " | ".join(g["nombre"] for g in gpus)
    es_nvidia = any("nvidia" in g["nombre"].lower() or "geforce" in g["nombre"].lower() or "rtx" in g["nombre"].lower() for g in gpus)
    es_gamer = (soporta_nvenc or (es_nvidia and ram_gb >= 12.0)) or (soporta_amf and ram_gb >= 12.0)

    if soporta_nvenc:
        encoder_video = "h264_nvenc"
        preset_video = "p4"
        perfil = "gamer_pro"
        titulo_perfil = "🚀 Modo Gamer / Aceleración NVIDIA RTX Activada"
        detalle_perfil = f"GPU: {gpus[0]['nombre']} (NVENC Activo) | CPU: {cores} núcleos | RAM: {ram_gb} GB"
        threads = cores
        whisper_dev = "cuda" if soporta_cuda_ia else "cpu"
    elif soporta_amf:
        encoder_video = "h264_amf"
        preset_video = "speed"
        perfil = "gamer_pro"
        titulo_perfil = "🚀 Modo Gamer / Aceleración AMD Radeon Activada"
        detalle_perfil = f"GPU: {gpus[0]['nombre']} (AMF Activo) | CPU: {cores} núcleos | RAM: {ram_gb} GB"
        threads = cores
        whisper_dev = "cpu"
    else:
        encoder_video = "libx264"
        preset_video = "veryfast"
        perfil = "estandar"
        titulo_perfil = "⚡ Modo Estándar CPU (Flujo Estable y Ligero)"
        detalle_perfil = f"CPU: {cores} núcleos | RAM: {ram_gb} GB (Modo Ligero sin sobrecargar sistema)"
        threads = max(2, min(cores - 2, 4))
        whisper_dev = "cpu"

    config_hw = {
        "calibrado": True,
        "perfil": perfil,
        "es_gamer": es_gamer,
        "titulo_perfil": titulo_perfil,
        "detalle_perfil": detalle_perfil,
        "cores": cores,
        "ram_gb": ram_gb,
        "gpus": gpus,
        "encoder_video": encoder_video,
        "preset_video": preset_video,
        "threads_render": threads,
        "whisper_device": whisper_dev,
        "soporta_nvenc": soporta_nvenc,
        "soporta_qsv": soporta_qsv,
        "soporta_amf": soporta_amf,
        "soporta_cuda_ia": soporta_cuda_ia
    }

    try:
        ARCHIVO_CONFIG_HW.write_text(json.dumps(config_hw, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

    return config_hw


def obtener_info_hardware() -> dict:
    """Retorna la configuración de hardware calibrada."""
    return calibrar_hardware(forzar=False)


def aplicar_aceleracion_a_comando(cmd: list) -> list:
    """
    Toma un comando FFmpeg que use libx264 y, si el hardware soporta aceleración
    (NVENC, AMF, QSV), reemplaza el codec y preset de forma segura.
    Si la ejecución del encoder fallase, el llamador puede hacer fallback a libx264.
    """
    if not cmd or not isinstance(cmd, list):
        return cmd

    hw = obtener_info_hardware()
    encoder = hw.get("encoder_video", "libx264")
    if encoder == "libx264":
        return cmd

    cmd_ajustado = list(cmd)
    try:
        # Reemplazar -c:v libx264 por el encoder de GPU
        for idx, token in enumerate(cmd_ajustado):
            if token == "-c:v" and idx + 1 < len(cmd_ajustado):
                if cmd_ajustado[idx + 1] == "libx264":
                    cmd_ajustado[idx + 1] = encoder
                    # Ajustar preset para GPU si aplica
                    preset = hw.get("preset_video", "p4")
                    for p_idx, p_token in enumerate(cmd_ajustado):
                        if p_token == "-preset" and p_idx + 1 < len(cmd_ajustado):
                            cmd_ajustado[p_idx + 1] = preset
                            break
                    break
    except Exception:
        return cmd

    return cmd_ajustado


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 65)
    print("   AUTO-TUNING DE HARDWARE  -  CREADOR DE VIDEOS UNIVERSAL")
    print("=" * 65)
    info = calibrar_hardware(forzar=True)
    try:
        print(f"[*] Perfil asignado  : {info['titulo_perfil']}")
        print(f"[*] Detalle técnico  : {info['detalle_perfil']}")
    except UnicodeEncodeError:
        print(f"[*] Perfil asignado  : {info['perfil']}")
        print(f"[*] Detalle técnico  : Cores={info['cores']}, RAM={info['ram_gb']}GB")
    print(f"[*] Encoder de video : {info['encoder_video']} (Preset: {info['preset_video']})")
    print(f"[*] Hilos asignados  : {info['threads_render']}")
    print(f"[*] Motor Whisper IA : {info['whisper_device'].upper()}")
    print("=" * 65)
    print("[OK] Calibración guardada en: hardware_config.json\n")
