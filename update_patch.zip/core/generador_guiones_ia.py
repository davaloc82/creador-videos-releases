"""
generador_guiones_ia.py - Motor Inteligente de Generación de Guiones con IA
Basado en la Guía Maestra de Retención & Storytelling (Grefg, Ecos v4 y Famosos Esencial).

Capacidades:
1. Calibración matemática de palabras según la duración en segundos deseada (pacing de ~138 ppm / 2.3 palabras/seg).
2. Estructura de 6 Latidos de Retención (Golpe Frontal 0-3s, Diálogo Temprano 15-20s, Ley de la Dificultad, Escalera de Tensión, Clímax y Cierre Redondo).
3. Integración con Gemini API para generar tandas de 1 a 10 guiones continuos y limpios para TTS (ai33.pro / ElevenLabs).
"""

import json
import re
import urllib.request
import urllib.error
from pathlib import Path
from core.generador_prompts_gemini import obtener_claves_prompts, MODELOS_RECOMENDADOS

VELOCIDAD_PALABRAS_POR_SEGUNDO = 2.30  # ~138 palabras por minuto en locución en español


def calcular_palabras_por_duracion(duracion_segundos: int | float) -> tuple[int, int, int]:
    """
    Calcula el conteo objetivo, mínimo y máximo de palabras para cubrir una duración específica en segundos.
    Retorna: (palabras_objetivo, min_palabras, max_palabras)
    """
    seg = max(15, int(duracion_segundos))
    objetivo = int(round(seg * VELOCIDAD_PALABRAS_POR_SEGUNDO))
    minimo = max(25, int(round(objetivo * 0.90)))
    maximo = int(round(objetivo * 1.10))
    return objetivo, minimo, maximo


def resolver_instruccion_nicho(nicho_dir: Path, formato: str = "shorts") -> tuple[str, str, dict]:
    """
    Carga la instrucción maestra del nicho (Shorts o Largos) y los metadatos de configuración.
    """
    nicho_dir = Path(nicho_dir).resolve()
    dir_inst = nicho_dir / "instrucciones"
    config_p = nicho_dir / "config_nicho.json"
    
    cfg = {}
    if config_p.is_file():
        try:
            cfg = json.loads(config_p.read_text(encoding="utf-8"))
        except Exception:
            pass

    es_largo = (formato.lower() in ("largos", "largo", "16:9", "youtube", "horizontal"))
    
    nombre_archivo = "INSTRUCCION_LARGOS.md" if es_largo else "INSTRUCCION_SHORTS.md"
    inst_path = dir_inst / nombre_archivo
    if not inst_path.is_file():
        # Fallback alternativo
        cands = list(dir_inst.glob("*.md")) + list(nicho_dir.glob("*.md"))
        for c in cands:
            if ("largo" in c.name.lower() if es_largo else "short" in c.name.lower()):
                inst_path = c
                break

    inst_txt = ""
    if inst_path and inst_path.is_file():
        inst_txt = inst_path.read_text(encoding="utf-8", errors="replace").strip()

    # Cargar ejemplos previos de guiones si existen
    ejemplos_txt = ""
    guiones_f = nicho_dir / "guiones.txt"
    if guiones_f.is_file():
        txt_g = guiones_f.read_text(encoding="utf-8", errors="replace").strip()
        if txt_g and not txt_g.startswith("# GUIONES PARA EL PROYECTO"):
            bloques = re.split(r"(?:^|\n)GUION:\s*\d+", txt_g)
            limpios = [b.strip() for b in bloques if b.strip() and len(b.strip()) > 80]
            if limpios:
                ejemplos_txt = "\n\n---\n\n".join(limpios[:2])

    tipo_nicho = cfg.get("tipo_nicho") or nicho_dir.name
    return inst_txt, ejemplos_txt, cfg


def construir_prompt_generacion_guiones(
    nicho_dir: Path,
    cantidad: int = 3,
    duracion_segundos: int = 60,
    formato: str = "shorts",
    tema_libre: str = "",
    ejemplos_referencia: str = "",
    urls_referencia: list[str] = None
) -> tuple[str, str, int, int]:
    """
    Construye el System Prompt y el User Prompt fusionando la instrucción del nicho
    con el ADN de Retención (Grefg & Ecos Storytelling Engine).
    """
    objetivo_palabras, min_palabras, max_palabras = calcular_palabras_por_duracion(duracion_segundos)
    inst_base, ejemplos_nicho, cfg = resolver_instruccion_nicho(nicho_dir, formato=formato)
    
    tipo_nicho = cfg.get("tipo_nicho", nicho_dir.name)
    canal_ref = cfg.get("canal_origen", "Canal de Referencia")
    nombre_nicho = cfg.get("nombre", nicho_dir.name)
    es_largo = (formato.lower() in ("largos", "largo", "16:9", "youtube", "horizontal"))

    texto_combinado = f"{tipo_nicho} {nombre_nicho} {canal_ref} {inst_base}".lower()
    es_ingenieria_o_ciencia = any(
        k in texto_combinado for k in (
            "ingenieria", "ingeniería", "ciencia", "construccion", "construcción",
            "obra", "didactica", "didáctica", "cómo funciona", "como funciona",
            "tecnologia", "tecnología", "fisica", "física", "arquitectura", "mecanica", "mecánica"
        )
    )

    if es_ingenieria_o_ciencia:
        system_instruction = f"""Actúa como un Director de Divulgación de Ingeniería, Construcción, Física Aplicada y Ciencia Didáctica especializado en retención viral para YouTube Shorts, TikTok y Reels (al estilo de canales virales de millones de vistas como "Con Razón", "Nunca Te Lo Explicaron", "PV3D Animation", "Hecho a Propósito" y "Es ingeniería").
Tu misión es escribir guiones ultra-dinámicos, didácticos y de retención extrema para narración continua en voz en off.

ESTRUCTURA VIRAL OBLIGATORIA PARA INGENIERÍA Y CIENCIA DIDÁCTICA:
1. EL GANCHO INSTANTÁNEO (Primeros 3 a 4 segundos):
   - Arranca DIRECTO con la premisa, el dilema físico o el primer paso de construcción ("Pones X y ya tienes Y, pero...", "¿Por qué las trincheras van en zigzag?", "¿Cómo sabe Google Maps que hay un atasco delante de ti?"). CERO saludos, cero rodeos.
2. LA CADENA CAUSA-EFECTO ACUMULATIVA (Fricción y Solución Técnica):
   - Muestra el problema inmediato que surge y cómo la solución técnica es la ÚNICA respuesta lógica (ejemplo: si llueve el neumático pierde contacto con el asfalto: es el aquaplaning; si miles de móviles se agrupan en la autopista: la telemetría pinta la ruta de rojo en Google Maps; si un puente se dilata con el calor: se instalan juntas dentadas de expansión).
   - Cada componente o principio físico se presenta como un salvavidas ante una catástrofe inmediata que el espectador comprende al instante.
3. RITMO ACELERADO Y ANALOGÍAS VISUALES COTIDIANAS:
   - Oraciones breves de 3 a 5 segundos con progresión constante de información.
   - Traduce los conceptos complejos a analogías visuales familiares ("como la caja que no sabes dónde guardar y acaba debajo de la cama", "como el testigo en una carrera de relevos", "como el wasabi en la lengua").
4. EL GIRO / REVELACIÓN INESPERADA:
   - El dato científico contundente o la razón oculta por la que funciona (la roca de creta impermeable, el zigzag que atrapa la onda explosiva, el algoritmo que reserva la antena celular antes de desconectarte).
5. CIERRE REDONDO Y RETO VIRAL:
   - Conclusión ingeniosa con llamado a compartir ("Mándaselo a quien siempre aprieta el botón grande", "Mándaselo a quien cree que una trinchera es solo una zanja", "La próxima vez que estés en el rojo, piensa que tu móvil también lo está pintando", "¿Qué obra imposible construimos la próxima vez? Te leo en comentarios").

REGLAS ESTRICTAS DE LOCUCIÓN (PARA SÍNTESIS DE VOZ IA):
- Escribe ÚNICAMENTE el texto continuo que dirá el locutor palabra por palabra.
- CERO acotaciones teatrales, notas entre paréntesis, indicaciones técnicas ni etiquetas como 'Narrador:' o 'Locutor:'.
- CERO asteriscos ni negritas markdown dentro de la narración hablada.
- Números y cifras SIEMPRE escritos en letras ("quince", "dos mil", "trescientos", no "15" ni "2000").
"""
    else:
        system_instruction = f"""Actúa como un Director de Narrativa y Storyteller Audiovisual Senior especializado en retención extrema para YouTube, Facebook, TikTok e Instagram.
Tu misión es escribir guiones de alto impacto emocional, drama, tensión y ritmo, optimizados para narración en voz en off continua.

ESTRUCTURA DE RETENCIÓN OBLIGATORIA (LOS 6 LATIDOS):
1. EL GOLPE FRONTAL (Primeros 3 a 5 segundos):
   - La primera frase DEBE poner la herida, la injusticia, la amenaza, la contradicción o el choque directo al frente.
   - PROHIBIDO abrir con rutinas ("Todos los días...", "Un día cualquiera..."), fechas frías, resúmenes biográficos o frases cliché ("La historia de...", "El precio de la fama...", "Un día todo cambió..."). Abre con el conflicto en marcha.

2. CITA O VOZ TEMPRANA (Segundo 15 a 20):
   - Rompe la narración en tercera persona temprano. Incluye una declaración real, orden tajante o frase corta y demoledora entrecomillada del protagonista o antagonista.

3. LA LEY DE LA DIFICULTAD (Fricción Visible):
   - Lo épico es difícil; destruir o perder toma un segundo. Muestra el costo real, el sudor, la humillación, la prueba moral o la resistencia. Prohibido que las cosas salgan fáciles o en línea recta.

4. LA ESCALERA DE TENSIÓN Y CAMBIOS DE RITMO:
   - Alterna subidas y bajadas: un avance con esperanza, un revés que parece devolverlo al punto de partida, y un aumento de apuestas. 

5. CLÍMAX CATÁRTICO:
   - Cumple la promesa del gancho con impacto emocional, justicia poética o revelación inolvidable.

6. CIERRE REDONDO DE CONCEPTO:
   - Conclusión memorable que ata el sentido de la historia con una lección implícita sin sermonear y deja al espectador con la sensación de haber visto un video redondo.

REGLAS ESTRICTAS DE LOCUCIÓN (PARA SINTESIS DE VOZ IA):
- Escribe ÚNICAMENTE el texto que dirá el locutor palabra por palabra.
- CERO acotaciones teatrales, notas entre paréntesis, música [música], efectos de sonido ni etiquetas como 'Narrador:' o 'Locutor:'.
- CERO asteriscos ni negritas markdown dentro de la narración.
- Números y cifras SIEMPRE escritos en letras ("quince", "dos mil", no "$100" ni "100").
"""

    guia_tema = ""
    if tema_libre and str(tema_libre).strip():
        guia_tema = f"""
TEMA / ÁNGULO ESPECÍFICO SOLICITADO:
\"\"\"
{str(tema_libre).strip()}
\"\"\"
Desarrolla los guiones explorando diferentes facetas, giros, fallas o aplicaciones técnicas basadas en este tema.
"""
    elif es_ingenieria_o_ciencia:
        guia_tema = f"""
VARIEDAD TEMÁTICA OBLIGATORIA (TERRITORIOS TÉCNICOS DIVERSOS):
Cada uno de los {cantidad} guiones DEBE pertenecer a una temática o revelación de ingeniería y ciencia técnica relevante al sub-nicho del canal:
- Si el canal trata sobre Automoción, Seguridad Vial o Vehículos: explora temáticas vehiculares distintas (aquaplaning y neumáticos, radares de tramo y telemetría de velocidad, uso correcto de luces con lluvia, cajas de cambios automáticas vs mecánicas, frenos ABS y distancia de frenado).
- Si el canal trata sobre Infraestructura y Tecnología Cotidiana: explora temáticas técnicas de uso masivo (telemetría de Google Maps y congestiones, satélites GPS, antenas celulares de alta velocidad, cimentaciones antisísmicas, asfalto drenante).
- PROHIBIDO imponer temas desconectados del nicho (como plomería o sifones en un canal de autos). Cada guion debe tener un ángulo visual y explicativo único.
"""
    else:
        guia_tema = f"""
VARIEDAD TEMÁTICA OBLIGATORIA:
Genera historias completas, frescas y diferenciadas dentro del nicho "{tipo_nicho}".
Cada guion debe explorar un dilema, conflicto humano o revelación completamente distinta (personajes nuevos, profesiones distintas, escenarios variados).
"""

    bloque_ejemplos = ""
    if ejemplos_referencia or ejemplos_nicho:
        ejemplos_usar = (ejemplos_referencia or ejemplos_nicho)[:1200]
        bloque_ejemplos = f"""
EJEMPLOS DE TONO Y ESTILO DEL CANAL:
\"\"\"
{ejemplos_usar}
\"\"\"
"""

    bloque_urls = ""
    if urls_referencia:
        try:
            from core.analizar_nicho import extraer_info_url
            transcripciones = []
            for u in urls_referencia[:5]:
                u_str = str(u).strip()
                if not u_str:
                    continue
                info = extraer_info_url(u_str)
                g_txt = info.get("guion") or info.get("descripcion") or ""
                if g_txt:
                    c_name = info.get("canal") or "Canal Referencia"
                    t_name = info.get("titulo") or "Video Viral"
                    transcripciones.append(f"--- VIDEO VIRAL [{c_name}]: {t_name} ---\n{g_txt[:1600]}")
            if transcripciones:
                bloque_urls = f"""
VIDEOS VIRALES DE REFERENCIA APORTADOS POR EL CREADOR (PARAFRASEO INTELIGENTE):
El creador proporcionó los siguientes videos y transcripciones reales que son virales en su nicho.
Tu tarea es ASIMILAR el ritmo, el gancho y el tipo de revelación técnica para PARAFRASEAR y crear {cantidad} guiones NUEVOS y originales dentro del mismo territorio:
\"\"\"
{"\n\n".join(transcripciones)}
\"\"\"
REGLAS DE PARAFRASEO Y REPLICACIÓN VIRAL:
1. NUNCA hagas copia textual. Parafrasea la estructura psicológica de retención.
2. Explica fenómenos o dilemas paralelos con analogías visuales frescas y datos técnicos precisos.
3. Mantén la misma intensidad y progresión dramática/técnica que hizo viral a la referencia.
"""
        except Exception:
            pass

    bloque_inst_especifica = ""
    if inst_base:
        # Limpiar cualquier texto de '3 guiones' o bloque de entrega estático que confunda la cantidad
        inst_limpia = re.sub(r"redactar\s+\d+\s+guiones", f"redactar {cantidad} guiones", inst_base, flags=re.I)
        inst_limpia = re.sub(r"(?:FORMATO ESTRICTO DE ENTREGA|FORMATO DE ENTREGA)[\s\S]*$", "", inst_limpia, flags=re.I).strip()
        bloque_inst_especifica = f"""
INSTRUCCIÓN Y ESTILO DEL CANAL ({nombre_nicho}):
\"\"\"
{inst_limpia[:2500]}
\"\"\"
"""

    ejemplos_encabezados = "\n\n".join([
        f"GUION: {i:02d} - [Título del Guion {i:02d}]\n[Texto completo de la narración en voz en off continua del guion {i:02d}, exactamente entre {min_palabras} y {max_palabras} palabras]"
        for i in range(1, cantidad + 1)
    ])

    user_prompt = f"""Redacta OBLIGATORIAMENTE un total de EXACTAMENTE {cantidad} guiones originales de alta retención para el canal "{nombre_nicho}" ({tipo_nicho}).

REGLA DE CANTIDAD ABSOLUTA:
- Debes entregar EXACTAMENTE {cantidad} guiones completos (ni uno más, ni uno menos).
- PROHIBIDO detenerte antes de entregar los {cantidad} guiones.
- PROHIBIDO escribir ideas previas, lluvias de ideas, resúmenes, esquemas ni notas de bienvenida. Ve DIRECTO a los guiones.
- Cada uno de los {cantidad} guiones debe ser el texto íntegro y definitivo de la narración de principio a fin.

CALIBRACIÓN CRÍTICA DE EXTENSIÓN Y TIEMPO POR GUION:
- Duración solicitada: {duracion_segundos} segundos.
- Cada uno de los {cantidad} guiones debe tener OBLIGATORIAMENTE ENTRE {min_palabras} Y {max_palabras} PALABRAS (Objetivo: ~{objetivo_palabras} palabras).
- No excedas ni recortes esta cantidad: el narrador debe cubrir con precisión los {duracion_segundos} segundos.

{guia_tema}
{bloque_urls}
{bloque_ejemplos}
{bloque_inst_especifica}

FORMATO ESTRICTO DE ENTREGA:
Debes entregar los {cantidad} guiones completos numerados en orden secuencial del 01 al {cantidad:02d}, exactamente con esta estructura:

{ejemplos_encabezados}

CERO introducciones, cero explicaciones o notas previas o posteriores. Empieza directamente con 'GUION: 01'.
"""

    return system_instruction, user_prompt, min_palabras, max_palabras


def generar_tanda_guiones_ia(
    nicho_dir: Path,
    cantidad: int = 3,
    duracion_segundos: int = 60,
    formato: str = "shorts",
    tema_libre: str = "",
    api_key: str = None,
    urls_referencia: list[str] = None,
    **kwargs
) -> tuple[bool, str, list[dict], str]:
    """
    Ejecuta la llamada a Gemini y devuelve la tanda de guiones parseada con métricas.
    Retorna: (ok, mensaje, lista_guiones, texto_crudo)
    """
    if not tema_libre and kwargs.get("tema"):
        tema_libre = kwargs.get("tema")
    if not urls_referencia and (kwargs.get("urls") or kwargs.get("urls_referencia")):
        urls_referencia = kwargs.get("urls") or kwargs.get("urls_referencia")
    nicho_dir = Path(nicho_dir).resolve()
    if not nicho_dir.is_dir():
        return False, f"La carpeta del nicho no existe: {nicho_dir}", [], ""

    claves = obtener_claves_prompts(api_key)
    if not claves:
        return False, "No hay API Key de Gemini configurada. Por favor regístrala en la sección de Configuración.", [], ""

    sys_inst, user_prompt, min_p, max_p = construir_prompt_generacion_guiones(
        nicho_dir=nicho_dir,
        cantidad=cantidad,
        duracion_segundos=duracion_segundos,
        formato=formato,
        tema_libre=tema_libre,
        urls_referencia=urls_referencia
    )

    res_texto = ""
    modelo_usado = ""
    ultimo_error = ""

    for k in claves:
        for mod in MODELOS_RECOMENDADOS:
            endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={k}"
            body = {
                "contents": [{"parts": [{"text": user_prompt}]}],
                "systemInstruction": {"parts": [{"text": sys_inst}]},
                "generationConfig": {
                    "temperature": 0.45,
                    "maxOutputTokens": 16384
                }
            }
            try:
                req = urllib.request.Request(
                    endpoint,
                    data=json.dumps(body).encode("utf-8"),
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=120) as resp:
                    d_res = json.loads(resp.read().decode("utf-8"))
                    cand = d_res.get("candidates", [{}])[0]
                    t = cand.get("content", {}).get("parts", [{}])[0].get("text", "")
                    if t and len(t.strip()) > 100:
                        res_texto = t.strip()
                        modelo_usado = mod
                        break
            except urllib.error.HTTPError as he:
                ultimo_error = f"HTTP {he.code} en {mod}"
                continue
            except Exception as e:
                ultimo_error = f"{e} en {mod}"
                continue
        if res_texto:
            break

    if not res_texto:
        return False, f"Gemini no pudo generar los guiones ({ultimo_error or 'tiempo de espera agotado'}).", [], ""

    guiones_lista = parsear_guiones_generados(res_texto, duracion_objetivo_sec=duracion_segundos)
    if not guiones_lista:
        return False, "Gemini respondió pero no se pudieron estructurar los bloques GUION: 01, GUION: 02.", [], res_texto

    msg = f"Se generaron {len(guiones_lista)} guión(es) exitosamente con {modelo_usado} (~{duracion_segundos}s cada uno)."
    return True, msg, guiones_lista, res_texto


def parsear_guiones_generados(texto_crudo: str, duracion_objetivo_sec: int = 60) -> list[dict]:
    """
    Parsea el texto de salida en objetos estructurados por guion.
    Soporta cualquier variación de encabezados con markdown, asteriscos, corchetes, numerales, etc.
    """
    guiones = []
    # Buscar patrones de tipo: GUION: 01 - Título, **GUION 01:** Título, ## GUION: 01, etc.
    patron = r"(?:^|\n)[ \t]*(?:[#*`_~>\-]+\s*)*(?:GUION|GUIÓN|SHORT|VIDEO|HISTORIA|EPISODIO|CAPITULO|CAPÍTULO)\s*[:#\s]*\s*(\d+)(?:[ \t*:`_\-–—]+([^\n\r*`]+))?"
    matches = list(re.finditer(patron, texto_crudo, re.IGNORECASE))

    if not matches:
        # Fallback 1: Buscar patrones numéricos tipo 1. [Título] o # 1: [Título]
        patron_sec = r"(?:^|\n)[ \t]*(?:[#*`_~>\-]+\s*)*(\d+)[\.\)][ \t]+([^\n\r*`]+)"
        matches_sec = list(re.finditer(patron_sec, texto_crudo))
        if len(matches_sec) > 1:
            matches = matches_sec

    if not matches:
        # Fallback 2: Buscar bloques separados por triples saltos de línea si tienen texto sustancial
        bloques_raw = re.split(r"\n{3,}", texto_crudo.strip())
        if len(bloques_raw) > 1:
            for idx_b, b in enumerate(bloques_raw):
                b_limpio = limpiar_locucion_para_tts(b)
                pals = len(b_limpio.split())
                if pals > 20:
                    guiones.append({
                        "numero": idx_b + 1,
                        "identificador": str(idx_b + 1).zfill(2),
                        "titulo": f"Guion {idx_b + 1:02d}",
                        "texto": b_limpio,
                        "palabras": pals,
                        "duracion_estimada_sec": round(pals / VELOCIDAD_PALABRAS_POR_SEGUNDO, 1),
                        "gancho": obtener_primera_oracion(b_limpio)
                    })
            if guiones:
                return guiones

        # Fallback final: Tratar como 1 solo guion
        texto_limpio = limpiar_locucion_para_tts(texto_crudo)
        palabras = len(texto_limpio.split())
        if palabras > 20:
            guiones.append({
                "numero": 1,
                "identificador": "01",
                "titulo": "Guion Generado",
                "texto": texto_limpio,
                "palabras": palabras,
                "duracion_estimada_sec": round(palabras / VELOCIDAD_PALABRAS_POR_SEGUNDO, 1),
                "gancho": obtener_primera_oracion(texto_limpio)
            })
        return guiones

    for i, m in enumerate(matches):
        num_str = str(m.group(1)).zfill(2)
        titulo_raw = (m.group(2) or "").strip()
        start_idx = m.end()
        end_idx = matches[i + 1].start() if i + 1 < len(matches) else len(texto_crudo)
        cuerpo = texto_crudo[start_idx:end_idx].strip()
        
        cuerpo_limpio = limpiar_locucion_para_tts(cuerpo)
        palabras = len(cuerpo_limpio.split())
        
        # Limpiar si el título trae corchetes, asteriscos o negritas
        titulo = re.sub(r"[*_`\"\[\]#]", "", titulo_raw).strip()
        if not titulo or len(titulo) < 3 or titulo.lower() in ("titulo", "título", "titulo sugerido"):
            titulo = f"Guion {num_str}"

        guiones.append({
            "numero": i + 1,
            "identificador": num_str,
            "titulo": titulo,
            "texto": cuerpo_limpio,
            "palabras": palabras,
            "duracion_estimada_sec": round(palabras / VELOCIDAD_PALABRAS_POR_SEGUNDO, 1),
            "gancho": obtener_primera_oracion(cuerpo_limpio)
        })

    return guiones


def limpiar_locucion_para_tts(texto: str) -> str:
    """
    Garantiza que el texto quede 100% limpio para el sintetizador de voz (sin acotaciones ni markdown).
    """
    t = texto.strip()
    # Eliminar bloques markdown como ```texto ... ```
    t = re.sub(r"```[a-zA-Z]*\n?", "", t)
    t = re.sub(r"```", "", t)
    # Eliminar acotaciones entre corchetes [música alegre], [pausa], [risas]
    t = re.sub(r"\[[^\]]+\]", "", t)
    # Eliminar acotaciones entre paréntesis con verbos o direcciones (pausa), (suspiro), (tono irónico)
    t = re.sub(r"\((?:pausa|suspiro|tono|música|efecto|grito|llanto|sonrisa|voz)[^\)]*\)", "", t, flags=re.I)
    # Eliminar etiquetas de personajes o roles al inicio de línea como Narrador:, Locutor:, Persona 1:
    t = re.sub(r"^(?:Narrador|Locutor|Voz en off|Voz|Personaje(?:\s*\d+)?)\s*:\s*", "", t, flags=re.MULTILINE | re.I)
    # Eliminar asteriscos de negrita/cursiva markdown
    t = t.replace("**", "").replace("*", "")
    # Reemplazar múltiples saltos de línea por párrafos fluidos
    t = re.sub(r"\n\s*\n+", "\n\n", t)
    # Reemplazar símbolos $ por palabras si quedan
    t = re.sub(r"\$(\d+)", r"\1 dólares", t)
    return t.strip()


def obtener_primera_oracion(texto: str) -> str:
    """Extrae la primera oración para mostrar el gancho en la UI."""
    m = re.search(r"^([^.!?\n]+[.!?])", texto)
    if m:
        return m.group(1).strip()
    lineas = [l.strip() for l in texto.splitlines() if l.strip()]
    return lineas[0][:120] + "..." if lineas else ""


def guardar_guiones_en_archivo_nicho(nicho_dir: Path, guiones_lista: list[dict], modo: str = "apendizar") -> tuple[bool, str]:
    """
    Guarda o apendiza los guiones en el archivo guiones.txt del nicho.
    """
    nicho_dir = Path(nicho_dir).resolve()
    if not nicho_dir.is_dir():
        return False, "La carpeta del nicho no existe."

    guiones_f = nicho_dir / "guiones.txt"
    bloques_txt = []
    
    for g in guiones_lista:
        b = f"GUION: {g['identificador']} - {g['titulo']}\n{g['texto']}"
        bloques_txt.append(b)

    contenido_nuevo = "\n\n".join(bloques_txt) + "\n"

    try:
        if modo == "sobrescribir" or not guiones_f.is_file():
            guiones_f.write_text(contenido_nuevo, encoding="utf-8")
        else:
            existente = guiones_f.read_text(encoding="utf-8", errors="replace").rstrip()
            if existente:
                guiones_f.write_text(existente + "\n\n" + contenido_nuevo, encoding="utf-8")
            else:
                guiones_f.write_text(contenido_nuevo, encoding="utf-8")
        return True, f"Se guardaron {len(guiones_lista)} guión(es) en {guiones_f.name}"
    except Exception as e:
        return False, f"Error al escribir {guiones_f.name}: {e}"
