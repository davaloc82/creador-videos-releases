# -*- coding: utf-8 -*-
"""
Módulo de Generación de Prompts con Gemini IA para NEXOR.
Genera referencias.txt (P1, P2), imagen.txt (escenas 1:1 + portada 9:16)
y movimiento.txt para proyectos de video a partir de guion.txt y sincronia.txt.
"""

import os
import sys
import re
import json
import time
import urllib.request
import urllib.error
import subprocess
from pathlib import Path

AQUI = Path(__file__).resolve().parent.parent
CONFIG_PROMPTS_FILE = AQUI / "config_ia_prompts.json"

MODELOS_RECOMENDADOS = [
    "gemini-3.5-flash-lite",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "gemini-3.5-flash"
]


def obtener_config_prompts() -> dict:
    """Carga configuración dedicada para generación de prompts si existe."""
    if CONFIG_PROMPTS_FILE.is_file():
        try:
            return json.loads(CONFIG_PROMPTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def guardar_config_prompts(cfg: dict) -> bool:
    """Guarda configuración dedicada para generación de prompts."""
    try:
        CONFIG_PROMPTS_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        return True
    except Exception:
        return False


def obtener_claves_prompts(clave_directa: str = None) -> list:
    """Obtiene la lista ordenada de claves de API a utilizar."""
    if clave_directa and clave_directa.strip() and not clave_directa.startswith("PEGA_"):
        return [clave_directa.strip()]

    cfg = obtener_config_prompts()
    k_dedicada = (cfg.get("api_key") or cfg.get("gemini_api_key") or "").strip()
    if k_dedicada and not k_dedicada.startswith("PEGA_"):
        return [k_dedicada]

    # Comprobar config_gemini.json en la raíz
    cfg_g = AQUI / "config_gemini.json"
    if cfg_g.is_file():
        try:
            d_g = json.loads(cfg_g.read_text(encoding="utf-8"))
            k_g = (d_g.get("gemini_api_key") or d_g.get("api_key") or "").strip()
            if k_g and not k_g.startswith(("PEGA_", "TU_")):
                return [k_g]
        except Exception:
            pass

    try:
        from core.diseccion_multimodal import obtener_claves_activas
        return obtener_claves_activas()
    except Exception:
        pass

    env_k = os.environ.get("GEMINI_API_KEY", "").strip()
    if env_k:
        return [env_k]

    return []


def resolver_estilo_visual_nicho(proy_dir: Path, nicho_raiz: Path = None) -> dict:
    """Busca y extrae la configuración del estilo visual del nicho.
    Si el nicho es de estilo Cómic/Caricatura, garantiza sufijos y prompts de estilo cómic.
    Si se configuró otro estilo (ej: Pixar 3D, Realismo, Anime, etc.), usa dicho estilo.
    Por defecto, adopta el estilo probado de Novela Gráfica / Cómic Ilustrado (estilo Ecos).
    """
    estilo_defecto = {
        "estilo_id": "comic",
        "estilo_nombre": "Novela Gráfica / Cómic Ilustrado",
        "sufijo_estilo": "Highly detailed comic book illustration style with clean bold line art, vibrant colors, flat color fills, graphic novel aesthetic, masterpiece, 8k --ar 9:16 --v 6 --stylize 250 --style raw",
        "sufijo_movimiento": "Maintain the exact comic book illustration, clean bold line art, vibrant colors, flat color fills, and graphic novel style of the original image. No text.",
        "tipo_personajes": "variados",
        "es_caricatura": True
    }

    raiz_cand = nicho_raiz or (proy_dir.parent if proy_dir else None)
    cfg_f = None
    if raiz_cand:
        f = Path(raiz_cand) / "config_nicho.json"
        if f.is_file():
            cfg_f = f
    if not cfg_f and proy_dir:
        f = proy_dir.parent / "config_nicho.json"
        if f.is_file():
            cfg_f = f

    if cfg_f and cfg_f.is_file():
        try:
            data = json.loads(cfg_f.read_text(encoding="utf-8"))
            iv = data.get("identidad_visual") or {}
            e_id = iv.get("estilo_id") or data.get("estilo_id") or ""
            e_nom = iv.get("estilo_nombre") or data.get("estilo_visual") or ""
            e_suf = iv.get("sufijo_estilo") or data.get("sufijo_estilo") or ""
            e_mov = iv.get("sufijo_movimiento") or data.get("sufijo_movimiento") or ""
            t_p = data.get("tipo_personajes") or ""

            res = dict(estilo_defecto)
            if e_id:
                res["estilo_id"] = str(e_id).strip()
            if e_nom:
                res["estilo_nombre"] = str(e_nom).strip()
            if e_suf:
                res["sufijo_estilo"] = str(e_suf).strip()
            if e_mov:
                res["sufijo_movimiento"] = str(e_mov).strip()
            if t_p:
                res["tipo_personajes"] = str(t_p).strip()

            cadena_check = (res["estilo_id"] + " " + res["estilo_nombre"] + " " + res["sufijo_estilo"]).lower()
            if any(k in cadena_check for k in ["comic", "caricatura", "cartoon", "pixar", "anime", "dibujo", "ilustra", "bold line", "shonen", "3d animation"]):
                res["es_caricatura"] = True
            elif any(k in cadena_check for k in ["realis", "35mm", "fotograf", "photography"]):
                res["es_caricatura"] = False
            return res
        except Exception:
            pass

    return estilo_defecto


def resolver_instruccion_prompts(proy_dir: Path, nicho_raiz: Path = None) -> str:
    """Busca y carga la instrucción de prompts maestra o específica del canal."""
    candidatos = []
    if nicho_raiz:
        candidatos.append(nicho_raiz / "instrucciones" / "INSTRUCCION_PROMPTS.md")
        candidatos.append(nicho_raiz / "INSTRUCCION_PROMPTS.md")
    if proy_dir:
        candidatos.append(proy_dir.parent / "instrucciones" / "INSTRUCCION_PROMPTS.md")
        candidatos.append(proy_dir / "INSTRUCCION_PROMPTS.md")

    candidatos.extend([
        Path(r"C:\Users\Usuario\Downloads\virales ecos\prompts ecos\PROMPTS ECOS MASTER v2.md"),
        Path(r"C:\Users\Usuario\Downloads\virales ecos\PROMPTS ECOS MASTER v2.md"),
        AQUI / "instrucciones_maestras" / "INSTRUCCION_MAESTRA_PROMPTS.md",
        AQUI / "instrucciones" / "INSTRUCCION_PROMPTS.md"
    ])

    for c in candidatos:
        try:
            if c and c.is_file():
                txt = c.read_text(encoding="utf-8").strip()
                if txt:
                    return txt
        except Exception:
            continue
    return ""


def resolver_referencias_maestras(proy_dir: Path, nicho_raiz: Path = None) -> str:
    """Busca personajes maestros para canales con personaje(s) recurrente(s) fijo(s) (ej: Tío Rico Mac Pato, Lobo, Avatar).
    Si el nicho es de historias variadas / antología (como Ecos o reflexiones sin personaje fijo), devuelve '' para que Gemini
    diseñe un elenco nuevo y único a medida para este guion específico."""
    # 1. Si es explícitamente la antología personal de Ecos / Nuevos Guiones
    if proy_dir and "nuevos guiones" in str(proy_dir).lower():
        return ""
    if nicho_raiz and "nuevos guiones" in str(nicho_raiz).lower():
        return ""

    # 2. Comprobar config_nicho.json en la raíz del nicho o carpeta contenedora
    raiz_cand = nicho_raiz or (proy_dir.parent if proy_dir else None)
    if raiz_cand:
        cfg_f = Path(raiz_cand) / "config_nicho.json"
        if not cfg_f.is_file() and proy_dir:
            cfg_f = proy_dir.parent / "config_nicho.json"
        if cfg_f.is_file():
            try:
                c_data = json.loads(cfg_f.read_text(encoding="utf-8"))
                # Si se configuró explícitamente como antología de historias con personajes variados
                t_p = str(c_data.get("tipo_personajes", "")).lower()
                if t_p in ("variados", "antologia", "historias_variadas", "reflexion_variada"):
                    return ""
                # Si tiene personaje sugerido o personaje 1 definido en identidad visual
                iv = c_data.get("identidad_visual") or {}
                p1_p = iv.get("personaje_sugerido_prompt") or iv.get("personaje_1_prompt") or ""
                p2_p = iv.get("personaje_2_prompt") or ""
                if p1_p and len(p1_p.strip()) > 15:
                    lineas = [f"(P1): {p1_p.strip()}"]
                    if p2_p and len(p2_p.strip()) > 15 and p2_p != "N/A" and not p2_p.startswith("#"):
                        lineas.append(f"(P2): {p2_p.strip()}")
                    return "\n\n".join(lineas)
            except Exception:
                pass

    # 3. Comprobar archivos físicos maestros de personajes
    candidatos = []
    if nicho_raiz:
        for n in ("referencias_maestras.txt", "personajes_nicho.txt", "IDENTIDAD_PERSONAJES.txt"):
            candidatos.append(nicho_raiz / n)
            candidatos.append(nicho_raiz / "instrucciones" / n)
    if proy_dir:
        for n in ("referencias_maestras.txt", "personajes_nicho.txt", "IDENTIDAD_PERSONAJES.txt"):
            candidatos.append(proy_dir.parent / n)
            candidatos.append(proy_dir.parent / "instrucciones" / n)

    for c in candidatos:
        try:
            if c and c.is_file():
                txt = c.read_text(encoding="utf-8", errors="replace").strip()
                # Filtrar comentarios o encabezados vacíos
                lineas_utiles = [l for l in txt.splitlines() if l.strip() and not l.strip().startswith("#")]
                if lineas_utiles:
                    return "\n".join(lineas_utiles)
        except Exception:
            continue
    return ""


def resolver_instruccion_seo(proy_dir: Path = None, nicho_raiz: Path = None) -> str:
    """Busca y carga la instrucción de SEO maestra para YouTube/TikTok/FB."""
    candidatos = []
    if nicho_raiz:
        candidatos.append(nicho_raiz / "instrucciones" / "INSTRUCCION_SEO.md")
        candidatos.append(nicho_raiz / "SEO_MASTER.md")
    if proy_dir:
        candidatos.append(proy_dir.parent / "instrucciones" / "INSTRUCCION_SEO.md")
    candidatos.extend([
        Path(r"C:\Users\Usuario\Downloads\virales ecos\SEO ECOS MASTER v2.md"),
        Path(r"C:\Users\Usuario\Downloads\virales ecos\SEO ECOS MASTER.md"),
        AQUI / "instrucciones_maestras" / "INSTRUCCION_MAESTRA_SEO.md"
    ])
    for c in candidatos:
        try:
            if c and c.is_file():
                txt = c.read_text(encoding="utf-8", errors="replace").strip()
                if txt:
                    return txt
        except Exception:
            continue
    return ""


def limpiar_texto_bloque(texto: str) -> str:
    """Limpia citas de NotebookLM/Gemini, referencias [cite: XX], corchetes numéricos y residuos Markdown."""
    if not texto:
        return ""
    # Eliminar cualquier variante de citación [cite: 21], [cite:1], [cite 1], [citation: ...], 【...】
    t = re.sub(r'\[cite(?::\s*|\s+)[^\]]*\]', '', texto, flags=re.I)
    t = re.sub(r'\[(?:cite|citation|source|fuente)[^\]]*\]', '', t, flags=re.I)
    t = re.sub(r'【[^】]*】', '', t)
    t = re.sub(r'\[\d+(?:,\s*\d+)*\]', '', t)
    # Eliminar posibles vallas markdown residuales
    t = re.sub(r'^```[a-zA-Z0-9_-]*\s*\n', '', t)
    t = re.sub(r'\n```\s*$', '', t)
    # Limpiar espacios dobles o múltiples dejados por las eliminaciones
    t = re.sub(r'[ \t]{2,}', ' ', t)
    return t.strip()


def extraer_bloques_salida(respuesta: str) -> dict:
    """Extrae referencias.txt, imagen.txt, movimiento.txt y seo.txt de la respuesta de Gemini."""
    res = {
        "referencias": "",
        "imagen": "",
        "movimiento": "",
        "seo": "",
        "prompt_yt": "",
        "portada_16_9": ""
    }
    if not respuesta:
        return res

    # 1. Búsqueda por bloques de código identificados
    patrones = {
        "referencias": [
            r"```(?:referencias\.txt|referencias|ref)\s*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*referencias(?:\.txt)?\s*\n```[a-zA-Z]*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*referencias(?:\.txt)?\s*\n(.*?)(?=\n#{1,3}|\n```|\Z)"
        ],
        "imagen": [
            r"```(?:imagen\.txt|imagen|scenes|escenas)\s*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*imagen(?:\.txt)?\s*\n```[a-zA-Z]*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*imagen(?:\.txt)?\s*\n(.*?)(?=\n#{1,3}|\n```|\Z)"
        ],
        "movimiento": [
            r"```(?:movimiento\.txt|movimiento|motion)\s*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*movimiento(?:\.txt)?\s*\n```[a-zA-Z]*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*movimiento(?:\.txt)?\s*\n(.*?)(?=\n#{1,3}|\n```|\Z)"
        ],
        "seo": [
            r"```(?:seo\.txt|seo|paquete_seo)\s*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*(?:paquete\s*)?seo(?:\.txt)?\s*\n```[a-zA-Z]*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*(?:paquete\s*)?seo(?:\.txt)?\s*\n(.*?)(?=\n#{1,3}|\n```|\Z)"
        ],
        "prompt_yt": [
            r"```(?:prompt\s*yt\.txt|prompt_yt\.txt|miniatura_yt)\s*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*prompt\s*yt(?:\.txt)?\s*\n```[a-zA-Z]*\n(.*?)\n```"
        ],
        "portada_16_9": [
            r"```(?:portada_16_9\.txt|portada_16_9|portada_youtube|miniatura_16_9|portada_horizontal)\s*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*portada(?:_16_9|_youtube|_horizontal)?(?:\.txt)?\s*\n```[a-zA-Z]*\n(.*?)\n```",
            r"(?:^|\n)#{1,3}\s*(?:portada|miniatura)\s*(?:youtube|16:9|16_9|horizontal)\s*\n(.*?)(?=\n#{1,3}|\n```|\Z)"
        ]
    }

    for clave, lista_patrones in patrones.items():
        for pat in lista_patrones:
            m = re.search(pat, respuesta, re.DOTALL | re.IGNORECASE)
            if m:
                res[clave] = limpiar_texto_bloque(m.group(1))
                if res[clave]:
                    break

    # 2. Si no se encontraron los bloques con triple backtick exacto, usar parser universal flexible
    if not res.get("imagen") or not res.get("referencias"):
        tags = ["referencias", "imagen", "movimiento", "seo", "portada_16_9"]
        header_pattern = re.compile(r'(?:^|\n)(?:`{1,4}|#{1,4}\s*)?([a-zA-Z0-9_]+(?:\.txt)?)(?:`{1,4})?[:\s]*\n', re.IGNORECASE)
        splits = []
        for m in header_pattern.finditer(respuesta):
            name = m.group(1).lower().replace('.txt', '')
            for t in tags:
                if t in name:
                    splits.append((m.start(), m.end(), t))
                    break

        for i, (start_h, end_h, t) in enumerate(splits):
            end_content = splits[i+1][0] if i+1 < len(splits) else len(respuesta)
            content = respuesta[end_h:end_content].strip()
            content = re.sub(r'\n`{1,4}\s*$', '', content).strip()
            c_clean = limpiar_texto_bloque(content)
            if c_clean and not res.get(t):
                res[t] = c_clean

    # Si imagen.txt sigue vacía, buscar bloques anónimos
    if not res["imagen"]:
        bloques_anonimos = re.findall(r"`{1,4}(?:text|markdown|txt)?\s*\n(.*?)\n`{1,4}", respuesta, re.DOTALL)
        for b in bloques_anonimos:
            b_clean = limpiar_texto_bloque(b)
            if "comic book" in b_clean.lower() or "--ar" in b_clean:
                if len(b_clean.splitlines()) > 3:
                    res["imagen"] = b_clean
                    break

    # Soporte para respuestas formateadas como JSON por Gemini
    for campo in ("referencias", "imagen", "movimiento"):
        val = (res.get(campo) or "").strip()
        if val.startswith("[") or val.startswith("{"):
            try:
                parsed_json = json.loads(val)
                if isinstance(parsed_json, list):
                    lineas_conv = []
                    for idx_j, it in enumerate(parsed_json, 1):
                        if isinstance(it, dict):
                            p_txt = it.get("prompt_imagen") or it.get("prompt") or it.get("descripcion") or ""
                            pref = f"(P{idx_j}): " if campo == "referencias" else ""
                            if p_txt:
                                lineas_conv.append(f"{pref}{p_txt}")
                        elif isinstance(it, str):
                            lineas_conv.append(it)
                    if lineas_conv:
                        res[campo] = "\n\n".join(lineas_conv) if campo == "imagen" else "\n".join(lineas_conv)
            except Exception:
                pass

    return res


def calcular_escenas_movimiento(num_escenas: int, es_video_largo: bool = False) -> list[int]:
    """Calcula las escenas exactas que deben tener prompt de movimiento.
    - Shorts (vertical 9:16): 1 y 2 siempre animadas; luego alternan saltando 2 imágenes estáticas:
      1, 2, 5, 8, 11, 14, 17, 20, 23...
    - Videos Largos (16:9 horizontal): 1 y 2 siempre animadas; luego alternando saltos de 2 y 3:
      1, 2, 5, 9, 12, 16, 19, 23, 26, 30...
    """
    if num_escenas <= 0:
        return []
    if num_escenas == 1:
        return [1]

    escenas = [1, 2]
    if not es_video_largo:
        curr = 5
        while curr <= num_escenas:
            escenas.append(curr)
            curr += 3
    else:
        curr = 2
        salto_dos = True
        while True:
            paso = 3 if salto_dos else 4
            curr += paso
            if curr > num_escenas:
                break
            escenas.append(curr)
            salto_dos = not salto_dos

    return [e for e in escenas if e <= num_escenas]


def formatear_movimiento_estricto(raw_movimiento: str, escenas_objetivo: list[int], sufijo_mov: str = None) -> str:
    """Garantiza que movimiento.txt contenga ÚNICAMENTE las escenas objetivo (ej: 1, 2, 5, 8, 11, 14, 17)
    ordenadas numéricamente y con su número de escena al inicio, sin etiquetas de personaje (P1, P2)."""
    if not escenas_objetivo:
        return ""

    sufijo_def = sufijo_mov or "Maintain the exact comic book illustration, clean bold line art, vibrant colors, flat color fills, and graphic novel style of the original image. No text."

    lineas_por_escena = {}
    if raw_movimiento:
        bloques_raw = [b.strip() for b in re.split(r"\n\s*\n+", raw_movimiento) if b.strip()]
        for b in bloques_raw:
            # Ignorar cualquier línea de comentario o cabecera que empiece con // o #
            if b.startswith("//") or b.startswith("#") or "imágenes para animar" in b.lower() or "imagenes para animar" in b.lower():
                continue
            m = re.match(r"^(?:prompt|escena|scene|imagen|img|frame|clip)?\s*#?\[?(\d+)\]?[\.\-:\)\s]+\s*([\s\S]+)$", b, re.I) or re.match(r"^(\d+)\s+([\s\S]+)$", b)
            if m:
                num = int(m.group(1))
                texto = m.group(2).strip()
                # Limpiar etiquetas de personajes (P1), (P2), [P1], etc. ya que el video usa la imagen renderizada
                texto = re.sub(r"[\(\[]\s*(?:P\d+|REF\d+|Ref\d+|p\d+)\s*[\)\]][:.\s]*", "", texto, flags=re.I)
                texto = re.sub(r"@p\d+\b[:.\s]*", "", texto, flags=re.I).strip()
                if num in escenas_objetivo and num not in lineas_por_escena:
                    lineas_por_escena[num] = f"{num}. {texto}"

    salida_final = []
    for esc in escenas_objetivo:
        if esc in lineas_por_escena:
            salida_final.append(lineas_por_escena[esc])
        else:
            salida_final.append(f"{esc}. Slow cinematic push-in. {sufijo_def}")

    return "\n\n".join(salida_final)


def generar_prompts_para_proyecto(proy_dir: Path, nicho_raiz: Path = None, api_key: str = None) -> tuple[bool, str, dict]:
    """
    Genera referencias.txt, imagen.txt y movimiento.txt para un proyecto específico.
    Lee guion.txt y sincronia.txt del directorio y llama a Gemini API.
    """
    proy_dir = Path(proy_dir).resolve()
    if not proy_dir.is_dir():
        return False, f"Directorio no encontrado: {proy_dir}", {}

    guion_f = proy_dir / "guion.txt"
    sinc_f = proy_dir / "sincronia.txt"

    if not guion_f.is_file():
        return False, f"No existe guion.txt en {proy_dir.name}", {}

    guion_txt = guion_f.read_text(encoding="utf-8", errors="replace").strip()
    if not guion_txt:
        return False, f"El archivo guion.txt está vacío en {proy_dir.name}", {}

    # Si sincronia.txt no existe o está vacía, auto-segmentar inmediatamente
    if not sinc_f.is_file() or sinc_f.stat().st_size == 0:
        try:
            aqui_raiz = Path(__file__).resolve().parent.parent
            script_seg = aqui_raiz / "ecos" / "segmentar_guion.py"
            if script_seg.is_file():
                kw_seg = {"capture_output": True, "timeout": 30}
                if sys.platform.startswith("win"): kw_seg["creationflags"] = 0x08000000
                subprocess.run([sys.executable, str(script_seg), str(proy_dir)], **kw_seg)
        except Exception:
            pass

    # Si aún no existe, generar segmentación base desde las oraciones del guion
    if not sinc_f.is_file() or sinc_f.stat().st_size == 0:
        parrafos = [p.strip() for p in guion_txt.splitlines() if p.strip()]
        escenas_auto = []
        t_acum = 0.0
        for p in parrafos:
            frases = [f.strip() for f in re.split(r'[.?!]+', p) if len(f.strip()) > 3]
            if not frases:
                frases = [p]
            for fr in frases:
                dur = max(2.5, min(5.5, len(fr.split()) * 0.42))
                escenas_auto.append(f"{t_acum:.2f} - {t_acum+dur:.2f} | {fr}")
                t_acum += dur
        if escenas_auto:
            sinc_f.write_text("\n".join(escenas_auto), encoding="utf-8")

    sinc_txt = sinc_f.read_text(encoding="utf-8", errors="replace").strip() if sinc_f.is_file() else ""
    sinc_lineas = [l for l in sinc_txt.splitlines() if l.strip() and not l.strip().startswith("#")]
    num_escenas = len(sinc_lineas)
    if num_escenas == 0:
        return False, f"No se detectaron escenas válidas en {proy_dir.name}", {}

    # Determinar si el nicho es formato largo (16:9 / dual) o vertical (Shorts/Reels)
    es_largo = False
    if num_escenas >= 25:
        es_largo = True
    elif nicho_raiz:
        nom_nicho = str(nicho_raiz).lower()
        if any(x in nom_nicho for x in ("finanza", "pelicula", "largo", "novela", "historia_larga", "horizontal")):
            es_largo = True
        cfg_f = Path(nicho_raiz) / "config_nicho.json"
        if cfg_f.is_file():
            try:
                c_data = json.loads(cfg_f.read_text(encoding="utf-8"))
                fmt = str(c_data.get("formato", "")).lower()
                if any(k in fmt for k in ("largo", "16:9", "horizontal", "dual", "youtube")):
                    es_largo = True
            except Exception:
                pass

    escenas_mov = calcular_escenas_movimiento(num_escenas, es_video_largo=es_largo)
    str_escenas_mov = ", ".join(str(e) for e in escenas_mov)

    instruccion = resolver_instruccion_prompts(proy_dir, nicho_raiz)
    ref_maestra = resolver_referencias_maestras(proy_dir, nicho_raiz)
    info_estilo = resolver_estilo_visual_nicho(proy_dir, nicho_raiz)
    estilo_nom = info_estilo.get("estilo_nombre", "Novela Gráfica / Cómic Ilustrado")
    sufijo_estilo = info_estilo.get("sufijo_estilo", "")
    sufijo_mov = info_estilo.get("sufijo_movimiento", "")
    es_caricatura = info_estilo.get("es_caricatura", True)

    claves = obtener_claves_prompts(api_key)
    if not claves:
        return False, "No hay API Key de Gemini configurada. Por favor configúrala en el panel o en config_gemini.json.", {}

    if ref_maestra:
        instruccion_personajes = f"""1. 'referencias.txt': ESTE CANAL UTILIZA PERSONAJE(S) RECURRENTE(S) FIJO(S) (CONSISTENCIA ABSOLUTA):
\"\"\"
{ref_maestra}
\"\"\"
   REGLA DE CONSISTENCIA OBLIGATORIA: Debes incluir en 'referencias.txt' exactamente el personaje principal del canal con prefijo `(P1):`, conservando todos sus rasgos físicos, vestimenta y estilo del personaje recurrente fijado arriba, en plano de cuerpo completo (`Full body shot from head to toe`), fondo blanco puro (`solid white background, studio lighting. textless, without words, clean background`) y el sufijo estándar `--ar 9:16 --v 6 --stylize 250 --style raw`. Si el guion requiere un segundo personaje recurrente o antagonista/secundario para esa escena, defínelo como `(P2):` con las mismas especificaciones."""
    else:
        instruccion_personajes = """1. 'referencias.txt': Personajes principales con prefijos obligatorios `(P1):` y `(P2):`, en plano de cuerpo completo (`Full body shot from head to toe`), fondo blanco puro (`solid white background, studio lighting. textless, without words, clean background`) y el sufijo estándar de cómic `--ar 9:16 --v 6 --stylize 250 --style raw`.
   REGLA DE VARIEDAD OBLIGATORIA (ANTOLOGÍA DE HISTORIAS): Cada guion DEBE tener personajes completamente únicos y diseñados a medida según la narración exacta (edad, etnia, contextura, vestimenta y rol: ej. un joven universitario de 20 años presumido, un padre campesino humilde, un rey con capa y corona, un ejecutivo agresivo en traje, una asistente tímida, un maestro relojero con delantal, una madre anciana de campo, etc.). CADA GUION DEBE TENER UN ELENCO FRESCO, VARIADO Y DIFERENCIADO; PROHIBIDO reutilizar siempre el mismo anciano o mujer."""

    bloque_largo = ""
    if es_largo:
        bloque_largo = f"""
5. 'portada_16_9.txt': PORTADA YOUTUBE HORIZONTAL (16:9).
   Dado que este video es de formato largo para YouTube, debes entregar una SEGUNDA PORTADA en un bloque independiente ```portada_16_9.txt```.
   - Relación de aspecto panorámica 16:9 (`--ar 16:9 --v 6 --stylize 120 --style raw`).
   - Composición horizontal cinematográfica de impacto para miniatura de YouTube: personaje principal en un tercio (izq o der), encuadre amplio con alto contraste dramático y espacio negativo para título.
   - Iluminación cinematográfica de película y colores vibrantes.
   - Parámetros negativos obligatorios: `--no diptych, split screen, comic panels, panel division, dividing line, vertical line, gutter, white border, black border, white margin, letterbox, pillarbox, frame, border, padding, comic page, speech bubbles, text balloons`.
"""

    bloque_estilo_canal = f"""
================================================================================
ESTILO VISUAL DEL CANAL: {estilo_nom.upper()}
SUFIJO DE ESTILO VISUAL OBLIGATORIO:
{sufijo_estilo}
================================================================================
"""
    if es_caricatura:
        bloque_estilo_canal += f"""⚠️ REGLA CRÍTICA DE ESTILO VISUAL — PROHIBIDO EL REALISMO:
Este canal utiliza ESTRICTAMENTE estilo de CARICATURA / NOVELA GRÁFICA / CÓMIC ILUSTRADO / ANIMACIÓN ESTILIZADA.
- Todos los personajes, expresiones y escenarios deben ser descritos como ILUSTRACIONES DIBUJADAS, DIBUJOS o CARICATURAS con trazo definido (crisp clean bold ink line art, vibrant rich saturated colors, flat color fills or stylized comic shading).
- QUEDA TERMINANTEMENTE PROHIBIDO generar descripciones fotorrealistas de personas reales de carne y hueso ('real human', 'photorealistic', 'raw photography', '35mm real actor portrait', etc.).
- Cada uno de los {num_escenas} prompts en 'imagen.txt' DEBE terminar OBLIGATORIAMENTE con el sufijo de estilo del canal:
  "{sufijo_estilo}"
"""
    else:
        bloque_estilo_canal += f"""- Cada uno de los {num_escenas} prompts en 'imagen.txt' DEBE terminar OBLIGATORIAMENTE con el sufijo de estilo del canal:
  "{sufijo_estilo}"
"""

    prompt_usuario = f"""Por favor genera los archivos para el proyecto '{proy_dir.name}' siguiendo estrictamente la guía de Director de Arte, Guionista Visual y Especialista SEO:

GUION NARRADO:
\"\"\"
{guion_txt}
\"\"\"

SEGMENTACION DE ESCENAS (sincronia.txt con {num_escenas} escenas):
\"\"\"
{sinc_txt}
\"\"\"

{bloque_estilo_canal}

REQUISITOS ESTRICTOS DE ENTREGA:
{instruccion_personajes}
2. 'imagen.txt': Exactamente {num_escenas} escenas (1 a {num_escenas}) correspondientes 1:1 con sincronia.txt, inyectando la etiqueta `(P1)` o `(P2)` cuando aparezcan. Sin numeración, sin etiquetas `// cubre:`, cada prompt separado por UNA LÍNEA EN BLANCO.
   Cada prompt de escena DEBE describir la acción, el entorno completo y terminar OBLIGATORIAMENTE con el sufijo de estilo del canal:
   "{sufijo_estilo}"
   La última línea ({num_escenas + 1}) debe ser la PORTADA / MINIATURA híbrida en 9:16 bajo las REGLAS FULL-BLEED DEFINITIVAS:
   - NUNCA usar palabras negativas como 'without borders', 'no frames', 'undivided' en el texto positivo (el modelo CLIP genera marcos blancos al leer esas palabras). Describir positivamente la cobertura: 'A dramatic full-bleed edge-to-edge cinematic graphic illustration with 100% full canvas coverage filling the entire frame'.
   - NUNCA usar 'on the left side... on the right side...' junto a estilos de cómic (produce pantalla dividida con línea negra central). Describir la escena en profundidad integrada: en primer plano (foreground) un personaje y de pie frente a él en la misma habitación (midground) el otro.
   - NUNCA usar 'comic book illustration style' o 'graphic novel aesthetic' (provoca viñetas y márgenes blancos de papel). Usar siempre: 'Stylized digital illustration with crisp bold ink line art, rich vibrant saturated colors, dramatic cinematic lighting, masterpiece, 8k'.
   - Texto estrictamente en el centro exacto (Dead Center Safe Zone): Línea 1 en blanco grande con borde negro, Línea 2 en rosa/rojo vibrante con borde negro.
   - Parámetros obligatorios al final del prompt de portada: `--no diptych, split screen, comic panels, panel division, dividing line, vertical line, gutter, white border, black border, white margin, letterbox, pillarbox, frame, border, padding, comic page, speech bubbles, text balloons --ar 9:16 --v 6 --stylize 120 --style raw`.
   REGLAS CRÍTICAS DE ENCUADRE Y ESCENARIO PARA 'imagen.txt':
   a) PROHIBIDO 'Close-up on hands', 'Close-up on document', 'Close-up on fabric' o planos detalle de manos/objetos sueltos sin contexto. En videos virales de historias, el espectador conecta con PERSONAS y DRAMA, no con manos flotantes de stock. Si la narración menciona dinero, una carta, ropa o comida, DEBE mostrarse al personaje interactuando en 'Medium-full shot' (plano americano de rodillas arriba), 'Full body shot' o 'Two-shot'.
   b) COMPOSICIÓN CINEMATOGRÁFICA DE PELÍCULA: Prioriza encuadres amplios y dinámicos que venden la historia: 'Full body shot' (personaje completo en su entorno), 'Medium-full shot' (cowboy shot mostrando postura y acción), 'Two-shot medium profile' (dos personajes interactuando cara a cara) y 'Wide cinematic establishing shot' (personaje inmerso en la atmósfera del lugar). Limita los 'Close-up on face' a máximo 1 o 2 momentos cumbre en todo el video (para el clímax emocional de lágrimas o revelación).
   c) PROHIBIDO FONDO BLANCO O ESTUDIO EN 'imagen.txt': El fondo blanco es EXCLUSIVAMENTE para referencias.txt. En 'imagen.txt' NUNCA uses 'white background', 'studio lighting', 'solid backdrop' ni 'clean background'. CADA ESCENA DEBE DESCRIBIR EL ESCENARIO AMBIENTAL COMPLETO donde ocurre la historia (ej: hacienda polvorienta bajo sol abrasador, porche rústico con vigas de madera, lujoso restaurante con ventanales a la noche, cocina humilde con luz cálida de atardecer, carretera solitaria con lluvia nocturna).
3. 'movimiento.txt': Prompts de movimiento de cámara para FlowBatch ÚNICAMENTE para las siguientes {len(escenas_mov)} escenas exactas: {str_escenas_mov}.
   REGLA OBLIGATORIA: Cada línea DEBE comenzar exactamente con el número de escena (ej: '1. ...', '2. ...', '5. ...', '8. ...') y describir el movimiento terminando con la preservación del estilo visual: "{sufijo_mov}".
   PROHIBIDO incluir títulos, encabezados, listas o comentarios como '// Imágenes para animar en Flow:'. El archivo debe contener ÚNICAMENTE los prompts numerados directamente sin texto adicional.
   IMPORTANTE: NO incluyas etiquetas de personajes como (P1), (P2), [P1] o referencias en movimiento.txt; los videos toman como referencia visual la imagen generada, por lo que el prompt debe describir únicamente el movimiento y la acción sin etiquetas.
4. 'seo.txt': Paquete SEO optimizado para el algoritmo (Facebook Reels, TikTok, YouTube Shorts):
   - 1. Keywords long-tail (3-5 frases de búsqueda real)
   - 2. Títulos CTR (3 opciones: 2 en formato pregunta —A interpelación en 2ª persona que genere comentarios, B tensión sin spoiler— y C directo/emocional con 1 palabra en MAYÚSCULAS). CERO cifras de dinero ni spoilers.
   - 3. Descripción corta (3-4 líneas con gancho antes del 'ver más' y llamada a la acción).
   - 4. Hashtags (5 exactos: 2 fijos en español `#reflexion #leccionesdevida` + 3 variables en inglés acordes al valor del guion).
   - 5. Tags de YouTube (separados por comas para copiar y pegar).
   - 6. Idea y prompt de portada/miniatura en 9:16.
{bloque_largo}
Entrega ÚNICAMENTE los bloques de código delimitados así:
```referencias.txt
(P1): ...
(P2): ...
```

```imagen.txt
...
```

```movimiento.txt
...
```

```seo.txt
### PAQUETE SEO — {proy_dir.name}
...
```
{f'```portada_16_9.txt\n...\n```' if es_largo else ''}
Cero introducciones, cero explicaciones, cero citaciones [cite].
"""

    cfg_custom = obtener_config_prompts()
    modelo_preferido = cfg_custom.get("model")
    modelos_a_probar = [modelo_preferido] if modelo_preferido else []
    for m in MODELOS_RECOMENDADOS:
        if m not in modelos_a_probar:
            modelos_a_probar.append(m)

    res_text = None
    modelo_usado = None
    ultimo_error = None

    for k in claves:
        for mod in modelos_a_probar:
            endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={k}"
            body = {
                "contents": [{"parts": [{"text": prompt_usuario}]}],
                "generationConfig": {
                    "temperature": float(cfg_custom.get("temperature", 0.25)),
                    "maxOutputTokens": 32768
                }
            }
            if instruccion:
                body["systemInstruction"] = {"parts": [{"text": instruccion}]}

            data_bytes = json.dumps(body).encode("utf-8")
            try:
                req = urllib.request.Request(endpoint, data=data_bytes, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=90) as resp:
                    res_json = json.loads(resp.read().decode("utf-8"))
                    cand = res_json.get("candidates", [{}])[0]
                    texto_cand = cand.get("content", {}).get("parts", [{}])[0].get("text", "")
                    if texto_cand:
                        res_text = texto_cand
                        modelo_usado = mod
                        break
            except urllib.error.HTTPError as he:
                ultimo_error = f"HTTP {he.code} en {mod}"
                continue
            except Exception as e:
                ultimo_error = f"{e} en {mod}"
                continue
        if res_text:
            break

    if not res_text:
        return False, f"Gemini no devolvió respuesta ({ultimo_error or 'tiempo de espera agotado'})", {}

    bloques = extraer_bloques_salida(res_text)

    if not bloques.get("imagen"):
        return False, "No se pudo extraer el bloque imagen.txt de la respuesta de Gemini", {}

    # Guardar archivos en el proyecto
    guardados = {}
    if bloques.get("referencias"):
        (proy_dir / "referencias.txt").write_text(bloques["referencias"] + "\n", encoding="utf-8")
        guardados["referencias"] = True
    elif ref_maestra and not (proy_dir / "referencias.txt").is_file():
        (proy_dir / "referencias.txt").write_text(ref_maestra + "\n", encoding="utf-8")
        guardados["referencias"] = True

    if bloques.get("imagen"):
        img_texto = bloques["imagen"]
        # Limpieza de seguridad: evitar que se cuele 'white background' o 'clean background' en imagen.txt
        img_lineas = []
        for blk in re.split(r"\n\s*\n+", img_texto):
            b_str = blk.strip()
            if not b_str:
                continue
            # Limpiar menciones residuales de fondo blanco o estudio en imagen.txt
            b_clean = re.sub(r",?\s*(?:solid\s+)?white\s+background\b", "", b_str, flags=re.I)
            b_clean = re.sub(r",?\s*studio\s+lighting\b", ", cinematic atmospheric lighting", b_clean, flags=re.I)
            b_clean = re.sub(r",?\s*clean\s+background\b", ", rich detailed environment background", b_clean, flags=re.I)
            b_clean = b_clean.strip()

            # Asegurar que cada escena termine con el sufijo de estilo del canal si Gemini no lo incluyó
            if sufijo_estilo and not any(k in b_clean for k in ("--ar", "--v", "line art", "comic book", "hyperrealistic", "pixar")):
                b_clean = f"{b_clean}. {sufijo_estilo}"
            img_lineas.append(b_clean.strip())
        (proy_dir / "imagen.txt").write_text("\n\n".join(img_lineas) + "\n", encoding="utf-8")
        guardados["imagen"] = True

    if bloques.get("movimiento") or escenas_mov:
        mov_limpio = formatear_movimiento_estricto(bloques.get("movimiento", ""), escenas_mov, sufijo_mov=sufijo_mov)
        if mov_limpio:
            (proy_dir / "movimiento.txt").write_text(mov_limpio + "\n", encoding="utf-8")
            guardados["movimiento"] = True

    if bloques.get("seo"):
        (proy_dir / "seo.txt").write_text(bloques["seo"] + "\n", encoding="utf-8")
        guardados["seo"] = True

    if es_largo and not bloques.get("portada_16_9") and bloques.get("imagen"):
        prompts_img = [p.strip() for p in re.split(r"\n\s*\n", bloques["imagen"]) if p.strip()]
        if prompts_img:
            portada_base = prompts_img[-1]
            p_169 = re.sub(r"--ar\s+9:16", "--ar 16:9", portada_base)
            if "--ar 16:9" not in p_169:
                p_169 = p_169 + " --ar 16:9 --v 6 --stylize 120 --style raw"
            bloques["portada_16_9"] = p_169

    if bloques.get("portada_16_9"):
        p_169 = bloques["portada_16_9"].strip()
        (proy_dir / "portada_16_9.txt").write_text(p_169 + "\n", encoding="utf-8")
        (proy_dir / "portada_youtube_16_9.txt").write_text(p_169 + "\n", encoding="utf-8")
        guardados["portada_16_9"] = True

    if bloques.get("prompt_yt"):
        (proy_dir / "prompt yt.txt").write_text(bloques["prompt_yt"] + "\n", encoding="utf-8")
        guardados["prompt_yt"] = True

    info = {
        "modelo": modelo_usado,
        "escenas_sincronia": num_escenas,
        "guardados": guardados,
        "tiene_referencias": bool(bloques.get("referencias") or ref_maestra or (proy_dir / "referencias.txt").is_file()),
        "tiene_imagen": bool(bloques.get("imagen") or (proy_dir / "imagen.txt").is_file()),
        "tiene_movimiento": bool(bloques.get("movimiento") or (proy_dir / "movimiento.txt").is_file()),
        "tiene_seo": bool(bloques.get("seo") or (proy_dir / "seo.txt").is_file())
    }

    return True, f"Prompts y SEO generados con éxito usando {modelo_usado}", info


def generar_seo_para_proyecto(proy_dir: Path, nicho_raiz: Path = None, api_key: str = None) -> tuple[bool, str, dict]:
    """
    Genera exclusivamente el archivo seo.txt para un proyecto específico a partir de guion.txt.
    Alineado a la guía viral de Ecos (2 preguntas, 5 hashtags, 0 montos de dinero).
    """
    proy_dir = Path(proy_dir).resolve()
    if not proy_dir.is_dir():
        return False, f"Directorio no encontrado: {proy_dir}", {}

    guion_f = proy_dir / "guion.txt"
    if not guion_f.is_file():
        guion_f = proy_dir / "dis_guion.txt"
    if not guion_f.is_file():
        return False, f"No existe guion.txt en {proy_dir.name}", {}

    guion_txt = guion_f.read_text(encoding="utf-8", errors="replace").strip()
    if not guion_txt:
        return False, f"El archivo de guion está vacío en {proy_dir.name}", {}

    instruccion_seo = resolver_instruccion_seo(proy_dir, nicho_raiz)
    claves = obtener_claves_prompts(api_key)
    if not claves:
        return False, "No hay API Key de Gemini configurada.", {}

    prompt_usuario = f"""Actúa como Copywriter y Especialista SEO viral para Facebook Reels, TikTok y YouTube Shorts.
Analiza este guion narrado y genera el PAQUETE SEO completo para el proyecto '{proy_dir.name}':

GUION:
\"\"\"
{guion_txt}
\"\"\"

REGLAS INQUEBRANTABLES:
1. Idioma: 100% en español (solo los 3 hashtags variables van en inglés).
2. Títulos: 3 opciones. DOS de las tres deben ser PREGUNTA (A: interpelación al espectador en 2ª persona que lo obligue a responder mentalmente y comentar; B: tensión/curiosidad sobre la historia sin spoiler; C: directo/emocional con 1 palabra en MAYÚSCULAS).
3. CERO montos de dinero en todo el paquete ($100, cincuenta dólares, miles, etc.).
4. Hashtags: Exactamente 5 hashtags en el formato '#reflexion #leccionesdevida #tag_en1 #tag_en2 #tag_en3'.
5. Descripción: 3-4 líneas (primera línea es el gancho antes del 'ver más' y llamada a la acción al final).
6. Tags de YouTube: lista de etiquetas separadas por comas.
7. Portada/Miniatura: descripción visual en inglés para generar thumbnail en 9:16 con Nano Banana / Midjourney.

Entrega ÚNICAMENTE el bloque con este formato exacto:
```seo.txt
### PAQUETE SEO — {proy_dir.name}

1. KEYWORDS LONG-TAIL (Búsqueda Real):
- ...
- ...
- ...

2. TÍTULOS (CTR Alto):
- A (Interpelación): "¿...?"
- B (Tensión/Curiosidad): "¿...?"
- C (Directo/Emocional): "..."

3. DESCRIPCIÓN CORTA:
...

4. HASHTAGS (5 Probados):
#reflexion #leccionesdevida #... #... #...

5. TAGS DE YOUTUBE:
..., ..., ..., ...

6. IDEA Y PROMPT DE PORTADA / MINIATURA (9:16):
...
```
Cero introducciones, cero explicaciones.
"""

    cfg_custom = obtener_config_prompts()
    modelos_a_probar = MODELOS_RECOMENDADOS
    res_text = None
    modelo_usado = None
    ultimo_error = None

    for k in claves:
        for mod in modelos_a_probar:
            endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={k}"
            body = {
                "contents": [{"parts": [{"text": prompt_usuario}]}],
                "generationConfig": {"temperature": 0.3, "maxOutputTokens": 4096}
            }
            if instruccion_seo:
                body["systemInstruction"] = {"parts": [{"text": instruccion_seo}]}

            try:
                req = urllib.request.Request(endpoint, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=60) as resp:
                    res_json = json.loads(resp.read().decode("utf-8"))
                    cand = res_json.get("candidates", [{}])[0]
                    texto_cand = cand.get("content", {}).get("parts", [{}])[0].get("text", "")
                    if texto_cand:
                        res_text = texto_cand
                        modelo_usado = mod
                        break
            except Exception as e:
                ultimo_error = f"{e} en {mod}"
                continue
        if res_text:
            break

    if not res_text:
        return False, f"Gemini no devolvió SEO ({ultimo_error or 'error de conexión'})", {}

    bloques = extraer_bloques_salida(res_text)
    texto_seo = bloques.get("seo") or limpiar_texto_bloque(res_text)

    if not texto_seo:
        return False, "No se pudo extraer el texto de SEO de la respuesta", {}

    (proy_dir / "seo.txt").write_text(texto_seo + "\n", encoding="utf-8")
    return True, f"SEO generado con éxito en {proy_dir.name}/seo.txt", {"seo": texto_seo, "modelo": modelo_usado}
