# -*- coding: utf-8 -*-
"""
core/transcriptor_metadata.py
------------------------------
Módulo de extracción ultra rápida de transcripciones y guiones a través de la metadata
y pistas de subtítulos de videos en línea (YouTube, Shorts, TikTok, Instagram, etc.).
No descarga video ni audio: extrae directamente las pistas de subtítulos oficiales o
generados automáticamente por la plataforma en 2-4 segundos.
"""

import json
import os
import re
import subprocess
import sys
import urllib.request
from pathlib import Path


def _asegurar_ytdlp():
    """Verifica si yt_dlp está instalado y si no, lo instala automáticamente."""
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        try:
            print("[*] yt-dlp no encontrado. Instalando automáticamente...")
            subprocess.run([sys.executable, "-m", "pip", "install", "yt-dlp", "curl-cffi", "--quiet"], check=False)
            import yt_dlp
            return yt_dlp
        except Exception as ex:
            print(f"[ERROR] No se pudo auto-instalar yt-dlp: {ex}")
            return None


def _limpiar_texto_subtitulos(raw_text: str, track_ext: str = "") -> str:
    """Parsea y limpia pistas de subtítulos en formato json3, vtt, srt o xml."""
    if not raw_text or not raw_text.strip():
        return ""

    raw_text = raw_text.strip()

    # Caso 1: Formato json3 (YouTube timedtext API)
    if track_ext == "json3" or raw_text.startswith("{"):
        try:
            sub_json = json.loads(raw_text)
            frases = []
            for ev in sub_json.get("events", []):
                seg_txt = "".join(s.get("utf8", "") for s in ev.get("segs", []) if "utf8" in s)
                seg_txt = seg_txt.replace("\n", " ").strip()
                if seg_txt and seg_txt != "\n":
                    frases.append(seg_txt)
            texto = " ".join(frases)
            # Limpiar espacios repetidos
            return re.sub(r"\s+", " ", texto).strip()
        except Exception:
            pass

    # Caso 2: WebVTT o SRT
    if "WEBVTT" in raw_text or "-->" in raw_text:
        lineas = []
        for linea in raw_text.splitlines():
            linea = linea.strip()
            # Ignorar cabeceras y timestamps tipo 00:00:01.000 --> 00:00:04.000
            if not linea or linea.startswith("WEBVTT") or "-->" in linea or linea.isdigit():
                continue
            # Eliminar tags HTML/VTT <c> </c> <v Speaker> etc
            linea_limpia = re.sub(r"<[^>]+>", "", linea).strip()
            if linea_limpia:
                # Evitar líneas idénticas consecutivas (muy común en roll-up captions)
                if not lineas or lineas[-1] != linea_limpia:
                    lineas.append(linea_limpia)
        texto = " ".join(lineas)
        return re.sub(r"\s+", " ", texto).strip()

    # Caso 3: XML / TTML / srv1 / srv3
    if "<text" in raw_text or "<p" in raw_text or "<transcript" in raw_text:
        textos = re.findall(r">(.*?)<", raw_text)
        lineas = [t.strip() for t in textos if t.strip() and not t.strip().startswith("<")]
        texto = " ".join(lineas)
        texto = re.sub(r"&amp;", "&", texto)
        texto = re.sub(r"&quot;", '"', texto)
        texto = re.sub(r"&#39;", "'", texto)
        texto = re.sub(r"&lt;", "<", texto)
        texto = re.sub(r"&gt;", ">", texto)
        return re.sub(r"\s+", " ", texto).strip()

    # Fallback genérico
    texto = re.sub(r"<[^>]+>", " ", raw_text)
    return re.sub(r"\s+", " ", texto).strip()


def extraer_transcripcion_url(url: str, idioma_pref: str = "es") -> dict:
    """
    Extrae la transcripción/guion de un video por sus subtítulos/metadata en segundos
    sin descargar el archivo de video ni audio.
    Soporta YouTube, YouTube Shorts, TikTok, Instagram, etc. vía yt-dlp.
    """
    url = url.strip()
    if not url:
        return {"ok": False, "url": url, "error": "URL vacía"}

    yt_dlp_mod = _asegurar_ytdlp()
    if not yt_dlp_mod:
        return {"ok": False, "url": url, "error": "Librería yt-dlp no disponible"}

    ydl_opts = {
        'skip_download': True,
        'quiet': True,
        'no_warnings': True,
        'writesubtitles': True,
        'writeautomaticsub': True,
        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
    }

    try:
        with yt_dlp_mod.YoutubeDL(ydl_opts) as ydl:
            data = ydl.extract_info(url, download=False)
            if not data:
                return {"ok": False, "url": url, "error": "No se recibieron metadatos del video"}

            # Si es playlist con entries
            if "entries" in data and not data.get("title"):
                entries = [e for e in data.get("entries", []) if e]
                if entries:
                    data = entries[0]

            titulo = data.get("title", "") or "Sin título"
            canal = data.get("uploader", "") or data.get("channel", "") or "Desconocido"
            duracion = data.get("duration", 0) or 0
            descripcion = data.get("description", "") or ""
            thumbnail = data.get("thumbnail", "") or ""
            aspect = data.get("aspect_ratio")

            es_vertical = False
            if aspect and aspect < 0.9:
                es_vertical = True
            elif duracion and duracion <= 90:
                es_vertical = True

            subs = data.get("subtitles", {}) or {}
            auto = data.get("automatic_captions", {}) or {}

            # Prioridad de idiomas
            cand_langs = []
            if idioma_pref:
                cand_langs.extend([k for k in subs.keys() if k.startswith(idioma_pref)])
                cand_langs.extend([k for k in auto.keys() if k.startswith(idioma_pref)])
            # Fallbacks: español, inglés, cualquiera
            cand_langs.extend([k for k in subs.keys() if k.startswith("es")])
            cand_langs.extend([k for k in auto.keys() if k.startswith("es")])
            cand_langs.extend([k for k in subs.keys() if k.startswith("en")])
            cand_langs.extend([k for k in auto.keys() if k.startswith("en")])
            cand_langs.extend(list(subs.keys()))
            cand_langs.extend(list(auto.keys()))

            vistos = set()
            langs_ordenados = []
            for l in cand_langs:
                if l not in vistos:
                    vistos.add(l)
                    langs_ordenados.append(l)

            texto_transcripcion = ""
            fuente = ""
            lang_usado = ""

            for lang in langs_ordenados:
                tracks = subs.get(lang) or auto.get(lang) or []
                es_oficial = lang in subs

                track_url = None
                track_ext = None
                for prefer_ext in ("json3", "vtt", "srv3", "srv1", "ttml", "srt"):
                    t = next((x for x in tracks if x.get("ext") == prefer_ext), None)
                    if t and t.get("url"):
                        track_url = t.get("url")
                        track_ext = prefer_ext
                        break
                if not track_url and tracks and tracks[0].get("url"):
                    track_url = tracks[0].get("url")
                    track_ext = tracks[0].get("ext", "")

                if track_url:
                    try:
                        req = urllib.request.Request(track_url, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=10) as resp:
                            raw_sub = resp.read().decode('utf-8', errors='ignore')

                        limpio = _limpiar_texto_subtitulos(raw_sub, track_ext)
                        if len(limpio.split()) >= 10:
                            texto_transcripcion = limpio
                            tipo_sub = "Subtítulos oficiales" if es_oficial else "Subtítulos automáticos"
                            fuente = f"{tipo_sub} ({lang})"
                            lang_usado = lang
                            break
                    except Exception:
                        pass

            # Si no hubo subtítulos, verificar si la descripción tiene el guion
            if not texto_transcripcion:
                if len(descripcion) > 150 and len(descripcion.split()) > 35:
                    texto_transcripcion = descripcion.strip()
                    fuente = "Descripción del video"

            # Limpiar repeticiones consecutivas si las hubiera
            if texto_transcripcion:
                palabras = texto_transcripcion.split()
                limpias = []
                for p in palabras:
                    if not limpias or p != limpias[-1]:
                        limpias.append(p)
                texto_transcripcion = " ".join(limpias)

            dur_fmt = f"{int(duracion//60)}:{int(duracion%60):02d}" if duracion else "N/D"
            num_palabras = len(texto_transcripcion.split()) if texto_transcripcion else 0

            return {
                "ok": bool(texto_transcripcion),
                "url": url,
                "titulo": titulo,
                "canal": canal,
                "duracion": duracion,
                "duracion_fmt": dur_fmt,
                "es_vertical": es_vertical,
                "thumbnail": thumbnail,
                "transcripcion": texto_transcripcion,
                "fuente": fuente or "No disponible en metadata",
                "idioma": lang_usado,
                "num_palabras": num_palabras,
                "error": "" if texto_transcripcion else "No se encontraron subtítulos ni guion en la metadata de este video."
            }

    except Exception as e:
        return {"ok": False, "url": url, "error": f"Error al procesar enlace: {str(e)}"}


def sanitizar_nombre_archivo(nombre: str, max_len: int = 80) -> str:
    """Convierte un título en un nombre de archivo seguro para Windows."""
    s = re.sub(r'[\\/*?:"<>|]', "", nombre)
    s = re.sub(r'\s+', " ", s).strip()
    if len(s) > max_len:
        s = s[:max_len].strip()
    return s or "guion"


def transcribir_lote_enlaces(
    urls: list,
    carpeta_salida: str = None,
    idioma_pref: str = "es",
    guardar_archivos: bool = True,
    guardar_individuales: bool = True,
    guardar_combinado: bool = True,
    nombre_combinado: str = "_GUIONES.txt"
) -> dict:
    """
    Procesa una lista de URLs, extrayendo guiones por metadata y guardándolos
    en la carpeta destino especificada.
    """
    if isinstance(urls, str):
        # Separar por saltos de línea o comas
        urls = [u.strip() for u in re.split(r"[\r\n,]+", urls) if u.strip()]

    # Filtrar URLs válidas (http:// o https://)
    urls_validas = [u for u in urls if u.startswith("http://") or u.startswith("https://")]
    if not urls_validas:
        return {
            "ok": False,
            "error": "No se encontraron enlaces válidos (deben comenzar con http:// o https://)",
            "resultados": []
        }

    out_dir = None
    if guardar_archivos:
        if not carpeta_salida or not carpeta_salida.strip():
            carpeta_salida = str(Path.home() / "Downloads" / "GUIONES EXTRAIDOS")
        out_dir = Path(carpeta_salida).resolve()
        out_dir.mkdir(parents=True, exist_ok=True)

    resultados = []
    combinados = []
    exitosos = 0
    fallidos = 0

    for idx, u in enumerate(urls_validas, 1):
        res = extraer_transcripcion_url(u, idioma_pref=idioma_pref)
        res["indice"] = idx
        resultados.append(res)

        if res.get("ok") and res.get("transcripcion"):
            exitosos += 1
            txt_guion = res["transcripcion"]
            tit_guion = res.get("titulo", f"Video {idx}")
            canal_guion = res.get("canal", "")

            # Formato estándar para el combinado: GUION: <nombre/numero>
            cabecera = f"GUION: {idx:02d} - {tit_guion}"
            if canal_guion:
                cabecera += f" ({canal_guion})"
            combinados.append(f"{cabecera}\n\n{txt_guion}")

            # Guardar archivo individual si se solicita
            if out_dir and guardar_individuales:
                nombre_base = sanitizar_nombre_archivo(f"{idx:02d}_{tit_guion}")
                archivo_ind = out_dir / f"{nombre_base}.txt"
                try:
                    archivo_ind.write_text(txt_guion, encoding="utf-8-sig")
                    res["archivo_individual"] = str(archivo_ind)
                except Exception as ex_ind:
                    res["error_guardado"] = str(ex_ind)
        else:
            fallidos += 1

    # Guardar archivo combinado si se solicita y hay éxitos
    archivo_comb_ruta = None
    if out_dir and guardar_combinado and combinados:
        nom_comb = nombre_combinado if nombre_combinado.endswith(".txt") else f"{nombre_combinado}.txt"
        comb_path = out_dir / nom_comb
        try:
            contenido_comb = "\n\n\n".join(combinados) + "\n"
            comb_path.write_text(contenido_comb, encoding="utf-8-sig")
            archivo_comb_ruta = str(comb_path)
        except Exception:
            pass

    return {
        "ok": True,
        "total": len(urls_validas),
        "exitosos": exitosos,
        "fallidos": fallidos,
        "carpeta_salida": str(out_dir) if out_dir else "",
        "archivo_combinado": archivo_comb_ruta or "",
        "resultados": resultados
    }

