# -*- coding: utf-8 -*-
"""
diagnostico_retencion.py
------------------------
Analizador forense de retención de audiencia (YouTube Studio CSV).
Identifica con precisión matemática:
  1. HOOK LEAK: Fuga en los primeros 30 segundos (<25% saludable, >40% severo).
  2. CLIFFS (Acantilados): Caídas bruscas cruzadas con el guion y sincronía (qué frase y qué escena causó el abandono).
  3. SLIDE (Deslizamiento): Tasa de pérdida en el cuerpo del vídeo (ritmo/pacing de edición).
100% Python estándar (cero dependencias).
"""

import csv
import io
import json
import os
import re
import sys

def parse_csv_retencion(csv_path_or_content: str):
    rows = []
    if os.path.isfile(csv_path_or_content):
        try:
            with open(csv_path_or_content, newline="", encoding="utf-8-sig", errors="replace") as fh:
                reader = csv.reader(fh)
                for r in reader:
                    nums = []
                    for c in r:
                        c_clean = c.strip().replace("%", "").replace(",", ".")
                        try:
                            nums.append(float(c_clean))
                        except ValueError:
                            pass
                    if len(nums) >= 2:
                        rows.append((nums[0], nums[1]))
        except Exception:
            return []
    else:
        try:
            reader = csv.reader(io.StringIO(csv_path_or_content))
            for r in reader:
                nums = []
                for c in r:
                    c_clean = c.strip().replace("%", "").replace(",", ".")
                    try:
                        nums.append(float(c_clean))
                    except ValueError:
                        pass
                if len(nums) >= 2:
                    rows.append((nums[0], nums[1]))
        except Exception:
            return []
    return rows

def parse_sincronia_local(ruta_sincronia_o_texto: str):
    """Extrae bloques de tiempo y texto/prompts desde sincronia.txt o un transcript."""
    if not ruta_sincronia_o_texto:
        return []

    raw = ""
    if os.path.isfile(ruta_sincronia_o_texto):
        try:
            with open(ruta_sincronia_o_texto, "r", encoding="utf-8", errors="replace") as f:
                raw = f.read()
        except Exception:
            return []
    else:
        raw = ruta_sincronia_o_texto

    bloques = []
    # Formato: 00:00 - 00:04 | Texto...
    for line in raw.splitlines():
        line = line.strip()
        m = re.match(r"(\d+[:.]\d+)\s*[-–]\s*(\d+[:.]\d+)\s*[:|]\s*(.*)", line)
        if m:
            def to_sec(s):
                p = s.replace(",", ".").split(":")
                return int(p[0]) * 60 + float(p[1]) if len(p) == 2 else float(p[0])
            try:
                s_t = to_sec(m.group(1))
                e_t = to_sec(m.group(2))
                bloques.append((s_t, e_t, m.group(3).strip()))
            except Exception:
                pass
    return bloques

def diagnosticar_retencion(csv_input: str, transcript_o_sincronia: str = "", duracion_total_seg: float = None) -> dict:
    rows = parse_csv_retencion(csv_input)
    if len(rows) < 8:
        return {
            "ok": False,
            "error": "Se requieren al menos 8 puntos de datos en el CSV de retención.",
            "puntos": len(rows)
        }

    xs = [r[0] for r in rows]
    ys = [r[1] for r in rows]

    pct_axis = max(xs) <= 100.5
    dur = duracion_total_seg

    def at_sec(x):
        return (x / 100.0 * dur) if (pct_axis and dur) else x

    start_ret = ys[0] if ys[0] is not None else 100.0
    cutoff = 30.0 if not pct_axis else (30.0 / dur * 100.0 if dur else 10.0)

    # Retención en corte de apertura (30 segundos)
    hook_end = min((y for x, y in rows if x <= cutoff), default=start_ret)
    hook_leak = max(0.0, start_ret - hook_end)

    # Detección de caídas bruscas (Cliffs)
    drops = []
    for i in range(1, len(rows)):
        d = ys[i - 1] - ys[i]
        span = xs[i] - xs[i - 1] or 1.0
        drops.append((d / span, xs[i - 1], xs[i], d))

    drops.sort(reverse=True)
    cliffs_raw = [
        {
            "desde": round(a1, 1),
            "hasta": round(b1, 1),
            "perdida": round(d, 1),
            "segundo": round(at_sec(a1), 1) if (not pct_axis or dur) else None
        }
        for _, a1, b1, d in drops[:5] if d > 0.8
    ]

    # Deslizamiento en la parte central
    mid = [d for d, x0, _, _ in [(r[0], r[1], r[2], r[3]) for r in drops] if x0 > cutoff]
    slide = sum(mid) / len(mid) if mid else 0.0

    # Cruzar caídas con el texto/prompt en ese segundo
    cues = parse_sincronia_local(transcript_o_sincronia)
    cliffs_analizados = []
    for c in cliffs_raw:
        seg = c["segundo"]
        frase = ""
        if seg is not None and cues:
            coincidentes = [q[2] for q in cues if q[0] <= seg + 3 and q[1] >= seg - 3]
            frase = " ".join(coincidentes)[:160]

        cliffs_analizados.append({
            **c,
            "segundo_fmt": f"{int(seg//60):02d}:{int(seg%60):02d}" if seg is not None else f"{c['desde']}%",
            "frase_o_escena": frase
        })

    # Veredicto de gancho
    if hook_leak < 25:
        veredicto_hook = "SALUDABLE (Retención inicial sólida)"
        color_hook = "green"
    elif hook_leak < 40:
        veredicto_hook = "FUGA MODERADA (Ajustar promesa inicial)"
        color_hook = "yellow"
    else:
        veredicto_hook = "CRÍTICO (El inicio pierde más del 40% de la audiencia)"
        color_hook = "red"

    return {
        "ok": True,
        "puntos_leidos": len(rows),
        "retencion_inicio": round(start_ret, 1),
        "retencion_final": round(ys[-1], 1),
        "hook_leak_30s": round(hook_leak, 1),
        "hook_veredicto": veredicto_hook,
        "hook_color": color_hook,
        "cliffs": cliffs_analizados,
        "slide_ritmo": round(slide, 3),
        "diagnostico_ritmo": "Ritmo consistente" if slide < 0.15 else "Pérdida continua por edición lenta o estática (recortar pausas, no reescribir)"
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = diagnosticar_retencion(sys.argv[1])
        print(json.dumps(res, ensure_ascii=False, indent=2))
