# -*- coding: utf-8 -*-
"""
analizador_outliers.py
----------------------
Detector de Outliers Virales y Clasificador de Fórmulas sobre la Mediana del Canal.
Mide el rendimiento real de una idea independientemente del tamaño de suscriptores del canal.
100% Python estándar (cero dependencias).
"""

import json
import os
import re
import statistics
import sys

_DIR = os.path.dirname(os.path.abspath(__file__))
_HOOKS_JSON = os.path.join(_DIR, "hooks.json")

try:
    with open(_HOOKS_JSON, "r", encoding="utf-8") as _f:
        FORMULAS = json.load(_f).get("hooks", [])
except Exception:
    FORMULAS = []

def clasificar_titulo(titulo: str) -> str:
    scored = []
    for f in FORMULAS:
        matches = 0
        for p in f.get("match", []):
            try:
                if re.search(p, titulo, re.I):
                    matches += 1
            except Exception:
                pass
        if matches:
            scored.append((matches, f.get("name", "")))
    scored.sort(reverse=True)
    return scored[0][1] if scored else "Unclassified"

def analizar_outliers(videos_list: list, min_multiplo: float = 1.5) -> dict:
    if not videos_list:
        return {
            "ok": False,
            "error": "Lista de vídeos vacía.",
            "outliers": []
        }

    by_canal = {}
    for r in videos_list:
        ch = r.get("canal") or r.get("channel") or "General"
        by_canal.setdefault(ch, []).append(r)

    outliers, canales_pocos_videos = [], []

    for ch, vids in by_canal.items():
        vistas = [float(v.get("vistas") or v.get("views") or 0) for v in vids]
        if len(vids) < 4:
            canales_pocos_videos.append({"canal": ch, "total_videos": len(vids)})
            continue

        med = statistics.median(vistas) if vistas else 0
        for v in vids:
            v_count = float(v.get("vistas") or v.get("views") or 0)
            mult = (v_count / med) if med > 0 else 0.0
            titulo = v.get("titulo") or v.get("title") or ""
            form = clasificar_titulo(titulo)

            if mult >= min_multiplo:
                outliers.append({
                    "canal": ch,
                    "titulo": titulo,
                    "vistas": int(v_count),
                    "mediana_canal": int(med),
                    "multiplo": round(mult, 2),
                    "formula": form,
                    "url": v.get("url", "")
                })

    outliers.sort(key=lambda r: -r["multiplo"])

    # Conteo de fórmulas exitosas
    conteo_formulas = {}
    for r in outliers:
        f = r["formula"]
        conteo_formulas[f] = conteo_formulas.get(f, 0) + 1

    return {
        "ok": True,
        "total_analizados": len(videos_list),
        "total_canales": len(by_canal),
        "total_outliers": len(outliers),
        "canales_con_poca_muestra": canales_pocos_videos,
        "outliers": outliers,
        "formulas_ganadoras": sorted(conteo_formulas.items(), key=lambda x: -x[1])
    }

if __name__ == "__main__":
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        with open(sys.argv[1], "r", encoding="utf-8") as f:
            data = json.load(f)
        items = data.get("videos", data) if isinstance(data, dict) else data
        res = analizar_outliers(items)
        print(json.dumps(res, ensure_ascii=False, indent=2))
