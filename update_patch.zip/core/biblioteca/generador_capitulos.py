# -*- coding: utf-8 -*-
"""
generador_capitulos.py
----------------------
Generador de Capítulos para descripciones de YouTube.
Valida y garantiza el cumplimiento de las normas oficiales de YouTube:
  1. El primer capítulo debe iniciar estrictamente en 00:00.
  2. Mínimo 3 capítulos obligatorios.
  3. Duración mínima de 10 segundos por capítulo.
100% Python estándar (cero dependencias).
"""

import json
import os
import re
import sys

STOP_WORDS = {
    "el", "la", "los", "las", "un", "una", "de", "del", "en", "para", "por", "con", "sin",
    "sobre", "y", "o", "que", "es", "son", "se", "su", "sus", "este", "esta", "estos",
    "the", "a", "an", "of", "for", "to", "in", "on", "and", "or", "is", "are", "with"
}

def fmt_mmss(segundos: float) -> str:
    t = int(segundos)
    h = t // 3600
    m = (t % 3600) // 60
    s = t % 60
    return f"{h}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"

def generar_capitulos_youtube(sincronia_o_cues: list, target_capitulos: int = 5) -> dict:
    """
    Recibe lista de tuplas (start, end, text) o texto de sincronia.txt.
    """
    if isinstance(sincronia_o_cues, str):
        from .limpiador_audio import load_cues
        cues = load_cues(sincronia_o_cues)
    else:
        cues = sincronia_o_cues

    if not cues or len(cues) < 3:
        return {
            "ok": False,
            "error": "Se requieren al menos 3 marcas de contenido para generar capítulos válidos.",
            "capitulos": [],
            "texto_descripcion": ""
        }

    dur_total = cues[-1][1]
    if dur_total < 30:
        return {
            "ok": False,
            "error": f"El vídeo dura {dur_total:.1f}s. YouTube requiere vídeos más largos para capítulos significativos.",
            "capitulos": [],
            "texto_descripcion": ""
        }

    # Seleccionar puntos clave basados en cambios o pausas
    intervalo = dur_total / max(3, min(target_capitulos, 12))
    puntos = [0.0]

    for c in cues:
        t = c[0]
        if t - puntos[-1] >= max(12.0, intervalo * 0.8) and (dur_total - t) >= 10.0:
            puntos.append(t)
            if len(puntos) >= target_capitulos:
                break

    capitulos = []
    for idx, p in enumerate(puntos):
        fin_cap = puntos[idx + 1] if idx + 1 < len(puntos) else dur_total
        # Extraer palabras representativas
        texto_bloque = " ".join(c[2] for c in cues if c[0] >= p and c[1] <= fin_cap)
        palabras = [w for w in re.findall(r"[a-záéíóúñ]{4,}", texto_bloque.lower()) if w not in STOP_WORDS]
        frec = {}
        for w in palabras:
            frec[w] = frec.get(w, 0) + 1
        top_kw = sorted(frec.items(), key=lambda x: -x[1])[:3]
        titulo_draft = " ".join(w.capitalize() for w, _ in top_kw) or f"Parte {idx + 1}"
        if idx == 0 and not top_kw:
            titulo_draft = "Introducción"

        capitulos.append({
            "inicio_seg": round(p, 1),
            "fin_seg": round(fin_cap, 1),
            "duracion": round(fin_cap - p, 1),
            "timestamp": fmt_mmss(p),
            "titulo": titulo_draft
        })

    # Validación oficial de YouTube
    es_valido = (
        len(capitulos) >= 3 and
        capitulos[0]["inicio_seg"] == 0.0 and
        all(c["duracion"] >= 10.0 for c in capitulos)
    )

    lineas_desc = [f"{c['timestamp']} {c['titulo']}" for c in capitulos]
    bloque_texto = "\n".join(lineas_desc)

    return {
        "ok": True,
        "cumple_normas_youtube": es_valido,
        "total_capitulos": len(capitulos),
        "capitulos": capitulos,
        "texto_descripcion": bloque_texto
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = generar_capitulos_youtube(sys.argv[1])
        print(json.dumps(res, ensure_ascii=False, indent=2))
