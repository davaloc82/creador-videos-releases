# -*- coding: utf-8 -*-
"""
validador_empaquetado.py
------------------------
Linter de Empaquetado: Valida la unidad Título + Portada/Miniatura antes de publicar.
Audita truncamiento móvil (<40 chars), escritorio (<60 chars), texto en miniatura (máx 3 palabras),
duplicación innecesaria de palabras y mayúsculas spam.
100% Python estándar (cero dependencias).
"""

import json
import os
import re
import sys

DESKTOP_LIMIT = 60
MOBILE_LIMIT = 40
HARD_LIMIT = 100

VAGUE = {
    # Español
    "increible", "increíble", "asombroso", "loco", "enorme", "masivo", "secreto",
    "poderoso", "definitivo", "mejor", "revolucionario", "alucinante", "brutal",
    "magico", "mágico", "perfecto", "unico", "único", "truco", "epico", "épico",
    # Inglés
    "amazing", "incredible", "insane", "crazy", "huge", "massive", "ultimate", "best",
    "powerful", "secret", "revolutionary", "mindblowing", "epic", "perfect", "complete"
}

STOP = {
    # Español
    "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "a", "al", "en",
    "para", "por", "con", "sin", "sobre", "y", "o", "u", "e", "que", "es", "son", "tu",
    "tus", "su", "sus", "mi", "mis", "como", "cómo", "que", "qué", "este", "esta", "estos",
    # Inglés
    "the", "a", "an", "of", "for", "to", "in", "on", "and", "or", "is", "are", "with",
    "your", "you", "my", "i", "this", "that", "it", "how", "what", "why"
}

def _words(text: str):
    return re.findall(r"[a-záéíóúñ0-9']+", text.lower())

def auditar_empaquetado(titulo: str, texto_portada: str = "") -> dict:
    t = (titulo or "").strip()
    thumb = (texto_portada or "").strip()

    n = len(t)
    issues, good = [], []

    # 1. Longitud del título
    if n > HARD_LIMIT:
        issues.append(("length", f"{n} caracteres - El límite estricto de YouTube es {HARD_LIMIT}."))
    elif n > DESKTOP_LIMIT:
        issues.append(("length", f"{n} caracteres - La búsqueda en PC suele cortar después de los {DESKTOP_LIMIT}."))
    else:
        good.append(f"{n} caracteres: entra perfectamente en los {DESKTOP_LIMIT} de escritorio.")

    # 2. Visibilidad móvil (Feed de YouTube / TikTok)
    if n > MOBILE_LIMIT:
        corte = t[:MOBILE_LIMIT].rsplit(" ", 1)[0]
        issues.append(("mobile", f'En móviles se verá aprox: "{corte}...". Verifica que el sujeto principal no se corte.'))
    else:
        good.append("Título corto: 100% visible sin cortes en pantallas de móviles.")

    # 3. Mayúsculas excesivas (Spam visual)
    palabras_raw = t.split()
    caps = [w for w in palabras_raw if len(w) > 2 and w.isupper()]
    if len(caps) > 2:
        issues.append(("shouting", f"{len(caps)} palabras en MAYÚSCULAS - Máximo dos para dar énfasis sin parecer spam."))
    elif caps:
        good.append(f"{len(caps)} palabra(s) en mayúsculas para énfasis natural.")

    # 4. Palabras abstractas o vagas
    w_title = _words(t)
    vagos_hallados = [w for w in w_title if w in VAGUE]
    if vagos_hallados:
        issues.append(("vague", f"Contiene adjetivos vagos ({', '.join(sorted(set(vagos_hallados)))}). Reemplázalos por una cifra o nombre propio."))

    # 5. Cifras o datos concretos
    nums = re.findall(r"\d[\d,.]*%?", t)
    if nums:
        good.append(f"Incluye dato o cifra concreta ({', '.join(nums[:3])}).")
    else:
        issues.append(("no-number", "Sin números, fechas ni nombres concretos (el mejor potenciador de CTR)."))

    # 6. Pregunta abierta
    if t.endswith("?"):
        good.append("Termina con signo de pregunta (abre bucle de curiosidad).")

    # 7. Duplicidad y longitud de portada/miniatura
    if thumb:
        tw = set(w_title) - STOP
        hw = set(_words(thumb)) - STOP
        shared = tw & hw
        if shared:
            issues.append(("duplicate", f"La portada repite palabras del título ({', '.join(sorted(shared))}). La portada debe aportar lo que el título omite."))
        else:
            good.append("La portada y el título se complementan sin duplicar texto.")

        thumb_words = _words(thumb)
        if len(thumb_words) > 3:
            issues.append(("thumb-length", f"{len(thumb_words)} palabras en la portada. En móvil se recomienda máximo 3 palabras legibles."))
        else:
            good.append(f"Texto de portada conciso ({len(thumb_words)} palabras).")

    score = max(0, min(100, 100 - 15 * len(issues) + 5 * len(good)))

    return {
        "ok": True,
        "titulo": t,
        "chars": n,
        "texto_portada": thumb,
        "score": score,
        "veredicto": "ÓPTIMO" if score >= 75 else ("MEJORABLE" if score >= 50 else "RIESGOSO"),
        "problemas": [{"tipo": k, "msg": m} for k, m in issues],
        "puntos_fuertes": good
    }

if __name__ == "__main__":
    t_test = sys.argv[1] if len(sys.argv) > 1 else "Dejé que la IA creara mi canal por 30 días"
    p_test = sys.argv[2] if len(sys.argv) > 2 else "CERO VISTAS"
    res = auditar_empaquetado(t_test, p_test)
    print(json.dumps(res, ensure_ascii=False, indent=2))
