"""
core/biblioteca/perfilador_voces.py
===================================
Módulo de Perfilado Acústico y Emparejamiento de Voces Gratuitas Locales ($0 Costo).

Extrae vectores matemáticos de audio (Pitch F0 en Hz, Cadencia WPM, Rango Dinámico y Timbre)
a partir de un fragmento de audio o enlace de referencia de la competencia, y recomienda
la voz gratuita local (Kokoro-82M / Edge-TTS) más idéntica para replicar la retención
sin obligar al usuario a pagar suscripciones recurrentes de ElevenLabs o servicios externos.

100% Python estándar + numpy/scipy + ffmpeg (sin dependencias externas pesadas).
"""

import os
import sys
import json
import tempfile
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

try:
    import numpy as np
    import scipy.io.wavfile as wavfile
    HAY_NUMPY = True
except ImportError:
    HAY_NUMPY = False


# ==============================================================================
# CATÁLOGO DE VECTORES DE REFERENCIA DE VOCES (KOKORO / EDGE-TTS / ELEVENLABS)
# ==============================================================================
CATALOGO_VOCES_KOKORO = [
    {
        "id": "am_adam",
        "nombre": "Adam (Kokoro Local)",
        "genero": "masculino",
        "pitch_target_hz": 118,
        "cadencia_wpm": 165,
        "tono": "Grave / Profundo / Cinematográfico",
        "nichos_afines": ["finanzas", "misterio", "documentales", "negocios", "crimen", "obras", "mac_pato", "datos"],
        "descripcion": "Voz masculina profunda, autoritaria y resonante. Mantiene alta retención en documentales y temas de dinero/misterio.",
        "offline": True,
        "costo": "$0.00",
        "elevenlabs_alt": "pNInz6obpgDQGcFmaJgB (Adam)"
    },
    {
        "id": "am_echo",
        "nombre": "Echo (Kokoro Local)",
        "genero": "masculino",
        "pitch_target_hz": 142,
        "cadencia_wpm": 180,
        "tono": "Medio / Enérgico / Dinámico",
        "nichos_afines": ["curiosidades", "gaming", "tops", "shorts", "ciencia", "tecnologia", "viral"],
        "descripcion": "Voz masculina ágil, entusiasta y veloz. Ideal para captar el scroll en Shorts y Reels dinámicos.",
        "offline": True,
        "costo": "$0.00",
        "elevenlabs_alt": "ErXwobaYiN019PkySvjV (Antoni)"
    },
    {
        "id": "am_michael",
        "nombre": "Michael (Kokoro Local)",
        "genero": "masculino",
        "pitch_target_hz": 108,
        "cadencia_wpm": 138,
        "tono": "Profundo / Reflexivo / Solemne",
        "nichos_afines": ["filosofia", "reflexiones", "historia", "antiguedad", "audiolibros", "psicologia"],
        "descripcion": "Voz grave y pausada, estilo narrador histórico o sabio. Genera inmersión y respeto.",
        "offline": True,
        "costo": "$0.00",
        "elevenlabs_alt": "TxGEqnHWrfWFTfGW9XjX (Josh)"
    },
    {
        "id": "af_heart",
        "nombre": "Heart (Kokoro Local)",
        "genero": "femenino",
        "pitch_target_hz": 208,
        "cadencia_wpm": 155,
        "tono": "Cálido / Emotivo / Envolvente",
        "nichos_afines": ["dramas", "novelas", "fabulas", "historias_reales", "consejos", "emocional"],
        "descripcion": "Voz femenina dulce, íntima y emotiva. Conecta profundamente en relatos de drama o moralejas.",
        "offline": True,
        "costo": "$0.00",
        "elevenlabs_alt": "21m00Tcm4TlvDq8ikWAM (Rachel)"
    },
    {
        "id": "af_bella",
        "nombre": "Bella (Kokoro Local)",
        "genero": "femenino",
        "pitch_target_hz": 226,
        "cadencia_wpm": 175,
        "tono": "Brillante / Juvenil / Pop",
        "nichos_afines": ["famosos", "farandula", "lifestyle", "entretenimiento", "resumenes", "tendencias"],
        "descripcion": "Voz femenina moderna, chispeante y rápida. Diseñada para nichos de farándula y cultura pop.",
        "offline": True,
        "costo": "$0.00",
        "elevenlabs_alt": "EXAVITQu4vr4xnSDxMaL (Bella)"
    },
    {
        "id": "af_sarah",
        "nombre": "Sarah (Kokoro Local)",
        "genero": "femenino",
        "pitch_target_hz": 195,
        "cadencia_wpm": 160,
        "tono": "Claro / Profesional / Didáctico",
        "nichos_afines": ["educacion", "salud", "tutoriales", "noticias", "psico", "desarrollo_personal"],
        "descripcion": "Voz femenina equilibrada y articulada. Transmite confianza pedagógica y claridad mental.",
        "offline": True,
        "costo": "$0.00",
        "elevenlabs_alt": "ThT5KcBeYPX3keUQqHPh (Dorothy)"
    }
]

CATALOGO_VOCES_EDGE_TTS = [
    {
        "id": "es-MX-JorgeNeural",
        "nombre": "Jorge (Edge-TTS Latino Neutro)",
        "genero": "masculino",
        "pitch_target_hz": 132,
        "cadencia_wpm": 168,
        "tono": "Latino Neutro / Dinámico",
        "nichos_afines": ["curiosidades", "finanzas", "shorts", "tops"],
        "descripcion": "Voz neutra mexicana de ritmo ágil, extremadamente usada y viral en TikTok/Shorts.",
        "offline": False,
        "costo": "$0.00 (Nube gratuita)"
    },
    {
        "id": "es-ES-AlvaroNeural",
        "nombre": "Álvaro (Edge-TTS España)",
        "genero": "masculino",
        "pitch_target_hz": 115,
        "cadencia_wpm": 150,
        "tono": "Castellano / Grave y Serio",
        "nichos_afines": ["documentales", "historia", "misterio"],
        "descripcion": "Locución sobria de alta credibilidad para documentales y relatos serios.",
        "offline": False,
        "costo": "$0.00 (Nube gratuita)"
    },
    {
        "id": "es-MX-DaliaNeural",
        "nombre": "Dalia (Edge-TTS Latina Neutra)",
        "genero": "femenino",
        "pitch_target_hz": 205,
        "cadencia_wpm": 162,
        "tono": "Latina Neutra / Fluida y Cálida",
        "nichos_afines": ["dramas", "famosos", "educacion", "lifestyle"],
        "descripcion": "Locución femenina natural y cercana para narrativas y tops de entretenimiento.",
        "offline": False,
        "costo": "$0.00 (Nube gratuita)"
    }
]


# ==============================================================================
# EXTRACCIÓN DE CARACTERÍSTICAS ACÚSTICAS (PITCH, TEMPO, ENERGÍA)
# ==============================================================================
def extraer_vector_acustico(ruta_audio: str, duracion_max_seg: float = 20.0) -> Dict[str, Any]:
    """
    Lee un archivo de audio (mp3 o wav), extrae un fragmento de muestra y calcula:
    - Pitch F0 medio (Hz) y desviación estándar.
    - Cadencia de habla (WPM estimada por picos silábicos).
    - RMS de energía y ratio de silencios.
    Retorna un diccionario con los vectores matemáticos de la voz.
    """
    p = Path(ruta_audio).resolve()
    if not p.is_file():
        return {"ok": False, "error": f"Archivo de audio no encontrado: {ruta_audio}"}

    if not HAY_NUMPY:
        return {"ok": False, "error": "numpy/scipy no disponibles en el entorno"}

    temp_wav = None
    try:
        # Convertir a WAV mono 16kHz temporal con ffmpeg
        temp_wav = Path(tempfile.gettempdir()) / f"perfil_voz_{os.getpid()}_{hash(p.name)%10000}.wav"
        cmd = [
            "ffmpeg", "-y", "-i", str(p),
            "-t", str(duracion_max_seg),
            "-vn", "-ac", "1", "-ar", "16000",
            str(temp_wav)
        ]
        kw = {"capture_output": True}
        if sys.platform.startswith("win"):
            kw["creationflags"] = 0x08000000
        subprocess.run(cmd, check=True, **kw)

        sr, data = wavfile.read(str(temp_wav))
        if data.dtype == np.int16:
            data = data.astype(np.float32) / 32768.0
        elif data.dtype != np.float32:
            data = data.astype(np.float32)

        duracion = float(len(data) / sr)
        if duracion < 1.0:
            return {"ok": False, "error": "Audio demasiado corto para perfilar"}

        # 1. Energía RMS global
        rms = float(np.sqrt(np.mean(data**2)))

        # 2. Estimación de Pitch F0 vía autocorrelación sobre frames activos
        # Rango de voz humana: 65 Hz a 350 Hz
        min_lag = int(sr / 350)
        max_lag = int(sr / 65)
        frame_size = int(sr * 0.050)  # 50 ms
        step = int(sr * 0.025)        # 25 ms

        pitches = []
        silencios_frames = 0
        total_frames = 0

        for i in range(0, len(data) - frame_size, step):
            total_frames += 1
            frame = data[i:i + frame_size]
            frame_rms = float(np.sqrt(np.mean(frame**2)))
            if frame_rms < rms * 0.35:
                silencios_frames += 1
                continue

            # Autocorrelación
            corr = np.correlate(frame, frame, mode='full')
            corr = corr[len(frame) - 1:]
            
            # Buscar pico en rango vocal
            segmento = corr[min_lag:max_lag]
            if len(segmento) > 0 and np.max(segmento) > 0:
                peak_lag = min_lag + int(np.argmax(segmento))
                f0 = sr / peak_lag
                if 70 <= f0 <= 340:
                    pitches.append(f0)

        f0_mediana = float(np.median(pitches)) if pitches else 135.0
        f0_std = float(np.std(pitches)) if pitches else 25.0
        ratio_silencio = float(silencios_frames / max(1, total_frames))

        # 3. Estimación de Cadencia Silábica y WPM (Envolvente suavizada)
        k_size = int(sr * 0.080)
        kernel = np.ones(k_size) / k_size
        env_smooth = np.convolve(np.abs(data), kernel, mode='same')

        sub_step = int(sr * 0.010)
        sub = env_smooth[::sub_step]
        umbral_sub = float(np.mean(sub) * 0.75)
        min_dist = int(0.120 / 0.010)  # Mínimo 120 ms entre sílabas

        picos_silabicos = 0
        last_p = -min_dist
        for i in range(1, len(sub) - 1):
            if sub[i] > umbral_sub and sub[i] > sub[i - 1] and sub[i] > sub[i + 1] and (i - last_p) >= min_dist:
                picos_silabicos += 1
                last_p = i

        silabas_por_seg = float(picos_silabicos / max(1.0, duracion))
        # En español promedio: ~1.6 sílabas por palabra
        wpm_estimado = int((silabas_por_seg * 60) / 1.6)
        wpm_estimado = max(90, min(230, wpm_estimado))

        # 4. Clasificación Humana del Perfil
        if f0_mediana < 165:
            genero_estimado = "masculino"
            if f0_mediana < 125:
                tono_desc = "Grave / Profundo / Cinematográfico"
            else:
                tono_desc = "Medio / Dinámico / Conversacional"
        else:
            genero_estimado = "femenino"
            if f0_mediana < 210:
                tono_desc = "Medio / Cálido / Emotivo"
            else:
                tono_desc = "Agudo / Brillante / Vivaz"

        return {
            "ok": True,
            "duracion_analizada_seg": round(duracion, 2),
            "pitch_f0_hz": round(f0_mediana, 1),
            "pitch_variabilidad_hz": round(f0_std, 1),
            "wpm_estimado": wpm_estimado,
            "silabas_por_segundo": round(silabas_por_seg, 1),
            "ratio_silencio": round(ratio_silencio, 2),
            "genero_estimado": genero_estimado,
            "tono_desc": tono_desc,
            "energia_rms": round(rms, 4)
        }
    except Exception as ex:
        return {"ok": False, "error": str(ex)}
    finally:
        if temp_wav and temp_wav.is_file():
            try:
                temp_wav.unlink(missing_ok=True)
            except Exception:
                pass


# ==============================================================================
# ALGORITMO DE EMPAREJAMIENTO VECTORIAL DE VOCES
# ==============================================================================
def calcular_similitud_voz(vector_analizado: Dict[str, Any], candidato: Dict[str, Any], tipo_nicho: str = "") -> float:
    """
    Calcula la distancia matemática normalizada (0.0 a 1.0) entre la voz del competidor
    y la voz candidata del catálogo, evaluando:
    1. Género (peso 35%)
    2. Pitch F0 (peso 35%)
    3. Cadencia WPM (peso 20%)
    4. Afinidad temática de nicho (peso 10%)
    """
    score = 1.0

    # 1. Penalización de género
    genero_a = vector_analizado.get("genero_estimado", "")
    genero_c = candidato.get("genero", "")
    if genero_a and genero_c and genero_a != genero_c:
        score -= 0.50  # Si difiere en género la similitud cae drásticamente

    # 2. Distancia de Pitch F0
    pitch_a = float(vector_analizado.get("pitch_f0_hz", 135))
    pitch_c = float(candidato.get("pitch_target_hz", 135))
    diff_pitch = abs(pitch_a - pitch_c)
    # 40 Hz de diferencia reduce 0.25
    factor_pitch = max(0.0, 1.0 - (diff_pitch / 70.0))
    score -= (1.0 - factor_pitch) * 0.35

    # 3. Distancia de Cadencia WPM
    wpm_a = float(vector_analizado.get("wpm_estimado", 160))
    wpm_c = float(candidato.get("cadencia_wpm", 160))
    diff_wpm = abs(wpm_a - wpm_c)
    factor_wpm = max(0.0, 1.0 - (diff_wpm / 60.0))
    score -= (1.0 - factor_wpm) * 0.20

    # 4. Afinidad con el nicho
    if tipo_nicho:
        nicho_clean = tipo_nicho.lower().strip()
        afines = candidato.get("nichos_afines", [])
        if any(af in nicho_clean for af in afines):
            score += 0.08

    return max(0.40, min(0.98, score))


def perfilar_y_recomendar_voces(
    ruta_audio: Optional[str] = None,
    transcripcion: str = "",
    tipo_nicho: str = "",
    formato: str = "shorts"
) -> Dict[str, Any]:
    """
    Función maestra:
    Si hay ruta de audio válida, extrae el vector físico real.
    Si no hay audio (o falló descarga), infiere el perfil acústico a partir del tipo de nicho.
    Compara contra el catálogo de voces libres locales de Kokoro y Edge-TTS y genera la recomendación completa.
    """
    vector = None
    fuente_analisis = "audio_real"

    if ruta_audio and Path(ruta_audio).is_file():
        vec_res = extraer_vector_acustico(ruta_audio)
        if vec_res.get("ok"):
            vector = vec_res
            # Si hay transcripción con tiempo conocido, refinar WPM exacto
            if transcripcion and len(transcripcion.split()) > 10 and vector.get("duracion_analizada_seg", 0) > 3:
                palabras = len(transcripcion.split())
                wpm_real = int((palabras / vector["duracion_analizada_seg"]) * 60)
                vector["wpm_estimado"] = max(90, min(240, wpm_real))

    # Fallback Semántico si no hubo audio disponible
    if not vector:
        fuente_analisis = "inferencia_nicho"
        nicho_l = (tipo_nicho or "").lower()
        if any(w in nicho_l for w in ["drama", "novela", "emocion", "amor", "fabula"]):
            gen = "femenino"
            p_hz = 205.0
            tono = "Medio / Cálido / Emotivo"
            wpm = 150
        elif any(w in nicho_l for w in ["famosos", "farandula", "chisme", "pop", "moda"]):
            gen = "femenino"
            p_hz = 225.0
            tono = "Agudo / Brillante / Vivaz"
            wpm = 175
        elif any(w in nicho_l for w in ["misterio", "finanzas", "dinero", "mac_pato", "terror", "crimen", "obra"]):
            gen = "masculino"
            p_hz = 118.0
            tono = "Grave / Profundo / Cinematográfico"
            wpm = 165
        elif any(w in nicho_l for w in ["curiosidades", "top", "gaming", "viral"]):
            gen = "masculino"
            p_hz = 142.0
            tono = "Medio / Enérgico / Dinámico"
            wpm = 180
        else:
            gen = "masculino"
            p_hz = 125.0
            tono = "Grave / Firme y Asertivo"
            wpm = 165

        vector = {
            "ok": True,
            "pitch_f0_hz": p_hz,
            "wpm_estimado": wpm,
            "genero_estimado": gen,
            "tono_desc": tono,
            "fuente": "Inferencia semántica del nicho"
        }

    # Evaluar catálogo Kokoro Local
    candidatos_kokoro = []
    for c in CATALOGO_VOCES_KOKORO:
        sim = calcular_similitud_voz(vector, c, tipo_nicho=tipo_nicho)
        cand_dict = dict(c)
        cand_dict["similitud_pct"] = int(round(sim * 100))
        candidatos_kokoro.append(cand_dict)
    candidatos_kokoro.sort(key=lambda x: x["similitud_pct"], reverse=True)
    mejor_kokoro = candidatos_kokoro[0]

    # Evaluar catálogo Edge-TTS Gratuito
    candidatos_edge = []
    for c in CATALOGO_VOCES_EDGE_TTS:
        sim = calcular_similitud_voz(vector, c, tipo_nicho=tipo_nicho)
        cand_dict = dict(c)
        cand_dict["similitud_pct"] = int(round(sim * 100))
        candidatos_edge.append(cand_dict)
    candidatos_edge.sort(key=lambda x: x["similitud_pct"], reverse=True)
    mejor_edge = candidatos_edge[0]

    mensaje_ahorro = (
        f"🎯 Voz detectada en el nicho: {vector['genero_estimado'].capitalize()} "
        f"({vector['pitch_f0_hz']} Hz, ~{vector['wpm_estimado']} WPM, {vector['tono_desc']}).\n"
        f"💡 ¡No necesitas gastar en ElevenLabs! Puedes usar la voz local 100% gratuita '{mejor_kokoro['nombre']}' "
        f"con {mejor_kokoro['similitud_pct']}% de similitud tímbrica para producir sin internet ni cuotas."
    )

    return {
        "ok": True,
        "fuente_analisis": fuente_analisis,
        "perfil_acustico": vector,
        "voz_gratuita_local": mejor_kokoro,
        "voz_gratuita_online": mejor_edge,
        "alternativa_elevenlabs": {
            "id": mejor_kokoro.get("elevenlabs_alt", "Adam"),
            "nota": "Para usuarios que ya cuenten con suscripción activa de ElevenLabs/AI33"
        },
        "mensaje_ahorro": mensaje_ahorro,
        "todas_opciones_kokoro": candidatos_kokoro[:3]
    }


if __name__ == "__main__":
    # Test rápido de autoverificación
    test_res = perfilar_y_recomendar_voces(tipo_nicho="Finanzas y Misterio de Mac Pato")
    print(json.dumps(test_res, indent=2, ensure_ascii=False))
