# -*- coding: utf-8 -*-
"""
limpiador_audio.py
------------------
Detector de Silencios Muertos (Dead-air), Muletillas aisladas y Tomas Falsas (EDL).
Procesa archivos de subtítulos (.srt, .vtt), transcripciones Whisper (.json) o texto sincronizado.
Calcula los cortes exactos dejando un margen central de respiración natural para que la voz no suene asfixiada.
100% Python estándar (cero dependencias).
"""

import json
import os
import re
import sys

FILLER_ONLY = re.compile(
    r"^[\s,.-]*((um+|uh+|er+|ah+|eh+|em+|este|o sea|osea|bueno|pues|so|okay|ok|right|yeah|like|anyway|basically|"
    r"actually|you know|i mean|let me see|hold on)[\s,.-]*)+$",
    re.I
)

def parse_ts(s: str) -> float:
    s = s.strip().replace(",", ".")
    p = s.split(":")
    if len(p) == 3:
        return int(p[0]) * 3600 + int(p[1]) * 60 + float(p[2])
    elif len(p) == 2:
        return int(p[0]) * 60 + float(p[1])
    try:
        return float(s)
    except Exception:
        return 0.0

def load_cues(source_path_or_text: str):
    """Carga los cues desde un archivo (.srt, .vtt, .json) o directamente desde texto."""
    if os.path.isfile(source_path_or_text):
        try:
            with open(source_path_or_text, "r", encoding="utf-8", errors="replace") as f:
                raw = f.read()
        except Exception:
            return []
    else:
        raw = source_path_or_text

    raw = raw.strip()
    if not raw:
        return []

    # Caso JSON (Whisper)
    if raw.startswith("{") or raw.startswith("["):
        try:
            d = json.loads(raw)
            segs = d.get("segments", d if isinstance(d, list) else [])
            return [(float(s["start"]), float(s["end"]), (s.get("text") or "").strip()) for s in segs if "start" in s]
        except Exception:
            pass

    # Caso SRT / VTT
    cues, cur = [], None
    for line in raw.splitlines():
        m = re.match(r"\s*(\d[\d:.,]+)\s*-->\s*(\d[\d:.,]+)", line)
        if m:
            cur = [parse_ts(m.group(1)), parse_ts(m.group(2)), []]
            cues.append(cur)
        elif cur is not None and line.strip() and not line.strip().isdigit():
            cur[2].append(line.strip())

    if cues:
        return [(a, b, " ".join(t)) for a, b, t in cues if t]

    # Caso sincronia.txt personalizado (ej: 00:00 - 00:04 | Texto)
    cues_custom = []
    for line in raw.splitlines():
        m2 = re.match(r"(\d+[:.]\d+)\s*[-–]\s*(\d+[:.]\d+)\s*[:|]\s*(.*)", line)
        if m2:
            t1 = parse_ts(m2.group(1))
            t2 = parse_ts(m2.group(2))
            cues_custom.append((t1, t2, m2.group(3).strip()))
    return cues_custom

def _norm(t: str):
    return re.sub(r"[^a-záéíóúñ0-9 ]", "", t.lower()).split()

def auditar_silencios(source_path_or_text: str, floor_silencio: float = 0.45) -> dict:
    cues = load_cues(source_path_or_text)
    if not cues:
        return {
            "ok": False,
            "error": "No se encontraron marcas de tiempo válidas (se requiere .srt, .vtt, whisper json o sincronía)",
            "cortes": []
        }

    dur_total = cues[-1][1]
    cortes = []

    for i, (s, e, t) in enumerate(cues):
        # 1. Muletilla aislada
        if FILLER_ONLY.match(t):
            cortes.append({
                "tipo": "FILLER",
                "inicio": round(s, 2),
                "fin": round(e, 2),
                "duracion": round(e - s, 2),
                "motivo": f"Muletilla aislada: '{t.strip()[:35]}'"
            })

        # 2. Silencio muerto entre bloques
        if i > 0:
            gap = s - cues[i - 1][1]
            if gap > floor_silencio:
                # Se mantiene un margen de respiración natural de floor / 2
                margen = floor_silencio / 2.0
                c_start = cues[i - 1][1] + margen
                c_end = s - margen
                if c_end > c_start:
                    cortes.append({
                        "tipo": "DEAD",
                        "inicio": round(c_start, 2),
                        "fin": round(c_end, 2),
                        "duracion": round(c_end - c_start, 2),
                        "motivo": f"Pausa muerta de {gap:.2f}s (se deja respiración natural)"
                    })

        # 3. Frase reiniciada / Toma falsa (Repeat)
        if t.strip() and not FILLER_ONLY.match(t):
            j = i - 1
            while j >= 0 and (FILLER_ONLY.match(cues[j][2]) or not cues[j][2].strip()):
                j -= 1
            if j >= 0:
                a1 = _norm(cues[j][2])[:5]
                b1 = _norm(t)[:5]
                if len(a1) >= 3 and a1 == b1:
                    cortes.append({
                        "tipo": "REPEAT",
                        "inicio": round(cues[j][0], 2),
                        "fin": round(cues[j][1], 2),
                        "duracion": round(cues[j][1] - cues[j][0], 2),
                        "motivo": f"Toma falsa / Reintento de: '{' '.join(a1)}'"
                    })

    cortes = [c for c in cortes if c["fin"] > c["inicio"]]
    cortes.sort(key=lambda c: c["inicio"])
    tiempo_recortado = sum(c["duracion"] for c in cortes)
    dur_final = max(0.0, dur_total - tiempo_recortado)
    pct_ahorro = (tiempo_recortado / dur_total * 100.0) if dur_total > 0 else 0.0

    return {
        "ok": True,
        "total_cues": len(cues),
        "duracion_original": round(dur_total, 2),
        "duracion_optimizada": round(dur_final, 2),
        "tiempo_recortado": round(tiempo_recortado, 2),
        "porcentaje_reduccion": round(pct_ahorro, 1),
        "total_cortes": len(cortes),
        "cortes": cortes
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = auditar_silencios(sys.argv[1])
        print(json.dumps(res, ensure_ascii=False, indent=2))
