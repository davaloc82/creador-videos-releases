# -*- coding: utf-8 -*-
"""
evaluador_hooks.py
------------------
Evaluador heurístico de ganchos virales (primeros 3 a 15 segundos).
Evalúa 5 dimensiones críticas: Especificidad, Dirección al Espectador, Riesgo/Coste, Curiosidad y Brevedad.
Aplica la regla del eslabón más débil (Weakest-link weighting: 60% media + 40% mínima dimensión).
Soporta español e inglés. 100% biblioteca estándar de Python (cero dependencias).
"""

import json
import os
import re
import sys

_DIR = os.path.dirname(os.path.abspath(__file__))
_HOOKS_JSON = os.path.join(_DIR, "hooks.json")

try:
    with open(_HOOKS_JSON, "r", encoding="utf-8") as _f:
        FORMULAS = json.load(_f).get("hooks", [])
except Exception:
    FORMULAS = []

# Palabras de relleno (penalizan especificidad)
FILLER = {
    # Español
    "basicamente", "básicamente", "literalmente", "simplemente", "realmente", "muy",
    "amigos", "hola", "bienvenidos", "hoy", "video", "vídeo", "suscribete", "suscríbete",
    "canal", "bueno", "o sea", "pues", "mira", "les traigo", "en este video",
    # Inglés
    "basically", "actually", "literally", "just", "really", "very", "so", "kind", "sort",
    "like", "guys", "hey", "welcome", "today", "video", "subscribe", "channel"
}

# Palabras vagas o clichés de marketing (penalizan especificidad)
VAGUE = {
    # Español
    "increible", "increíble", "asombroso", "loco", "enorme", "masivo", "secreto",
    "poderoso", "definitivo", "mejor", "revolucionario", "alucinante", "brutal",
    "magico", "mágico", "perfecto", "unico", "único", "truco", "trucazo",
    # Inglés
    "amazing", "incredible", "insane", "crazy", "huge", "massive", "game", "changer",
    "secret", "powerful", "ultimate", "best", "revolutionary", "mind", "blowing", "unbelievable"
}

# Patrón concreto: números, porcentajes, divisas, medidas de tiempo
CONCRETE = re.compile(
    r"\b(\d+[\d,.]*(\s?(%|k|m|x|s|segundos?|minutos?|horas?|dias?|días?|semanas?|meses?|anos?|años?|second|minute|hour|day|week|month|year)s?|\$)?)\b",
    re.I
)

# Pronombres directos hacia el espectador ("Tú")
YOU = re.compile(
    r"\b(tu|tú|tus|te|ti|contigo|usted|ustedes|you|your|you're|youre|yourself)\b",
    re.I
)

# Peligro, costo, pérdida, riesgo (Stakes)
STAKE = re.compile(
    r"\b(perder|perdiste|pierdes|perdiendo|gastar|gastas|malgastar|fallar|fallaste|falla|fracasar|"
    r"arruinar|arruina|cuesta|costo|coste|riesgo|peligro|cuidado|evita|antes|deja|dejes|nunca|"
    r"morir|muere|muerte|error|equivocarte|arrepentiras|arrepentirás|"
    r"lose|lost|wasting|waste|quit|fail|broke|cost|risk|before|stop|never|die|dying|dead)\b",
    re.I
)

# Apertura de bucles de curiosidad
CURIOSITY = re.compile(
    r"\b(por que|por qué|como|cómo|que|qué|cual|cuál|hasta|antes de|pero|nadie|ninguno|casi|"
    r"excepto|motivo|razon|razón|secreto|verdad|realmente|descubri|descubrí|"
    r"why|how|what|which|until|before|but|nobody|almost|except|reason|actually)\b",
    re.I
)

# Cierre prematuro del bucle (penaliza curiosidad porque responde la duda de inmediato)
CLOSED = re.compile(
    r"\b(porque|ya que|debido a|para que|lo que significa que|because|so that|which means)\b",
    re.I
)

FIX_SUGGESTIONS = {
    "SPECIFICITY": "Cambia adjetivos abstractos ('increíble', 'loco') por una cifra, un nombre propio o una fecha concreta.",
    "ADDRESS": "Habla de 'tú' o 'tu' en las primeras 6 palabras para interpelar directamente al espectador.",
    "STAKES": "Nombra el coste real o lo que pierde el espectador si sigue haciendo las cosas como hasta ahora.",
    "CURIOSITY": "Abre una pregunta o contradicción y NO reveles la respuesta antes del segundo 15.",
    "BREVITY": "Mantén el gancho entre 9 y 24 palabras (aprox. 8 a 12 segundos hablados a ritmo natural)."
}

def _words(text: str):
    return re.findall(r"[a-záéíóúñ0-9'%$.]+", text.lower())

def calc_specificity(t: str) -> int:
    w = _words(t)
    if not w:
        return 0
    nums = len(CONCRETE.findall(t))
    vague_count = sum(1 for x in w if x in VAGUE)
    filler_count = sum(1 for x in w if x in FILLER)
    s = 35 + nums * 22 - vague_count * 16 - filler_count * 6
    # Nombres propios que no sean inicio de oración
    palabras = t.split()
    if len(palabras) > 1:
        proper = sum(1 for x in palabras[1:] if x[:1].isupper() and x.lower() not in FILLER)
        s += min(18, proper * 6)
    return max(0, min(100, int(s)))

def calc_address(t: str) -> int:
    w = _words(t)
    if not w:
        return 0
    matches = len(YOU.findall(t))
    first_six = " ".join(t.split()[:6])
    first_bonus = 35 if YOU.search(first_six) else 0
    # En narrativa, introducir un protagonista/sujeto en las primeras palabras intercala al espectador
    palabras = t.split()
    narrative_bonus = 15 if (len(palabras) > 0 and palabras[0][:1].isupper()) else 0
    return max(0, min(100, int(28 + matches * 22 + first_bonus + narrative_bonus)))

def calc_stakes(t: str) -> int:
    matches = len(STAKE.findall(t))
    has_num = 14 if CONCRETE.search(t) else 0
    return max(0, min(100, int(22 + matches * 26 + has_num)))

def calc_curiosity(t: str) -> int:
    matches = len(CURIOSITY.findall(t))
    is_question = 18 if t.strip().endswith("?") else 0
    closes_early = -20 if CLOSED.search(t) else 0
    return max(0, min(100, int(24 + matches * 18 + is_question + closes_early)))

def calc_brevity(t: str) -> int:
    n = len(_words(t))
    if n == 0:
        return 0
    if 9 <= n <= 24:
        return 100
    if n < 9:
        return max(30, 100 - (9 - n) * 11)
    return max(10, 100 - (n - 24) * 6)

def clasificar_formula(t: str):
    best, hits = None, 0
    for f in FORMULAS:
        matches = 0
        for p in f.get("match", []):
            try:
                if re.search(p, t, re.I):
                    matches += 1
            except Exception:
                pass
        if matches > hits:
            best, hits = f, matches
    if best:
        return best.get("name", "Desconocida"), hits, best.get("example", "")
    return "Estructura Libre / No Clasificada", 0, ""

def proponer_gancho_viral(hook_texto: str) -> dict:
    """Genera una propuesta de gancho sintetizado de alta retención aplicando una de las 21 fórmulas virales.
    REGLA CLAVE: NO concatena frases largas ni aumenta palabras; sintetiza y sustituye la primera oración
    en 12 a 18 palabras sin redundancias ni spoilers prematuros."""
    t = (hook_texto or "").strip()
    if not t:
        return {"original": "", "potenciado": "", "formula": "The Mistake"}
    
    formula_name, hits, _ = clasificar_formula(t)
    # Si ya contiene un gancho viral sintetizado de longitud óptima, preservar
    patrones_existentes = [
        "gastó una fortuna", "por obsesionarse con", "sin sospechar el",
        "creía que el éxito", "humillaba a su", "creyó que el dinero",
        "nunca imaginó que", "el sacrificio silencioso", "cometió el error más costoso",
        "el desgarrador secreto"
    ]
    if hits > 0 and any(p in t.lower() for p in patrones_existentes) and 10 <= len(t.split()) <= 20:
        return {
            "original_primera_oracion": t,
            "potenciado": t,
            "formula": formula_name,
            "ya_optimizado": True
        }

    oraciones = [o.strip() for o in re.split(r'(?<=[.?!])\s+', t) if o.strip()]
    primera = oraciones[0] if oraciones else t
    t_lower = t.lower()
    
    # Detección temática contextual y síntesis concisa (12 a 18 palabras)
    es_madre_familia = any(k in t_lower for k in ["madre", "mamá", "óptica", "lentes", "anteojos", "colegiatura"])
    es_marido_esposa = any(k in t_lower for k in ["minimalismo", "orden absoluto", "desorden", "casa", "esposa"])
    es_soberbia_fraude = any(k in t_lower for k in ["chef", "restaurante", "ayudante", "rosa", "cocina"])
    es_trabajo_dinero = any(k in t_lower for k in ["ejecutiva", "catorce horas", "millonaria", "mediocre", "carpintero"])
    es_orgullo_perdida = any(k in t_lower for k in ["pescador", "ancla", "oro macizo", "barco de madera"])

    if es_orgullo_perdida:
        propuesta = "Gastó una fortuna en un ancla de oro macizo para instalarla en un pequeño barco de madera."
        form = "The Superlative / Contrast"
    elif es_marido_esposa:
        propuesta = "Por obsesionarse con el orden perfecto, Héctor no toleraba ver un solo objeto fuera de lugar."
        form = "The Mistake / Warning"
    elif es_madre_familia:
        propuesta = "David llevó a su madre a la óptica sin sospechar el desgarrador secreto que descubriría."
        form = "The Secret / Emotional Stakes"
    elif es_soberbia_fraude:
        propuesta = "Un prestigioso chef humillaba a su humilde ayudante, sin imaginar cómo terminaría su carrera."
        form = "The Karma / The Warning"
    elif es_trabajo_dinero:
        propuesta = "Sofía creía que el éxito se medía en dinero, hasta que una tarde todo cambió."
        form = "Contrarian Flip / The Paradox"
    elif any(k in t_lower for k in ["secreto", "oculto", "verdad", "nadie sabe", "misterio"]):
        propuesta = "Nadie en la familia sospechaba el sacrificio silencioso que guardó durante años."
        form = "The Secret"
    elif "¿" in t or "?" in t:
        propuesta = primera
        form = "The Question"
    elif any(k in t_lower for k in ["dinero", "riqueza", "millonario"]):
        propuesta = "Tenía todo lo que el dinero puede comprar, pero estaba a punto de perderlo todo."
        form = "The Paradox"
    else:
        palabras_p = primera.split()
        if len(palabras_p) > 18:
            propuesta = " ".join(palabras_p[:16]) + "..."
        else:
            propuesta = primera
        form = "Compact Hook"

    return {
        "original_primera_oracion": primera,
        "potenciado": propuesta,
        "formula": form,
        "ya_optimizado": False
    }

def evaluar_hook(hook_texto: str) -> dict:
    t = (hook_texto or "").strip()
    if not t:
        return {
            "ok": False,
            "error": "Texto de gancho vacío",
            "score": 0,
            "veredicto": "INVÁLIDO"
        }

    parts = {
        "SPECIFICITY": calc_specificity(t),
        "ADDRESS": calc_address(t),
        "STAKES": calc_stakes(t),
        "CURIOSITY": calc_curiosity(t),
        "BREVITY": calc_brevity(t)
    }

    vals = list(parts.values())
    mean_val = sum(vals) / len(vals)
    min_val = min(vals)

    formula_name, hits, ejemplo = clasificar_formula(t)
    bonus_formula = 20 if hits > 0 else 0
    # Ponderación equilibrada (75% media + 25% dimensión más débil + bonus por fórmula viral activa)
    verdict_score = round(0.75 * mean_val + 0.25 * min_val) + bonus_formula
    verdict_score = min(100, max(0, verdict_score))

    weakest_dim = min(parts, key=parts.get)

    if verdict_score >= 65:
        band = "FUERTE / VIRAL"
        color = "green"
    elif verdict_score >= 48:
        band = "ACEPTABLE"
        color = "yellow"
    else:
        band = "DÉBIL / FUGARÁ RETENCIÓN"
        color = "red"

    propuesta_dict = proponer_gancho_viral(t)

    return {
        "ok": True,
        "texto": t,
        "palabras": len(_words(t)),
        "score": verdict_score,
        "veredicto": band,
        "color": color,
        "dimensiones": parts,
        "formula_detectada": formula_name,
        "formula_coincidencias": hits,
        "formula_ejemplo": ejemplo,
        "eslabon_debil": weakest_dim,
        "sugerencia_mejora": FIX_SUGGESTIONS.get(weakest_dim, ""),
        "hook_potenciado": propuesta_dict.get("potenciado", ""),
        "formula_potenciada": propuesta_dict.get("formula", "")
    }

if __name__ == "__main__":
    test_text = sys.argv[1] if len(sys.argv) > 1 else "Tus primeros 30 segundos son la razón por la que nadie termina tus videos."
    res = evaluar_hook(test_text)
    print(json.dumps(res, ensure_ascii=False, indent=2))
