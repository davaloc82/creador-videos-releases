# -*- coding: utf-8 -*-
"""
Biblioteca Modular de Diagnóstico y Optimización
------------------------------------------------
Suite modular autónoma con cero dependencias externas.
Protegida contra cambios externos de GitHub y totalmente aislada.

Módulos incluidos:
  - evaluador_hooks: Evalúa ganchos de 3 a 15s en 5 dimensiones heurísticas + 21 fórmulas virales.
  - validador_empaquetado: Linter de Título y Portada/Miniatura para móvil y escritorio.
  - limpiador_audio: Detección de silencios muertos, muletillas y tomas falsas.
  - diagnostico_retencion: Diagnóstico forense de retención de YouTube Studio cruzado con sincronia.txt.
  - generador_capitulos: Capítulos automáticos certificados para normas oficiales de YouTube.
  - analizador_outliers: Detección de ideas virales sobre la mediana del canal.
  - perfilador_voces: Perfilado acústico y emparejamiento con voces gratuitas locales Kokoro ($0 costo).
"""

from .evaluador_hooks import evaluar_hook, FORMULAS as FORMULAS_HOOKS
from .validador_empaquetado import auditar_empaquetado
from .limpiador_audio import auditar_silencios, load_cues
from .diagnostico_retencion import diagnosticar_retencion
from .generador_capitulos import generar_capitulos_youtube
from .analizador_outliers import analizar_outliers
from .perfilador_voces import perfilar_y_recomendar_voces, extraer_vector_acustico

__all__ = [
    "evaluar_hook",
    "FORMULAS_HOOKS",
    "auditar_empaquetado",
    "auditar_silencios",
    "load_cues",
    "diagnosticar_retencion",
    "generar_capitulos_youtube",
    "analizador_outliers",
    "perfilar_y_recomendar_voces",
    "extraer_vector_acustico"
]
