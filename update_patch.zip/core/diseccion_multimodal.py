# -*- coding: utf-8 -*-
"""
MÓDULO DE DISECCIÓN AUDIOVISUAL PROFUNDA (MULTIMODAL / VISIÓN IA)
NEXOR - Creador de Videos © 2026

Descarga temporalmente una muestra del video representativo, extrae fotogramas clave
con FFmpeg, audita la pista de audio (Whisper/energía) y realiza una disección visual
quirúrgica (vía Gemini Vision API si hay clave disponible, o vía heurística visual local).
"""

import os
import sys
import re
import json
import base64
import hashlib
import tempfile
import subprocess
import urllib.request
import urllib.parse
from pathlib import Path

AQUI = Path(__file__).resolve().parent
RAIZ_PROYECTO = AQUI.parent
CONFIG_GEMINI = RAIZ_PROYECTO / "config_gemini.json"

# Pool de Claves Oficiales de Cortesía de NEXOR para onboarding de nuevos clientes
POOL_CLAVES_CORTESIA = [
    "AQ.Ab8RN6JCd7T2vNECZX_goRNNQYFRYdRAnr304FllZkdTSdbgeQ",  # NEXOR Oficial
    "AQ.Ab8RN6I6kA4SOTVgLYoPluzX2FG0eS6HMLwWRHlm1Iw7gFUXxg",  # NEXOR Respaldo 1
    "AQ.Ab8RN6L2Md41PZsyY1zvmIWgfeHlea2oMV3g2Nck3Zpd42PXig",  # NEXOR Respaldo 2
]
LIMITE_ANALISIS_CORTESIA = 5


def _obtener_config_gemini_file() -> tuple[dict, Path]:
    """Carga la configuración de Gemini buscando config_gemini.json o gemini_config.json."""
    for p in [RAIZ_PROYECTO / "config_gemini.json", RAIZ_PROYECTO / "gemini_config.json"]:
        if p.is_file():
            try:
                return json.loads(p.read_text(encoding="utf-8")), p
            except Exception:
                pass
    return {}, RAIZ_PROYECTO / "config_gemini.json"


def obtener_info_gemini() -> dict:
    """Devuelve el estado de la API de Gemini: si es clave propia o cortesía, y usos restantes."""
    cfg, _ = _obtener_config_gemini_file()
    custom_k = ""
    k = (cfg.get("gemini_api_key") or cfg.get("api_key") or "").strip()
    if k and not k.startswith("PEGA_"):
        custom_k = k

    if not custom_k:
        k_env = os.environ.get("GEMINI_API_KEY", "").strip()
        if k_env and not k_env.startswith("PEGA_"):
            custom_k = k_env

    usados = 0
    try:
        usados = int(cfg.get("analisis_cortesia_usados", 0))
    except Exception:
        usados = 0

    if custom_k:
        masked = f"{custom_k[:6]}...{custom_k[-4:]}" if len(custom_k) > 10 else "Clave Personal Activa"
        return {
            "has_custom_key": True,
            "modo_cortesia": False,
            "cortesias_restantes": 9999,
            "cortesias_usadas": usados,
            "masked_key": masked,
            "permite_analizar": True,
            "url_crear_api": "https://aistudio.google.com/app/apikey"
        }
    else:
        restantes = max(0, LIMITE_ANALISIS_CORTESIA - usados)
        return {
            "has_custom_key": False,
            "modo_cortesia": True,
            "cortesias_restantes": restantes,
            "cortesias_usadas": usados,
            "masked_key": "Modo Cortesía NEXOR (3 Claves)",
            "permite_analizar": restantes > 0,
            "url_crear_api": "https://aistudio.google.com/app/apikey"
        }


def registrar_uso_cortesia():
    """Registra un uso de cortesía si el usuario no tiene clave propia."""
    info = obtener_info_gemini()
    if info.get("modo_cortesia"):
        try:
            cfg, path_cfg = _obtener_config_gemini_file()
            cfg["analisis_cortesia_usados"] = info.get("cortesias_usadas", 0) + 1
            path_cfg.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        except Exception:
            pass


def obtener_claves_activas(clave_usuario: str = None) -> list:
    """Devuelve la lista ordenada de claves a intentar (clave propia primero, o pool de cortesía)."""
    if clave_usuario and clave_usuario.strip() and not clave_usuario.startswith("PEGA_"):
        return [clave_usuario.strip()]

    cfg, _ = _obtener_config_gemini_file()
    k_cfg = (cfg.get("gemini_api_key") or cfg.get("api_key") or os.environ.get("GEMINI_API_KEY", "")).strip()
    if k_cfg and not k_cfg.startswith("PEGA_"):
        return [k_cfg]

    info = obtener_info_gemini()
    if info.get("cortesias_restantes", 0) > 0:
        return list(POOL_CLAVES_CORTESIA)

    return []


def obtener_clave_gemini() -> str:
    """Obtiene la clave de Gemini activa (personal o primera del pool de cortesía)."""
    claves = obtener_claves_activas()
    return claves[0] if claves else ""


def guardar_clave_gemini(api_key: str) -> bool:
    """Guarda la clave personal de Gemini en config_gemini.json o gemini_config.json."""
    try:
        limpia = (api_key or "").strip()
        cfg, path_cfg = _obtener_config_gemini_file()
        cfg["gemini_api_key"] = limpia
        cfg["api_key"] = limpia
        path_cfg.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def traducir_al_espanol(texto: str) -> str:
    """Traduce texto extranjero al español usando endpoint de Google Translate."""
    if not texto or len(texto.strip()) < 3:
        return texto
    if not any(ord(c) > 1000 for c in texto) and any(w in texto.lower() for w in [" el ", " la ", " de ", " en ", " y ", " que "]):
        return texto
    try:
        url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=es&dt=t&q=" + urllib.parse.quote(texto)
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read().decode("utf-8"))
            trad = "".join([part[0] for part in data[0] if part[0]])
            return trad.strip()
    except Exception:
        return texto


def sanitizar_prompts_copyright(texto: str) -> str:
    """
    Sanitiza prompts en inglés y descripciones para eliminar marcas registradas
    y personajes comerciales protegidos (ej: Scrooge McDuck, Donald Duck, Disney,
    Marvel, etc.) que activan los filtros de censura o infracción de IP en
    Midjourney v6, Flux, DALL-E 3 y Kling.
    Sustituye por descripciones físicas, anatómicas y estilísticas seguras y neutras.
    """
    if not texto:
        return ""

    t = str(texto)
    reemplazos = [
        (r"\bcharacter\s+(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+scrooge\s+mcduck\b", "in distinguished affluent cartoon style"),
        (r"\b(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+scrooge\s+mcduck\b", "in distinguished affluent cartoon style"),
        (r"\bscrooge\s+mcduck\s+style\b", "distinguished affluent cartoon character"),
        (r"\bscrooge\s+mcduck\b", "affluent cartoon duck character"),
        (r"\bcharacter\s+(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+rico\s+mcpato\b", "en distinguido estilo de caricatura aristócrata"),
        (r"\b(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+rico\s+mcpato\b", "en distinguido estilo de pato aristócrata"),
        (r"\brico\s*mcpato\b", "pato antropomórfico aristócrata de negocios"),
        (r"\bmr\.?\s*pato\b", "pato antropomórfico distinguido"),
        (r"\bdonald\s+duck\b", "anthropomorphic cartoon duck"),
        (r"\bpato\s+donald\b", "pato animado"),
        (r"\bmickey\s+mouse\b", "anthropomorphic cartoon mouse"),
        (r"\bminnie\s+mouse\b", "anthropomorphic cartoon mouse"),
        (r"\bdaffy\s+duck\b", "anthropomorphic animated black duck"),
        (r"\bbugs\s+bunny\b", "anthropomorphic animated rabbit"),
        (r"\blooney\s+tunes\b", "classic animated slapstick style"),
        (r"\bdisney\s+pixar\b", "stylized 3D CGI studio animation"),
        (r"\bpixar\s+disney\b", "stylized 3D CGI studio animation"),
        (r"\bdisney\s+animation\b", "vibrant 3D animated CGI render"),
        (r"\bdisney\s+style\b", "stylized 3D animation render"),
        (r"\bdisney\b", "stylized 3D studio"),
        (r"\bwarren\s+buffett\b", "distinguished senior billionaire mentor"),
        (r"\belon\s+musk\b", "visionary modern tech CEO"),
    ]
    for pat, rep in reemplazos:
        t = re.sub(pat, rep, t, flags=re.IGNORECASE)

    t = re.sub(r",\s*,+", ", ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def auditar_audio_locucion(audio_wav: str) -> tuple[bool, str, str]:
    """
    Audita la pista de audio con Whisper para determinar si hay locución humana real
    o si el video se basa en música viral y efectos sonoros.
    Retorna: (tiene_locucion, transcripcion, descripcion_formato)
    """
    if not os.path.isfile(audio_wav):
        return False, "", "Audio no disponible"
    try:
        import whisper
        model = whisper.load_model("base")
        res = model.transcribe(audio_wav)
        
        segments = res.get("segments", [])
        total_texto = (res.get("text") or "").strip()
        lang = res.get("language", "")

        # Si Whisper alucina idiomas no comunes en audio que es pura música
        if lang not in ["es", "en", "pt", "ru", "fr", "de", "it"]:
            return False, "", "Música viral y efectos sonoros (Sin voz en off hablada)"

        if not segments or len(total_texto) < 18:
            return False, "", "Música instrumental y ambiente (Sin locución estructurada)"

        no_speech_avg = sum(s.get("no_speech_prob", 0) for s in segments) / max(1, len(segments))
        if no_speech_avg > 0.40:
            return False, "", "Música de fondo y ambiente (Sin locución hablada)"

        return True, total_texto, "Locución en voz en off continua detectada"
    except Exception:
        return False, "", "Música y sonido ambiental"


def consultar_gemini_vision(frames_b64: list, prompt_guia: str, api_keys=None) -> dict:
    """Envía los 3 fotogramas clave a la API de Gemini Vision con rotación automática de claves ante límites."""
    if isinstance(api_keys, str):
        lista_claves = [api_keys.strip()] if api_keys.strip() else []
    elif isinstance(api_keys, (list, tuple)):
        lista_claves = [k.strip() for k in api_keys if k and isinstance(k, str) and k.strip()]
    else:
        lista_claves = []

    if not lista_claves:
        lista_claves = obtener_claves_activas()

    if not lista_claves or not frames_b64:
        return {}

    modelos = ["gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash"]
    
    parts = [{"text": prompt_guia}]
    for b64 in frames_b64[:3]:
        parts.append({
            "inline_data": {
                "mime_type": "image/jpeg",
                "data": b64
            }
        })
    
    body = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "temperature": 0.2,
            "response_mime_type": "application/json"
        }
    }
    data_bytes = json.dumps(body).encode("utf-8")

    for k in lista_claves:
        for mod in modelos:
            endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={k}"
            try:
                req = urllib.request.Request(endpoint, data=data_bytes, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=25) as resp:
                    res_json = json.loads(resp.read().decode("utf-8"))
                    text_cand = res_json.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                    if text_cand:
                        t_clean = text_cand.strip()
                        if t_clean.startswith("```"):
                            t_clean = t_clean.split("```")[1]
                            if t_clean.startswith("json"):
                                t_clean = t_clean[4:]
                        t_clean = t_clean.strip()
                        res_parsed = json.loads(t_clean)
                        if res_parsed and isinstance(res_parsed, dict):
                            registrar_uso_cortesia()
                            return res_parsed
            except urllib.error.HTTPError as he:
                if he.code == 429:
                    print(f"Nota: Cuota temporal de Gemini alcanzada ({k[:8]}...), rotando a siguiente clave...")
                    break  # Salta a la siguiente clave del pool
                continue
            except Exception:
                continue

    return {}


def diseccionar_video_completo(url: str, metadata_inicial: dict, clave_gemini: str = None) -> dict:
    """
    Ejecuta la disección audiovisual completa de un video:
    1. Descarga el archivo de video ligero en directorio temporal.
    2. Extrae 3 fotogramas clave en alta definición.
    3. Audita la pista de audio con Whisper.
    4. Analiza la estética y personajes vía Gemini Vision (o heurística local avanzada).
    """
    url_limpia = (url or "").strip()
    if not url_limpia:
        return {"ok": False, "error": "URL vacía"}

    url_hash = hashlib.md5(url_limpia.encode("utf-8")).hexdigest()[:10]
    temp_dir = Path(tempfile.gettempdir()) / "nexor_diseccion" / url_hash
    temp_dir.mkdir(parents=True, exist_ok=True)
    video_path = temp_dir / "muestra.mp4"

    # 1. Descarga del video si no existe en caché temporal
    if not video_path.is_file() or video_path.stat().st_size < 10000:
        cmd_dl = [
            sys.executable, "-m", "yt_dlp",
            "--no-check-certificates",
            "--no-warnings",
            "-f", "bestvideo[height<=720]+bestaudio/best[height<=720]/best",
            "-o", str(video_path),
            url_limpia
        ]
        def _run_silencioso(cmd_s, timeout_s=None):
            kw = {"capture_output": True}
            if timeout_s: kw["timeout"] = timeout_s
            if sys.platform.startswith("win"):
                kw["creationflags"] = 0x08000000
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = 0
                kw["startupinfo"] = si
            return subprocess.run(cmd_s, **kw)

        try:
            _run_silencioso(cmd_dl, timeout_s=35)
        except Exception as ex:
            return {"ok": False, "error": f"Error al descargar muestra para disección: {ex}"}

    if not video_path.is_file() or video_path.stat().st_size < 10000:
        return {"ok": False, "error": "No se pudo obtener el archivo de video para análisis."}

    # 2. Medir duración exacta
    duracion = float(metadata_inicial.get("duracion") or 30.0)
    try:
        cmd_dur = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)
        ]
        r_dur = _run_silencioso(cmd_dur, timeout_s=10)
        out_dur = r_dur.stdout.decode("utf-8", errors="replace").strip()
        duracion = float(out_dur)
    except Exception:
        pass

    # 3. Extraer 3 fotogramas clave (al 15%, 50% y 80%)
    t1 = max(1.0, duracion * 0.15)
    t2 = max(2.0, duracion * 0.50)
    t3 = max(3.0, duracion * 0.80)

    f1 = temp_dir / "f1.jpg"
    f2 = temp_dir / "f2.jpg"
    f3 = temp_dir / "f3.jpg"

    _run_silencioso(["ffmpeg", "-y", "-ss", f"{t1:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(f1)], timeout_s=15)
    _run_silencioso(["ffmpeg", "-y", "-ss", f"{t2:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(f2)], timeout_s=15)
    _run_silencioso(["ffmpeg", "-y", "-ss", f"{t3:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(f3)], timeout_s=15)

    frames_b64 = []
    for fp in [f1, f2, f3]:
        if fp.is_file():
            frames_b64.append(base64.b64encode(fp.read_bytes()).decode("utf-8"))

    # 4. Extraer audio y auditar locución
    audio_wav = temp_dir / "audio.wav"
    _run_silencioso(["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", "16000", str(audio_wav)], timeout_s=20)
    tiene_locucion, transcripcion, tipo_audio_desc = auditar_audio_locucion(str(audio_wav))

    # 5. Traducción semántica del título y descripción inicial
    tit_original = metadata_inicial.get("titulo", "")
    desc_original = metadata_inicial.get("descripcion", "")
    tit_es = traducir_al_espanol(tit_original)
    desc_es = traducir_al_espanol(desc_original)

    # 6. Análisis Visual: Gemini Vision API (si hay claves disponibles) o Heurística Local
    claves_a_probar = obtener_claves_activas(clave_gemini)
    analisis_gemini = {}
    uso_gemini = False

    if claves_a_probar and frames_b64:
        prompt_vision = f"""Actúa como un Director de Arte Audiovisual y Supervisor de Motion Graphics e Inteligencia Artificial.
Analiza con máxima precisión estos 3 fotogramas de un video de formato vertical (TikTok/Reels/Shorts).
Canal: "{metadata_inicial.get('canal', '')}"
Título traducido: "{tit_es}"
Duración: {duracion:.1f} segundos.
Tiene locución hablada: {"Sí" if tiene_locucion else "No, música/efectos únicamente"}.

CRITERIOS CLAVE DE IDENTIFICACIÓN VISUAL Y TÉCNICA DE PRODUCCIÓN:
1. ANIMACIÓN VECTORIAL 2D / INFOGRAFÍA, INGENIERÍA & DIAGRAMAS ESQUEMÁTICOS (motion_graphics_2d):
   - Si los fotogramas muestran arte plano (flat 2D vector), maquetas esquemáticas en cel-shading, cortes arquitectónicos transversales (edificios, casas, techos, tuberías, mecanismos), diagramas didácticos de ingeniería, construcción, física o supervivencia con rótulos explicativos paso a paso.
   - Clasifícalo como "motion_graphics_2d". "es_codigo_motion": true, "tipo_produccion": "codigo_motion".

2. COMEDIA TECH LOW-POLY / VOXEL / DIÁLOGOS DE AGENTES IA (voxel_lowpoly_3d):
   - Si los fotogramas muestran personajes poligonales facetados (low-poly mesh), avatares cúbicos voxel (como la mascota rectangular naranja de Claude, bloques con gafas oscuras, o humanos de gorro de lana estilo low-poly), en un diálogo cómico de oficina/startup/IA.
   - Clasifícalo como "voxel_lowpoly_3d". "es_codigo_motion": true, "tipo_produccion": "codigo_motion".

3. ANIMACIÓN 3D DIDÁCTICA / SIMULACIONES (zack_d_films):
   - Personajes 3D estilizados explicando curiosidades médicas, inventos, ciencia, anatomía o experimentos visuales en Unreal/Blender.

4. 3D CARTOON HÍBRIDO (cartoon_hibrido):
   - Mascota antropomórfica 3D (ej: pato con traje/chistera, zorro o lobo en traje sastre) interactuando en oficinas ejecutivas o entornos fotorrealistas de negocios y dinero.

5. 3D PIXAR (pixar_3d):
   - Animación 3D tierna y expresiva de parejas o animales humanizados (estilo Pixar/Disney).

6. REALISMO CINEMATOGRÁFICO (realismo_cinematografico):
   - Fotografía o cine de acción real fotorrealista con actores humanos y lente 35mm.

REGLA ESTRICTA DE ANTI-COPYRIGHT Y POLÍTICA DE GENERADORES IA:
- Para generación de imagen IA, se utiliza FLOW (nuestra extensión oficial con créditos de prueba). PROHIBIDO mencionar Midjourney ni herramientas ajenas.
- NUNCA utilices nombres de marcas protegidas ni personajes comerciales en los prompts en inglés (PROHIBIDO escribir 'Scrooge McDuck', 'Donald Duck', 'Rico McPato', 'Disney', 'Pixar', 'Claude', 'Anthropic', etc.).
- Describe ÚNICAMENTE características anatómicas puras, geometría, vestimenta, colores e iluminación neutra.

Responde ÚNICAMENTE un objeto JSON estrictamente válido con los siguientes campos:
{{
  "estilo_visual_id": "uno de: motion_graphics_2d, voxel_lowpoly_3d, zack_d_films, cartoon_hibrido, pixar_3d, realismo_cinematografico, dark_noir, documental_historico, terror_misterio, anime_moderno, comic, plastilina_stopmotion, minecraft_voxel, roblox_3d, codigo_motion",
  "estilo_visual_nombre": "Nombre descriptivo del estilo artístico exacto",
  "es_codigo_motion": true si es animación 2D vectorial, low-poly/voxel por código, motion graphics o diagramas técnicos, false si usa modelos generativos de imágenes IA (como Flow),
  "tipo_produccion": "ia_generativa_flow" o "codigo_motion",
  "tipo_nicho": "Nicho y temática exacta del contenido",
  "personaje_1_desc": "Casillero 1 - Descripción detallada del personaje principal o activo visual detectado",
  "personaje_1_prompt": "Prompt en inglés para recrear este personaje o activo visual (--cref) SIN nombres comerciales ni copyright",
  "personaje_sugerido_desc": "Casillero 2 - Descripción de una variación sugerida diferenciada para la marca propia del creador",
  "personaje_sugerido_prompt": "Prompt en inglés para esta variación sugerida (--cref)",
  "personaje_2_desc": "Descripción del segundo personaje o contraparte (o 'N/A')",
  "personaje_2_prompt": "Prompt en inglés del segundo personaje (o 'N/A') SIN copyright",
  "sufijo_estilo_sugerido": "Sufijo en inglés para los prompts de estilo",
  "formato_guion": "Descripción del formato narrativo exacto (ej: Diálogo cómico a dos voces, o Protocolo de supervivencia con reglas de 10 segundos, etc.)",
  "texto_pantalla_ejemplo": "Ejemplo de texto corto en pantalla que encaje con el video",
  "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON TU GENERADOR",
  "score_replicabilidad": 95,
  "nombres_canal_sugeridos": ["8 opciones creativas y atractivas de nombres para un canal en este nicho"],
  "bio_tiktok": "Bio corta (<80 car) para TikTok con gancho y llamada a la acción para este nicho",
  "bio_instagram": "Bio de 3 líneas limpias para Instagram con emojis para este nicho",
  "bio_youtube": "Descripción completa para la pestaña información de YouTube para este canal y nicho",
  "bio_facebook": "Descripción para la página de Facebook",
  "categoria_facebook": "Categoría sugerida para la página de Facebook"
}}
"""
        analisis_gemini = consultar_gemini_vision(frames_b64, prompt_vision, claves_a_probar)
        if analisis_gemini:
            for campo in ["personaje_1_prompt", "personaje_sugerido_prompt", "personaje_2_prompt", "sufijo_estilo_sugerido"]:
                if campo in analisis_gemini and isinstance(analisis_gemini[campo], str):
                    analisis_gemini[campo] = sanitizar_prompts_copyright(analisis_gemini[campo])
            for campo_desc in ["personaje_1_desc", "personaje_sugerido_desc", "personaje_2_desc", "estilo_visual_nombre"]:
                if campo_desc in analisis_gemini and isinstance(analisis_gemini[campo_desc], str):
                    analisis_gemini[campo_desc] = sanitizar_prompts_copyright(analisis_gemini[campo_desc])
            if analisis_gemini.get("estilo_visual_id"):
                uso_gemini = True

    # 7. Fallback Local Inteligente si no se usó Gemini
    if not uso_gemini:
        canal_nom = str(metadata_inicial.get('canal', '') or '').lower()
        uploader_nom = str(metadata_inicial.get('uploader', '') or '').lower()
        texto_comb = f"{tit_original} {desc_original} {tit_es} {desc_es} {canal_nom} {uploader_nom}".lower()

        # Detección de Avatar / Mascota Antropomórfica (Mr. Pato, Rico McPato, Scrooge McDuck, etc.)
        raices_pato = ["pato", "mrpato", "mr.pato", "duck", "scrooge", "mcduck", "mcpato", "donald"]
        es_pato_canal = any(k in texto_comb or k in canal_nom for k in raices_pato)

        # Detección de Ingeniería, Construcción, Arquitectura y Hogar (Maquetas y Diagramas Esquemáticos)
        raices_construccion = [
            "construcción", "construccion", "ingeniería", "ingenieria", "arquitectura",
            "albañil", "albañilería", "albanil", "albanileria", "casa", "casas", "techo", "techos",
            "ladrillo", "ladrillos", "cemento", "viga", "vigas", "columna", "columnas",
            "tubería", "tuberias", "tuberia", "drenaje", "drenajes", "fontanería", "fontaneria",
            "canaleta", "canaletas", "bajante", "bajantes", "humedad", "filtración", "filtracion",
            "paneles solares", "panel solar", "obra", "obras", "remodelación", "remodelacion",
            "cimientos", "grieta", "grietas", "plano", "planos", "hormigón", "hormigon",
            "plomería", "plomeria", "reparación de casa", "reparacion de casa", "bricolaje",
            "tumpis"
        ]
        es_construccion = any(k in texto_comb or k in canal_nom for k in raices_construccion)

        # Detección de Parejas / Animales Tiernos / Humor Relatable (ej. Suricatas de TikTok, Norana na dvoikh)
        raices_pareja_ternura = [
            # Español (raíces para atrapar conjugaciones y plurales)
            "abraz", "bes", "mim", "tiern", "parej", "novi", "enamor", "cariñ", "afect", "quehacer",
            "etiqueta a", "hacerte reír", "hacerte reir", "risa", "ternura", "suricata", "meerkat",
            # Ruso (canales virales como norana2ih / Нора на двоих)
            "обним", "обнять", "обнимашки", "поцелу", "двоих", "нора", "мило", "любов", "norana", "na2ih", "dvoikh",
            # Inglés
            "cute", "cuddle", "hug", "kiss", "laugh", "smile", "chibi", "wholesome", "relatable"
        ]
        es_pareja_ternura = any(k in texto_comb for k in raices_pareja_ternura)

        es_animacion_3d = es_pareja_ternura or any(k in texto_comb for k in [
            "pixar", "disney", "cartoon", "animación", "animacion", "3d", "blender", "render"
        ])

        if es_construccion:
            analisis_gemini = {
                "estilo_visual_id": "motion_graphics_2d",
                "estilo_visual_nombre": "Infografía Animada 2D / Motion Graphics & Diagramas Esquemáticos",
                "es_codigo_motion": True,
                "tipo_produccion": "codigo_motion",
                "tipo_nicho": "Ingeniería, Construcción y Ciencia Didáctica",
                "personaje_1_desc": "Maqueta esquemática 3D cel-shaded de vivienda / arquitectura con cortes transversales didácticos",
                "personaje_1_prompt": "3D cel-shaded schematic architectural cutaway diagram of a house, brick walls, roof framing structure, clean outlines, educational diagram style --ar 9:16",
                "personaje_sugerido_desc": "Variación de Marca Propia: Maqueta moderna con cortes transversales, capas semitransparentes y flechas dinámicas de flujo",
                "personaje_sugerido_prompt": "Modern 3D cel-shaded cross-section cutaway diagram of a house, showing water drainage system and roof slope, bold outlines, clean minimalist engineering aesthetic --ar 9:16",
                "personaje_2_desc": "Diagrama de detalle técnico / Instalación o viga de soporte",
                "personaje_2_prompt": "N/A",
                "sufijo_estilo_sugerido": "Clean 2D/3D schematic cross-section animation style, bold outlines, cel-shaded, vibrant educational diagram palette, minimalist engineering aesthetic --ar 9:16",
                "formato_guion": "Desglose didáctico de procesos de construcción paso a paso mediante capas visuales interactivas",
                "texto_pantalla_ejemplo": tit_es or "CANALETA / BAJANTE",
                "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON TU GENERADOR (95%)",
                "score_replicabilidad": 95,
                "nombres_canal_sugeridos": [
                    "Ingeniería Maestra",
                    "Mundo Construcción",
                    "Obra & Ciencia",
                    "Estructura Visual",
                    "El Arte de Construir",
                    "Ingeniería al Detalle",
                    "Manual de Construcción",
                    "Plano & Obra"
                ],
                "bio_tiktok": "🏗️ Secretos de construcción, arquitectura e ingeniería explicados paso a paso | 📐 Aprende cómo se hace | 👇 Sígueme para más",
                "bio_instagram": "🏗️ Ingeniería, Construcción & Arquitectura Didáctica\n📐 Secretos de obra, estructuras y cómo construir bien\n👇 Nuevas explicaciones diarias",
                "bio_youtube": "Bienvenido al canal donde la ingeniería, la construcción y los procesos arquitectónicos cobran vida a través de diagramas y explicaciones didácticas paso a paso.\n\nDescubre cómo funcionan las estructuras, los errores comunes en obra, instalaciones de agua, techos, cimientos y los principios físicos explicados de forma clara, directa y visual.\n\n🔔 Suscríbete y activa la campana para aprender algo nuevo de ingeniería cada semana.",
                "bio_facebook": "Explicaciones didácticas de ingeniería, procesos de construcción, arquitectura y ciencia aplicada paso a paso.",
                "categoria_facebook": "Ingeniería y Construcción / Ciencia Didáctica"
            }
        elif es_pato_canal:
            analisis_gemini = {
                "estilo_visual_id": "cartoon_hibrido",
                "estilo_visual_nombre": "3D Cartoon Híbrido / Mascota Antropomórfica en Entorno Realista (Estilo Mr. Pato)",
                "es_codigo_motion": False,
                "tipo_produccion": "ia_generativa",
                "tipo_nicho": "Historias de Negocios, Mentalidad y Psicología Financiera con Avatar Animado",
                "personaje_1_desc": "Mascota Detectada (Referencia): Pato Antropomórfico en Chaqueta Roja de Terciopelo (Red Suit Jacket), Chistera Negra con Cinta Roja y Bastón de Oro",
                "personaje_1_prompt": "Character reference portrait of an anthropomorphic white cartoon duck in Victorian haute couture, wearing a luxury tailored red suit jacket with polished gold buttons, tall black silk top hat with crimson band, white spats, holding a polished golden walking stick, sharp confident and wealthy expression, vibrant cinematic 3D CGI stylized render composited in photorealistic luxury office, dramatic warm lighting, 8k resolution --ar 9:16",
                "personaje_sugerido_desc": "Mascota Sugerida (Marca Propia): Pato Ejecutivo en Traje Sastre Azul Medianoche, Chaleco Plateado, Monóculo Dorado y Reloj de Bolsillo",
                "personaje_sugerido_prompt": "Character reference portrait of an anthropomorphic white cartoon duck in bespoke modern executive attire, wearing an elegant tailored midnight navy blue suit jacket with charcoal satin lapels, silver silk waistcoat, polished gold pocket watch chain, sophisticated golden monocle, sharp ambitious expression, vibrant cinematic 3D CGI stylized render integrated into a photorealistic modern high-rise penthouse office, dramatic atmospheric lighting, 8k resolution --ar 9:16",
                "personaje_2_desc": "El Magnate o Mentor de Negocios (Inversionista Realista)",
                "personaje_2_prompt": "Character reference portrait of a distinguished elderly billionaire mentor in classic dark grey business suit and glasses, sitting in an opulent mahogany executive office filled with stacks of cash, realistic cinematic lighting, 35mm lens --ar 9:16",
                "sufijo_estilo_sugerido": "Cinematic 3D hybrid cartoon animation style, vibrant stylized anthropomorphic character integrated seamlessly into photorealistic cinematic business environment, dramatic warm volumetric lighting, Octane render 8k --ar 9:16",
                "formato_guion": "Narración en voz en off continua sobre psicología de negocios y lecciones de vida protagonizada visualmente por avatar animado en escenas realistas",
                "texto_pantalla_ejemplo": tit_es or "Una verdad incómoda que pocos aceptan sobre el dinero y la familia",
                "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON TU GENERADOR (FLOW)",
                "score_replicabilidad": 95
            }
        elif es_pareja_ternura or es_animacion_3d:
            texto_pantalla_propuesto = tit_es if (tit_es and len(tit_es) < 70) else "POV: Los abrazos son más importantes que cualquier quehacer 🤍"
            analisis_gemini = {
                "estilo_visual_id": "pixar_3d",
                "estilo_visual_nombre": "3D Pixar / Render Cinematográfico Digital",
                "es_codigo_motion": False,
                "tipo_produccion": "ia_generativa",
                "tipo_nicho": "Micro-momentos de Parejas, Ternura y Humor Relatable (Animación 3D)",
                "personaje_1_desc": "Personaje Detectado (Referencia): Suricata hembra animada estilo 3D Pixar con flor rosada en la oreja y expresión coqueta",
                "personaje_1_prompt": "Character reference portrait of an adorable female meerkat in 3D stylized animation studio render, big glossy expressive eyes, soft fine cream and light grey fur, tiny pink flower behind her left ear, warm cinematic lighting, octane render, 8k --ar 9:16",
                "personaje_sugerido_desc": "Personaje Sugerido (Marca Propia): Mascota Tierna con Chaleco Lavanda Artesanal o Lazo Aguamarina",
                "personaje_sugerido_prompt": "Character reference portrait of an adorable fluffy animal character in 3D stylized animation studio render, big emotive glossy eyes, soft warm cream and caramel fur, wearing a tiny handcrafted lavender knit vest, warm cozy studio lighting, octane render, 8k --ar 9:16",
                "personaje_2_desc": "Suricata macho animado estilo 3D Pixar, pelaje castaño miel esponjoso, sonrisa tierna y mirada enamorada",
                "personaje_2_prompt": "Character reference portrait of a cute male meerkat in 3D stylized animation studio render, warm golden brown fluffy fur, big curious expressive eyes, animated playful affectionate expression, octane render, 8k --ar 9:16",
                "sufijo_estilo_sugerido": "3D Pixar animation style render, cute and expressive character design, soft subsurface scattering, vibrant warm studio lighting, Unreal Engine 5 octane render, 8k --ar 9:16",
                "formato_guion": "Micro-animación 3D gestual con Foley diegético y texto POV en pantalla (CERO voz en off)",
                "texto_pantalla_ejemplo": texto_pantalla_propuesto,
                "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON TU GENERADOR (FLOW)",
                "score_replicabilidad": 96
            }

    # Si se detectó pixar_3d y no hay locución hablada, ajustar la descripción de audio a Foley diegético
    if not tiene_locucion and (analisis_gemini.get("estilo_visual_id") == "pixar_3d" or analisis_gemini.get("tipo_produccion") == "ia_generativa"):
        tipo_audio_desc = "Foley y Efectos Naturales Diegéticos (Pasos, abrazos, besos, cortes y suspiros sincronizados con la animación + Melodía cálida de fondo. Cero voz en off)"

    return {
        "ok": True,
        "duracion": duracion,
        "fotogramas": frames_b64,
        "tiene_locucion": tiene_locucion,
        "transcripcion": transcripcion,
        "tipo_audio_desc": tipo_audio_desc,
        "titulo_es": tit_es,
        "descripcion_es": desc_es,
        "uso_gemini": uso_gemini,
        "datos_diseccion": analisis_gemini
    }
