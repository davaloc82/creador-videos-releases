# -*- coding: utf-8 -*-
"""
MÓDULO DE DISECCIÓN AUDIOVISUAL PROFUNDA (MULTIMODAL / VISIÓN IA)
NEXOR - Creador de Videos © 2026

Descarga temporalmente una muestra del video representativo, extrae fotogramas clave
con FFmpeg, audita la pista de audio (Whisper/energía) y realiza una disección visual
quirúrgica (vía Gemini Vision API si hay clave disponible, o vía heurística visual local).
"""

import os
import sys
import re
import json
import base64
import hashlib
import tempfile
import subprocess
import urllib.request
import urllib.parse
from pathlib import Path

AQUI = Path(__file__).resolve().parent
RAIZ_PROYECTO = AQUI.parent
CONFIG_GEMINI = RAIZ_PROYECTO / "config_gemini.json"


def obtener_clave_gemini() -> str:
    """Obtiene la clave de Gemini configurada en el sistema o variable de entorno."""
    if CONFIG_GEMINI.is_file():
        try:
            cfg = json.loads(CONFIG_GEMINI.read_text(encoding="utf-8"))
            k = (cfg.get("gemini_api_key") or cfg.get("api_key") or "").strip()
            if k and not k.startswith("PEGA_"):
                return k
        except Exception:
            pass

    k_env = os.environ.get("GEMINI_API_KEY", "").strip()
    if k_env and not k_env.startswith("PEGA_"):
        return k_env

    hw_cfg = RAIZ_PROYECTO / "hardware_config.json"
    if hw_cfg.is_file():
        try:
            cfg = json.loads(hw_cfg.read_text(encoding="utf-8"))
            k = (cfg.get("gemini_api_key") or "").strip()
            if k:
                return k
        except Exception:
            pass

    return ""


def guardar_clave_gemini(api_key: str) -> bool:
    """Guarda la clave de Gemini en config_gemini.json."""
    try:
        limpia = (api_key or "").strip()
        CONFIG_GEMINI.write_text(json.dumps({"gemini_api_key": limpia}, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def traducir_al_espanol(texto: str) -> str:
    """Traduce texto extranjero al español usando endpoint de Google Translate."""
    if not texto or len(texto.strip()) < 3:
        return texto
    if not any(ord(c) > 1000 for c in texto) and any(w in texto.lower() for w in [" el ", " la ", " de ", " en ", " y ", " que "]):
        return texto
    try:
        url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=es&dt=t&q=" + urllib.parse.quote(texto)
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read().decode("utf-8"))
            trad = "".join([part[0] for part in data[0] if part[0]])
            return trad.strip()
    except Exception:
        return texto


def sanitizar_prompts_copyright(texto: str) -> str:
    """
    Sanitiza prompts en inglés y descripciones para eliminar marcas registradas
    y personajes comerciales protegidos (ej: Scrooge McDuck, Donald Duck, Disney,
    Marvel, etc.) que activan los filtros de censura o infracción de IP en
    Midjourney v6, Flux, DALL-E 3 y Kling.
    Sustituye por descripciones físicas, anatómicas y estilísticas seguras y neutras.
    """
    if not texto:
        return ""

    t = str(texto)
    reemplazos = [
        (r"\bcharacter\s+(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+scrooge\s+mcduck\b", "in distinguished affluent cartoon style"),
        (r"\b(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+scrooge\s+mcduck\b", "in distinguished affluent cartoon style"),
        (r"\bscrooge\s+mcduck\s+style\b", "distinguished affluent cartoon character"),
        (r"\bscrooge\s+mcduck\b", "affluent cartoon duck character"),
        (r"\bcharacter\s+(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+rico\s+mcpato\b", "en distinguido estilo de caricatura aristócrata"),
        (r"\b(inspired\s+by|in\s+the\s+style\s+of|based\s+on)\s+rico\s+mcpato\b", "en distinguido estilo de pato aristócrata"),
        (r"\brico\s*mcpato\b", "pato antropomórfico aristócrata de negocios"),
        (r"\bmr\.?\s*pato\b", "pato antropomórfico distinguido"),
        (r"\bdonald\s+duck\b", "anthropomorphic cartoon duck"),
        (r"\bpato\s+donald\b", "pato animado"),
        (r"\bmickey\s+mouse\b", "anthropomorphic cartoon mouse"),
        (r"\bminnie\s+mouse\b", "anthropomorphic cartoon mouse"),
        (r"\bdaffy\s+duck\b", "anthropomorphic animated black duck"),
        (r"\bbugs\s+bunny\b", "anthropomorphic animated rabbit"),
        (r"\blooney\s+tunes\b", "classic animated slapstick style"),
        (r"\bdisney\s+pixar\b", "stylized 3D CGI studio animation"),
        (r"\bpixar\s+disney\b", "stylized 3D CGI studio animation"),
        (r"\bdisney\s+animation\b", "vibrant 3D animated CGI render"),
        (r"\bdisney\s+style\b", "stylized 3D animation render"),
        (r"\bdisney\b", "stylized 3D studio"),
        (r"\bwarren\s+buffett\b", "distinguished senior billionaire mentor"),
        (r"\belon\s+musk\b", "visionary modern tech CEO"),
    ]
    for pat, rep in reemplazos:
        t = re.sub(pat, rep, t, flags=re.IGNORECASE)

    t = re.sub(r",\s*,+", ", ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def auditar_audio_locucion(audio_wav: str) -> tuple[bool, str, str]:
    """
    Audita la pista de audio con Whisper para determinar si hay locución humana real
    o si el video se basa en música viral y efectos sonoros.
    Retorna: (tiene_locucion, transcripcion, descripcion_formato)
    """
    if not os.path.isfile(audio_wav):
        return False, "", "Audio no disponible"
    try:
        import whisper
        model = whisper.load_model("base")
        res = model.transcribe(audio_wav)
        
        segments = res.get("segments", [])
        total_texto = (res.get("text") or "").strip()
        lang = res.get("language", "")

        # Si Whisper alucina idiomas no comunes en audio que es pura música
        if lang not in ["es", "en", "pt", "ru", "fr", "de", "it"]:
            return False, "", "Música viral y efectos sonoros (Sin voz en off hablada)"

        if not segments or len(total_texto) < 18:
            return False, "", "Música instrumental y ambiente (Sin locución estructurada)"

        no_speech_avg = sum(s.get("no_speech_prob", 0) for s in segments) / max(1, len(segments))
        if no_speech_avg > 0.40:
            return False, "", "Música de fondo y ambiente (Sin locución hablada)"

        return True, total_texto, "Locución en voz en off continua detectada"
    except Exception:
        return False, "", "Música y sonido ambiental"


def consultar_gemini_vision(frames_b64: list, prompt_guia: str, api_key: str) -> dict:
    """Envía los 3 fotogramas clave a la API de Gemini Vision para una disección estética perfecta."""
    modelos = ["gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"]
    
    parts = [{"text": prompt_guia}]
    for b64 in frames_b64[:3]:
        parts.append({
            "inline_data": {
                "mime_type": "image/jpeg",
                "data": b64
            }
        })
    
    body = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "temperature": 0.2,
            "response_mime_type": "application/json"
        }
    }
    data_bytes = json.dumps(body).encode("utf-8")

    for mod in modelos:
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={api_key}"
        try:
            req = urllib.request.Request(endpoint, data=data_bytes, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=25) as resp:
                res_json = json.loads(resp.read().decode("utf-8"))
                text_cand = res_json.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                if text_cand:
                    t_clean = text_cand.strip()
                    if t_clean.startswith("```"):
                        t_clean = t_clean.split("```")[1]
                        if t_clean.startswith("json"):
                            t_clean = t_clean[4:]
                    t_clean = t_clean.strip()
                    return json.loads(t_clean)
        except Exception:
            continue

    return {}


def diseccionar_video_completo(url: str, metadata_inicial: dict, clave_gemini: str = None) -> dict:
    """
    Ejecuta la disección audiovisual completa de un video:
    1. Descarga el archivo de video ligero en directorio temporal.
    2. Extrae 3 fotogramas clave en alta definición.
    3. Audita la pista de audio con Whisper.
    4. Analiza la estética y personajes vía Gemini Vision (o heurística local avanzada).
    """
    url_limpia = (url or "").strip()
    if not url_limpia:
        return {"ok": False, "error": "URL vacía"}

    url_hash = hashlib.md5(url_limpia.encode("utf-8")).hexdigest()[:10]
    temp_dir = Path(tempfile.gettempdir()) / "nexor_diseccion" / url_hash
    temp_dir.mkdir(parents=True, exist_ok=True)
    video_path = temp_dir / "muestra.mp4"

    # 1. Descarga del video si no existe en caché temporal
    if not video_path.is_file() or video_path.stat().st_size < 10000:
        cmd_dl = [
            sys.executable, "-m", "yt_dlp",
            "--no-check-certificates",
            "--no-warnings",
            "-f", "bestvideo[height<=720]+bestaudio/best[height<=720]/best",
            "-o", str(video_path),
            url_limpia
        ]
        try:
            subprocess.run(cmd_dl, capture_output=True, timeout=35)
        except Exception as ex:
            return {"ok": False, "error": f"Error al descargar muestra para disección: {ex}"}

    if not video_path.is_file() or video_path.stat().st_size < 10000:
        return {"ok": False, "error": "No se pudo obtener el archivo de video para análisis."}

    # 2. Medir duración exacta
    duracion = float(metadata_inicial.get("duracion") or 30.0)
    try:
        cmd_dur = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)
        ]
        out_dur = subprocess.check_output(cmd_dur, text=True).strip()
        duracion = float(out_dur)
    except Exception:
        pass

    # 3. Extraer 3 fotogramas clave (al 15%, 50% y 80%)
    t1 = max(1.0, duracion * 0.15)
    t2 = max(2.0, duracion * 0.50)
    t3 = max(3.0, duracion * 0.80)

    f1 = temp_dir / "f1.jpg"
    f2 = temp_dir / "f2.jpg"
    f3 = temp_dir / "f3.jpg"

    subprocess.run(["ffmpeg", "-y", "-ss", f"{t1:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(f1)], capture_output=True)
    subprocess.run(["ffmpeg", "-y", "-ss", f"{t2:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(f2)], capture_output=True)
    subprocess.run(["ffmpeg", "-y", "-ss", f"{t3:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(f3)], capture_output=True)

    frames_b64 = []
    for fp in [f1, f2, f3]:
        if fp.is_file():
            frames_b64.append(base64.b64encode(fp.read_bytes()).decode("utf-8"))

    # 4. Extraer audio y auditar locución
    audio_wav = temp_dir / "audio.wav"
    subprocess.run(["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", "16000", str(audio_wav)], capture_output=True)
    tiene_locucion, transcripcion, tipo_audio_desc = auditar_audio_locucion(str(audio_wav))

    # 5. Traducción semántica del título y descripción inicial
    tit_original = metadata_inicial.get("titulo", "")
    desc_original = metadata_inicial.get("descripcion", "")
    tit_es = traducir_al_espanol(tit_original)
    desc_es = traducir_al_espanol(desc_original)

    # 6. Análisis Visual: Gemini Vision API (si hay clave) o Heurística Local
    clave_activa = (clave_gemini or "").strip() or obtener_clave_gemini()
    analisis_gemini = {}
    uso_gemini = False

    if clave_activa and frames_b64:
        prompt_vision = f"""Actúa como un Director de Arte Audiovisual y Supervisor de Efectos Visuales e Inteligencia Artificial.
Analiza con máxima precisión estos 3 fotogramas de un video de formato vertical (TikTok/Reels/Shorts).
Canal: "{metadata_inicial.get('canal', '')}"
Título traducido: "{tit_es}"
Duración: {duracion:.1f} segundos.
Tiene locución hablada: {"Sí" if tiene_locucion else "No, música/efectos únicamente"}.
REGLA CRÍTICA DE IDENTIDAD VISUAL: Si en los fotogramas aparece un personaje de caricatura, pato, animal antropomórfico o avatar 3D interactuando en escenas realistas o con dinero/personas, clasifícalo como "cartoon_hibrido" o "pixar_3d" y describe exactamente su especie, atuendo (ej: frac rojo, chistera, bastón) en personaje_1_desc. PROHIBIDO clasificarlo como realismo humano si hay una mascota o avatar animado.

REGLA ESTRICTA DE ANTI-COPYRIGHT Y POLÍTICA DE GENERADORES IA (PROHIBIDO NOMBRES DE PERSONAJES COMERCIALES):
Para que los prompts sean aceptados por Midjourney v6, Flux, DALL-E 3 y Kling SIN ser censurados por políticas de derechos de autor:
- En los campos en inglés ("personaje_1_prompt", "personaje_2_prompt", "sufijo_estilo_sugerido"), NUNCA utilices nombres de marcas, empresas ni personajes con derechos de autor protegidos (PROHIBIDO escribir 'Scrooge McDuck', 'Donald Duck', 'Rico McPato', 'Disney', 'Pixar', 'Looney Tunes', 'Mickey Mouse', etc.).
- En su lugar, describe ÚNICAMENTE las características anatómicas y físicas puras, especie animal, vestimenta, telas, colores e iluminación en inglés fotográfico o renderizado 3D neutro (ej: 'Character reference portrait of an anthropomorphic white duck in luxury Victorian tailored crimson velvet coat with polished gold buttons, tall black silk top hat with red band, holding a polished golden cane, confident sharp gaze, vibrant 3D CGI stylized render composited in photorealistic luxury office, dramatic warm lighting --ar 9:16 --v 6').

Responde ÚNICAMENTE un objeto JSON estrictamente válido con los siguientes campos:
{{
  "estilo_visual_id": "uno de: pixar_3d, cartoon_hibrido, realismo_cinematografico, codigo_motion, anime_moderno, comic, plastilina_stopmotion, zack_d_films, dark_noir, minecraft_voxel, roblox_3d",
  "estilo_visual_nombre": "Nombre descriptivo del estilo artístico exacto",
  "es_codigo_motion": true si es animación programada por código/gráficas vectoriales/canvas/python sin imágenes IA, false si usa modelos generativos como Midjourney/Flux/Veo/Pixar 3D,
  "tipo_produccion": "ia_generativa" o "codigo_motion",
  "tipo_nicho": "Nicho y temática exacta del contenido",
  "personaje_1_desc": "Casillero 1 - Descripción detallada del personaje principal detectado en el video (especie, apariencia física, ropa original ej: red suit jacket, expresión)",
  "personaje_1_prompt": "Prompt fotográfico o de render en inglés para generar el personaje detectado exactamente con su ropa original (--cref) SIN nombres comerciales ni copyright",
  "personaje_sugerido_desc": "Casillero 2 - Descripción de una variación sugerida y diferenciada de este personaje para la marca propia del creador (misma especie/arquetipo pero con otro color de traje elegante, ropa distinta y accesorios como monóculo o reloj de bolsillo para evitar copyright)",
  "personaje_sugerido_prompt": "Prompt en inglés para generar esta variación sugerida diferenciada (--cref)",
  "personaje_2_desc": "Descripción detallada del segundo personaje (mentor, contraparte o antagonista) en español (o 'N/A')",
  "personaje_2_prompt": "Prompt en inglés del segundo personaje (o 'N/A') SIN nombres comerciales ni copyright",
  "sufijo_estilo_sugerido": "Sufijo en inglés para los prompts de imagen SIN nombres protegidos",
  "formato_guion": "Descripción del formato (ej: micro-momento de pareja con texto en pantalla y música viral, o narrador en voz en off continua, o diálogo)",
  "texto_pantalla_ejemplo": "Ejemplo de texto corto en pantalla que encaje con el video",
  "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON TU GENERADOR",
  "score_replicabilidad": 95
}}
"""
        analisis_gemini = consultar_gemini_vision(frames_b64, prompt_vision, clave_activa)
        if analisis_gemini:
            for campo in ["personaje_1_prompt", "personaje_sugerido_prompt", "personaje_2_prompt", "sufijo_estilo_sugerido"]:
                if campo in analisis_gemini and isinstance(analisis_gemini[campo], str):
                    analisis_gemini[campo] = sanitizar_prompts_copyright(analisis_gemini[campo])
            for campo_desc in ["personaje_1_desc", "personaje_sugerido_desc", "personaje_2_desc", "estilo_visual_nombre"]:
                if campo_desc in analisis_gemini and isinstance(analisis_gemini[campo_desc], str):
                    analisis_gemini[campo_desc] = sanitizar_prompts_copyright(analisis_gemini[campo_desc])
            if analisis_gemini.get("estilo_visual_id"):
                uso_gemini = True

    # 7. Fallback Local Inteligente si no se usó Gemini
    if not uso_gemini:
        canal_nom = str(metadata_inicial.get('canal', '') or '').lower()
        uploader_nom = str(metadata_inicial.get('uploader', '') or '').lower()
        texto_comb = f"{tit_original} {desc_original} {tit_es} {desc_es} {canal_nom} {uploader_nom}".lower()

        # Detección de Avatar / Mascota Antropomórfica (Mr. Pato, Rico McPato, Scrooge McDuck, etc.)
        raices_pato = ["pato", "mrpato", "mr.pato", "duck", "scrooge", "mcduck", "mcpato", "donald"]
        es_pato_canal = any(k in texto_comb or k in canal_nom for k in raices_pato)

        # Detección de Parejas / Animales Tiernos / Humor Relatable (ej. Suricatas de TikTok, Norana na dvoikh)
        raices_pareja_ternura = [
            # Español (raíces para atrapar conjugaciones y plurales)
            "abraz", "bes", "mim", "tiern", "parej", "novi", "enamor", "cariñ", "afect", "quehacer",
            "etiqueta a", "hacerte reír", "hacerte reir", "risa", "ternura", "suricata", "meerkat",
            # Ruso (canales virales como norana2ih / Нора на двоих)
            "обним", "обнять", "обнимашки", "поцелу", "двоих", "нора", "мило", "любов", "norana", "na2ih", "dvoikh",
            # Inglés
            "cute", "cuddle", "hug", "kiss", "laugh", "smile", "chibi", "wholesome", "relatable"
        ]
        es_pareja_ternura = any(k in texto_comb for k in raices_pareja_ternura)

        es_animacion_3d = es_pareja_ternura or any(k in texto_comb for k in [
            "pixar", "disney", "cartoon", "animación", "animacion", "3d", "blender", "render"
        ])

        if es_pato_canal:
            analisis_gemini = {
                "estilo_visual_id": "cartoon_hibrido",
                "estilo_visual_nombre": "3D Cartoon Híbrido / Mascota Antropomórfica en Entorno Realista (Estilo Mr. Pato)",
                "es_codigo_motion": False,
                "tipo_produccion": "ia_generativa",
                "tipo_nicho": "Historias de Negocios, Mentalidad y Psicología Financiera con Avatar Animado",
                "personaje_1_desc": "Mascota Detectada (Referencia): Pato Antropomórfico en Chaqueta Roja de Terciopelo (Red Suit Jacket), Chistera Negra con Cinta Roja y Bastón de Oro",
                "personaje_1_prompt": "Character reference portrait of an anthropomorphic white cartoon duck in Victorian haute couture, wearing a luxury tailored red suit jacket with polished gold buttons, tall black silk top hat with crimson band, white spats, holding a polished golden walking stick, sharp confident and wealthy expression, vibrant cinematic 3D CGI stylized render composited in photorealistic luxury office, dramatic warm lighting, 8k resolution --ar 9:16 --v 6",
                "personaje_sugerido_desc": "Mascota Sugerida (Marca Propia): Pato Ejecutivo en Traje Sastre Azul Medianoche, Chaleco Plateado, Monóculo Dorado y Reloj de Bolsillo",
                "personaje_sugerido_prompt": "Character reference portrait of an anthropomorphic white cartoon duck in bespoke modern executive attire, wearing an elegant tailored midnight navy blue suit jacket with charcoal satin lapels, silver silk waistcoat, polished gold pocket watch chain, sophisticated golden monocle, sharp ambitious expression, vibrant cinematic 3D CGI stylized render integrated into a photorealistic modern high-rise penthouse office, dramatic atmospheric lighting, 8k resolution --ar 9:16 --v 6",
                "personaje_2_desc": "El Magnate o Mentor de Negocios (Inversionista Realista)",
                "personaje_2_prompt": "Character reference portrait of a distinguished elderly billionaire mentor in classic dark grey business suit and glasses, sitting in an opulent mahogany executive office filled with stacks of cash, realistic cinematic lighting, 35mm lens --ar 9:16 --v 6",
                "sufijo_estilo_sugerido": "Cinematic 3D hybrid cartoon animation style, vibrant stylized anthropomorphic character integrated seamlessly into photorealistic cinematic business environment, dramatic warm volumetric lighting, Octane render 8k --ar 9:16 --v 6",
                "formato_guion": "Narración en voz en off continua sobre psicología de negocios y lecciones de vida protagonizada visualmente por avatar animado en escenas realistas",
                "texto_pantalla_ejemplo": tit_es or "Una verdad incómoda que pocos aceptan sobre el dinero y la familia",
                "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON MODELOS HÍBRIDOS (MIDJOURNEY/FLUX + VEO/KLING)",
                "score_replicabilidad": 95
            }
        elif es_pareja_ternura or es_animacion_3d:
            texto_pantalla_propuesto = tit_es if (tit_es and len(tit_es) < 70) else "POV: Los abrazos son más importantes que cualquier quehacer 🤍"
            analisis_gemini = {
                "estilo_visual_id": "pixar_3d",
                "estilo_visual_nombre": "3D Pixar / Render Cinematográfico Digital",
                "es_codigo_motion": False,
                "tipo_produccion": "ia_generativa",
                "tipo_nicho": "Micro-momentos de Parejas, Ternura y Humor Relatable (Animación 3D)",
                "personaje_1_desc": "Personaje Detectado (Referencia): Suricata hembra animada estilo 3D Pixar con flor rosada en la oreja y expresión coqueta",
                "personaje_1_prompt": "Character reference portrait of an adorable female meerkat in 3D stylized animation studio render, big glossy expressive eyes, soft fine cream and light grey fur, tiny pink flower behind her left ear, warm cinematic lighting, octane render, 8k --ar 9:16 --v 6",
                "personaje_sugerido_desc": "Personaje Sugerido (Marca Propia): Mascota Tierna con Chaleco Lavanda Artesanal o Lazo Aguamarina",
                "personaje_sugerido_prompt": "Character reference portrait of an adorable fluffy animal character in 3D stylized animation studio render, big emotive glossy eyes, soft warm cream and caramel fur, wearing a tiny handcrafted lavender knit vest, warm cozy studio lighting, octane render, 8k --ar 9:16 --v 6",
                "personaje_2_desc": "Suricata macho animado estilo 3D Pixar, pelaje castaño miel esponjoso, sonrisa tierna y mirada enamorada",
                "personaje_2_prompt": "Character reference portrait of a cute male meerkat in 3D stylized animation studio render, warm golden brown fluffy fur, big curious expressive eyes, animated playful affectionate expression, octane render, 8k --ar 9:16 --v 6",
                "sufijo_estilo_sugerido": "3D Pixar animation style render, cute and expressive character design, soft subsurface scattering, vibrant warm studio lighting, Unreal Engine 5 octane render, 8k --ar 9:16 --v 6",
                "formato_guion": "Micro-animación 3D gestual con Foley diegético y texto POV en pantalla (CERO voz en off)",
                "texto_pantalla_ejemplo": texto_pantalla_propuesto,
                "veredicto_replicabilidad": "TOTALMENTE COMPATIBLE CON MODELOS GENERATIVOS 3D (FLUX / MIDJOURNEY + VEO / KLING)",
                "score_replicabilidad": 96
            }

    # Si se detectó pixar_3d y no hay locución hablada, ajustar la descripción de audio a Foley diegético
    if not tiene_locucion and (analisis_gemini.get("estilo_visual_id") == "pixar_3d" or analisis_gemini.get("tipo_produccion") == "ia_generativa"):
        tipo_audio_desc = "Foley y Efectos Naturales Diegéticos (Pasos, abrazos, besos, cortes y suspiros sincronizados con la animación + Melodía cálida de fondo. Cero voz en off)"

    return {
        "ok": True,
        "duracion": duracion,
        "fotogramas": frames_b64,
        "tiene_locucion": tiene_locucion,
        "transcripcion": transcripcion,
        "tipo_audio_desc": tipo_audio_desc,
        "titulo_es": tit_es,
        "descripcion_es": desc_es,
        "uso_gemini": uso_gemini,
        "datos_diseccion": analisis_gemini
    }
