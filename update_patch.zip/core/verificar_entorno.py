# -*- coding: utf-8 -*-
"""
verificar_entorno.py
--------------------
Auditor y Reparador Automático del Entorno del Creador de Videos.
Se ejecuta antes de iniciar el panel para garantizar que el 100% de
las librerías de Python y binarios multimedia (FFmpeg) estén instalados,
configurados y listos para trabajar SIN intervención del usuario.
"""

import sys
import os
import subprocess
import shutil
import time
import warnings
from pathlib import Path

# Silenciar advertencias informativas externas (HF Hub, Hugging Face, deprecaciones)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
os.environ.setdefault("PYTHONWARNINGS", "ignore")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")

# Paquetes requeridos: (nombre_modulo_import, nombre_paquete_pip)
DEPENDENCIAS_REQUERIDAS = [
    ("PIL", "pillow>=9.5.0"),
    ("numpy", "numpy>=1.24.0"),
    ("cv2", "opencv-python>=4.8.0"),
    ("imageio_ffmpeg", "imageio-ffmpeg>=0.5.0"),
    ("faster_whisper", "faster-whisper>=1.0.0"),
    ("yt_dlp", "yt-dlp>=2024.0.0"),
    ("curl_cffi", "curl-cffi>=0.7.0"),
]

def verificar_y_reparar():
    faltantes = []
    for modulo, pkg in DEPENDENCIAS_REQUERIDAS:
        try:
            __import__(modulo)
        except ImportError:
            faltantes.append(pkg)

    # 1. Si faltan librerías de Python, auto-instalarlas inmediatamente
    if faltantes:
        print("=" * 68)
        print("   CREADOR DE VIDEOS  -  CONFIGURACION AUTOMATICA DE ENTORNO")
        print("=" * 68)
        print(f"[*] Se detectaron {len(faltantes)} componente(s) necesarios pendientes.")
        print("[*] Instalando y calibrando componentes en segundo plano...\n")

        # Asegurar pip actualizado
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "--quiet"], check=False)
        except Exception:
            pass

        # Verificar si hay repositorio de wheels local precargado
        wheels_dir = Path(__file__).resolve().parent.parent / "redist" / "wheels"
        base_cmd = [sys.executable, "-m", "pip", "install"]
        if wheels_dir.is_dir():
            base_cmd.extend(["--find-links", str(wheels_dir)])

        for pkg in faltantes:
            if sys.version_info >= (3, 13) and "faster-whisper" in pkg:
                print(f"  -> [AVISO] {pkg} requiere Python 3.11/3.12 en Windows (tu interprete es {sys.version_info.major}.{sys.version_info.minor}).")
                print("     Ejecuta con Python 3.11 desde la carpeta redist\\ para activar subtitulos.")
                continue
            print(f"  -> Instalando: {pkg}...")
            try:
                subprocess.run(
                    base_cmd + [pkg, "--no-warn-script-location"],
                    check=True
                )
                print(f"     [OK] {pkg} instalado con exito.")
            except Exception as e:
                print(f"     [ERROR] Falló instalación de {pkg}: {e}")

        print("\n[*] Verificación de librerías de Python completada.")
        print("=" * 68)

    # 2. Verificar y garantizar motor multimedia FFmpeg
    try:
        from ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe
        ff = detectar_ffmpeg()
        if not ff or ff == "ffmpeg" and not shutil.which("ffmpeg"):
            print("[*] Configurando binario de FFmpeg portátil...")
            subprocess.run([sys.executable, "-m", "pip", "install", "imageio-ffmpeg", "--quiet"], check=False)
            from ffmpeg_resolver import detectar_ffmpeg
            ff = detectar_ffmpeg()

        # Probar ejecución real de FFmpeg para certificar que el subproceso funciona al 100%
        res = subprocess.run([ff, "-version"], capture_output=True, text=True, errors="replace")
        if res.returncode != 0:
            print(f"[AVISO] FFmpeg respondió con código {res.returncode}")
    except Exception as err:
        print(f"[!] Aviso al auditar FFmpeg: {err}")

    # 3. Calibración inteligente de Hardware (Auto-Tuning)
    try:
        from hardware_tuner import calibrar_hardware
        hw = calibrar_hardware(forzar=False)
        print(f"[*] Perfil de Hardware: {hw.get('titulo_perfil', 'Estándar')}")
    except Exception as e:
        pass

    return True

if __name__ == "__main__":
    verificar_y_reparar()
