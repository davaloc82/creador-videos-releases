"""
Detector y Resolutor Universal de FFmpeg y FFprobe.
Busca binarios en PATH, WinGet, rutas locales o instala automáticamente imageio-ffmpeg portátil.
Garantiza que ninguna máquina cliente falle con FileNotFoundError [WinError 2].
"""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

_CACHED_FFMPEG = None
_CACHED_FFPROBE = None

def detectar_ffmpeg():
    global _CACHED_FFMPEG
    if _CACHED_FFMPEG and os.path.isfile(_CACHED_FFMPEG):
        return _CACHED_FFMPEG

    # 1. Rutas locales de la aplicación (Prioridad absoluta para portabilidad)
    aqui = Path(__file__).resolve().parent
    candidatos_directos = [
        aqui / "bin" / "ffmpeg.exe",
        aqui / "ffmpeg.exe",
        aqui.parent / "bin" / "ffmpeg.exe",
        aqui.parent / "ffmpeg.exe",
        Path("C:/ffmpeg/bin/ffmpeg.exe"),
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "ffmpeg" / "bin" / "ffmpeg.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "ffmpeg" / "bin" / "ffmpeg.exe",
    ]
    for c in candidatos_directos:
        if c.is_file():
            _CACHED_FFMPEG = str(c)
            return str(c)

    # 2. PATH del sistema
    p = shutil.which("ffmpeg")
    if p and os.path.isfile(p):
        _CACHED_FFMPEG = p
        return p

    # 3. Buscar en paquetes de WinGet (Gyan.FFmpeg)
    local_appdata = os.environ.get("LOCALAPPDATA", "")
    if local_appdata:
        winget_pkgs = Path(local_appdata) / "Microsoft" / "WinGet" / "Packages"
        if winget_pkgs.is_dir():
            for f in winget_pkgs.glob("**/ffmpeg.exe"):
                if f.is_file():
                    _CACHED_FFMPEG = str(f)
                    return str(f)

    # 4. imageio_ffmpeg ya instalado
    try:
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and os.path.isfile(p):
            _CACHED_FFMPEG = p
            return p
    except Exception:
        pass

    # 5. Auto-instalar imageio-ffmpeg via pip si no existe ningún FFmpeg
    try:
        print("[*] Configurando componente multimedia FFmpeg automáticamente...", flush=True)
        kw_pip = {"check": True}
        if sys.platform.startswith("win"): kw_pip["creationflags"] = 0x08000000
        subprocess.run([sys.executable, "-m", "pip", "install", "imageio-ffmpeg", "--quiet"], **kw_pip)
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and os.path.isfile(p):
            _CACHED_FFMPEG = p
            return p
    except Exception as e:
        print(f"[!] No se pudo auto-instalar imageio-ffmpeg: {e}", flush=True)

    # Fallback por defecto si todo falla
    return "ffmpeg"


def detectar_ffprobe():
    global _CACHED_FFPROBE
    if _CACHED_FFPROBE and os.path.isfile(_CACHED_FFPROBE):
        return _CACHED_FFPROBE

    # 1. Buscar junto a ffmpeg si este fue encontrado
    ff = detectar_ffmpeg()
    if ff and ff != "ffmpeg" and os.path.isfile(ff):
        cand = Path(ff).parent / "ffprobe.exe"
        if cand.is_file():
            _CACHED_FFPROBE = str(cand)
            return str(cand)

    # 2. PATH del sistema
    p = shutil.which("ffprobe")
    if p and os.path.isfile(p):
        _CACHED_FFPROBE = p
        return p

    local_appdata = os.environ.get("LOCALAPPDATA", "")
    if local_appdata:
        winget_pkgs = Path(local_appdata) / "Microsoft" / "WinGet" / "Packages"
        if winget_pkgs.is_dir():
            for f in winget_pkgs.glob("**/ffprobe.exe"):
                if f.is_file():
                    _CACHED_FFPROBE = str(f)
                    return str(f)

    return None


def obtener_duracion(ruta_archivo):
    """
    Obtiene la duración en segundos de un audio o video.
    Usa ffprobe si está disponible; si no, usa ffmpeg -i de respaldo.
    """
    probe = detectar_ffprobe()
    if probe:
        try:
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" and hasattr(subprocess, "CREATE_NO_WINDOW") else 0
            r = subprocess.run(
                [probe, "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(ruta_archivo)],
                capture_output=True, text=True, check=True, creationflags=flags
            )
            val = float(r.stdout.strip())
            if val > 0:
                return val
        except Exception:
            pass

    # Respaldo 100% confiable usando ffmpeg directamente
    ff = detectar_ffmpeg()
    try:
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" and hasattr(subprocess, "CREATE_NO_WINDOW") else 0
        r = subprocess.run([ff, "-hide_banner", "-i", str(ruta_archivo)],
                           capture_output=True, text=True, errors="replace", creationflags=flags)
        m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr)
        if m:
            h, mins, s = m.groups()
            return int(h) * 3600 + int(mins) * 60 + float(s)
    except Exception:
        pass

    return None


def ajustar_comando_ffmpeg(cmd):
    """Reemplaza 'ffmpeg' o 'ffprobe' en cmd[0] por la ruta absoluta resuelta."""
    if not cmd or not isinstance(cmd, list):
        return cmd
    copia = list(cmd)
    primer = str(copia[0]).lower()
    if primer == "ffmpeg" or primer.endswith("ffmpeg.exe"):
        copia[0] = detectar_ffmpeg()
    elif primer == "ffprobe" or primer.endswith("ffprobe.exe"):
        p = detectar_ffprobe()
        if p:
            copia[0] = p
    return copia


def obtener_encoder_video():
    """Retorna (encoder, preset) óptimo según el hardware del usuario."""
    try:
        from hardware_tuner import obtener_info_hardware
        hw = obtener_info_hardware()
        return hw.get("encoder_video", "libx264"), hw.get("preset_video", "veryfast")
    except Exception:
        return "libx264", "veryfast"


def aplicar_aceleracion_hardware(cmd):
    """
    Si el comando usa libx264 y hay GPU dedicada disponible (NVENC, AMF, QSV),
    ajusta el comando para renderizar con aceleración de hardware.
    """
    try:
        from hardware_tuner import aplicar_aceleracion_a_comando
        return aplicar_aceleracion_a_comando(cmd)
    except Exception:
        return cmd
