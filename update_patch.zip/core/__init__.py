# -*- coding: utf-8 -*-
"""
core - Paquete central de utilidades, análisis de nichos, métricas y entorno.
"""
from pathlib import Path
import sys

_CORE_DIR = Path(__file__).resolve().parent
if str(_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(_CORE_DIR))

