import sys
from pathlib import Path

BASE = Path(r"c:\Users\Usuario\Documents\DAVID\Generador_Contenido")
UI_DIR = BASE / "ui"
OUTPUT = BASE / "panel_template.html"

def build():
    # 1. Leer shell base
    shell_file = UI_DIR / "shell.html"
    if not shell_file.is_file():
        print("[ERROR] No se encontró ui/shell.html")
        return False

    shell = shell_file.read_text(encoding="utf-8")

    # 2. Leer CSS
    css_file = UI_DIR / "css" / "styles.css"
    css = css_file.read_text(encoding="utf-8") if css_file.is_file() else ""

    # 3. Leer módulos JS en orden estricto de dependencias
    js_modules = [
        UI_DIR / "core" / "app.js",
        UI_DIR / "core" / "router.js",
        UI_DIR / "components" / "modal_flowbatch.js",
        UI_DIR / "components" / "modal_guiones.js",
        UI_DIR / "views" / "ecos" / "ecos.js",
        UI_DIR / "views" / "psico" / "psico.js",
        UI_DIR / "views" / "herramientas" / "entretenimiento.js",
        UI_DIR / "views" / "herramientas" / "herramientas.js",
        UI_DIR / "views" / "herramientas" / "descargar.js",
        UI_DIR / "views" / "dashboard" / "dashboard.js",
        UI_DIR / "views" / "replicador" / "analizador.js",
        UI_DIR / "views" / "replicador" / "replicador.js",
        UI_DIR / "views" / "herramientas" / "licencias.js",
        UI_DIR / "views" / "flowbatch" / "flowbatch.js"
    ]

    all_js = []
    for mod in js_modules:
        if not mod.is_file():
            print(f"[ERROR] Módulo no encontrado: {mod}")
            return False
        all_js.append(f"/* === MÓDULO: {mod.relative_to(UI_DIR)} === */\n" + mod.read_text(encoding="utf-8"))

    bundled_js = "\n\n".join(all_js)

    # 4. Generar el HTML unificado para el servidor en ejecución
    # Reemplazar el link a styles.css con el CSS inline si se usa en standalone
    # y los scripts modulares con el bundle JS
    built_html = shell

    # Inyectar CSS
    link_css = '<link rel="stylesheet" href="/ui/css/styles.css">'
    if link_css in built_html:
        built_html = built_html.replace(link_css, f"<style>\n{css}\n</style>")

    # Inyectar JS
    script_tags_marker = "<!-- NEXOR Core Modular -->"
    end_marker = "<!-- Mini-widget Flotante Segundo Plano FlowBatch Pro -->"
    
    start_pos = built_html.find(script_tags_marker)
    end_pos = built_html.find(end_marker)

    if start_pos != -1 and end_pos != -1:
        built_html = built_html[:start_pos] + f"<script>\n{bundled_js}\n</script>\n\n" + built_html[end_pos:]
    else:
        print("[WARNING] No se encontraron marcadores exactos en shell.html, inyectando antes de </body>")
        built_html = built_html.replace("</body>", f"<script>\n{bundled_js}\n</script>\n</body>")

    OUTPUT.write_text(built_html, encoding="utf-8")
    print(f"✓ Compilación exitosa: {OUTPUT.name} ({len(built_html)} bytes, {len(built_html.splitlines())} líneas)")
    return True

if __name__ == "__main__":
    build()
