# -*- coding: utf-8 -*-
"""
publicar_actualizacion.py
--------------------------
Herramienta de Lanzamiento para David.
Prepara y empaqueta automáticamente una nueva versión para distribuir a todos tus clientes.

Uso:
  python publicar_actualizacion.py 2.5.0 "Nuevas funciones y mejoras"
"""

import sys
import json
import zipfile
import os
import shutil
import subprocess
from pathlib import Path
from datetime import datetime

AQUI = Path(__file__).resolve().parent
ARCHIVO_VERSION = AQUI / "version.json"
PATCH_OUTPUT = AQUI / "update_patch.zip"
REPO_DIR = Path(r"c:\Users\Usuario\Documents\DAVID\_repo_releases")

exclude_dirs = {"__pycache__", ".git", ".idea", ".vscode", "PROYECTOS_VIDEO", "_repo_releases"}
exclude_files = {
    ".DS_Store", "Thumbs.db",
    "licencia.lic", "DATOS_DE_TU_LICENCIA.txt",
    "licencias_registradas.json", "licencias_emitidas.json",
    "ai33_config.txt", "nichos_usuario.json",
    "update_patch.zip", "Creador_de_Videos_Universal.zip"
}

def publicar():
    nueva_ver = sys.argv[1].strip().replace("v", "") if len(sys.argv) > 1 else "2.4.0"
    novedades = sys.argv[2] if len(sys.argv) > 2 else "Lanzamiento oficial v2.4.0 con soporte multicanal y auto-actualizaciones."

    print("=" * 65)
    print(f"  PUBLICADOR DE ACTUALIZACIONES  -  VERSIÓN v{nueva_ver}")
    print("=" * 65)

    # 1. Cargar y actualizar version.json
    data_ver = {
        "version": nueva_ver,
        "fecha": datetime.now().strftime("%Y-%m-%d"),
        "canal": "produccion",
        "repositorio": "davaloc82/creador-videos-releases",
        "url_servidor_versiones": "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/version.json",
        "download_url": "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/update_patch.zip",
        "novedades": novedades
    }

    ARCHIVO_VERSION.write_text(json.dumps(data_ver, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[*] version.json actualizado a v{nueva_ver}")

    # 2. Empaquetar update_patch.zip
    print(f"[*] Empaquetando {PATCH_OUTPUT.name}...")
    archivos_empaquetados = 0

    with zipfile.ZipFile(PATCH_OUTPUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(AQUI):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for f in files:
                if f in exclude_files or f.endswith((".pyc", ".zip", ".log")):
                    continue
                f_path = Path(root) / f
                if f == "licencia.py" and (AQUI / "licencia_dev_source.py").is_file():
                    zf.write(AQUI / "licencia_dev_source.py", "licencia.py")
                else:
                    rel = f_path.relative_to(AQUI)
                    zf.write(f_path, rel)
                archivos_empaquetados += 1

    size_mb = PATCH_OUTPUT.stat().st_size / (1024 * 1024)
    print(f"[OK] Paquete {PATCH_OUTPUT.name} creado ({archivos_empaquetados} archivos, {size_mb:.2f} MB).")

    # 3. Copiar a _repo_releases
    REPO_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ARCHIVO_VERSION, REPO_DIR / "version.json")
    shutil.copy2(PATCH_OUTPUT, REPO_DIR / "update_patch.zip")

    readme_content = f"""# Creador de Videos (Universal) - Canal de Actualizaciones Oficiales

Repositorio oficial de distribución de parches y versiones para clientes.

- **Última versión:** v{nueva_ver}
- **Fecha:** {datetime.now().strftime("%Y-%m-%d")}
- **Notas de lanzamiento:** {novedades}

## Archivos de distribución:
- `version.json`: Manifiesto de versión para detección automática.
- `update_patch.zip`: Paquete con los archivos del motor del sistema.
"""
    (REPO_DIR / "README.md").write_text(readme_content, encoding="utf-8")

    # 4. Commit en git local
    try:
        subprocess.run(["git", "config", "user.name", "David"], cwd=REPO_DIR, check=True)
        subprocess.run(["git", "config", "user.email", "davaloc82@gmail.com"], cwd=REPO_DIR, check=True)
        subprocess.run(["git", "add", "version.json", "update_patch.zip", "README.md"], cwd=REPO_DIR, check=True)
        subprocess.run(["git", "commit", "-m", f"Release v{nueva_ver}: {novedades}"], cwd=REPO_DIR, capture_output=True)
    except Exception:
        pass

    print("\n" + "=" * 65)
    print(f"  [COMPLETADO] ARCHIVOS PREPARADOS EN: {REPO_DIR.name}")
    print("=" * 65)
    print("Para enviar la actualización a GitHub:")
    print("  -> Haz doble clic en: _repo_releases\\subir_a_github.bat")
    print("=" * 65)

if __name__ == "__main__":
    publicar()
