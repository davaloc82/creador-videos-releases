; ==============================================================================
; SCRIPT MAESTRO DE INNO SETUP - NEXOR
; Sistema Integrado de Replicación de Canales
; Genera un instalador profesional 'Setup.exe' para Windows con:
; 1. Cero configuraciones manuales por parte del cliente.
; 2. Instalación en LocalAppData (No requiere permisos de Administrador).
; 3. Auto-tuning de Hardware (Modo Gamer vs Modo Estándar).
; 4. Instalador silencioso de Python 3.11 integrado si el cliente no lo tiene.
; 5. Binarios de FFmpeg/FFprobe incluidos (Cero descargas externas).
; 6. Icono oficial NEXOR de alta resolución en Escritorio e Instalador.
; ==============================================================================

#define MyAppName "NEXOR"
#define MyAppVersion "2.5.1"
#define MyAppPublisher "David"
#define MyAppURL "https://github.com/davaloc82"
#define MyAppExeName "iniciar_panel_silencioso.vbs"

[Setup]
AppId={{9B7E3E8C-4C7A-4E38-B7D4-95C5E6E92B10}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}

; Icono del instalador ejecutable
SetupIconFile=..\nexor.ico

; Instalación por usuario: NO pide contraseña de admin de Windows
PrivilegesRequired=lowest
DefaultDirName={localappdata}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes

; Salida del instalador compilado
OutputDir=..\dist_instalador
OutputBaseFilename=Instalador_NEXOR_v{#MyAppVersion}_Setup
Compression=lzma2/fast
SolidCompression=no
WizardStyle=modern

; Permite desinstalar limpiamente con icono oficial
UninstallDisplayIcon={app}\nexor.ico
UninstallDisplayName={#MyAppName} - Sistema Integrado de Replicación de Canales

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
; 1. Archivos principales del sistema (Se excluyen secretos de admin, logs y backups)
Source: "..\\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; \
    Excludes: "admin_licencias,admin_licencias\\*,_backup,_backup\\*,dist_instalador,dist_instalador\\*,scratch,scratch\\*,.git,.git\\*,.vscode,.vscode\\*,.idea,.idea\\*,_repo_releases,_repo_releases\\*,PROYECTOS_VIDEO,PROYECTOS_VIDEO\\*,*.pyc,__pycache__,__pycache__\\*,*.log,*.tmp,*respaldo*,update_patch.zip,Creador_de_Videos_Universal.zip,licencias_emitidas.json,licencias_registradas.json,licencia_dev.py,licencia_dev_source.py,compilar_licencia.py,generar_licencia_admin.py,generar_codigo_cliente.py,licencia.lic,DATOS_DE_TU_LICENCIA.txt,ai33_config.txt,nichos_usuario.json,config_gemini.json,gemini_config.json,cuentas_redes.json,historial_analisis_nichos.json,hardware_config.json,.entorno_listo"

[Icons]
; Acceso directo en el Escritorio con Icono Oficial NEXOR (Sin ventana negra)
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\nexor.ico"; Tasks: desktopicon; Comment: "Iniciar NEXOR - Sistema Integrado de Replicación de Canales"

; Menú Inicio de Windows
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\nexor.ico"; Comment: "Iniciar NEXOR"
Name: "{group}\Detener Servidor NEXOR"; Filename: "{app}\detener_panel.bat"; Comment: "Apagar el servidor local"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"

[Code]
function PythonNoInstalado(): Boolean;
var
  ResultCode: Integer;
begin
  // 1. Rutas conocidas
  if FileExists(ExpandConstant('{localappdata}\Programs\Python\Python311\python.exe')) or
     FileExists(ExpandConstant('{localappdata}\Programs\Python\Python312\python.exe')) or
     FileExists(ExpandConstant('{localappdata}\Programs\Python\Python310\python.exe')) or
     FileExists('C:\Python311\python.exe') or
     FileExists('C:\Python312\python.exe') then
  begin
    Result := False;
    Exit;
  end;

  // 2. Probar si un comando real de Python responde (evita el falso alias de Microsoft Store en WindowsApps)
  if Exec('cmd.exe', '/c python -c "import sys"', '', SW_HIDE, ewWaitUntilTerminated, ResultCode) and (ResultCode = 0) then
  begin
    Result := False;
    Exit;
  end;

  // No hay interprete real instalado -> Proceder a instalar
  Result := True;
end;

[Run]
; 1. Si no hay Python en la PC, instalar Python 3.11 de forma silenciosa sin pedir permisos
Filename: "{app}\redist\python-3.11.9-amd64.exe"; Parameters: "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 SimpleInstall=1"; Check: PythonNoInstalado; Flags: waituntilterminated

; 2. Iniciar NEXOR de inmediato al terminar (iniciar_panel_silencioso.vbs audita librerías y arranca el panel sin consola)
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: shellexec postinstall nowait skipifsilent
