# -*- coding: utf-8 -*-
"""
Transcriptor por LOTE con faster-whisper: carga el modelo UNA sola vez y procesa
varios archivos seguidos (mucho mas rapido que llamar transcribir.py por cada uno).

Si se pide --combinar, junta todos los guiones en un unico .txt (para analizar la
estructura del contenido) y NO deja archivos sueltos por video. Si NO se combina,
deja <archivo>.srt y <archivo>.txt junto a cada video.

USO:
  python transcribir_lote.py --idioma es --modelo small a.mp4 b.mp4 ...
  python transcribir_lote.py --idioma auto --combinar "C:\\...\\_GUIONES.txt" a.mp4 b.mp4

FORMATO del combinado: antes de cada guion la linea  "GUION: <nombre>"  y una
linea en blanco; entre un guion y el siguiente, una linea en blanco de separacion.
"""
import argparse, os, subprocess, tempfile, time


def fmt(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = int(t % 60); ms = int((t - int(t)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def transcribir_uno(model, src, idioma, escribir_sueltos=True):
    """Transcribe UN archivo ya con el modelo cargado. Devuelve (texto, idioma).
    Si escribir_sueltos, deja <archivo>.srt y <archivo>.txt junto al video; si no,
    solo devuelve el texto (para el combinado _GUIONES.txt)."""
    base = os.path.splitext(src)[0]
    tmp = os.path.join(tempfile.gettempdir(), "fw_lote.wav")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src,
                    "-vn", "-ar", "16000", "-ac", "1", tmp], check=True)
    lang = None if str(idioma).strip().lower() in ("", "auto") else idioma
    # SIN vad_filter: el filtro de voz (VAD) destroza el audio cantado y a veces
    # el hablado (p.ej. "reina del cisne" -> "reina del cisne que ve son los
    # palomas en raudobo"). Whisper solo, con beam 5, transcribe mucho mejor.
    segments, info = model.transcribe(tmp, language=lang, beam_size=5)
    lineas, n = [], 0
    if escribir_sueltos:
        srt_path, txt_path = base + ".srt", base + ".txt"
        with open(srt_path, "w", encoding="utf-8") as fs, open(txt_path, "w", encoding="utf-8") as ft:
            for seg in segments:
                n += 1
                txt = seg.text.strip()
                fs.write(f"{n}\n{fmt(seg.start)} --> {fmt(seg.end)}\n{txt}\n\n")
                ft.write(txt + "\n")
                lineas.append(txt)
    else:
        for seg in segments:
            lineas.append(seg.text.strip())
    return "\n".join(lineas), (info.language if lang is None else lang)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("archivos", nargs="+")
    ap.add_argument("--modelo", default="small", help="tiny|base|small|medium|large-v3")
    ap.add_argument("--idioma", default="es", help="zh, ko, en, es... o 'auto'")
    ap.add_argument("--combinar", default=None,
                    help="ruta de un .txt unico donde juntar todos los guiones")
    args = ap.parse_args()

    from faster_whisper import WhisperModel
    print(f">> cargando modelo '{args.modelo}' (la 1a vez lo descarga)...")
    model = WhisperModel(args.modelo, device="cpu", compute_type="int8")

    total = len(args.archivos)
    # Al combinar: NO se dejan .srt/.txt sueltos, solo el _GUIONES.txt unico.
    sueltos = not args.combinar
    combinados, ok = [], 0
    for i, src in enumerate(args.archivos, 1):
        src = os.path.abspath(src)
        nombre = os.path.splitext(os.path.basename(src))[0]
        print(f">> [{i}/{total}] {nombre} ...")
        try:
            t0 = time.time()
            texto, lang = transcribir_uno(model, src, args.idioma, sueltos)
            print(f"   OK {nombre} ({lang}) en {time.time()-t0:.0f}s")
            combinados.append((nombre, texto))
            ok += 1
        except Exception as e:
            print(f"   ERROR en {nombre}: {e}")

    if args.combinar and combinados:
        partes = [f"GUION: {nombre}\n\n{texto}" for nombre, texto in combinados]
        contenido = "\n\n\n".join(partes) + "\n"
        with open(args.combinar, "w", encoding="utf-8") as f:
            f.write(contenido)
        print(f">> COMBINADO: {args.combinar}  ({ok}/{total} guiones)")

    print(f">> LISTO: {ok}/{total} transcritos")


if __name__ == "__main__":
    main()
