@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

set "AQUI=%~dp0"
set "PYTHON=python"

echo ===================================================================
echo     EXTRACTOR DE CLIPS CRUDOS Y LIMPIOS PARA CAPCUT (FAMOSOS)
echo ===================================================================
echo.

if "%~1"=="" (
    echo Puedes arrastrar una carpeta de proyecto sobre este archivo .bat
    echo o escribir el nombre de la carpeta (ej. "Aprendiz de brujo" o "peliculas").
    echo.
    set /p CARPETA="Nombre o ruta completa del proyecto: "
) else (
    set "CARPETA=%~1"
)

rem Quitar comillas si las hay
set "CARPETA=%CARPETA:"=%"

if not exist "!CARPETA!" (
    if exist "%USERPROFILE%\Downloads\FAMOSOS\!CARPETA!" (
        set "CARPETA=%USERPROFILE%\Downloads\FAMOSOS\!CARPETA!"
    )
)

if not exist "!CARPETA!" (
    echo [ERROR] No se encontro la carpeta especificada: "!CARPETA!"
    echo.
    pause
    exit /b 1
)

echo.
echo -> Procesando proyecto: "!CARPETA!"
echo -> Extrayendo tomas crudas de 2.5s a 3.5s sincronizadas con guion...
echo.

if exist "%AQUI%famosos\extraer_clips_famosos.py" (
    "%PYTHON%" "%AQUI%famosos\extraer_clips_famosos.py" "!CARPETA!"
) else (
    "%PYTHON%" "%AQUI%..\famosos\extraer_clips_famosos.py" "!CARPETA!"
)

echo.
echo ===================================================================
echo   Extraccion finalizada. Revisa la subcarpeta "clips_capcut"
echo ===================================================================
pause
