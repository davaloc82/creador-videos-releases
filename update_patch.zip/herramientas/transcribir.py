# -*- coding: utf-8 -*-
"""
Transcriptor local con faster-whisper (gratis, sin limites, sin internet tras bajar modelo).

USO:
  python transcribir.py "video.mp4"                    -> transcribe todo, modelo small, chino
  python transcribir.py "video.mp4" --modelo medium    -> mas preciso, mas lento
  python transcribir.py "video.mp4" --idioma ko        -> otro idioma (ko, en, es, zh...)
  python transcribir.py "video.mp4" --hasta 300        -> solo los primeros 300 segundos

SALIDA: <video>.srt  y  <video>.txt  junto al video.
"""
import argparse, os, sys, subprocess, tempfile, time

def fmt(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = int(t % 60); ms = int((t - int(t)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("entrada")
    ap.add_argument("--modelo", default="small", help="tiny|base|small|medium|large-v3")
    ap.add_argument("--idioma", default="zh", help="zh, ko, en, es... o 'auto' para detectar")
    ap.add_argument("--hasta", type=float, default=None, help="solo los primeros N segundos")
    args = ap.parse_args()

    src = os.path.abspath(args.entrada)
    base = os.path.splitext(src)[0]

    # 1) extraer audio mono 16k
    tmp = os.path.join(tempfile.gettempdir(), "fw_audio.wav")
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", src]
    if args.hasta:
        cmd += ["-t", str(args.hasta)]
    cmd += ["-vn", "-ar", "16000", "-ac", "1", tmp]
    print(">> extrayendo audio...")
    subprocess.run(cmd, check=True)

    # 2) transcribir
    from faster_whisper import WhisperModel
    print(f">> cargando modelo '{args.modelo}' (la 1a vez lo descarga)...")
    model = WhisperModel(args.modelo, device="cpu", compute_type="int8")

    # "auto" (o vacio) -> language=None: faster-whisper detecta el idioma solo
    lang = None if args.idioma.strip().lower() in ("", "auto") else args.idioma
    print(f">> transcribiendo (idioma={lang or 'auto'})...")
    t0 = time.time()
    # SIN vad_filter: el filtro de voz (VAD) degrada mucho la transcripcion
    # (sobre todo audio cantado). Whisper solo, con beam 5, es bastante mas fiel.
    segments, info = model.transcribe(tmp, language=lang, beam_size=5)
    if lang is None:
        print(f">> idioma detectado: {info.language} ({info.language_probability:.0%})")

    srt_path, txt_path = base + ".srt", base + ".txt"
    n = 0
    with open(srt_path, "w", encoding="utf-8") as fs, open(txt_path, "w", encoding="utf-8") as ft:
        for seg in segments:
            n += 1
            fs.write(f"{n}\n{fmt(seg.start)} --> {fmt(seg.end)}\n{seg.text.strip()}\n\n")
            ft.write(seg.text.strip() + "\n")
            if n % 20 == 0:
                print(f"   ...{n} segmentos ({seg.end:.0f}s de audio)")

    dur = time.time() - t0
    print(f">> LISTO: {n} segmentos en {dur:.0f}s")
    print(f"   SRT: {srt_path}")
    print(f"   TXT: {txt_path}")

if __name__ == "__main__":
    main()
