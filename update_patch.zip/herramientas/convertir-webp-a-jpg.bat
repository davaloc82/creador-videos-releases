@echo off
rem = """
chcp 65001 >nul
title Convertidor de WEBP a JPG

where python >nul 2>&1
if not errorlevel 1 goto :run_python

echo [AVISO] Python no detectado en el sistema. Renombrando extensiones directamente...
set /a cont=0
for /r %%F in (*.webp *.WEBP) do (
    if exist "%%F" (
        ren "%%F" "%%~nF.jpg"
        set /a cont+=1
    )
)
echo Listo: Se renombraron archivos a .jpg
pause
exit /b 0

:run_python
python -x "%~f0" %*
if errorlevel 1 pause
exit /b %errorlevel%
rem """
import sys
import os
import subprocess

def instalar_pillow_si_falta():
    try:
        from PIL import Image
        return True
    except ImportError:
        print("[*] Instalando modulo Pillow para conversion de imagenes...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "pillow"], check=True)
            return True
        except Exception as e:
            print(f"[!] Error al instalar Pillow: {e}")
            return False

def procesar_imagen_webp(ruta_webp):
    from PIL import Image
    try:
        base_sin_ext = os.path.splitext(ruta_webp)[0]
        ruta_jpg = base_sin_ext + ".jpg"

        with Image.open(ruta_webp) as img:
            # Manejar transparencias limpiamente sobre fondo blanco
            if img.mode in ("RGBA", "LA", "P"):
                fondo_blanco = Image.new("RGB", img.size, (255, 255, 255))
                img_rgba = img.convert("RGBA")
                canal_alfa = img_rgba.split()[-1]
                fondo_blanco.paste(img_rgba, mask=canal_alfa)
                img_final = fondo_blanco
            else:
                img_final = img.convert("RGB")

            # Guardar en formato JPG real con maxima calidad (95%)
            img_final.save(ruta_jpg, "JPEG", quality=95, subsampling=0)

        # Eliminar el .webp original solo tras guardar con exito
        try:
            os.remove(ruta_webp)
        except Exception:
            pass

        return True, ruta_jpg, None
    except Exception as err:
        return False, None, str(err)

def main():
    print("=" * 68)
    print("        CONVERTIDOR PROFESIONAL DE IMAGENES: WEBP a JPG")
    print("=" * 68)

    tiene_pillow = instalar_pillow_si_falta()
    if not tiene_pillow:
        print("[!] No se pudo cargar Pillow. Renombrando extensiones...")

    # Determinar rutas a procesar (argumentos arrastrados o carpeta actual)
    rutas_objetivo = []
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            rutas_objetivo.append(os.path.abspath(arg))
    else:
        # Por defecto procesa la carpeta donde esta el script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        rutas_objetivo.append(script_dir)

    # Recolectar todos los archivos .webp
    archivos_webp = []
    for obj in rutas_objetivo:
        if os.path.isfile(obj):
            if obj.lower().endswith(".webp"):
                archivos_webp.append(obj)
        elif os.path.isdir(obj):
            for root, dirs, files in os.walk(obj):
                for f in sorted(files):
                    if f.lower().endswith(".webp"):
                        archivos_webp.append(os.path.join(root, f))

    if not archivos_webp:
        print("\nNo se encontraron archivos .webp en la(s) carpeta(s):")
        for r in rutas_objetivo:
            print(f" -> {r}")
        print("\nConsejo: Copia este archivo .bat dentro de la carpeta donde estan tus")
        print("imagenes .webp y haz doble clic sobre el, o arrastra la carpeta al .bat.")
        input("\nPresiona Enter para salir...")
        return

    print(f"\nSe encontraron {len(archivos_webp)} archivo(s) .webp para convertir:\n")
    exitosos = 0
    fallidos = 0

    for idx, p in enumerate(archivos_webp, 1):
        nombre_orig = os.path.basename(p)
        dir_padre = os.path.dirname(p)
        nombre_carpeta = os.path.basename(dir_padre) or dir_padre

        if tiene_pillow:
            ok, out_path, err = procesar_imagen_webp(p)
            if ok:
                nombre_nuevo = os.path.basename(out_path)
                print(f"  [{idx}/{len(archivos_webp)}] [OK] [{nombre_carpeta}] {nombre_orig} -> {nombre_nuevo}")
                exitosos += 1
            else:
                print(f"  [{idx}/{len(archivos_webp)}] [ERROR] {nombre_orig}: {err}")
                fallidos += 1
        else:
            # Fallback renombrado directo
            try:
                base = os.path.splitext(p)[0]
                out_path = base + ".jpg"
                os.rename(p, out_path)
                print(f"  [{idx}/{len(archivos_webp)}] [RENOMBRADO] {nombre_orig} -> {os.path.basename(out_path)}")
                exitosos += 1
            except Exception as e:
                print(f"  [{idx}/{len(archivos_webp)}] [ERROR] {nombre_orig}: {e}")
                fallidos += 1

    print("\n" + "=" * 68)
    print(f"  RESULTADO FINAL:")
    print(f"  Archivos convertidos a JPG con exito: {exitosos}")
    if fallidos > 0:
        print(f"  Archivos con errores: {fallidos}")
    print("=" * 68)
    try:
        input("\nPresiona Enter para cerrar...")
    except EOFError:
        pass

if __name__ == "__main__":
    main()
