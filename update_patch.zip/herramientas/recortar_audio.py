# -*- coding: utf-8 -*-
"""
recortar_audio.py  —  Limpia respiros y recorta silencios de un audio (voz)
==================================================================================
Idea: se genera la voz (TTS) -> se limpia aqui -> se transcribe el audio YA limpio
(con tiempos) -> esos tiempos van a la skill de prompts. Asi los clips nacen adaptados
y NO hay que ajustar nada en edicion.

No cambia la voz (no acelera ni cambia el tono). Hace DOS cosas, en este orden:

  1) RESPIROS: detecta esos suspiros / tomas de aire entre palabras (sonido tenue
     y "ruidoso", sin tono) y los SUSTITUYE por silencio del MISMO largo (no los
     borra). Asi no se pegan las palabras: donde habia un respiro queda un huequito
     de silencio en su lugar.
  2) SILENCIOS: sobre el audio ya sin respiros, ACORTA los silencios largos dejando
     una pausa fija. Cada nicho conserva mas o menos pausa segun su ritmo. Como el
     respiro quedo convertido en silencio, este paso tambien lo acorta a la pausa.

PRESETS (la diferencia clave es cuanta pausa se deja = --cap):
  finanzas  : videos largos, con descansos      -> silencios>0.9s se dejan en 0.5s
  ecos      : shorts reflexivos, cortes medios   -> silencios>0.7s se dejan en 0.4s
  famosos   : informativo, corrido y claro       -> silencios>0.35s se dejan en 0.15s
  peliculas : recap agil                          -> silencios>0.4s se dejan en 0.18s
  suave/medio/fuerte : intensidades genericas si no encaja un nicho

Uso:
  python recortar_audio.py "voz.mp3" --nicho finanzas
  python recortar_audio.py "voz.mp3" --nicho famosos --bordes
  python recortar_audio.py "voz.mp3" --nicho ecos --no-respiros     (solo silencios)
  python recortar_audio.py "voz.mp3" --min 0.8 --cap 0.4            (manual)

Salida: <nombre>_recortado.mp3  (o --out). Imprime cuanto se recorto.
"""
import os, sys, subprocess, wave, argparse
import numpy as np

SR = 44100

PRESETS = {
    #  nicho    : (min_silencio, pausa_que_queda)
    "mapas"    : (0.45, 0.20),
    "finanzas" : (0.90, 0.50),
    "reflexion": (0.70, 0.40),
    "ecos"     : (0.70, 0.40),
    "famosos"  : (0.35, 0.15),
    "peliculas": (0.40, 0.18),
    "suave"    : (1.00, 0.60),
    "medio"    : (0.70, 0.35),
    "fuerte"   : (0.35, 0.15),
}

# Ventana de analisis (20 ms) con salto de 10 ms: fina para ubicar respiros/silencios.
VENTANA = int(SR * 0.020)
SALTO   = int(SR * 0.010)


def run(args):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        sys.stderr.write(p.stderr.decode("utf-8", "ignore")[-1200:]); raise SystemExit("ffmpeg fallo")
    return p


def dur(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1", path], stdout=subprocess.PIPE)
    return float(p.stdout.decode().strip() or 0)


def decode(path):
    tmp = path + ".dec.wav"
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", path, "-ac", "2", "-ar", str(SR), "-c:a", "pcm_s16le", tmp])
    with wave.open(tmp, "rb") as w:
        raw = w.readframes(w.getnframes())
    os.remove(tmp)
    return np.frombuffer(raw, dtype=np.int16).astype(np.float32).reshape(-1, 2) / 32768.0


def _rasgos(mono):
    """Por cada ventana devuelve (db, zcr, hf): energia en dB, tasa de cruces por
    cero (ruido/sordez) y fraccion de energia en agudos (>1.8 kHz). Con eso se
    reconoce el respiro: tenue, muy ruidoso y con bastante agudo, sin tono."""
    n = len(mono)
    if n < VENTANA:
        return np.array([]), np.array([]), np.array([]), np.array([], dtype=int)
    ini = np.arange(0, n - VENTANA, SALTO)
    win = np.hanning(VENTANA).astype(np.float32)
    freqs = np.fft.rfftfreq(VENTANA, 1.0 / SR)
    agudos = freqs >= 1800.0
    db = np.empty(len(ini), np.float32)
    zcr = np.empty(len(ini), np.float32)
    hf = np.empty(len(ini), np.float32)
    for k, s in enumerate(ini):
        fr = mono[s:s + VENTANA]
        rms = float(np.sqrt(np.mean(fr * fr))) + 1e-9
        db[k] = 20.0 * np.log10(rms)
        sg = np.signbit(fr)
        zcr[k] = float(np.mean(sg[1:] != sg[:-1]))
        mag = np.abs(np.fft.rfft(fr * win))
        hf[k] = float(mag[agudos].sum() / (mag.sum() + 1e-9))
    return db, zcr, hf, ini


def _tramos(mascara, ini, dur_min, dur_max):
    """Agrupa ventanas contiguas marcadas en tramos (muestra_ini, muestra_fin),
    filtrando por duracion. dur_max=None => sin tope."""
    segs = []
    i, nF = 0, len(mascara)
    while i < nF:
        if mascara[i]:
            j = i
            while j < nF and mascara[j]:
                j += 1
            s0 = int(ini[i]); s1 = int(ini[j - 1]) + VENTANA
            d = (s1 - s0) / SR
            if d >= dur_min and (dur_max is None or d <= dur_max):
                segs.append((s0, s1))
            i = j
        else:
            i += 1
    return segs


def detectar_respiros(mono, zcr_min, hf_min, techo_rel, dur_min, dur_max):
    """Ubica los respiros: ventanas TENUES (mas bajas que la voz) pero con sonido
    (por encima del silencio), RUIDOSAS (zcr alto) y con AGUDOS (hf alto). Devuelve
    tramos (muestra_ini, muestra_fin)."""
    db, zcr, hf, ini = _rasgos(mono)
    if not len(db):
        return []
    fuerte = float(np.percentile(db, 92.0))     # nivel tipico de la voz
    techo = fuerte - techo_rel                   # el respiro es mas bajo que la voz
    piso = fuerte - 45.0                          # pero por encima del silencio de fondo
    resp = (db > piso) & (db < techo) & (zcr > zcr_min) & (hf > hf_min)
    return _tramos(resp, ini, dur_min, dur_max)


def silenciar(nar, segs, fade_ms=5):
    """Sustituye cada tramo por silencio (ceros) con un pequeño fundido en los
    bordes para que no queden 'clics'. Mantiene el largo: no desplaza nada."""
    f = max(1, int(SR * fade_ms / 1000.0))
    for s0, s1 in segs:
        s0 = max(0, s0); s1 = min(len(nar), s1)
        if s1 <= s0:
            continue
        nar[s0:s1] = 0.0
        a = max(0, s0 - f)
        if s0 > a:
            nar[a:s0] *= np.linspace(1.0, 0.0, s0 - a)[:, None]
        b = min(len(nar), s1 + f)
        if b > s1:
            nar[s1:b] *= np.linspace(0.0, 1.0, b - s1)[:, None]
    return nar


def detectar_silencios(mono, noise_db, min_dur):
    """Silencios (ventanas por debajo del umbral) de al menos min_dur segundos.
    Equivale al silencedetect de ffmpeg pero sobre el audio YA sin respiros."""
    db, _, _, ini = _rasgos(mono)
    if not len(db):
        return []
    segs = _tramos(db < noise_db, ini, min_dur, None)
    return [(s0 / SR, s1 / SR) for s0, s1 in segs]


def main():
    ap = argparse.ArgumentParser(description="Limpia respiros y recorta silencios de un audio (por nicho).")
    ap.add_argument("audio")
    ap.add_argument("--nicho", choices=list(PRESETS.keys()))
    ap.add_argument("--min", type=float, help="silencio minimo a recortar (s)")
    ap.add_argument("--cap", type=float, help="pausa que se deja (s)")
    ap.add_argument("--noise", default="-35dB", help="umbral de silencio (def -35dB)")
    ap.add_argument("--bordes", action="store_true", help="recorta tambien el silencio de inicio/fin a 0.1s")
    ap.add_argument("--no-respiros", dest="respiros", action="store_false",
                    help="NO limpiar respiros (solo recortar silencios)")
    # afinado de la deteccion de respiros (por si hay que ajustar por voz)
    ap.add_argument("--respiro-zcr", type=float, default=0.12, help="cruces-por-cero minimos (ruido)")
    ap.add_argument("--respiro-hf", type=float, default=0.35, help="fraccion de agudos minima")
    ap.add_argument("--respiro-techo", type=float, default=12.0, help="dB por debajo de la voz para considerarlo respiro")
    ap.add_argument("--respiro-min", type=float, default=0.06, help="duracion minima del respiro (s)")
    ap.add_argument("--respiro-max", type=float, default=0.70, help="duracion maxima del respiro (s)")
    ap.add_argument("--out", help="ruta de salida (def <nombre>_recortado.mp3)")
    a = ap.parse_args()

    if not os.path.exists(a.audio):
        raise SystemExit("No existe: " + a.audio)
    if a.nicho:
        pmin, pcap = PRESETS[a.nicho]
    else:
        pmin, pcap = 0.70, 0.35
    if a.min is not None: pmin = a.min
    if a.cap is not None: pcap = a.cap
    try:
        noise_db = float(str(a.noise).lower().replace("db", ""))
    except ValueError:
        noise_db = -35.0
    out = a.out or (os.path.splitext(a.audio)[0] + "_recortado.mp3")

    d0 = dur(a.audio)
    nar = decode(a.audio)

    # ---- PASO 1: respiros -> silencio (mismo largo, sin borrar) ----
    n_resp = 0
    if a.respiros:
        mono0 = nar.mean(axis=1)
        respiros = detectar_respiros(mono0, a.respiro_zcr, a.respiro_hf,
                                     a.respiro_techo, a.respiro_min, a.respiro_max)
        silenciar(nar, respiros)
        n_resp = len(respiros)

    # ---- PASO 2: silencios largos -> se acortan a 'cap' ----
    mono = nar.mean(axis=1)                    # ya sin respiros
    sil = detectar_silencios(mono, noise_db, pmin)
    rem = []
    for s, e in sil:
        if (e - s) <= pcap:
            continue
        if a.bordes and (s <= 0.05 or e >= d0 - 0.05):
            rem.append((s + 0.10, e))          # borde inicial/final: deja solo 0.1s
        else:
            rem.append((s + pcap, e))          # interior: deja 'cap' de pausa
    rem.sort()

    if rem:
        keep, prev = [], 0
        for x, y in rem:
            ix, iy = int(x * SR), int(y * SR)
            if ix > prev:
                keep.append(nar[prev:ix])
            prev = max(prev, iy)
        keep.append(nar[prev:])
        nar = np.concatenate(keep, axis=0)

    out16 = (np.clip(nar, -1, 1) * 32767).astype(np.int16)
    tmpw = out + ".tmp.wav"
    with wave.open(tmpw, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(out16.tobytes())
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmpw, "-c:a", "libmp3lame", "-q:a", "2", out])
    os.remove(tmpw)

    d1 = dur(out); quitado = sum(y - x for x, y in rem)
    nicho = a.nicho or "manual"
    print(f"[OK] {out}")
    print(f"     nicho={nicho}  min={pmin}s  pausa={pcap}s  bordes={'si' if a.bordes else 'no'}")
    print(f"     respiros limpiados: {n_resp}" if a.respiros else "     respiros: (desactivado)")
    print(f"     {d0:.1f}s -> {d1:.1f}s   ({len(rem)} recortes de silencio, -{quitado:.1f}s)")
    print(f"     Siguiente paso: transcribe ESTE audio (con tiempos) y pasa esos tiempos a la skill de prompts.")


if __name__ == "__main__":
    main()
