@echo off
chcp 65001 >nul
title Descargador Universal de Videos
echo ========================================================
echo    DESCARGADOR UNIVERSAL DE VIDEOS DE REDES SOCIALES
echo    Facebook, TikTok, Instagram, YouTube, X
echo ========================================================
echo.
python "%~dp0descargar_videos.py" %*
echo.
pause
