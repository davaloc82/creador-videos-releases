# -*- coding: utf-8 -*-
"""
publicar_actualizacion.py
--------------------------
Herramienta de Lanzamiento para David.
Prepara y empaqueta automáticamente una nueva versión limpia y ligera para distribuir a todos tus clientes.

Uso:
  python herramientas/publicar_actualizacion.py 2.7.0 "Nuevas funciones y mejoras"
"""

import sys
import json
import zipfile
import os
import shutil
import subprocess
from pathlib import Path
from datetime import datetime

_SCRIPT_DIR = Path(__file__).resolve().parent
AQUI = _SCRIPT_DIR.parent if _SCRIPT_DIR.name.lower() == "herramientas" else _SCRIPT_DIR
ARCHIVO_VERSION = AQUI / "version.json"
PATCH_OUTPUT = AQUI / "update_patch.zip"
REPO_DIR = Path(r"C:\Users\Usuario\Documents\DAVID\_repo_releases")

# Solo carpetas esenciales del motor y la interfaz
DIRS_SISTEMA = {
    "core", "ecos", "ai33", "videos", "herramientas",
    "instrucciones_maestras", "instalador_config", "AdminLTE", "fonts",
    "video_engine"
}

# Archivos del sistema en la raíz permitidos
ARCHIVOS_RAIZ_PERMITIDOS = {
    "panel.py", "panel_template.html", "requirements.txt", "version.json",
    "panel.bat", "detener_panel.bat", "iniciar_panel_silencioso.vbs",
    "licencia.py", "nexor.ico", "nexor.png", "LEEME.txt",
    "icono_opcion_a.png", "icono_opcion_b.png", "icono_opcion_a_replix.ico", "icono_opcion_b_nexus.ico"
}

exclude_dirs = {
    "__pycache__", ".git", ".idea", ".vscode", ".pytest_cache",
    "PROYECTOS_VIDEO", "_repo_releases", "bin", "redist",
    "dist_instalador", "admin_licencias", "_backup", "scratch",
    "portal_registro_pagos", ".temp_render", ".hyperframes", "landing_nexor", "entrega_hotmart"
}

exclude_files = {
    ".DS_Store", "Thumbs.db",
    "licencia.lic", "DATOS_DE_TU_LICENCIA.txt",
    "licencias_registradas.json", "licencias_emitidas.json",
    "licencia_dev.py", "licencia_dev_source.py",
    "compilar_licencia.py", "generar_licencia_admin.py", "generar_codigo_cliente.py",
    "ai33_config.txt", "nichos_usuario.json",
    "config_gemini.json", "gemini_config.json",
    "cuentas_redes.json", "historial_analisis_nichos.json",
    "hardware_config.json", ".entorno_listo", "flowbatch_cola.json",
    "update_patch.zip", "Creador_de_Videos_Universal.zip"
}

EXTENSIONES_PROHIBIDAS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".wav", ".mp3", ".onnx", ".pyc", ".zip", ".log", ".tmp"}


def publicar():
    nueva_ver = sys.argv[1].strip().replace("v", "") if len(sys.argv) > 1 else "2.7.0"
    novedades = sys.argv[2] if len(sys.argv) > 2 else "Generador de prompts Gemini IA (imagen.txt y movimiento.txt) integrado, correccion de audio TTS y optimizaciones del motor."

    print("=" * 65)
    print(f"  PUBLICADOR DE ACTUALIZACIONES  -  VERSIÓN v{nueva_ver}")
    print("=" * 65)

    # 1. Cargar y actualizar version.json local
    data_ver = {
        "version": nueva_ver,
        "fecha": datetime.now().strftime("%Y-%m-%d"),
        "canal": "produccion",
        "repositorio": "davaloc82/creador-videos-releases",
        "url_servidor_versiones": "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/version.json",
        "download_url": "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/update_patch.zip",
        "novedades": novedades
    }

    ARCHIVO_VERSION.write_text(json.dumps(data_ver, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[*] version.json actualizado a v{nueva_ver}")

    # 2. Empaquetar update_patch.zip limpio
    print(f"[*] Empaquetando {PATCH_OUTPUT.name}...")
    archivos_empaquetados = 0

    if PATCH_OUTPUT.exists():
        try:
            PATCH_OUTPUT.unlink()
        except Exception:
            pass

    with zipfile.ZipFile(PATCH_OUTPUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(AQUI):
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".") and "respaldo" not in d.lower()]
            rel_dir = Path(root).relative_to(AQUI)
            partes = rel_dir.parts

            # Solo incluir si está en la raíz permitida o dentro de DIRS_SISTEMA
            if len(partes) > 0 and partes[0] not in DIRS_SISTEMA:
                continue

            for f in files:
                if len(partes) == 0:
                    if f not in ARCHIVOS_RAIZ_PERMITIDOS:
                        continue
                if f in exclude_files or "respaldo" in f.lower():
                    continue
                ext = Path(f).suffix.lower()
                if ext in EXTENSIONES_PROHIBIDAS:
                    continue

                f_path = Path(root) / f
                rel = f_path.relative_to(AQUI)
                zf.write(f_path, rel)
                archivos_empaquetados += 1

    size_mb = PATCH_OUTPUT.stat().st_size / (1024 * 1024)
    print(f"[OK] Paquete {PATCH_OUTPUT.name} creado ({archivos_empaquetados} archivos, {size_mb:.2f} MB).")

    # 3. Copiar a _repo_releases
    REPO_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ARCHIVO_VERSION, REPO_DIR / "version.json")
    shutil.copy2(PATCH_OUTPUT, REPO_DIR / "update_patch.zip")

    readme_content = f"""# Creador de Videos (Universal) - Canal de Actualizaciones Oficiales

Repositorio oficial de distribución de parches y versiones para clientes.

- **Última versión:** v{nueva_ver}
- **Fecha:** {datetime.now().strftime("%Y-%m-%d")}
- **Notas de lanzamiento:** {novedades}

## Archivos de distribución:
- `version.json`: Manifiesto de versión para detección automática.
- `update_patch.zip`: Paquete con los archivos del motor del sistema.
"""
    (REPO_DIR / "README.md").write_text(readme_content, encoding="utf-8")

    # 4. Commit en git local del repositorio de releases
    try:
        subprocess.run(["git", "config", "user.name", "David"], cwd=REPO_DIR, check=True)
        subprocess.run(["git", "config", "user.email", "davaloc82@gmail.com"], cwd=REPO_DIR, check=True)
        subprocess.run(["git", "add", "version.json", "update_patch.zip", "README.md"], cwd=REPO_DIR, check=True)
        subprocess.run(["git", "commit", "-m", f"Release v{nueva_ver}: {novedades}"], cwd=REPO_DIR, capture_output=True)
        print(f"[OK] Commit local registrado en _repo_releases para v{nueva_ver}")
    except Exception as e:
        print(f"[AVISO] Git commit: {e}")

    print("\n" + "=" * 65)
    print(f"  [COMPLETADO] ARCHIVOS PREPARADOS EN: {REPO_DIR.name}")
    print("=" * 65)
    print("Para publicar en vivo a todos tus clientes:")
    print("  -> Ejecuta: _repo_releases\\subir_a_github.bat")
    print("=" * 65)


if __name__ == "__main__":
    publicar()
