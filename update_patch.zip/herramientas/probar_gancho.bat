@echo off
chcp 65001 >nul
echo ========================================================
echo    PROBAR BLOQUE 1: GANCHO MODULAR (MAPAS VIRALES)
echo ========================================================
echo.
set "PROY_DIR=%USERPROFILE%\Downloads\MAPAS\43 Linajes Bajio"
if not "%~1"=="" set "PROY_DIR=%~1"

echo Proyecto: %PROY_DIR%
echo Renderizando Bloque 1 (Gancho 13s) en ~20 segundos...
echo.

python "%~dp0mapas\productor_bloques_mapas.py" "%PROY_DIR%" --bloque 1

echo.
echo ========================================================
echo    RENDERIZADO COMPLETADO
echo    Archivo generado: %PROY_DIR%\bloques\01_bloque_gancho.mp4
echo ========================================================
pause
