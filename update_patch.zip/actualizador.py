# -*- coding: utf-8 -*-
"""
actualizador.py
----------------
Sistema de Auto-Actualización Silenciosa y en 1 Clic para Clientes.
Permite a David distribuir actualizaciones de código a cientos de usuarios
sin necesidad de que los clientes tengan Git instalado ni pierdan sus licencias.

Reglas de Oro:
1. JAMÁS sobreescribe 'licencia.lic' (la licencia activada del cliente persiste de por vida).
2. JAMÁS sobreescribe 'ai33_config.txt' ni 'nichos_usuario.json' (sus claves y canales se respetan).
3. JAMÁS toca 'PROYECTOS_VIDEO/' (sus proyectos y renders permanecen intactos).
4. Reemplaza únicamente archivos del motor y la interfaz (panel.py, templates, scripts de IA).
"""

import io
import json
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
ARCHIVO_VERSION = AQUI / "version.json"

import ssl

_SSL_CTX = None
def _obtener_ssl_context():
    global _SSL_CTX
    if _SSL_CTX is None:
        try:
            _SSL_CTX = ssl.create_default_context()
        except Exception:
            _SSL_CTX = ssl._create_unverified_context()
    return _SSL_CTX

ARCHIVOS_SAGRADOS_USUARIO = {
    "licencia.lic",
    "DATOS_DE_TU_LICENCIA.txt",
    "ai33_config.txt",
    "nichos_usuario.json",
    "licencias_registradas.json"
}


def obtener_version_local() -> dict:
    """Lee la versión instalada actualmente en la máquina."""
    if ARCHIVO_VERSION.is_file():
        try:
            return json.loads(ARCHIVO_VERSION.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "version": "2.4.0",
        "fecha": "2026-10-30",
        "url_servidor_versiones": "https://raw.githubusercontent.com/davaloc82/creador-videos-releases/main/version.json"
    }


def _parse_version(v_str: str) -> tuple:
    """Convierte '2.4.1' en tupla (2, 4, 1) para comparación segura."""
    try:
        numeros = [int(x) for x in v_str.replace("v", "").replace("V", "").strip().split(".")]
        return tuple(numeros)
    except Exception:
        return (0, 0, 0)


def verificar_actualizaciones() -> dict:
    """
    Comprueba si existe una versión superior en el servidor remoto.
    Se ejecuta de forma ligera y rápida con timeout de 3 segundos.
    """
    local = obtener_version_local()
    ver_local = local.get("version", "2.4.0")
    url_remota = local.get("url_servidor_versiones", "")

    if not url_remota or "placeholder" in url_remota:
        return {
            "hay_actualizacion": False,
            "version_actual": ver_local,
            "version_remota": ver_local,
            "novedades": "Configura un repositorio remoto en version.json para habilitar actualizaciones.",
            "download_url": ""
        }

    try:
        req = urllib.request.Request(
            url_remota,
            headers={"User-Agent": "CreadorVideos-AutoUpdater/2.4"}
        )
        ctx = _obtener_ssl_context()
        with urllib.request.urlopen(req, timeout=6, context=ctx) as resp:
            data_remota = json.loads(resp.read().decode("utf-8"))

        ver_remota = data_remota.get("version", ver_local)
        hay_nueva = _parse_version(ver_remota) > _parse_version(ver_local)

        return {
            "hay_actualizacion": hay_nueva,
            "version_actual": ver_local,
            "version_remota": ver_remota,
            "novedades": data_remota.get("novedades") or data_remota.get("notas", "Mejoras de rendimiento y estabilidad."),
            "download_url": data_remota.get("download_url", ""),
            "fecha": data_remota.get("fecha", "")
        }
    except Exception as e:
        return {
            "hay_actualizacion": False,
            "version_actual": ver_local,
            "version_remota": ver_local,
            "error": str(e),
            "novedades": "No se pudo conectar con el servidor de actualizaciones."
        }


def aplicar_actualizacion(download_url: str) -> dict:
    """
    Descarga el paquete de actualización y lo aplica de forma segura,
    respetando estrictamente los datos de usuario y licencias.
    """
    if not download_url:
        return {"ok": False, "msg": "No se especificó la URL de descarga del paquete de actualización."}

    try:
        print(f"[*] Descargando actualización desde: {download_url}...", flush=True)
        req = urllib.request.Request(
            download_url,
            headers={"User-Agent": "CreadorVideos-AutoUpdater/2.4"}
        )
        ctx = _obtener_ssl_context()
        with urllib.request.urlopen(req, timeout=90, context=ctx) as resp:
            zip_bytes = resp.read()

        # Abrir el ZIP en memoria
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            archivos_actualizados = 0
            for info in zf.infolist():
                if info.is_dir():
                    continue

                partes = Path(info.filename).parts
                # Normalizar si viene dentro de una subcarpeta raíz (ej: Creador_de_Videos/panel.py)
                if partes and partes[0].lower() in ("creador_de_videos", "generador_universal", "repo-main"):
                    partes = partes[1:]

                if not partes:
                    continue

                nombre_rel = Path(*partes)
                destino = AQUI / nombre_rel

                # COMPROBACIÓN DE SEGURIDAD 1: No tocar archivos sagrados del usuario
                if nombre_rel.name in ARCHIVOS_SAGRADOS_USUARIO:
                    continue

                # COMPROBACIÓN DE SEGURIDAD 2: No tocar proyectos ni renders del usuario
                if "proyectos_video" in [p.lower() for p in partes]:
                    continue

                # Crear carpetas contenedoras
                destino.parent.mkdir(parents=True, exist_ok=True)

                # Extraer archivo
                with zf.open(info) as src, open(destino, "wb") as dst:
                    shutil.copyfileobj(src, dst)

                archivos_actualizados += 1

        print(f"[OK] Actualización completada: {archivos_actualizados} archivos actualizados.", flush=True)
        return {
            "ok": True,
            "msg": f"¡Sistema actualizado con éxito ({archivos_actualizados} archivos aplicados)! Por favor reinicia o recarga la página.",
            "archivos_actualizados": archivos_actualizados
        }

    except Exception as e:
        return {"ok": False, "msg": f"Error aplicando la actualización: {e}"}


if __name__ == "__main__":
    print("=" * 60)
    print("  VERIFICADOR DE ACTUALIZACIONES")
    print("=" * 60)
    res = verificar_actualizaciones()
    print("  Versión actual :", res.get("version_actual"))
    print("  Versión remota :", res.get("version_remota"))
    print("  Hay nueva      :", res.get("hay_actualizacion"))
    print("  Novedades      :", res.get("novedades"))
    print("=" * 60)

