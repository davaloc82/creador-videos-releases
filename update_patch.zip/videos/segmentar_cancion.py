# -*- coding: utf-8 -*-
"""
ecos/segmentar_cancion.py - Segmentador especializado para CANCIONES de Suno / Bots musicales en Ecos del Alma.

Diferencia clave con narraciones estándar:
1. Una narración es voz continua a ~145 WPM. Una canción tiene ritmo musical, pausas,
   solos de guitarra/batería y estrofas con tempos variables.
2. Lee el prompt de Suno y extrae la letra limpia, eliminando metadatos (LYRICS, STYLES, BPM, [Verse...], etc.).
3. Transcribe el audio real con Whisper para detectar el segundo exacto donde entra la voz y donde termina.
4. Identifica las pausas instrumentales (solos, intros, outros) y crea escenas visuales coherentes
   para que no queden huecos sin imágenes o clips en el video final.
5. Genera 'sincronia.txt' en el formato estándar de Ecos y 'guion_limpio.txt' con solo la letra.
"""

import os
import sys
import re
import argparse
import subprocess
from pathlib import Path

try:
    import whisper
except ImportError:
    whisper = None


PATRONES_CANCIÓN = [
    r'\bLYRICS\s*:',
    r'\bSTYLES?\s*:',
    r'\[(?:Verse|Chorus|Intro|Bridge|Outro|Pre-Chorus|Drop|Hook|Solo|Estrofa|Coro|Puente|Canci[oó]n)\b',
    r'\b(?:TIPO|MODO)\s*:\s*CANCI[OÓ]N\b',
    r'\b\d{2,3}\s*BPM\b',
]


def es_guion_cancion(texto: str) -> bool:
    """Detecta si el texto proviene de un bot de música / Suno o fue marcado como canción."""
    if not texto:
        return False
    for pat in PATRONES_CANCIÓN:
        if re.search(pat, texto, re.IGNORECASE):
            return True
    return False


def fmt_min_sec(segundos: float) -> str:
    """Convierte segundos a formato M:SS."""
    m, s = divmod(int(round(segundos)), 60)
    return f"{m}:{s:02d}"


def ffprobe_dur(path: Path) -> float:
    """Devuelve la duración exacta en segundos usando ffprobe."""
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
            capture_output=True, text=True, check=True
        )
        return float(r.stdout.strip())
    except Exception:
        return 0.0


def normalizar_palabras(texto: str) -> str:
    """Elimina signos de puntuación y pasa a minúsculas para comparaciones semánticas."""
    return re.sub(r'[^\w\s]', '', texto.lower())


def limpiar_letra_suno(texto_crudo: str) -> list:
    """
    Elimina metadatos de Suno (LYRICS, STYLES, BPM, corchetes y notas entre paréntesis)
    y devuelve las líneas de letra limpias y no vacías.
    """
    lineas_limpias = []
    ignorar_bloque = False

    for linea in texto_crudo.splitlines():
        linea = linea.strip()
        if not linea:
            continue

        # Detectar inicio de bloque de estilos / metadatos al final
        if re.match(r'^(STYLES?|STYLE|GENRE|BPM|PROMPT|INSTRUMENTAL|TAGS)\b', linea, re.IGNORECASE):
            ignorar_bloque = True
            continue
        if ignorar_bloque:
            continue

        # Ignorar encabezado inicial LYRICS:
        if re.match(r'^LYRICS\s*:', linea, re.IGNORECASE):
            continue

        # Ignorar marcadores de estructura entre corchetes [Verse 1...], [Chorus...]
        if re.match(r'^\[.*?\]$', linea):
            continue

        # Ignorar acotaciones de interpretación entre paréntesis (Voz profunda...), (Fade out)
        if re.match(r'^\(.*?\)$', linea):
            continue

        # Limpiar corchetes o paréntesis residuales incrustados
        linea = re.sub(r'\[.*?\]', '', linea).strip()
        linea = re.sub(r'\((?:voz|cantado|fade|pausa|grito|susurro|hablado|outro|intro).*?\)', '', linea, flags=re.IGNORECASE).strip()

        if linea and len(linea) > 2:
            lineas_limpias.append(linea)

    return lineas_limpias


def transcribir_audio_whisper(audio_path: Path, idioma: str = "es"):
    """Transcribe el archivo de audio con Whisper (modelo base) para obtener timestamps reales."""
    if not whisper:
        print("  [AVISO] Whisper no está disponible en este entorno. Se usará estimación musical.")
        return []

    print(f"  [Whisper] Escuchando canción real ({audio_path.name}) para mapear melodía y pausas...")
    try:
        modelo = whisper.load_model("base")
        res = modelo.transcribe(str(audio_path), language=idioma, fp16=False)
        return res.get("segments", [])
    except Exception as e:
        print(f"  [ERROR] Falla al transcribir con Whisper: {e}")
        return []


def generar_escenas_instrumentales(t0: float, t1: float, tipo: str = "interludio") -> list:
    """Genera tomas instrumentales balanceadas (4.0s a 6.5s) con descripciones visuales ricas."""
    dur = t1 - t0
    if dur <= 0.5:
        return []

    n_partes = max(1, int(round(dur / 5.2)))
    dt = dur / n_partes
    escenas = []

    descripciones = {
        "intro": [
            "[Intro instrumental: Acordes acústicos y apertura de ambientación]",
            "[Intro instrumental: Entrada rítmica de percusión y bajo]",
            "[Intro instrumental: Preparación de la historia]"
        ],
        "interludio": [
            "[Solo instrumental: Melodía de guitarra y ritmo marcado]",
            "[Interludio musical: Transición rítmica de cajón y bajo]",
            "[Puente musical: Tensión acústica y acordes de paso]"
        ],
        "outro": [
            "[Outro musical: Desvanecimiento de acordes de guitarra]",
            "[Outro musical: Eco rítmico y atmósfera en retirada]",
            "[Outro musical: Silencio y desvanecimiento final (Fade Out)]",
            "[Outro musical: Cierre visual del relato]"
        ]
    }
    pool = descripciones.get(tipo, descripciones["interludio"])

    for i in range(n_partes):
        sub_t0 = t0 + i * dt
        sub_t1 = t0 + (i + 1) * dt if i < n_partes - 1 else t1
        desc = pool[i % len(pool)]
        escenas.append({"ini": sub_t0, "fin": sub_t1, "dur": sub_t1 - sub_t0, "frase": desc})

    return escenas


def alinear_cancion_con_letra(audio_dur: float, whisper_segs: list, lineas_letra: list) -> list:
    """
    Combina los timestamps reales de Whisper con la letra limpia de Suno,
    e inserta escenas instrumentales para los espacios sin voz.
    """
    escenas = []
    curr_t = 0.0
    last_matched_idx = 0

    if not whisper_segs:
        # Fallback sin Whisper: repartir uniformemente
        dt = audio_dur / max(1, len(lineas_letra))
        for i, l in enumerate(lineas_letra):
            t0 = i * dt
            t1 = (i + 1) * dt if i < len(lineas_letra) - 1 else audio_dur
            escenas.append({"ini": t0, "fin": t1, "dur": t1 - t0, "frase": l})
        return escenas

    for seg in whisper_segs:
        st = float(seg["start"])
        en = float(seg["end"])
        txt = seg["text"].strip()

        # Si hay un hueco instrumental antes de este segmento de voz
        gap = st - curr_t
        if gap >= 2.5:
            tipo_gap = "intro" if curr_t < 1.0 else "interludio"
            escenas.extend(generar_escenas_instrumentales(curr_t, st, tipo=tipo_gap))
            curr_t = st
        elif gap > 0:
            st = curr_t

        # Buscar la mejor correspondencia en lineas_letra hacia adelante
        norm_txt = normalizar_palabras(txt).split()
        mejor_idx = -1
        mejor_score = 0

        # Buscar en una ventana de las próximas 4 líneas desde last_matched_idx
        ventana_fin = min(len(lineas_letra), last_matched_idx + 4)
        for idx in range(last_matched_idx, ventana_fin):
            norm_cand = normalizar_palabras(lineas_letra[idx])
            score = sum(1 for w in norm_txt if len(w) > 2 and w in norm_cand)
            if score > mejor_score:
                mejor_score = score
                mejor_idx = idx

        if mejor_idx != -1 and mejor_score >= 2:
            frase_final = lineas_letra[mejor_idx]
            last_matched_idx = mejor_idx + 1
        else:
            # Si no coincide fuerte, usar el texto detectado por Whisper pero formateado
            frase_final = txt.strip()
            if frase_final and not frase_final[0].isupper():
                frase_final = frase_final[0].upper() + frase_final[1:]

        # Si el segmento es largo (>6.5s), dividir en 2 tomas
        dur_seg = en - st
        if dur_seg > 6.5:
            mid_t = st + (dur_seg / 2.0)
            escenas.append({"ini": st, "fin": mid_t, "dur": mid_t - st, "frase": frase_final})
            escenas.append({"ini": mid_t, "fin": en, "dur": en - mid_t, "frase": frase_final})
        else:
            escenas.append({"ini": st, "fin": en, "dur": dur_seg, "frase": frase_final})

        curr_t = en

    # Espacio final de Outro (música restante hasta el fin del audio)
    if curr_t < audio_dur - 1.5:
        escenas.extend(generar_escenas_instrumentales(curr_t, audio_dur, tipo="outro"))

    # Ajustar continuidad exacta de tiempos
    for i in range(len(escenas) - 1):
        escenas[i]["fin"] = escenas[i + 1]["ini"]
        escenas[i]["dur"] = escenas[i]["fin"] - escenas[i]["ini"]
    if escenas:
        escenas[-1]["fin"] = audio_dur
        escenas[-1]["dur"] = audio_dur - escenas[-1]["ini"]

    # Renumerar tomas
    for idx, esc in enumerate(escenas, 1):
        esc["orden"] = idx

    return escenas


def generar_sincronia_cancion(proy_dir: Path, escenas: list, dur_total: float, letra_limpia: list):
    """Escribe sincronia.txt y guion_limpio.txt en la carpeta del proyecto."""
    sinc_path = proy_dir / "sincronia.txt"
    with open(sinc_path, "w", encoding="utf-8") as f:
        f.write("# | inicio–fin | dur | cubre\n")
        for esc in escenas:
            rango = f"{fmt_min_sec(esc['ini'])}–{fmt_min_sec(esc['fin'])}"
            f.write(f"{esc['orden']} | {rango} | {esc['dur']:.1f}s | \"{esc['frase']}\"\n")

    limpio_path = proy_dir / "guion_limpio.txt"
    with open(limpio_path, "w", encoding="utf-8") as f:
        f.write("\n".join(letra_limpia) + "\n")

    return sinc_path


def segmentar_cancion_proyecto(proy_dir: Path, texto_guion: str, audio_file: Path):
    """Punto de entrada principal para segmentar un proyecto de canción de Suno."""
    print("=" * 65)
    print("   SEGMENTADOR ESPECIALIZADO DE CANCIONES (SUNO / MÚSICA)")
    print("   Ecos del Alma · Detección de Melodía, Versos y Solos")
    print("=" * 65)
    print(f"  Proyecto : {proy_dir.name}")
    print(f"  Ruta     : {proy_dir}")

    # 1. Limpiar letra de Suno
    letra_limpia = limpiar_letra_suno(texto_guion)
    print(f"  Letra limpia detectada : {len(letra_limpia)} versos/líneas reales")
    print(f"  Instrucciones Suno     : Filtradas automáticamente (sin corchetes ni estilos)")

    # 2. Duración de audio
    dur_total = ffprobe_dur(audio_file) if (audio_file and audio_file.is_file()) else 0.0
    if dur_total > 0:
        print(f"  Audio real detectado   : {audio_file.name} ({fmt_min_sec(dur_total)} / {dur_total:.2f}s)")
    else:
        sys.exit(f"ERROR: No se encontró aud.mp3 en {proy_dir}. Para canciones se requiere el audio real.")

    # 3. Transcribir con Whisper para detectar tiempos exactos
    whisper_segs = transcribir_audio_whisper(audio_file, idioma="es")

    # 4. Alinear letra con Whisper e insertar tramos instrumentales
    escenas = alinear_cancion_con_letra(dur_total, whisper_segs, letra_limpia)
    
    cant_instrumentales = sum(1 for e in escenas if e["frase"].startswith("["))
    cant_vocales = len(escenas) - cant_instrumentales

    print(f"\n  Tomas generadas        : {len(escenas)} escenas en total")
    print(f"  - Escenas cantadas     : {cant_vocales}")
    print(f"  - Solos/Instrumentales : {cant_instrumentales} (con cobertura visual continua)")

    # 5. Generar sincronia.txt
    sinc_path = generar_sincronia_cancion(proy_dir, escenas, dur_total, letra_limpia)

    print("\n  [LISTO] Sincronía musical creada con éxito:")
    print(f"  -> {sinc_path.name} (calibrada con los tiempos reales del audio)")
    print(f"  -> guion_limpio.txt (letra pura sin etiquetas de Suno)")
    print("=" * 65 + "\n")
    return sinc_path


def main():
    parser = argparse.ArgumentParser(description="Segmenta canciones de Suno en escenas calibradas con el audio.")
    parser.add_argument("ruta", help="Ruta de la carpeta del proyecto (ej: NUEVOS GUIONES/294)")
    args = parser.parse_args()

    proy = Path(args.ruta).resolve()
    guion_cands = ["guion.txt", "guion.md", "guion"]
    guion_file = next((proy / g for g in guion_cands if (proy / g).is_file()), None)
    if not guion_file:
        sys.exit(f"ERROR: No se encontró guion.txt en {proy}")

    texto = guion_file.read_text(encoding="utf-8-sig", errors="replace")
    audio_file = next((proy / a for a in ("aud.mp3", "aud_limpio.mp3", "audio.mp3") if (proy / a).is_file()), None)

    segmentar_cancion_proyecto(proy, texto, audio_file)


if __name__ == "__main__":
    main()
