# -*- coding: utf-8 -*-
"""
Motor de Infografías Animadas 2D/3D Isométricas & Planos Arquitectónicos (1080x1920 @ 30fps)
NEXOR - Creador de Videos © 2026

Genera escenas vectoriales animadas con múltiples perspectivas reales:
- Vista Isométrica 3D (casas, edificios, puentes, terreno estratificado)
- Plano en Planta desde arriba (techos, perímetros, redes de tuberías y desvíos)
- Corte lateral completo de casa y terreno + subsuelo
- Perfil longitudinal subterráneo de tuberías en pendiente
- Explosión isométrica 3D de capas constructivas
- Composición arquitectónica paramétrica dirigida por Gemini
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from functools import lru_cache
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H = 1080, 1920
FPS = 30

# Escenario seguro: x=[66..1014], y=[252..1228] (Encabezado: y=76..232, Subtítulos: y>=1270)
STAGE_X0, STAGE_Y0, STAGE_X1, STAGE_Y1 = 66, 252, W - 66, 1228

PLANTILLAS_VALIDAS = (
    # Viviendas, tejados y drenaje pluvial
    "casa_isometrica_tejado",
    "plano_planta_tejado",
    "estancamiento_colapso_techo",
    "corte_casa_terreno_humedad",
    "capas_impermeables_3d",
    "desvio_hidraulico_planta",
    "fluido_sin_friccion",
    "comparativa_viviendas_3d",
    # Edificios, cimientos, tuberías y suelos
    "edificio_moderno_grietas",
    "plano_planta_drenaje",
    "perfil_tuberia_pendiente",
    "drenaje_cimientos",
    "presion_hidrostatica",
    "densidad_suelo_estratos",
    "vivienda_colapso_3d",
    # Puentes, dilatación térmica y estructuras civiles
    "puente_isometrico_calor",
    "compresion_sin_espacio",
    "junta_dilatacion_3d",
    "ciclo_termico",
    "alerta_fallo_junta",
    "viga_fractura",
    "estructura_flexible",
    "comparativa_doble",
    # Adaptativos y cierre
    "composicion_arquitectonica",
    "pregunta_panorama",
    "cta_comenta",
    "engranajes_sistema",
)

# Etiqueta de cámara / perspectiva mostrada discreta en esquina inferior del escenario
PERSPECTIVA_POR_PLANTILLA = {
    "casa_isometrica_tejado": ("isometrica", "VISTA 3D ISOMÉTRICA"),
    "plano_planta_tejado": ("planta", "PLANO EN PLANTA ↑"),
    "estancamiento_colapso_techo": ("corte_techo", "CORTE DE LOSA"),
    "corte_casa_terreno_humedad": ("corte_terreno", "CORTE COSTADO + TERRENO"),
    "capas_impermeables_3d": ("capas_3d", "CAPAS 3D EXPLOTADAS"),
    "desvio_hidraulico_planta": ("planta_flujo", "PLANTA AÉREA DE CAUDAL"),
    "fluido_sin_friccion": ("hidrodinamica", "PERFIL HIDRODINÁMICO"),
    "comparativa_viviendas_3d": ("comparativa", "DOBLE ISOMÉTRICO"),
    "edificio_moderno_grietas": ("isometrica_edif", "ISOMÉTRICA EDIFICIO 3D"),
    "plano_planta_drenaje": ("planta_red", "PLANTA RED DE TUBERÍAS"),
    "perfil_tuberia_pendiente": ("perfil_tubo", "PERFIL TUBERÍA 2%"),
    "drenaje_cimientos": ("corte_cimiento", "CORTE TRANSVERSAL ZANJA"),
    "presion_hidrostatica": ("corte_freatico", "CORTE SUBSUELO + FLUJO"),
    "densidad_suelo_estratos": ("estratos", "ESTRATOS DEL TERRENO"),
    "vivienda_colapso_3d": ("isometrica_dano", "ASENTAMIENTO 3D"),
    "puente_isometrico_calor": ("isometrica_puente", "VISTA 3D PUENTE"),
    "compresion_sin_espacio": ("macro_compresion", "ISOMÉTRICA COMPRESIÓN"),
    "junta_dilatacion_3d": ("macro_junta", "CORTE MACRO JUNTA"),
    "ciclo_termico": ("termico", "SIMULACIÓN TÉRMICA"),
    "alerta_fallo_junta": ("alerta_junta", "CORTE BLOQUEO"),
    "viga_fractura": ("portico", "PÓRTICO EN CARGA"),
    "estructura_flexible": ("atirantado", "ELEVACIÓN ESTRUCTURAL"),
    "comparativa_doble": ("comparativa", "COMPARATIVA TÉCNICA"),
    "composicion_arquitectonica": ("blueprint_ia", "PLANO ARQUITECTÓNICO"),
    "pregunta_panorama": ("wireframe", "PLANO GENERAL"),
    "cta_comenta": ("cta", "GUÍA Y PLANOS"),
    "engranajes_sistema": ("mecanica", "SISTEMA FÍSICO"),
}

POOLS_POR_TEMA = {
    "tejado_casa": [
        "casa_isometrica_tejado",
        "comparativa_viviendas_3d",
        "estancamiento_colapso_techo",
        "corte_casa_terreno_humedad",
        "capas_impermeables_3d",
        "desvio_hidraulico_planta",
        "plano_planta_tejado",
        "fluido_sin_friccion",
        "presion_hidrostatica",
        "perfil_tuberia_pendiente",
        "vivienda_colapso_3d",
    ],
    "cimientos_drenaje": [
        "edificio_moderno_grietas",
        "plano_planta_drenaje",
        "corte_casa_terreno_humedad",
        "presion_hidrostatica",
        "comparativa_viviendas_3d",
        "perfil_tuberia_pendiente",
        "drenaje_cimientos",
        "densidad_suelo_estratos",
        "vivienda_colapso_3d",
        "desvio_hidraulico_planta",
        "capas_impermeables_3d",
    ],
    "puente_termico": [
        "puente_isometrico_calor",
        "compresion_sin_espacio",
        "junta_dilatacion_3d",
        "ciclo_termico",
        "alerta_fallo_junta",
        "viga_fractura",
        "estructura_flexible",
        "comparativa_doble",
    ],
    "obra_general": [
        "casa_isometrica_tejado",
        "plano_planta_drenaje",
        "corte_casa_terreno_humedad",
        "edificio_moderno_grietas",
        "capas_impermeables_3d",
        "perfil_tuberia_pendiente",
        "comparativa_viviendas_3d",
        "densidad_suelo_estratos",
        "desvio_hidraulico_planta",
        "viga_fractura",
        "fluido_sin_friccion",
    ],
}

TEMAS_ACENTO = {
    "peligro": {
        "primario": (239, 68, 68),
        "secundario": (249, 115, 22),
        "suave": (127, 29, 29),
        "luz_bg": (28, 16, 28),
        "tag": "TENSIÓN CRÍTICA",
    },
    "solucion": {
        "primario": (16, 185, 129),
        "secundario": (6, 182, 212),
        "suave": (6, 78, 59),
        "luz_bg": (12, 32, 42),
        "tag": "DISEÑO SEGURO",
    },
    "ciencia": {
        "primario": (56, 189, 248),
        "secundario": (250, 204, 21),
        "suave": (12, 74, 110),
        "luz_bg": (14, 28, 52),
        "tag": "INGENIERÍA VISUAL",
    },
    "alerta": {
        "primario": (245, 158, 11),
        "secundario": (239, 68, 68),
        "suave": (120, 53, 15),
        "luz_bg": (30, 24, 22),
        "tag": "PUNTO DE FALLA",
    },
    "cta": {
        "primario": (56, 189, 248),
        "secundario": (168, 85, 247),
        "suave": (49, 46, 129),
        "luz_bg": (22, 20, 48),
        "tag": "PLANO TÉCNICO",
    },
}


def clamp01(x: float) -> float:
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


def ease_out_cubic(x: float) -> float:
    x = clamp01(x)
    return 1.0 - (1.0 - x) ** 3


def ease_in_out(x: float) -> float:
    x = clamp01(x)
    return 3.0 * x * x - 2.0 * x * x * x


def _resolver_ruta_ffmpeg(ffmpeg_bin: str = "ffmpeg") -> str:
    try:
        from ffmpeg_resolver import resolver_ffmpeg
        res = resolver_ffmpeg()
        if res:
            return res
    except Exception:
        pass
    return ffmpeg_bin


@lru_cache(maxsize=64)
def _get_font(size: int, kind: str = "bold") -> ImageFont.FreeTypeFont:
    aqui = Path(__file__).resolve().parent
    win_fonts = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    if kind == "mono":
        cands = [
            win_fonts / "consolab.ttf",
            win_fonts / "courbd.ttf",
            win_fonts / "segoeuib.ttf",
            win_fonts / "arialbd.ttf",
        ]
    elif kind == "regular":
        cands = [
            win_fonts / "segoeui.ttf",
            win_fonts / "arial.ttf",
            win_fonts / "calibri.ttf",
        ]
    else:
        cands = [
            win_fonts / "segoeuib.ttf",
            win_fonts / "arialbd.ttf",
            win_fonts / "calibrib.ttf",
            aqui / "fonts" / "MelvinsoneRegular-d9mvR.otf",
            aqui.parent / "fonts" / "MelvinsoneRegular-d9mvR.otf",
        ]
    for p in cands:
        if p.is_file():
            try:
                return ImageFont.truetype(str(p), size)
            except Exception:
                pass
    return ImageFont.load_default()


def _text_size(draw: ImageDraw.ImageDraw, text: str, font) -> tuple[int, int]:
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]


@lru_cache(maxsize=8)
def _notdef_mask_bytes(kind: str = "bold") -> bytes:
    f = _get_font(28, kind)
    try:
        return bytes(f.getmask("\u0378"))
    except Exception:
        return b""


def _limpiar_texto_visual(text: str, kind: str = "bold") -> str:
    txt = str(text or "")
    for bad in ("❌", "✖", "✗", "✘", "✓", "✔", "✅", "🔥", "💧", "☀", "🌧", "🌡", "🔧"):
        txt = txt.replace(bad, " ")
    txt = txt.replace("⚠", "!")
    txt = txt.replace("\ufe0f", "").replace("\u200d", "")
    f = _get_font(28, kind)
    nd = _notdef_mask_bytes(kind)
    if nd:
        clean_chars = []
        for ch in txt:
            if ch.isspace():
                clean_chars.append(ch)
                continue
            try:
                if bytes(f.getmask(ch)) == nd:
                    continue
            except Exception:
                pass
            clean_chars.append(ch)
        txt = "".join(clean_chars)
    return re.sub(r"\s{2,}", " ", txt).strip()


def _draw_vector_badge(draw: ImageDraw.ImageDraw, cx: int, cy: int, r: int, badge_type: str):
    if badge_type == "cross":
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(153, 27, 27), outline=(248, 113, 113), width=2)
        d = int(r * 0.44)
        draw.line([(cx - d, cy - d), (cx + d, cy + d)], fill=(255, 255, 255), width=3)
        draw.line([(cx - d, cy + d), (cx + d, cy - d)], fill=(255, 255, 255), width=3)
    elif badge_type == "check":
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(6, 95, 70), outline=(52, 211, 153), width=2)
        pts = [
            (cx - int(r * 0.45), cy + int(r * 0.04)),
            (cx - int(r * 0.10), cy + int(r * 0.38)),
            (cx + int(r * 0.48), cy - int(r * 0.34)),
        ]
        draw.line(pts, fill=(255, 255, 255), width=3, joint="curve")
    elif badge_type == "warn":
        poly = [(cx, cy - r), (cx - r, cy + int(r * 0.85)), (cx + r, cy + int(r * 0.85))]
        draw.polygon(poly, fill=(146, 64, 14), outline=(251, 191, 36))
        draw.line([(cx, cy - int(r * 0.35)), (cx, cy + int(r * 0.30))], fill=(255, 255, 255), width=3)
        draw.ellipse([cx - 2, cy + int(r * 0.48) - 2, cx + 2, cy + int(r * 0.48) + 2], fill=(255, 255, 255))


def _wrap_lines(draw: ImageDraw.ImageDraw, text: str, font, max_w: int, max_lines: int = 2) -> list[str]:
    words = text.split()
    if not words:
        return []
    lines = []
    cur = words[0]
    for w in words[1:]:
        cand = cur + " " + w
        if _text_size(draw, cand, font)[0] <= max_w:
            cur = cand
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines - 1] + [" ".join(lines[max_lines - 1:])]
    return lines


def _draw_text_fitted(
    draw: ImageDraw.ImageDraw,
    cx_or_x: int,
    y: int,
    text: str,
    max_w: int,
    sizes: tuple[int, ...] = (42, 36, 30, 24),
    fill: tuple[int, int, int] = (248, 250, 252),
    kind: str = "bold",
    centered: bool = False,
    max_lines: int = 2,
    line_gap: int = 4,
):
    txt = _limpiar_texto_visual(str(text or ""), kind)
    if not txt:
        return
    chosen_font = _get_font(sizes[-1], kind)
    chosen_lines = [txt]
    for sz in sizes:
        f = _get_font(sz, kind)
        if _text_size(draw, txt, f)[0] <= max_w:
            chosen_font = f
            chosen_lines = [txt]
            break
        if max_lines > 1:
            lines = _wrap_lines(draw, txt, f, max_w, max_lines=max_lines)
            if lines and all(_text_size(draw, ln, f)[0] <= max_w + 8 for ln in lines):
                chosen_font = f
                chosen_lines = lines
                break
    else:
        chosen_font = _get_font(sizes[-1], kind)
        chosen_lines = _wrap_lines(draw, txt, chosen_font, max_w, max_lines=max_lines)

    _, lh = _text_size(draw, "Ág", chosen_font)
    total_h = len(chosen_lines) * lh + max(0, len(chosen_lines) - 1) * line_gap
    cur_y = y - (total_h // 2 if centered else 0)
    for ln in chosen_lines:
        tw, _ = _text_size(draw, ln, chosen_font)
        x_draw = cx_or_x - tw // 2 if centered else cx_or_x
        draw.text((x_draw, cur_y), ln, font=chosen_font, fill=fill)
        cur_y += lh + line_gap


def _alpha_rect(frame: np.ndarray, x0: int, y0: int, x1: int, y1: int, color: tuple[int, int, int], alpha: float):
    x0c, y0c = max(0, int(x0)), max(0, int(y0))
    x1c, y1c = min(W, int(x1)), min(H, int(y1))
    if x1c <= x0c or y1c <= y0c or alpha <= 0:
        return
    roi = frame[y0c:y1c, x0c:x1c]
    col = np.array(color, dtype=np.float32)
    roi[:] = np.clip(roi.astype(np.float32) * (1.0 - alpha) + col * alpha, 0, 255).astype(np.uint8)


def _draw_glow_circle(frame: np.ndarray, cx: int, cy: int, radius: int, color: tuple[int, int, int], intensity: float = 0.5):
    if radius <= 2 or intensity <= 0.01:
        return
    pad = radius + 6
    x0, y0 = max(0, cx - pad), max(0, cy - pad)
    x1, y1 = min(W, cx + pad), min(H, cy + pad)
    if x1 <= x0 or y1 <= y0:
        return
    yy, xx = np.ogrid[y0:y1, x0:x1]
    dist2 = (xx - cx) ** 2 + (yy - cy) ** 2
    falloff = np.exp(-dist2 / max(1.0, (radius * 0.55) ** 2)) * clamp01(intensity)
    roi = frame[y0:y1, x0:x1].astype(np.float32)
    col = np.array(color, dtype=np.float32)
    frame[y0:y1, x0:x1] = np.clip(roi + falloff[:, :, None] * col[None, None, :], 0, 255).astype(np.uint8)


def _draw_arrow_vec(
    frame: np.ndarray,
    p0: tuple[int, int],
    p1: tuple[int, int],
    color: tuple[int, int, int],
    thickness: int = 8,
    head_len: int = 24,
):
    x0, y0 = int(p0[0]), int(p0[1])
    x1, y1 = int(p1[0]), int(p1[1])
    dx, dy = x1 - x0, y1 - y0
    dist = math.hypot(dx, dy)
    if dist < 4:
        return
    ux, uy = dx / dist, dy / dist
    bx, by = x1 - ux * head_len, y1 - uy * head_len
    cv2.line(frame, (x0, y0), (int(bx), int(by)), color, thickness, cv2.LINE_AA)
    px, py = -uy, ux
    w_head = head_len * 0.58
    tri = np.array([
        [x1, y1],
        [int(bx + px * w_head), int(by + py * w_head)],
        [int(bx - px * w_head), int(by - py * w_head)],
    ], dtype=np.int32)
    cv2.fillPoly(frame, [tri], color, cv2.LINE_AA)


def _draw_dashed_line(frame: np.ndarray, p0: tuple[int, int], p1: tuple[int, int], color, thickness: int = 2, dash: int = 12):
    x0, y0 = int(p0[0]), int(p0[1])
    x1, y1 = int(p1[0]), int(p1[1])
    dist = math.hypot(x1 - x0, y1 - y0)
    if dist < 2:
        return
    steps = max(1, int(dist // (dash * 1.8)))
    for i in range(steps):
        u0 = (i * 1.8 * dash) / dist
        u1 = min(1.0, (i * 1.8 * dash + dash) / dist)
        a = (int(x0 + (x1 - x0) * u0), int(y0 + (y1 - y0) * u0))
        b = (int(x0 + (x1 - x0) * u1), int(y0 + (y1 - y0) * u1))
        cv2.line(frame, a, b, color, thickness, cv2.LINE_AA)


def _draw_concrete_slab(frame: np.ndarray, x0: int, y0: int, x1: int, y1: int, tint_warm: float = 0.0):
    x0, y0, x1, y1 = int(x0), int(y0), int(x1), int(y1)
    if x1 <= x0 or y1 <= y0:
        return
    base_col = np.array([104, 116, 134], dtype=np.float32)
    if tint_warm > 0:
        warm_col = np.array([218, 76, 52], dtype=np.float32)
        base_col = base_col * (1.0 - tint_warm * 0.65) + warm_col * (tint_warm * 0.65)
    c_fill = tuple(int(v) for v in base_col)
    c_border = (203, 213, 225) if tint_warm < 0.4 else (251, 146, 60)

    cv2.rectangle(frame, (x0, y0), (x1, y1), c_fill, -1)
    cv2.rectangle(frame, (x0, y0), (x1, min(y1, y0 + 14)), (148, 163, 184), -1)
    rebar_y1 = y0 + max(24, (y1 - y0) // 3)
    rebar_y2 = y1 - max(24, (y1 - y0) // 4)
    cv2.line(frame, (x0 + 14, rebar_y1), (x1 - 14, rebar_y1), (190, 205, 220), 4, cv2.LINE_AA)
    cv2.line(frame, (x0 + 14, rebar_y2), (x1 - 14, rebar_y2), (190, 205, 220), 4, cv2.LINE_AA)
    seed = (x0 * 31 + y0 * 17) & 0xFFFF
    step_x = max(24, (x1 - x0) // 10)
    step_y = max(22, (y1 - y0) // 5)
    for gx in range(x0 + 18, x1 - 16, step_x):
        for gy in range(y0 + 24, y1 - 16, step_y):
            h_val = ((gx * 73856093) ^ (gy * 19349663) ^ seed) % 7
            r = 2 + (h_val % 3)
            col_dot = (71, 85, 105) if h_val % 2 == 0 else (148, 163, 184)
            cv2.circle(frame, (gx + h_val * 2, gy + (h_val % 4)), r, col_dot, -1, cv2.LINE_AA)
    cv2.rectangle(frame, (x0, y0), (x1, y1), c_border, 3, cv2.LINE_AA)


def _draw_caliper_dim(frame: np.ndarray, x0: int, x1: int, y: int, color: tuple[int, int, int] = (56, 189, 248)):
    x0, x1, y = int(x0), int(x1), int(y)
    if x1 - x0 < 16:
        return
    cv2.line(frame, (x0, y - 16), (x0, y + 16), color, 3, cv2.LINE_AA)
    cv2.line(frame, (x1, y - 16), (x1, y + 16), color, 3, cv2.LINE_AA)
    cv2.line(frame, (x0 + 4, y), (x1 - 4, y), color, 3, cv2.LINE_AA)
    cv2.circle(frame, (x0 + 8, y), 5, color, -1, cv2.LINE_AA)
    cv2.circle(frame, (x1 - 8, y), 5, color, -1, cv2.LINE_AA)


def _draw_gear(frame: np.ndarray, cx: int, cy: int, r_outer: int, teeth: int, angle_rad: float, fill_col, border_col):
    pts = []
    r_inner = r_outer * 0.78
    steps = teeth * 4
    for i in range(steps):
        ang = angle_rad + (2.0 * math.pi * i) / steps
        phase = i % 4
        rad = r_outer if phase in (1, 2) else r_inner
        pts.append([int(cx + math.cos(ang) * rad), int(cy + math.sin(ang) * rad)])
    poly = np.array(pts, dtype=np.int32)
    cv2.fillPoly(frame, [poly], fill_col, cv2.LINE_AA)
    cv2.polylines(frame, [poly], True, border_col, 3, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy), int(r_outer * 0.42), (15, 23, 42), -1, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy), int(r_outer * 0.42), border_col, 3, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy), int(r_outer * 0.14), border_col, -1, cv2.LINE_AA)


def _draw_hazard_triangle(frame: np.ndarray, cx: int, cy: int, size: int, pulse: float, color=(245, 158, 11)):
    s = int(size * (0.94 + 0.08 * pulse))
    h_tri = int(s * 0.86)
    pts = np.array([
        [cx, cy - h_tri // 2],
        [cx - s // 2, cy + h_tri // 2],
        [cx + s // 2, cy + h_tri // 2],
    ], dtype=np.int32)
    cv2.fillPoly(frame, [pts], (45, 25, 12), cv2.LINE_AA)
    cv2.polylines(frame, [pts], True, color, 5, cv2.LINE_AA)
    cv2.line(frame, (cx, cy - h_tri // 6), (cx, cy + h_tri // 5), color, 6, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy + h_tri // 3), 4, color, -1, cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Motor 3D Isométrico & Primitivas Arquitectónicas / Terreno / Tuberías
# ---------------------------------------------------------------------------
def _iso(x: float, y: float, z: float, ox: int = 540, oy: int = 780, sx: float = 0.866, sy: float = 0.45) -> tuple[int, int]:
    """Proyección isométrica 3D real: +x derecha-abajo, +y izquierda-abajo, +z arriba."""
    px = ox + (x - y) * sx
    py = oy + (x + y) * sy - z
    return int(round(px)), int(round(py))


def _draw_iso_box(
    frame: np.ndarray,
    x: float, y: float, z: float,
    dx: float, dy: float, dz: float,
    ox: int = 540, oy: int = 780,
    col_top=(148, 163, 184),
    col_left=(71, 85, 105),
    col_right=(51, 65, 85),
    edge_col=(203, 213, 225),
    edge_w: int = 2,
    tilt_dz_right: float = 0.0,
    draw_top: bool = True,
):
    """Dibuja prisma 3D isométrico con 3 caras sombreadas (arriba, frente-izq, frente-der)."""
    # Vértices de base (z) y techo (z + dz); tilt baja/sube los vértices del extremo +x
    p000 = _iso(x, y, z, ox, oy)
    p100 = _iso(x + dx, y, z + tilt_dz_right, ox, oy)
    p110 = _iso(x + dx, y + dy, z + tilt_dz_right, ox, oy)
    p010 = _iso(x, y + dy, z, ox, oy)

    p001 = _iso(x, y, z + dz, ox, oy)
    p101 = _iso(x + dx, y, z + dz + tilt_dz_right, ox, oy)
    p111 = _iso(x + dx, y + dy, z + dz + tilt_dz_right, ox, oy)
    p011 = _iso(x, y + dy, z + dz, ox, oy)

    # Cara izquierda visible (y + dy)
    face_l = np.array([p010, p110, p111, p011], dtype=np.int32)
    cv2.fillPoly(frame, [face_l], col_left, cv2.LINE_AA)
    # Cara derecha visible (x + dx)
    face_r = np.array([p100, p110, p111, p101], dtype=np.int32)
    cv2.fillPoly(frame, [face_r], col_right, cv2.LINE_AA)
    # Cara superior
    if draw_top:
        face_t = np.array([p001, p101, p111, p011], dtype=np.int32)
        cv2.fillPoly(frame, [face_t], col_top, cv2.LINE_AA)
        cv2.polylines(frame, [face_t], True, edge_col, edge_w, cv2.LINE_AA)
    cv2.polylines(frame, [face_l], True, edge_col, edge_w, cv2.LINE_AA)
    cv2.polylines(frame, [face_r], True, edge_col, edge_w, cv2.LINE_AA)

    return {
        "p001": p001, "p101": p101, "p111": p111, "p011": p011,
        "p010": p010, "p110": p110, "p100": p100, "p000": p000,
    }


def _draw_iso_ground_lot(
    frame: np.ndarray,
    ox: int = 540, oy: int = 860,
    w: float = 380, d: float = 340,
    strata_h: float = 95,
    saturado: bool = False,
    t: float = 0.0,
):
    """Dibuja un corte 3D isométrico del terreno (superficie césped/lote + estratos de tierra)."""
    x0, y0 = -w / 2.0, -d / 2.0
    # Estrato profundo (arcilla / húmedo si saturado)
    col_sub_l = (20, 62, 102) if saturado else (56, 39, 26)
    col_sub_r = (14, 46, 82) if saturado else (42, 29, 20)
    _draw_iso_box(
        frame, x0, y0, -strata_h, w, d, strata_h * 0.72, ox=ox, oy=oy,
        col_top=(36, 88, 62), col_left=col_sub_l, col_right=col_sub_r,
        edge_col=(56, 189, 248) if saturado else (120, 90, 65), edge_w=2, draw_top=False,
    )
    # Estrato superior suelo vegetal + césped técnico verde-azulado
    col_top_lot = (24, 58, 64) if saturado else (22, 68, 56)
    _draw_iso_box(
        frame, x0, y0, -strata_h * 0.28, w, d, strata_h * 0.28, ox=ox, oy=oy,
        col_top=col_top_lot,
        col_left=(72, 52, 36), col_right=(54, 39, 27),
        edge_col=(52, 211, 153) if not saturado else (56, 189, 248), edge_w=2,
    )
    # Punteado de grava / ondas freáticas si está saturado
    if saturado:
        for k in range(5):
            fy = -strata_h * 0.8 + k * 12
            p_a = _iso(x0 + 18, y0 + d, fy + math.sin(t * 4.0 + k) * 3, ox, oy)
            p_b = _iso(x0 + w - 18, y0 + d, fy - math.sin(t * 4.0 + k) * 3, ox, oy)
            cv2.line(frame, p_a, p_b, (56, 189, 248), 2, cv2.LINE_AA)
            p_c = _iso(x0 + w, y0 + 18, fy - math.sin(t * 4.0 + k) * 3, ox, oy)
            p_d = _iso(x0 + w, y0 + d - 18, fy + math.sin(t * 4.0 + k) * 3, ox, oy)
            cv2.line(frame, p_c, p_d, (14, 165, 233), 2, cv2.LINE_AA)


def _draw_iso_house(
    frame: np.ndarray,
    ox: int = 540, oy: int = 815,
    w: float = 220, d: float = 175, h_wall: float = 135,
    roof_style: str = "pendiente",  # "pendiente" | "dos_aguas" | "plano"
    pendiente_px: float = 34.0,
    water_film: bool = True,
    crack_p: float = 0.0,
    moisture_p: float = 0.0,
    tilt_dz: float = 0.0,
    t: float = 0.0,
):
    """Dibuja una vivienda arquitectónica en 3D isométrico con ventanas, techo, canaleta y daños opcionales."""
    x0, y0 = -w / 2.0, -d / 2.0
    # Cimiento zapata asomando sobre terreno
    _draw_iso_box(
        frame, x0 - 10, y0 - 10, 0, w + 20, d + 20, 20, ox=ox, oy=oy,
        col_top=(148, 163, 184), col_left=(90, 102, 118), col_right=(71, 85, 105),
        edge_col=(203, 213, 225), edge_w=2, tilt_dz_right=tilt_dz,
    )
    # Cuerpo principal de la casa
    col_wl = (68, 92, 122) if moisture_p < 0.2 else (48, 72, 108)
    col_wr = (46, 65, 92) if moisture_p < 0.2 else (32, 54, 86)
    _draw_iso_box(
        frame, x0, y0, 20, w, d, h_wall, ox=ox, oy=oy,
        col_top=(100, 116, 139), col_left=col_wl, col_right=col_wr,
        edge_col=(203, 213, 225), edge_w=2, tilt_dz_right=tilt_dz,
    )

    # Ventanas iluminadas en cara frente-izquierda (y = y0 + d)
    for wx_frac in (0.22, 0.62):
        wx0 = x0 + w * wx_frac
        wx1 = wx0 + w * 0.18
        wz0 = 20 + h_wall * 0.34
        wz1 = 20 + h_wall * 0.72
        t_r0 = tilt_dz * wx_frac
        t_r1 = tilt_dz * (wx_frac + 0.18)
        wpoly = np.array([
            _iso(wx0, y0 + d, wz0 + t_r0, ox, oy),
            _iso(wx1, y0 + d, wz0 + t_r1, ox, oy),
            _iso(wx1, y0 + d, wz1 + t_r1, ox, oy),
            _iso(wx0, y0 + d, wz1 + t_r0, ox, oy),
        ], dtype=np.int32)
        cv2.fillPoly(frame, [wpoly], (186, 230, 253) if crack_p < 0.4 else (127, 29, 29), cv2.LINE_AA)
        cv2.polylines(frame, [wpoly], True, (248, 250, 252), 2, cv2.LINE_AA)

    # Puerta en cara frente-derecha (x = x0 + w)
    dy0 = y0 + d * 0.36
    dy1 = dy0 + d * 0.28
    dpoly = np.array([
        _iso(x0 + w, dy0, 22 + tilt_dz, ox, oy),
        _iso(x0 + w, dy1, 22 + tilt_dz, ox, oy),
        _iso(x0 + w, dy1, 20 + h_wall * 0.65 + tilt_dz, ox, oy),
        _iso(x0 + w, dy0, 20 + h_wall * 0.65 + tilt_dz, ox, oy),
    ], dtype=np.int32)
    cv2.fillPoly(frame, [dpoly], (245, 158, 11) if crack_p < 0.4 else (120, 53, 15), cv2.LINE_AA)
    cv2.polylines(frame, [dpoly], True, (254, 243, 199), 2, cv2.LINE_AA)

    # Manchas ascendentes de humedad si moisture_p > 0
    if moisture_p > 0.05:
        mh = 20 + h_wall * 0.55 * clamp01(moisture_p)
        mpoly = np.array([
            _iso(x0, y0 + d, 20, ox, oy),
            _iso(x0 + w, y0 + d, 20 + tilt_dz, ox, oy),
            _iso(x0 + w, y0 + d, mh + tilt_dz, ox, oy),
            _iso(x0, y0 + d, mh * 0.72, ox, oy),
        ], dtype=np.int32)
        ov_l = frame.copy()
        cv2.fillPoly(ov_l, [mpoly], (14, 165, 233), cv2.LINE_AA)
        cv2.addWeighted(ov_l, 0.36, frame, 0.64, 0, frame)

    # Grietas escalonadas en fachada si crack_p > 0.05
    if crack_p > 0.05:
        nodes = [
            _iso(x0 + w * 0.48, y0 + d, 25 + tilt_dz * 0.5, ox, oy),
            _iso(x0 + w * 0.52, y0 + d, 52 + tilt_dz * 0.5, ox, oy),
            _iso(x0 + w * 0.44, y0 + d, 82 + tilt_dz * 0.4, ox, oy),
            _iso(x0 + w * 0.55, y0 + d, 112 + tilt_dz * 0.5, ox, oy),
            _iso(x0 + w * 0.49, y0 + d, h_wall + 14 + tilt_dz * 0.5, ox, oy),
        ]
        n_seg = max(2, int(round(clamp01(crack_p) * len(nodes))))
        pts_c = np.array(nodes[:n_seg], dtype=np.int32)
        cv2.polylines(frame, [pts_c], False, (239, 68, 68), 6, cv2.LINE_AA)
        cv2.polylines(frame, [pts_c], False, (254, 226, 226), 2, cv2.LINE_AA)

    # Techo 3D según estilo
    z_eave = 20 + h_wall
    over = 14.0
    if roof_style == "pendiente":
        # Techo inclinado desde x0 (alto) hacia x0 + w (bajo) para demostrar pendiente del 2%
        z_hi = z_eave + pendiente_px
        z_lo = z_eave + tilt_dz
        p_t0 = _iso(x0 - over, y0 - over, z_hi, ox, oy)
        p_t1 = _iso(x0 + w + over, y0 - over, z_lo, ox, oy)
        p_t2 = _iso(x0 + w + over, y0 + d + over, z_lo, ox, oy)
        p_t3 = _iso(x0 - over, y0 + d + over, z_hi, ox, oy)

        # Faldón grueso del tejado (espesor)
        p_b1 = _iso(x0 + w + over, y0 - over, z_lo - 10, ox, oy)
        p_b2 = _iso(x0 + w + over, y0 + d + over, z_lo - 10, ox, oy)
        p_b3 = _iso(x0 - over, y0 + d + over, z_hi - 10, ox, oy)

        cv2.fillPoly(frame, [np.array([p_t3, p_t2, p_b2, p_b3], np.int32)], (51, 65, 85), cv2.LINE_AA)
        cv2.fillPoly(frame, [np.array([p_t1, p_t2, p_b2, p_b1], np.int32)], (30, 41, 59), cv2.LINE_AA)
        col_roof = (14, 116, 144) if water_film else (100, 116, 139)
        cv2.fillPoly(frame, [np.array([p_t0, p_t1, p_t2, p_t3], np.int32)], col_roof, cv2.LINE_AA)
        cv2.polylines(frame, [np.array([p_t0, p_t1, p_t2, p_t3], np.int32)], True, (103, 232, 249) if water_film else (226, 232, 240), 3, cv2.LINE_AA)

        # Líneas de corriente paralelas deslizando sobre el tejado en 3D
        if water_film:
            for s_idx in range(3):
                yy_frac = 0.22 + s_idx * 0.28
                sy = y0 + d * yy_frac
                u = (t * 0.9 + s_idx * 0.25) % 1.0
                sx_cur = x0 + (w - 8) * u
                sz_cur = z_hi + (z_lo - z_hi) * u + 4
                p_drop = _iso(sx_cur, sy, sz_cur, ox, oy)
                cv2.circle(frame, p_drop, 6, (186, 230, 253), -1, cv2.LINE_AA)
                cv2.line(frame, _iso(x0 + 8, sy, z_hi + 2, ox, oy), _iso(x0 + w - 4, sy, z_lo + 2, ox, oy), (56, 189, 248), 2, cv2.LINE_AA)

        # Canaleta 3D en el borde bajo + tubo bajante
        gut0 = _iso(x0 + w + over + 4, y0 - over, z_lo - 6, ox, oy)
        gut1 = _iso(x0 + w + over + 4, y0 + d + over, z_lo - 6, ox, oy)
        cv2.line(frame, gut0, gut1, (56, 189, 248), 10, cv2.LINE_AA)
        down_top = gut1
        down_bot = _iso(x0 + w + over + 8, y0 + d + over, 4 + tilt_dz, ox, oy)
        down_out = _iso(x0 + w + over + 48, y0 + d + over, 2 + tilt_dz, ox, oy)
        cv2.line(frame, down_top, down_bot, (14, 165, 233), 9, cv2.LINE_AA)
        cv2.line(frame, down_bot, down_out, (56, 189, 248), 9, cv2.LINE_AA)
    elif roof_style == "dos_aguas":
        z_peak = z_eave + 52
        ym = y0 + d / 2.0
        p_ridge0 = _iso(x0 - over, ym, z_peak, ox, oy)
        p_ridge1 = _iso(x0 + w + over, ym, z_peak + tilt_dz, ox, oy)
        p_l0 = _iso(x0 - over, y0 - over, z_eave, ox, oy)
        p_l1 = _iso(x0 + w + over, y0 - over, z_eave + tilt_dz, ox, oy)
        p_r0 = _iso(x0 - over, y0 + d + over, z_eave, ox, oy)
        p_r1 = _iso(x0 + w + over, y0 + d + over, z_eave + tilt_dz, ox, oy)
        # Vertiente frontal izquierda visible + tímpano derecho
        cv2.fillPoly(frame, [np.array([p_ridge0, p_ridge1, p_l1, p_l0], np.int32)], (51, 65, 85), cv2.LINE_AA)
        cv2.fillPoly(frame, [np.array([p_ridge0, p_ridge1, p_r1, p_r0], np.int32)], (14, 116, 144) if water_film else (100, 116, 139), cv2.LINE_AA)
        cv2.fillPoly(frame, [np.array([p_ridge1, p_l1, p_r1], np.int32)], col_wr, cv2.LINE_AA)
        cv2.polylines(frame, [np.array([p_ridge0, p_ridge1, p_r1, p_r0], np.int32)], True, (186, 230, 253), 2, cv2.LINE_AA)
    else:
        # Techo plano (con agua estancada opcional)
        _draw_iso_box(
            frame, x0 - 8, y0 - 8, z_eave, w + 16, d + 16, 14, ox=ox, oy=oy,
            col_top=(239, 68, 68) if crack_p > 0.3 else (30, 58, 95),
            col_left=(71, 85, 105), col_right=(51, 65, 85),
            edge_col=(248, 113, 113) if crack_p > 0.3 else (56, 189, 248), edge_w=2, tilt_dz_right=tilt_dz,
        )
        if water_film:
            pool_poly = np.array([
                _iso(x0 + 14, y0 + 14, z_eave + 15, ox, oy),
                _iso(x0 + w - 14, y0 + 14, z_eave + 15 + tilt_dz, ox, oy),
                _iso(x0 + w - 14, y0 + d - 14, z_eave + 15 + tilt_dz, ox, oy),
                _iso(x0 + 14, y0 + d - 14, z_eave + 15, ox, oy),
            ], dtype=np.int32)
            cv2.fillPoly(frame, [pool_poly], (14, 165, 233), cv2.LINE_AA)


def _draw_iso_building(
    frame: np.ndarray,
    ox: int = 540, oy: int = 860,
    w: float = 210, d: float = 175, floors: int = 3, floor_h: float = 68,
    tilt_dz: float = 0.0,
    crack_p: float = 0.0,
    moisture_p: float = 0.0,
):
    """Dibuja un edificio moderno de múltiples pisos en 3D isométrico con zapata y grietas opcionales."""
    total_h = floors * floor_h
    x0, y0 = -w / 2.0, -d / 2.0

    # Zapata de cimentación visible en corte
    _draw_iso_box(
        frame, x0 - 16, y0 - 16, -24, w + 32, d + 32, 24, ox=ox, oy=oy,
        col_top=(148, 163, 184), col_left=(71, 85, 105), col_right=(51, 65, 85),
        edge_col=(203, 213, 225), edge_w=2, tilt_dz_right=tilt_dz,
    )
    # Cuerpo edificio
    _draw_iso_box(
        frame, x0, y0, 0, w, d, total_h, ox=ox, oy=oy,
        col_top=(51, 65, 85), col_left=(58, 76, 104), col_right=(38, 52, 74),
        edge_col=(148, 163, 184), edge_w=2, tilt_dz_right=tilt_dz,
    )

    # Ventanas por piso en ambas caras visibles
    for fl in range(floors):
        z_bot = fl * floor_h + floor_h * 0.25
        z_top = fl * floor_h + floor_h * 0.72
        for col_i in range(3):
            fx0 = 0.12 + col_i * 0.28
            fx1 = fx0 + 0.18
            tr0, tr1 = tilt_dz * fx0, tilt_dz * fx1
            wpoly_l = np.array([
                _iso(x0 + w * fx0, y0 + d, z_bot + tr0, ox, oy),
                _iso(x0 + w * fx1, y0 + d, z_bot + tr1, ox, oy),
                _iso(x0 + w * fx1, y0 + d, z_top + tr1, ox, oy),
                _iso(x0 + w * fx0, y0 + d, z_top + tr0, ox, oy),
            ], dtype=np.int32)
            win_col = (125, 211, 252) if (fl + col_i) % 2 == 0 else (56, 189, 248)
            if crack_p > 0.45 and fl == 0 and col_i == 1:
                win_col = (248, 113, 113)
            cv2.fillPoly(frame, [wpoly_l], win_col, cv2.LINE_AA)
            cv2.polylines(frame, [wpoly_l], True, (226, 232, 240), 1, cv2.LINE_AA)

            fy0 = 0.14 + col_i * 0.28
            fy1 = fy0 + 0.18
            wpoly_r = np.array([
                _iso(x0 + w, y0 + d * fy0, z_bot + tilt_dz, ox, oy),
                _iso(x0 + w, y0 + d * fy1, z_bot + tilt_dz, ox, oy),
                _iso(x0 + w, y0 + d * fy1, z_top + tilt_dz, ox, oy),
                _iso(x0 + w, y0 + d * fy0, z_top + tilt_dz, ox, oy),
            ], dtype=np.int32)
            cv2.fillPoly(frame, [wpoly_r], (30, 96, 145), cv2.LINE_AA)
            cv2.polylines(frame, [wpoly_r], True, (148, 163, 184), 1, cv2.LINE_AA)

    if moisture_p > 0.05:
        mh = total_h * 0.34 * clamp01(moisture_p)
        mpoly = np.array([
            _iso(x0, y0 + d, 0, ox, oy),
            _iso(x0 + w, y0 + d, tilt_dz, ox, oy),
            _iso(x0 + w, y0 + d, mh + tilt_dz, ox, oy),
            _iso(x0, y0 + d, mh * 0.8, ox, oy),
        ], dtype=np.int32)
        ov_b = frame.copy()
        cv2.fillPoly(ov_b, [mpoly], (14, 165, 233), cv2.LINE_AA)
        cv2.addWeighted(ov_b, 0.35, frame, 0.65, 0, frame)

    if crack_p > 0.05:
        nodes = [
            _iso(x0 + w * 0.38, y0 + d, 10, ox, oy),
            _iso(x0 + w * 0.48, y0 + d, total_h * 0.22 + tilt_dz * 0.4, ox, oy),
            _iso(x0 + w * 0.40, y0 + d, total_h * 0.45 + tilt_dz * 0.4, ox, oy),
            _iso(x0 + w * 0.56, y0 + d, total_h * 0.66 + tilt_dz * 0.5, ox, oy),
            _iso(x0 + w * 0.50, y0 + d, total_h * 0.88 + tilt_dz * 0.5, ox, oy),
        ]
        n_seg = max(2, int(round(clamp01(crack_p) * len(nodes))))
        pts_c = np.array(nodes[:n_seg], dtype=np.int32)
        cv2.polylines(frame, [pts_c], False, (239, 68, 68), 8, cv2.LINE_AA)
        cv2.polylines(frame, [pts_c], False, (254, 242, 242), 3, cv2.LINE_AA)


def _draw_topdown_lot_grid(frame: np.ndarray, x0: int, y0: int, x1: int, y1: int, accent=(56, 189, 248)):
    """Marco arquitectónico CAD para planos en planta vistos desde arriba."""
    cv2.rectangle(frame, (x0, y0), (x1, y1), (11, 21, 38), -1)
    # Lote / lindero discontinuo
    _draw_dashed_line(frame, (x0 + 18, y0 + 18), (x1 - 18, y0 + 18), accent, 2, 16)
    _draw_dashed_line(frame, (x1 - 18, y0 + 18), (x1 - 18, y1 - 18), accent, 2, 16)
    _draw_dashed_line(frame, (x1 - 18, y1 - 18), (x0 + 18, y1 - 18), accent, 2, 16)
    _draw_dashed_line(frame, (x0 + 18, y1 - 18), (x0 + 18, y0 + 18), accent, 2, 16)
    # Brújula Norte discreta en esquina superior izquierda del plano
    nx, ny = x0 + 52, y0 + 54
    cv2.circle(frame, (nx, ny), 20, (15, 32, 60), -1, cv2.LINE_AA)
    cv2.circle(frame, (nx, ny), 20, accent, 2, cv2.LINE_AA)
    cv2.fillPoly(frame, [np.array([[nx, ny - 15], [nx - 7, ny + 8], [nx, ny + 3], [nx + 7, ny + 8]], np.int32)], accent, cv2.LINE_AA)


def _draw_pipe_run(
    frame: np.ndarray,
    pts: list[tuple[int, int]],
    diam: int = 24,
    col_pipe=(30, 82, 128),
    col_edge=(56, 189, 248),
    perforado: bool = False,
    t: float = 0.0,
    flow_col=(186, 230, 253),
    n_beads: int = 8,
):
    """Dibuja tubería continua con uniones, perforaciones y bolitas de caudal animadas."""
    if len(pts) < 2:
        return
    arr = np.array(pts, dtype=np.int32)
    cv2.polylines(frame, [arr], False, col_edge, diam + 6, cv2.LINE_AA)
    cv2.polylines(frame, [arr], False, col_pipe, diam, cv2.LINE_AA)
    # Brillo central longitudinal
    cv2.polylines(frame, [arr], False, (14, 116, 144), max(3, diam // 3), cv2.LINE_AA)

    # Longitud acumulada para repartir perforaciones y caudal fluido
    segs = []
    tot_len = 0.0
    for i in range(len(pts) - 1):
        d = math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
        segs.append((pts[i], pts[i + 1], tot_len, d))
        tot_len += d
    if tot_len < 1.0:
        return

    def _pt_at(u_len: float) -> tuple[int, int]:
        for a, b, s0, d in segs:
            if u_len <= s0 + d or b == pts[-1]:
                frac = clamp01((u_len - s0) / max(1e-4, d))
                return int(a[0] + (b[0] - a[0]) * frac), int(a[1] + (b[1] - a[1]) * frac)
        return pts[-1]

    if perforado:
        step = max(22, int(diam * 1.15))
        for s_pos in range(18, int(tot_len) - 12, step):
            px, py = _pt_at(float(s_pos))
            cv2.circle(frame, (px, py), max(3, diam // 6), (250, 204, 21), -1, cv2.LINE_AA)

    # Codos / registros en vértices intermedios
    for vx, vy in pts[1:-1]:
        cv2.circle(frame, (vx, vy), diam // 2 + 5, (15, 23, 42), -1, cv2.LINE_AA)
        cv2.circle(frame, (vx, vy), diam // 2 + 5, col_edge, 3, cv2.LINE_AA)

    # Caudal animado siguiendo toda la polilínea
    for k in range(n_beads):
        u = ((t * 0.42 + k / float(max(1, n_beads))) % 1.0) * tot_len
        bx, by = _pt_at(u)
        cv2.circle(frame, (bx, by), max(4, diam // 3), flow_col, -1, cv2.LINE_AA)


@lru_cache(maxsize=8)
def _build_base_canvas(acento: str) -> np.ndarray:
    tema = TEMAS_ACENTO.get(acento, TEMAS_ACENTO["ciencia"])
    bg = np.zeros((H, W, 3), dtype=np.float32)
    base_rgb = np.array([8.0, 14.0, 27.0], dtype=np.float32)
    glow_rgb = np.array(tema["luz_bg"], dtype=np.float32)

    yy = np.linspace(0.0, 1.0, H, dtype=np.float32)[:, None]
    xx = np.linspace(0.0, 1.0, W, dtype=np.float32)[None, :]
    dist2 = ((xx - 0.5) * 1.15) ** 2 + ((yy - 0.40) * 1.45) ** 2
    rad = np.exp(-dist2 * 3.2)[:, :, None]
    bot_fade = np.clip((yy - 0.66) * 2.5, 0.0, 1.0)[:, :, None]

    bg[:] = base_rgb + rad * (glow_rgb - base_rgb) * 1.45
    bg = bg * (1.0 - 0.35 * bot_fade)
    out = np.clip(bg, 0, 255).astype(np.uint8)

    for x in range(0, W, 60):
        cv2.line(out, (x, 0), (x, 1255), (17, 29, 48), 1)
    for y in range(0, 1260, 60):
        cv2.line(out, (0, y), (W, y), (17, 29, 48), 1)

    prim = tema["primario"]
    dim_prim = tuple(int(c * 0.35) for c in prim)
    cv2.rectangle(out, (44, 62), (W - 44, 1244), dim_prim, 2, cv2.LINE_AA)
    m = 24
    for cx, cy in [(44, 62), (W - 44, 62), (44, 1244), (W - 44, 1244)]:
        cv2.line(out, (cx - m, cy), (cx + m, cy), prim, 3, cv2.LINE_AA)
        cv2.line(out, (cx, cy - m), (cx, cy + m), prim, 3, cv2.LINE_AA)
    return out


# ---------------------------------------------------------------------------
# Planificador Inteligente de Escenas (Gemini + Diversidad + Fallback Local)
# ---------------------------------------------------------------------------
def _cargar_claves_gemini(root: Path) -> list[str]:
    claves = []
    aqui = Path(__file__).resolve().parent
    core_dir = aqui.parent / "core"
    try:
        if str(core_dir) not in sys.path:
            sys.path.insert(0, str(core_dir))
        import diseccion_multimodal as dm
        claves = dm.obtener_claves_activas()
    except Exception:
        pass

    if not claves:
        for base in (root, root.parent, aqui.parent):
            for fname in ("config_gemini.json", "gemini_config.json"):
                f = base / fname
                if f.is_file():
                    try:
                        data = json.loads(f.read_text(encoding="utf-8"))
                        k = (data.get("gemini_api_key") or data.get("api_key") or "").strip()
                        if k and not k.startswith("PEGA_"):
                            claves.append(k)
                    except Exception:
                        pass
    return claves


def _detectar_tema_global(beats: list[dict]) -> str:
    texto_all = " ".join((b.get("frase") or "") for b in beats).lower()
    if any(k in texto_all for k in ("puente", "junta", "dilatacion", "dilatación", "viga", "expansión", "expansion")):
        return "puente_termico"
    if any(k in texto_all for k in ("tejado", "techo", "pendiente", "canaleta", "canales", "impermeable")):
        return "tejado_casa"
    if any(k in texto_all for k in ("cimento", "cimiento", "hidrostática", "hidrostatica", "drenaje", "geotextil", "grava", "densidad", "suelo")):
        return "cimientos_drenaje"
    if any(k in texto_all for k in ("casa", "vivienda", "edificio", "construc", "pared", "muro", "tuberia", "tubería")):
        return "obra_general"
    return "obra_general"


def _extraer_titulo_y_kpi_local(frase: str, idx: int) -> tuple[str, str]:
    f = frase.strip()
    low = f.lower()

    m_pct = re.search(r"(\d+(?:[.,]\d+)?)\s*(?:%|por ciento)", low)
    if m_pct:
        return f"{m_pct.group(1)}%", "PENDIENTE" if "pendiente" in low else "DATO %"
    if "dos por ciento" in low:
        return "2.0 %", "PENDIENTE"
    if "milim" in low:
        return "ΔL (mm)", "ESCALA mm"
    if "calor" in low or "temperatura" in low:
        return "+48 °C", "TÉRMICO"
    if "segundos" in low:
        return "FALLA", "IMPACTO"
    if "presion" in low or "presión" in low or "empuja" in low or "fuerza" in low:
        return "kPa ↑", "SUBPRESIÓN"
    if "años" in low:
        return "< 5 AÑOS", "VIDA ÚTIL"
    if "litros" in low:
        return "+300 L", "DESVÍO"
    if "fricc" in low:
        return "LOW μ", "FLUIDO LIBRE"

    m_cta = re.search(r"(?:palabra|comenta|escribe|deja)\s+(?:la palabra\s+)?[\"'«]?([a-záéíóúñ]{3,16})[\"'»]?", low)
    if m_cta:
        return m_cta.group(1).upper(), "COMENTA"

    return f"PLANO {idx + 1:02d}", "ARQUITECTURA"


def _extraer_etiquetas_frase(frase: str, defaults: list[str]) -> list[str]:
    clean = re.sub(r"[¿?¡!.,;:\"'()]", " ", frase).strip()
    stop = {
        "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al", "y",
        "o", "que", "porque", "para", "con", "sin", "en", "por", "sobre", "entre",
        "como", "si", "no", "mas", "más", "este", "esta", "estas", "estos", "esa",
        "ese", "te", "su", "sus", "tu", "tus", "es", "son", "puede", "pueden", "hacia",
        "detras", "detrás", "desde", "antes", "ahora", "mismo", "toda", "todo", "muchas",
        "miles", "cientos", "sino", "cuando", "bajo", "menos", "paso",
    }
    palabras = [p.upper() for p in clean.split() if len(p) >= 4 and p.lower() not in stop]
    out = []
    for p in palabras:
        if p not in out:
            out.append(p)
        if len(out) >= 3:
            break
    while len(out) < len(defaults):
        cand = defaults[len(out)]
        if cand not in out:
            out.append(cand)
        else:
            break
    return out[:3]


def _normalizar_plantilla_alias(pl: str) -> str:
    alias = {
        "tejado_pendiente": "casa_isometrica_tejado",
        "puente_calor": "puente_isometrico_calor",
        "junta_dilatacion": "junta_dilatacion_3d",
        "flujo_general": "desvio_hidraulico_planta",
    }
    p = alias.get(pl, pl)
    return p if p in PLANTILLAS_VALIDAS else "casa_isometrica_tejado"


def _asegurar_diversidad_escenas(plan: list[dict], beats: list[dict], tema_global: str) -> list[dict]:
    """Garantiza cero clips repetitivos y alternancia constante de perspectivas visuales."""
    pool = list(POOLS_POR_TEMA.get(tema_global, POOLS_POR_TEMA["obra_general"]))
    # Añadir complementos arquitectónicos por si hay más de 11 escenas
    for extra in POOLS_POR_TEMA["obra_general"]:
        if extra not in pool:
            pool.append(extra)

    usadas = set()
    prev_persp = None
    out = []

    for idx, item in enumerate(plan):
        pl = _normalizar_plantilla_alias(str(item.get("plantilla", "")).strip())
        # Nunca reutilizar una escena genérica si la narración pide cierre/pregunta al final
        persp, persp_label = PERSPECTIVA_POR_PLANTILLA.get(pl, ("isometrica", "VISTA 3D"))

        # Si ya se usó esa plantilla en otra escena del mismo Short (excepto composicion_arquitectonica si tiene objetos únicos)
        es_custom = (pl == "composicion_arquitectonica" and bool((item.get("dibujo") or {}).get("elementos")))
        necesita_cambio = (not es_custom and pl in usadas) or (persp == prev_persp)

        if necesita_cambio and pl not in ("cta_comenta", "pregunta_panorama"):
            # Elegir primero una del pool temático que NO haya sido usada y cambie la perspectiva
            candidata = next(
                (c for c in pool if c not in usadas and PERSPECTIVA_POR_PLANTILLA.get(c, ("", ""))[0] != prev_persp),
                None,
            )
            if not candidata:
                candidata = next((c for c in pool if c not in usadas), None)
            if not candidata:
                candidata = next(
                    (c for c in PLANTILLAS_VALIDAS if c not in usadas and c not in ("cta_comenta", "engranajes_sistema")),
                    pl,
                )
            pl = candidata

        if not es_custom:
            usadas.add(pl)
        persp, persp_label = PERSPECTIVA_POR_PLANTILLA.get(pl, ("isometrica", "VISTA 3D"))
        prev_persp = persp

        item_norm = dict(item)
        item_norm["orden"] = idx + 1
        item_norm["plantilla"] = pl
        item_norm["perspectiva_label"] = item_norm.get("perspectiva_label") or persp_label
        item_norm["tema_global"] = tema_global
        out.append(item_norm)

    return out


def _planificar_local(beats: list[dict], tema_global: str = None) -> list[dict]:
    tema_global = tema_global or _detectar_tema_global(beats)
    plan = []

    for i, b in enumerate(beats):
        frase = (b.get("frase") or "").strip()
        low = frase.lower()

        plantilla = "casa_isometrica_tejado"
        acento = "ciencia"
        titulo = ""
        subtitulo = "PLANO ARQUITECTÓNICO"
        kpi = ""
        etiquetas = []
        cta_palabra = ""

        if any(k in low for k in ("comenta", "comentarios", "escribe la palabra", "deja la palabra", "compartir")):
            plantilla = "cta_comenta"
            acento = "cta"
            m_kw = re.search(r"palabra\s+[\"'«]?([a-záéíóúñ]{3,16})[\"'»]?", low)
            cta_palabra = m_kw.group(1).upper() if m_kw else "PLANO"
            titulo = f"COMENTA: {cta_palabra}"
            subtitulo = "RECIBE EL PLANO"
            kpi = cta_palabra
            etiquetas = [cta_palabra, "COMENTARIOS", "GUÍA COMPLETA"]

        elif (i >= len(beats) - 3) and ("?" in frase or "¿" in frase or "sorprende" in low or "conocias" in low or "conocías" in low or "opinas" in low):
            plantilla = "pregunta_panorama"
            acento = "ciencia"
            titulo = "DISEÑO INTELIGENTE" if tema_global != "puente_termico" else "FÍSICA DE PUENTES"
            subtitulo = "PRINCIPIO CLAVE"
            kpi = "¿POR QUÉ?"
            etiquetas = _extraer_etiquetas_frase(frase, ["PENDIENTE", "DRENAJE", "ESTRUCTURA"])

        elif any(k in low for k in ("colapsan", "colapso", "peso del agua", "ruina")) and ("tejado" in low or "viviend" in low or "casa" in low or tema_global == "tejado_casa"):
            plantilla = "estancamiento_colapso_techo"
            acento = "peligro"
            titulo = "AGUA ESTANCADA"
            subtitulo = "SOBRECARGA EN LOSA"
            kpi = "DEFLEXIÓN !"
            etiquetas = ["SIN PENDIENTE", "BOLSA DE AGUA", "COLAPSO"]

        elif any(k in low for k in ("evacuac", "destruye los cimientos", "desde adentro", "mal nivel")) or ("cimientos" in low and tema_global == "tejado_casa"):
            plantilla = "corte_casa_terreno_humedad"
            acento = "alerta"
            titulo = "FILTRACIÓN EN BASE"
            subtitulo = "CASA Y SUBSUELO"
            kpi = "HUMEDAD ↑"
            etiquetas = ["ESCORRENTÍA", "SUBSUELO HÚMEDO", "CIMIENTO"]

        elif any(k in low for k in ("capas impermeables", "impermeable", "membrana")) and any(k in low for k in ("canales", "techo", "tejado", "capas")):
            plantilla = "capas_impermeables_3d"
            acento = "solucion"
            titulo = "CAPAS IMPERMEABLES"
            subtitulo = "EXPLOSIÓN 3D"
            kpi = "SEGURO 3D"
            etiquetas = ["BARRERA AGUA", "PENDIENTE 2%", "CANALETA"]

        elif any(k in low for k in ("desvia", "desvía", "cientos de litros", "lejos de la estructura")):
            plantilla = "desvio_hidraulico_planta"
            acento = "solucion"
            titulo = "DESVÍO DE CAUDAL"
            subtitulo = "VISTA EN PLANTA"
            kpi = "+300 L"
            etiquetas = ["CANALES", "DESVÍO", "CIMIENTO SECO"]

        elif any(k in low for k in ("fricc", "correr", "dejarla correr")):
            plantilla = "fluido_sin_friccion"
            acento = "solucion"
            titulo = "FLUJO SIN FRICCIÓN"
            subtitulo = "HIDRODINÁMICA"
            kpi = "FLUJO OK"
            etiquetas = ["CANAL LISO", "VELOCIDAD ↑", "CERO ATASCO"]

        elif any(k in low for k in ("tejado", "pendiente", "2%", "dos por ciento")) and i == 0:
            plantilla = "casa_isometrica_tejado"
            acento = "ciencia"
            titulo = "PENDIENTE DEL 2%"
            subtitulo = "CASA EN 3D"
            kpi = "2.0 %"
            etiquetas = ["TEJADO 2%", "CANALETA 3D", "BAJANTE"]

        elif any(k in low for k in ("salvar toda tu casa", "resistir el agua", "arquitectura")):
            plantilla = "plano_planta_tejado" if "arquitect" in low else "comparativa_viviendas_3d"
            acento = "ciencia"
            titulo = "PLANO DE CUBIERTA" if "arquitect" in low else "PROTECCIÓN TOTAL"
            subtitulo = "DISEÑO EN PLANTA" if "arquitect" in low else "DOBLE ISOMÉTRICO"
            kpi = "EVACUACIÓN"
            etiquetas = ["CUMBRERA", "BAJANTES", "LOTE SECO"]

        elif any(k in low for k in ("agrietando", "paredes", "edificios modernos", "silencioso")):
            plantilla = "edificio_moderno_grietas"
            acento = "peligro"
            titulo = "GRIETAS EN FACHADA"
            subtitulo = "EDIFICIO MODERNO"
            kpi = "DAÑO !"
            etiquetas = ["ASENTAMIENTO", "FISURA MURO", "BASE HÚMEDA"]

        elif any(k in low for k in ("hidrostática", "hidrostatica", "satura", "hacia arriba", "descomunal")):
            plantilla = "presion_hidrostatica"
            acento = "peligro"
            titulo = "PRESIÓN HIDROSTÁTICA"
            subtitulo = "SUBSUELO SATURADO"
            kpi = "kPa ↑"
            etiquetas = ["NIVEL FREÁTICO", "EMPUJE ↑", "ZAPATA"]

        elif any(k in low for k in ("tubo", "drenaje")) and "geotextil" not in low:
            plantilla = "perfil_tuberia_pendiente"
            acento = "solucion"
            titulo = "TUBERÍA DE DRENAJE"
            subtitulo = "PERFIL LONGITUDINAL"
            kpi = "2% PEND."
            etiquetas = ["TUBO PERFORADO", "GRAVA LAVADA", "DESCARGA"]

        elif any(k in low for k in ("geotextil", "filtra", "grava", "antes de que dañe")):
            plantilla = "drenaje_cimientos"
            acento = "solucion"
            titulo = "FILTRO GEOTEXTIL"
            subtitulo = "CORTE DE ZANJA"
            kpi = "FILTRADO"
            etiquetas = ["CIMIENTO", "MALLA GEOTEXTIL", "TUBO"]

        elif any(k in low for k in ("densidad", "terreno", "cálculo", "calculo")):
            plantilla = "densidad_suelo_estratos"
            acento = "alerta"
            titulo = "DENSIDAD DEL SUELO"
            subtitulo = "ESTRATOS 3D"
            kpi = "COMPACT."
            etiquetas = ["SUELO SUELTO", "VACÍOS", "SUELO FIRME"]

        elif "cinco años" in low or "5 años" in low or "arruina una obra" in low:
            plantilla = "vivienda_colapso_3d"
            acento = "peligro"
            titulo = "ASENTAMIENTO <5 AÑOS"
            subtitulo = "DAÑO PROGRESIVO"
            kpi = "< 5 AÑOS"
            etiquetas = ["HUNDIMIENTO", "ROTURA", "SIN DREN"]

        elif ("junta" in low or "dilatac" in low) and ("acero" in low or "colocan" in low or "especiales" in low):
            plantilla = "junta_dilatacion_3d"
            acento = "solucion"
            titulo = "JUNTAS DE ACERO"
            subtitulo = "CORTE MACRO"
            kpi = "ΔL LIBRE"
            etiquetas = ["DIENTES ACERO", "HOLGURA", "CERO TENSIÓN"]

        elif "temperatura" in low or "respirar" in low or "cemento" in low:
            plantilla = "ciclo_termico"
            acento = "ciencia"
            titulo = "CICLO TÉRMICO"
            subtitulo = "DÍA Y NOCHE"
            kpi = "10°↔45°C"
            etiquetas = ["CONTRAE FRÍO", "EXPANDE CALOR", "RESPIRA"]

        elif ("falla" in low or "fallan" in low or "separaciones" in low) and tema_global == "puente_termico":
            plantilla = "alerta_fallo_junta"
            acento = "alerta"
            titulo = "FALLO DE JUNTA"
            subtitulo = "BLOQUEO CRÍTICO"
            kpi = "! ALERTA"
            etiquetas = ["BLOQUEO 0 mm", "ESCOMBROS", "RIESGO"]

        elif "fractura" in low or "viga" in low or "vigas" in low:
            plantilla = "viga_fractura"
            acento = "peligro"
            titulo = "FRACTURA DE VIGA"
            subtitulo = "CARGA INTERNA"
            kpi = "FRACTURA"
            etiquetas = ["COMPRESIÓN", "GRIETAS", "RUPTURA"]

        elif ("calor" in low or "sol" in low) and ("puente" in low or tema_global == "puente_termico"):
            plantilla = "puente_isometrico_calor"
            acento = "peligro"
            titulo = "CALOR EN PUENTE"
            subtitulo = "VISTA ISOMÉTRICA 3D"
            kpi = "+48 °C"
            etiquetas = ["SOL DIRECTO", "TABLERO 3D", "EXPANSIÓN"]

        elif "espacio" in low or "expandirse" in low or "sin espacio" in low:
            plantilla = "compresion_sin_espacio"
            acento = "peligro"
            titulo = "SIN ESPACIO LIBRE"
            subtitulo = "COMPRESIÓN"
            kpi = "0 mm"
            etiquetas = ["EMPUJE → ←", "TENSIÓN", "CERO MARGEN"]

        elif "flexible" in low or "adaptan" in low or "sin romperse" in low:
            plantilla = "estructura_flexible" if tema_global == "puente_termico" else "comparativa_viviendas_3d"
            acento = "solucion"
            titulo = "DISEÑO FLEXIBLE"
            subtitulo = "FLUJO DE CARGAS"
            kpi = "SEGURO"
            etiquetas = ["AMORTIGUACIÓN", "EQUILIBRIO", "PROTECCIÓN"]

        else:
            pool = POOLS_POR_TEMA.get(tema_global, POOLS_POR_TEMA["obra_general"])
            plantilla = pool[i % len(pool)]
            acento = "ciencia"
            etiquetas = _extraer_etiquetas_frase(frase, ["PLANO", "TERRENO", "DISEÑO"])
            titulo = " ".join(etiquetas[:2])[:22] or f"PLANO {i + 1}"
            kpi, subtitulo = _extraer_titulo_y_kpi_local(frase, i)

        if not titulo:
            et_tit = _extraer_etiquetas_frase(frase, ["PLANO CLAVE", "INGENIERÍA"])
            titulo = " ".join(et_tit[:2])[:24]
        if not kpi:
            kpi, _ = _extraer_titulo_y_kpi_local(frase, i)

        plan.append({
            "orden": i + 1,
            "plantilla": plantilla,
            "titulo": titulo[:26].upper(),
            "subtitulo": subtitulo[:24].upper(),
            "acento": acento,
            "kpi": kpi[:12],
            "etiquetas": [e[:20].upper() for e in etiquetas[:3]],
            "cta_palabra": cta_palabra,
        })

    return _asegurar_diversidad_escenas(plan, beats, tema_global)


def planificar_escenas_motion(root: Path, beats: list[dict], cfg_nicho: dict = None) -> list[dict]:
    """Genera (y cachea) el storyboard visual multi-perspectiva para todas las escenas del guion."""
    if not beats:
        return []

    cortes_dir = root / "cortes"
    canvas_dir = cortes_dir / "_canvas"
    canvas_dir.mkdir(parents=True, exist_ok=True)
    cache_file = canvas_dir / "_motion_plan.json"

    firmas = [b.get("frase", "").strip() for b in beats]
    tema_global = _detectar_tema_global(beats)
    payload_hash = hashlib.md5(
        json.dumps({"v": 5, "tema": tema_global, "beats": firmas}, ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:12]

    if cache_file.is_file():
        try:
            cached = json.loads(cache_file.read_text(encoding="utf-8"))
            if cached.get("hash") == payload_hash and len(cached.get("escenas", [])) == len(beats):
                return cached["escenas"]
        except Exception:
            pass

    escenas_plan = None
    claves = _cargar_claves_gemini(root)
    if claves:
        nicho_nom = (cfg_nicho or {}).get("tipo_nicho") or (cfg_nicho or {}).get("nombre") or "Ingeniería, Arquitectura y Construcción"
        lineas_guion = "\n".join(f"{idx+1}. {b.get('frase', '').strip()}" for idx, b in enumerate(beats))
        prompt = f"""Eres el Director de Arte CAD/3D de Motion Graphics para Shorts de "{nicho_nom}".
Debes diseñar el guion gráfico (storyboard) para {len(beats)} escenas consecutivas en formato vertical 9:16.

FRASES DEL GUION EN ORDEN:
{lineas_guion}

REGLA DE ORO VISUAL (CERO REPETICIÓN):
- NUNCA repitas la misma plantilla dos veces en este video. Cada escena DEBE mostrar un plano distinto o ángulo de cámara diferente:
  alterna vistas ISOMÉTRICAS 3D de casas/edificios completos, PLANOS EN PLANTA DESDE ARRIBA (terreno/cubierta/red de tuberías), CORTES LATERALES DE CASA + TERRENO, PERFILES DE TUBERÍA y EXPLOSIÓN 3D DE CAPAS.

PLANTILLAS DISPONIBLES:
[CASAS, TEJADOS Y AGUA DE LLUVIA]
- "casa_isometrica_tejado": Casa 3D isométrica completa en su terreno con lluvia, pendiente 2%, canaleta y bajante.
- "plano_planta_tejado": Vista aérea en PLANTA desde arriba del techo y terreno con flechas de escorrentía a bajantes.
- "estancamiento_colapso_techo": Corte transversal de losa plana sin pendiente acumulando agua, flechándose y filtrando adentro.
- "corte_casa_terreno_humedad": Corte lateral completo de casa y terreno con agua empozada infiltrando cimientos desde adentro.
- "capas_impermeables_3d": Vista 3D explotada separando losa + barrera + membrana impermeable + pendiente 2% + canaleta.
- "desvio_hidraulico_planta": Plano desde arriba del lote desviando cientos de litros por zanjas perimetrales lejos de la casa.
- "fluido_sin_friccion": Perfil hidrodinámico comparando canal rugoso atascado vs superficie lisa de baja fricción.
- "comparativa_viviendas_3d": Doble isométrico 3D: vivienda en ruina sin evacuación vs casa seca protegida.

[EDIFICIOS, CIMIENTOS, TUBERÍAS Y SUELOS]
- "edificio_moderno_grietas": Edificio moderno multipiso en 3D sobre suelo cortado con humedad basal y grietas en fachada.
- "plano_planta_drenaje": Plano aéreo en PLANTA del terreno y perímetro del edificio con tubería francesa, codos, registros y descarga.
- "perfil_tuberia_pendiente": Corte longitudinal subterráneo con tubo perforado al 2%, cama de grava, geotextil y salida a registro.
- "drenaje_cimientos": Corte transversal profundo de muro de cimentación/sótano con geotextil, grava lavada y corte de tubo drenante.
- "presion_hidrostatica": Corte subterráneo con nivel freático saturado y flechas de subpresión empujando zapata hacia arriba.
- "densidad_suelo_estratos": Dos columnas estratigráficas 3D comparando suelo suelto hundiendo zapata vs estrato compactado firme.
- "vivienda_colapso_3d": Edificio/vivienda en 3D sufriendo asentamiento desigual e inclinación estructural en pocos años.

[PUENTES, JUNTAS Y ESTRUCTURAS]
- "puente_isometrico_calor": Puente vehicular 3D bajo sol radiante + termómetro + tablero expandiéndose.
- "compresion_sin_espacio": Dos losas 3D en choque frontal por falta de holgura.
- "junta_dilatacion_3d": Corte macro con dientes metálicos articulados y cota dinámica en mm.
- "ciclo_termico": Termómetro frío/calor con losa respirando en expansión y contracción.
- "alerta_fallo_junta": Junta de dilatación bloqueada por escombros (SOLO usar si el guion habla de juntas de puentes/losas).
- "viga_fractura": Viga bajo carga extrema con propagación de grieta.
- "estructura_flexible": Puente atirantado flexible distribuyendo cargas armónicamente.
- "comparativa_doble": Doble vista rígida fracturada vs articulada segura.

[ESPECIALES Y DIBUJO LIBRE PARAMÉTRICO]
- "composicion_arquitectonica": Escenario libre dibujado con tus objetos exactos en campo "dibujo" si la narración menciona una estructura distinta (muro de contención, tanque, tubería especial, edificio, sótano). Formato de "dibujo":
  {{
    "vista": "isometrica" | "planta" | "corte",
    "elementos": [
      {{"tipo": "terreno", "y": 72, "saturado": true}},
      {{"tipo": "casa_iso", "x": 45, "y": 62, "w": 32, "h": 24, "techo": "pendiente", "dano": "none"}},
      {{"tipo": "tuberia", "puntos": [[20, 68], [55, 76], [85, 80]], "flujo": "agua", "perforada": true}},
      {{"tipo": "flecha_flujo", "x1": 22, "y1": 40, "x2": 75, "y2": 62, "color": "agua"}},
      {{"tipo": "lluvia", "zona": [18, 12, 82, 42]}},
      {{"tipo": "cota", "x1": 20, "y1": 24, "x2": 78, "y2": 24, "texto": "2.0% CAIDA"}}
    ]
  }}
  (Tipos válidos de elementos: "terreno", "casa_iso", "edificio_iso", "tuberia", "losa", "flecha_flujo", "lluvia", "foco_alerta", "cota". Coordenadas 10..90).
- "pregunta_panorama": Plano wireframe acorde al tema ("casa"|"edificio"|"puente") + signo '?' para preguntas de cierre.
- "cta_comenta": Tarjeta de cierre invitando a comentar una palabra clave exacta.

REGLAS DE RESPUESTA JSON:
Devuelve JSON válido {{"escenas": [...]}} con EXACTAMENTE {len(beats)} objetos ordenados:
- "orden": 1..{len(beats)}
- "plantilla": ID exacto
- "titulo": MÁXIMO 24 caracteres MAYÚSCULAS en ESPAÑOL
- "subtitulo": MÁXIMO 22 caracteres MAYÚSCULAS (etiqueta técnica)
- "acento": "peligro" | "solucion" | "ciencia" | "alerta" | "cta"
- "kpi": dato corto exacto de la frase (ej: "2.0 %", "kPa ↑", "< 5 AÑOS", "FLUIDO OK", "PENDIENTE") sin emojis ni %. inventados
- "etiquetas": 2 o 3 rótulos cortos MAYÚSCULAS (<=18 chars c/u)
- "cta_palabra": palabra clave en MAYÚSCULAS si es CTA, si no ""
- "dibujo": (opcional, requerido solo si usas "composicion_arquitectonica", o para indicar {{"tema_visual": "casa"|"edificio"|"tuberia"|"puente"}} en "pregunta_panorama")
"""
        body = json.dumps({
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.3, "response_mime_type": "application/json"},
        }).encode("utf-8")

        for k in claves:
            for mod in ("gemini-3.5-flash", "gemini-3-flash-preview", "gemini-2.5-flash", "gemini-3.5-flash-lite"):
                endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={k}"
                try:
                    req = urllib.request.Request(endpoint, data=body, headers={"Content-Type": "application/json"})
                    with urllib.request.urlopen(req, timeout=45) as resp:
                        res = json.loads(resp.read().decode("utf-8"))
                        raw_txt = res.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                        if raw_txt:
                            t_clean = raw_txt.strip()
                            if t_clean.startswith("```"):
                                parts = t_clean.split("```")
                                t_clean = parts[1][4:] if parts[1].startswith("json") else parts[1]
                            parsed = json.loads(t_clean.strip())
                            cand = parsed.get("escenas", []) if isinstance(parsed, dict) else []
                            if isinstance(cand, list) and len(cand) >= max(1, len(beats) - 2):
                                fallback_loc = _planificar_local(beats, tema_global=tema_global)
                                escenas_plan = []
                                for idx in range(len(beats)):
                                    item = cand[idx] if idx < len(cand) and isinstance(cand[idx], dict) else fallback_loc[idx]
                                    pl = _normalizar_plantilla_alias(str(item.get("plantilla", "casa_isometrica_tejado")).strip())
                                    ac = str(item.get("acento", "ciencia")).strip().lower()
                                    if ac not in TEMAS_ACENTO:
                                        ac = "ciencia"
                                    frase_low = (beats[idx].get("frase") or "").lower()
                                    kpi_raw = _limpiar_texto_visual(str(item.get("kpi") or ""), "mono")[:16].strip()
                                    if "%" in kpi_raw and "%" not in frase_low and "por ciento" not in frase_low and "pendiente" not in frase_low:
                                        kpi_raw, _ = _extraer_titulo_y_kpi_local(beats[idx].get("frase") or "", idx)
                                    ets = [
                                        _limpiar_texto_visual(str(e), "bold")[:20].upper()
                                        for e in (item.get("etiquetas") or [])
                                        if _limpiar_texto_visual(str(e), "bold")
                                    ]
                                    escenas_plan.append({
                                        "orden": idx + 1,
                                        "plantilla": pl,
                                        "titulo": (_limpiar_texto_visual(str(item.get("titulo") or f"ESCENA {idx+1}"), "bold")[:26].upper() or f"ESCENA {idx+1}"),
                                        "subtitulo": (_limpiar_texto_visual(str(item.get("subtitulo") or TEMAS_ACENTO[ac]["tag"]), "bold")[:24].upper() or TEMAS_ACENTO[ac]["tag"]),
                                        "acento": ac,
                                        "kpi": kpi_raw or "PLANO",
                                        "etiquetas": ets[:3],
                                        "cta_palabra": _limpiar_texto_visual(str(item.get("cta_palabra") or ""), "bold")[:16].upper(),
                                        "dibujo": item.get("dibujo") if isinstance(item.get("dibujo"), dict) else {},
                                    })
                                escenas_plan = _asegurar_diversidad_escenas(escenas_plan, beats, tema_global)
                                print(f"  [MOTION] Storyboard multi-perspectiva generado con {mod}.", flush=True)
                                break
                except urllib.error.HTTPError as he:
                    print(f"  [MOTION] Aviso Gemini ({mod}): HTTP {he.code}", flush=True)
                    continue
                except Exception as ex:
                    print(f"  [MOTION] Aviso Gemini ({mod}): {type(ex).__name__}", flush=True)
                    continue
            if escenas_plan:
                break

    if not escenas_plan:
        print("  [MOTION] Usando director arquitectónico local multi-perspectiva.", flush=True)
        escenas_plan = _planificar_local(beats, tema_global=tema_global)

    try:
        cache_file.write_text(
            json.dumps({"hash": payload_hash, "escenas": escenas_plan}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass

    return escenas_plan


# ---------------------------------------------------------------------------
# Escenarios 3D Isométricos, Plantas Cenitales, Cortes de Terreno y Perfiles
# Escenario seguro: x=[66..1014], y=[252..1228] (Centro cx=540, cy=740)
# ---------------------------------------------------------------------------
def _stage_casa_isometrica_tejado(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    ox, oy = 540, 865
    # 1. Terreno 3D con estrato cortado
    _draw_iso_ground_lot(frame, ox=ox, oy=oy + 20, w=390, d=340, strata_h=90, saturado=False, t=t)
    # Jardín exterior con zanja de desagüe lateral alejada de la casa
    p_chan0 = _iso(148, 120, 4, ox, oy + 20)
    p_chan1 = _iso(182, 145, 2, ox, oy + 20)
    _draw_arrow_vec(frame, p_chan0, p_chan1, (16, 185, 129), 6, 18)

    # 2. Casa 3D isométrica con techo a 1 agua (pendiente 2%) y canaleta + bajante
    pend_px = 38.0 + math.sin(t * 2.0) * 2.0
    _draw_iso_house(
        frame, ox=ox - 20, oy=oy - 5, w=225, d=180, h_wall=140,
        roof_style="pendiente", pendiente_px=pend_px, water_film=True, t=t,
    )

    # 3. Lluvia cayendo desde arriba sobre la cubierta 3D
    for k in range(12):
        dt = (t * 1.15 + k * 0.11) % 1.0
        rx = 320 + ((k * 73) % 410)
        ry = int(350 + dt * (545 - 350))
        cv2.line(frame, (rx, ry), (rx - 4, ry + 18), (125, 211, 252), 3, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["TEJADO 2%", "MEMBRANA CYAN", "BAJANTE EXTERIOR"]
    textos_overlay.append(("pill", 300, 340, ets[0], (56, 189, 248), 24))
    textos_overlay.append(("pill", 775, 420, ets[1] if len(ets) > 1 else "CANALETA 3D", (6, 182, 212), 23))
    textos_overlay.append(("pill_icon", 770, 1085, ets[2] if len(ets) > 2 else "DESAGÜE ALEJADO", (16, 185, 129), 24, "check"))


def _stage_plano_planta_tejado(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Plano arquitectónico visto desde arriba (CENITAL)
    lx0, ly0, lx1, ly1 = 120, 315, 960, 1135
    _draw_topdown_lot_grid(frame, lx0, ly0, lx1, ly1, (56, 189, 248))

    # Contorno del tejado desde arriba (planta)
    rx0, ry0, rx1, ry1 = 235, 440, 845, 965
    # Sombras de caída de terreno
    cv2.rectangle(frame, (rx0 + 16, ry0 + 16), (rx1 + 16, ry1 + 16), (15, 23, 42), -1)
    # Dos paños inclinados separados por cumbrera vertical central
    cv2.rectangle(frame, (rx0, ry0), (540, ry1), (18, 62, 92), -1)
    cv2.rectangle(frame, (540, ry0), (rx1, ry1), (14, 76, 108), -1)
    cv2.rectangle(frame, (rx0, ry0), (rx1, ry1), (125, 211, 252), 4, cv2.LINE_AA)
    cv2.line(frame, (540, ry0), (540, ry1), (250, 204, 21), 5, cv2.LINE_AA)  # cumbrera

    # Canaletas perimetrales en borde izquierdo y derecho vistas desde arriba
    cv2.rectangle(frame, (rx0 - 26, ry0), (rx0, ry1), (2, 132, 199), -1)
    cv2.rectangle(frame, (rx1, ry0), (rx1 + 26, ry1), (2, 132, 199), -1)
    cv2.rectangle(frame, (rx0 - 26, ry0), (rx0, ry1), (186, 230, 253), 2, cv2.LINE_AA)
    cv2.rectangle(frame, (rx1, ry0), (rx1 + 26, ry1), (186, 230, 253), 2, cv2.LINE_AA)

    # Vectores de pendiente 2% partiendo desde la cumbrera hacia ambos canales + partículas
    for row_y in (520, 650, 780, 900):
        _draw_arrow_vec(frame, (520, row_y), (rx0 + 20, row_y), (56, 189, 248), 5, 16)
        _draw_arrow_vec(frame, (560, row_y), (rx1 - 20, row_y), (56, 189, 248), 5, 16)
        u = (t * 0.9 + row_y * 0.002) % 1.0
        cv2.circle(frame, (int(530 - u * 270), row_y), 7, (186, 230, 253), -1, cv2.LINE_AA)
        cv2.circle(frame, (int(550 + u * 270), row_y), 7, (186, 230, 253), -1, cv2.LINE_AA)

    # Bajantes en esquinas inferiores expulsando hacia afuera del terreno
    _draw_pipe_run(frame, [(rx0 - 13, ry1), (rx0 - 13, ry1 + 95), (160, ry1 + 95)], diam=18, t=t, n_beads=4)
    _draw_pipe_run(frame, [(rx1 + 13, ry1), (rx1 + 13, ry1 + 95), (920, ry1 + 95)], diam=18, t=t, n_beads=4)

    _draw_caliper_dim(frame, rx0, rx1, ry0 - 38, (250, 204, 21))
    ets = spec.get("etiquetas") or ["PENDIENTE 2%", "CUMBRERA", "BAJANTES"]
    textos_overlay.append(("pill", 540, 365, ets[0], (250, 204, 21), 24))
    textos_overlay.append(("pill", 390, 705, ets[1] if len(ets) > 1 else "PAÑO 2% CAÍDA", (125, 211, 252), 21))
    textos_overlay.append(("pill_icon", 540, 1080, ets[2] if len(ets) > 2 else "DESAGÜE PERIMETRAL", (16, 185, 129), 24, "check"))


def _stage_estancamiento_colapso_techo(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    sag = ease_in_out(clamp01((p - 0.12) / 0.78))
    shake = int(math.sin(t * 28.0) * 3.0 * sag)

    # Fachada completa en corte mostrando interior de la vivienda (cimientos + dos cuartos + ventanas con marco)
    cv2.rectangle(frame, (150, 625), (930, 1065), (26, 36, 54), -1)
    cv2.rectangle(frame, (130, 1065), (950, 1105), (51, 65, 85), -1)  # losa de piso
    cv2.line(frame, (130, 1065), (950, 1065), (148, 163, 184), 3)
    # Pretiles / parapetos laterales que encierran el agua en techo plano
    cv2.rectangle(frame, (135, 535), (165, 625), (71, 85, 105), -1)
    cv2.rectangle(frame, (915, 535), (945, 625), (71, 85, 105), -1)
    cv2.rectangle(frame, (135, 535), (165, 625), (148, 163, 184), 2)
    cv2.rectangle(frame, (915, 535), (945, 625), (148, 163, 184), 2)
    # Interior habitaciones (muro central + ventanas con cruceta)
    cv2.line(frame, (540, 665), (540, 1065), (71, 85, 105), 6)
    for wx0, wx1 in ((220, 425), (655, 860)):
        cv2.rectangle(frame, (wx0, 745), (wx1, 905), (15, 32, 58), -1)
        cv2.rectangle(frame, (wx0, 745), (wx1, 905), (125, 211, 252), 3)
        cv2.line(frame, ((wx0 + wx1) // 2, 745), ((wx0 + wx1) // 2, 905), (100, 116, 139), 2)
        cv2.line(frame, (wx0, 825), (wx1, 825), (100, 116, 139), 2)
    cv2.rectangle(frame, (150, 625), (930, 1065), (148, 163, 184), 4, cv2.LINE_AA)

    # Techo plano arqueándose por peso de bolsa de agua acumulada (0% pendiente)
    deflect = int(12 + sag * 54) + shake
    top_pts = []
    bot_pts = []
    for kx in range(160, 925, 25):
        frac = (kx - 540) / 380.0
        bowl = int((1.0 - frac * frac) * deflect)
        top_pts.append([kx, 585 + bowl])
        bot_pts.append([kx, 628 + bowl])

    # Bolsa profunda de agua acumulada sobre la losa
    water_top_y = 548 - int(sag * 12)
    water_poly = [[165, water_top_y]] + top_pts + [[915, water_top_y]]
    cv2.fillPoly(frame, [np.array(water_poly, np.int32)], (14, 116, 190), cv2.LINE_AA)
    cv2.line(frame, (165, water_top_y), (915, water_top_y), (125, 211, 252), 4, cv2.LINE_AA)

    # Losa flechada roja bajo tensión
    slab_poly = top_pts + list(reversed(bot_pts))
    cv2.fillPoly(frame, [np.array(slab_poly, np.int32)], (138, 66, 62) if sag > 0.35 else (100, 116, 139), cv2.LINE_AA)
    cv2.polylines(frame, [np.array(slab_poly, np.int32)], True, (248, 113, 113), 3, cv2.LINE_AA)

    # Goteras y grieta filtrándose hacia el interior de las habitaciones
    _draw_arrow_vec(frame, (540, 395), (540, water_top_y - 12), (239, 68, 68), 12, 28)
    if sag > 0.25:
        _draw_glow_circle(frame, 540, 610 + deflect, int(55 + 35 * sag), (239, 68, 68), 0.55)
        cv2.polylines(frame, [np.array([[540, 585 + deflect], [526, 610 + deflect], [548, 636 + deflect], [534, 672 + deflect]], np.int32)], False, (254, 226, 226), 5, cv2.LINE_AA)
        for d_i in range(4):
            gy = int(635 + deflect + ((t * 210 + d_i * 80) % 385))
            gx = 515 + d_i * 18
            cv2.circle(frame, (gx, gy), 7, (56, 189, 248), -1, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["PENDIENTE 0%", "AGUA ESTANCADA", "COLAPSO DE LOSA"]
    textos_overlay.append(("pill_icon", 540, 345, ets[0], (239, 68, 68), 26, "cross"))
    textos_overlay.append(("pill", 300, 485, ets[1] if len(ets) > 1 else "SOBRECARGA", (56, 189, 248), 23))
    textos_overlay.append(("pill", 540, 1148, ets[2] if len(ets) > 2 else "FILTRACIÓN Y FALLA", (239, 68, 68), 25))


def _stage_corte_casa_terreno_humedad(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Vista LATERAL COMPLETA: Casa a la izquierda/centro + jardín/terreno inclinado hacia los muros + subsuelo abajo
    # 1. Subsuelo estratificado
    cv2.rectangle(frame, (80, 795), (1000, 1135), (44, 30, 21), -1)
    # Terreno inclinado MAL nivelado hacia la pared derecha de la casa
    soil_surf = np.array([[80, 795], [520, 795], [990, 725], [990, 815], [80, 815]], np.int32)
    cv2.fillPoly(frame, [soil_surf], (22, 82, 58), cv2.LINE_AA)
    cv2.line(frame, (520, 795), (990, 725), (74, 222, 128), 4, cv2.LINE_AA)

    # Zapatas y cimientos bajo tierra
    _draw_concrete_slab(frame, 180, 795, 240, 1020, tint_warm=0.2)
    _draw_concrete_slab(frame, 470, 795, 535, 1020, tint_warm=0.65)
    _draw_concrete_slab(frame, 155, 1015, 265, 1085, tint_warm=0.2)
    _draw_concrete_slab(frame, 445, 1015, 560, 1085, tint_warm=0.65)

    # 2. Casa vista de costado (muros + ventanas + techo dos aguas sin canaleta)
    cv2.rectangle(frame, (180, 505), (535, 795), (42, 58, 82), -1)
    cv2.rectangle(frame, (180, 505), (535, 795), (203, 213, 225), 3, cv2.LINE_AA)
    cv2.rectangle(frame, (235, 575), (340, 685), (125, 211, 252), -1)
    cv2.rectangle(frame, (390, 575), (485, 685), (125, 211, 252), -1)
    roof_tri = np.array([[150, 505], [357, 370], [565, 505]], np.int32)
    cv2.fillPoly(frame, [roof_tri], (71, 85, 105), cv2.LINE_AA)
    cv2.polylines(frame, [roof_tri], True, (226, 232, 240), 3, cv2.LINE_AA)

    # 3. Charco acumulado junto al muro e infiltración bajando por el terreno hacia las zapatas
    _draw_glow_circle(frame, 585, 895, 130, (14, 165, 233), 0.42)
    cv2.ellipse(frame, (585, 790), (75, 16), 0, 0, 360, (14, 165, 233), -1)
    # Escorrentía bajando desde el jardín hacia la pared y luego filtrando hasta el cimiento
    _draw_arrow_vec(frame, (910, 705), (595, 765), (56, 189, 248), 7, 18)
    _draw_arrow_vec(frame, (585, 815), (555, 995), (239, 68, 68), 8, 20)
    for k in range(7):
        dt = (t * 0.8 + k * 0.14) % 1.0
        px = int(890 - dt * 310) if dt < 0.5 else int(580 - (dt - 0.5) * 40)
        py = int(695 + dt * 165) if dt < 0.5 else int(795 + (dt - 0.5) * 440)
        cv2.circle(frame, (px, py), 8, (56, 189, 248), -1, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["ESCORRENTÍA → CASA", "SUELO SATURADO", "DAÑO EN CIMIENTO"]
    textos_overlay.append(("pill", 770, 610, ets[0], (56, 189, 248), 23))
    textos_overlay.append(("pill", 785, 920, ets[1] if len(ets) > 1 else "INFILTRACIÓN", (245, 158, 11), 23))
    textos_overlay.append(("pill_icon", 357, 1140, ets[2] if len(ets) > 2 else "CIMIENTOS DAÑADOS", (239, 68, 68), 24, "cross"))


def _stage_capas_impermeables_3d(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Explosión Isométrica 3D en eje Z mostrando capas de abajo hacia arriba sin cruces de líneas
    sep = ease_in_out(clamp01(p / 0.55)) * 74.0 + math.sin(t * 2.5) * 4.0
    ox, oy = 390, 965
    w, d = 270, 210
    x0, y0 = -w / 2.0, -d / 2.0

    # Capa 1 (Abajo): Losa estructural concreto
    _draw_iso_box(
        frame, x0, y0, 0, w, d, 32, ox=ox, oy=oy,
        col_top=(100, 116, 139), col_left=(71, 85, 105), col_right=(51, 65, 85),
        edge_col=(203, 213, 225), edge_w=2,
    )
    # Capa 2 (Medio): Mortero de pendiente 2%
    z2 = 58 + sep
    p0 = _iso(x0, y0, z2 + 28, ox, oy)
    p1 = _iso(x0 + w, y0, z2 + 4, ox, oy)
    p2 = _iso(x0 + w, y0 + d, z2 + 4, ox, oy)
    p3 = _iso(x0, y0 + d, z2 + 28, ox, oy)
    pb3 = _iso(x0, y0 + d, z2, ox, oy)
    pb2 = _iso(x0 + w, y0 + d, z2, ox, oy)
    cv2.fillPoly(frame, [np.array([p3, p2, pb2, pb3], np.int32)], (120, 113, 108), cv2.LINE_AA)
    cv2.fillPoly(frame, [np.array([p0, p1, p2, p3], np.int32)], (168, 162, 158), cv2.LINE_AA)
    cv2.polylines(frame, [np.array([p0, p1, p2, p3], np.int32)], True, (245, 158, 11), 2, cv2.LINE_AA)

    # Capa 3 (Arriba): Lámina / membrana impermeable cyan brillante
    z3 = z2 + 56 + sep * 1.15
    _draw_iso_box(
        frame, x0, y0, z3, w, d, 12, ox=ox, oy=oy,
        col_top=(6, 182, 212), col_left=(14, 116, 144), col_right=(21, 94, 117),
        edge_col=(165, 243, 252), edge_w=2, tilt_dz_right=-22.0,
    )

    # Canaleta colectora limpia adosada al borde derecho de descarga
    z4 = z3 - 26.0
    _draw_iso_box(
        frame, x0 + w + 8, y0, z4, 24, d, 20, ox=ox, oy=oy,
        col_top=(16, 185, 129), col_left=(5, 150, 105), col_right=(4, 120, 87),
        edge_col=(167, 243, 208), edge_w=2,
    )

    # Bolitas de lluvia resbalando por encima de la capa impermeable hacia la canaleta
    for k in range(5):
        u = (t * 0.85 + k * 0.2) % 1.0
        bx, by = _iso(x0 + u * w, y0 + d * (0.25 + (k % 3) * 0.25), z3 + 16 - 22.0 * u, ox, oy)
        cv2.circle(frame, (bx, by), 7, (186, 230, 253), -1, cv2.LINE_AA)

    # Puntos exactos en el borde derecho de cada capa para alinear etiquetas sin cruces
    a_top = _iso(x0 + w, y0 + 25, z3 + 4, ox, oy)
    a_mid = _iso(x0 + w, y0 + d * 0.55, z2 + 12, ox, oy)
    a_bot = _iso(x0 + w, y0 + d * 0.85, 16, ox, oy)
    y_lbl_top = max(410, min(590, a_top[1] - 35))
    y_lbl_mid = max(y_lbl_top + 135, min(790, a_mid[1] - 10))
    y_lbl_bot = max(y_lbl_mid + 135, min(980, a_bot[1] + 10))

    for pt_a, yl, col_l in ((a_top, y_lbl_top, (56, 189, 248)), (a_mid, y_lbl_mid, (245, 158, 11)), (a_bot, y_lbl_bot, (203, 213, 225))):
        cv2.circle(frame, pt_a, 5, col_l, -1, cv2.LINE_AA)
        cv2.line(frame, pt_a, (685, yl), col_l, 2, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["MEMBRANA IMPERMEABLE", "PENDIENTE 2%", "LOSA ESTRUCTURAL"]
    # Auto-ordenar si Gemini envió "LOSA" en posición 0 (invertido respecto al plano 3D)
    e0, e1, e2 = ets[0], (ets[1] if len(ets) > 1 else "PENDIENTE 2%"), (ets[2] if len(ets) > 2 else "LOSA BASE")
    if "LOSA" in e0.upper() and ("MEMBRANA" in e2.upper() or "CAPA" in e2.upper() or "SELLO" in e2.upper()):
        e0, e2 = e2, e0
    textos_overlay.append(("pill", 795, y_lbl_top, e0, (6, 182, 212), 20))
    textos_overlay.append(("pill", 795, y_lbl_mid, e1, (245, 158, 11), 20))
    textos_overlay.append(("pill", 795, y_lbl_bot, e2, (203, 213, 225), 20))
    textos_overlay.append(("pill_icon", 540, 1140, "SELLADO MULTICAPA ACTIVO", (16, 185, 129), 24, "check"))


def _stage_desvio_hidraulico_planta(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Plano CENITAL (desde arriba): terreno verde/azul oscuro + casa protegida en el centro + caudal desviado por fuera
    _draw_topdown_lot_grid(frame, 115, 315, 965, 1125, (16, 185, 129))

    # Casa centrada vista desde arriba (segura / seca)
    hx0, hy0, hx1, hy1 = 345, 535, 735, 865
    cv2.rectangle(frame, (hx0, hy0), (hx1, hy1), (22, 48, 72), -1)
    cv2.rectangle(frame, (hx0, hy0), (hx1, hy1), (16, 185, 129), 4, cv2.LINE_AA)
    cv2.line(frame, (hx0, hy0), (hx1, hy1), (30, 64, 96), 2, cv2.LINE_AA)
    cv2.line(frame, (hx0, hy1), (hx1, hy0), (30, 64, 96), 2, cv2.LINE_AA)

    # Canales hidrodinámicos rodeando la casa desde arriba y evacuando hacia abajo/afuera
    canal_izq = [(540, 385), (300, 445), (225, 580), (225, 855), (165, 1045)]
    canal_der = [(540, 385), (780, 445), (855, 580), (855, 855), (915, 1045)]
    _draw_pipe_run(frame, canal_izq, diam=22, col_pipe=(6, 78, 95), col_edge=(56, 189, 248), t=t, n_beads=9)
    _draw_pipe_run(frame, canal_der, diam=22, col_pipe=(6, 78, 95), col_edge=(56, 189, 248), t=t + 0.15, n_beads=9)
    _draw_arrow_vec(frame, (205, 945), (165, 1065), (16, 185, 129), 7, 18)
    _draw_arrow_vec(frame, (875, 945), (915, 1065), (16, 185, 129), 7, 18)

    ets = spec.get("etiquetas") or ["FLUJO DESVIADO", "ZONA SECA", "EVACUACIÓN EXTERIOR"]
    textos_overlay.append(("pill", 540, 350, "CAUDAL ENTRANDO ↓", (56, 189, 248), 23))
    textos_overlay.append(("pill_icon", 540, 700, "ESTRUCTURA PROTEGIDA", (16, 185, 129), 24, "check"))
    textos_overlay.append(("pill", 540, 1085, f"{ets[0]} → +300 L FUERA", (56, 189, 248), 23))


def _stage_fluido_sin_friccion(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Comparativa perfil longitudinal de conductos: Arriba rugoso bloqueado vs Abajo curvo liso sin fricción
    # Superior: Superficie rugosa con dientes obstruyendo caudal
    cv2.rectangle(frame, (110, 330), (970, 695), (36, 18, 26), -1)
    cv2.rectangle(frame, (110, 330), (970, 695), (239, 68, 68), 3, cv2.LINE_AA)
    cv2.line(frame, (170, 585), (910, 585), (148, 163, 184), 5, cv2.LINE_AA)
    for rx in range(210, 880, 65):
        cv2.fillPoly(frame, [np.array([[rx, 585], [rx + 18, 550], [rx + 36, 585]], np.int32)], (239, 68, 68), cv2.LINE_AA)
    # Gotas lentas / atascadas
    for k in range(5):
        gx = int(200 + ((t * 48 + k * 90) % 450))
        gy = int(535 + math.sin(t * 9.0 + k) * 8)
        cv2.circle(frame, (gx, gy), 11, (249, 115, 22), -1, cv2.LINE_AA)

    # Inferior: Canal liso inclinado hidrodinámico acelerando agua suavemente
    cv2.rectangle(frame, (110, 735), (970, 1140), (10, 34, 46), -1)
    cv2.rectangle(frame, (110, 735), (970, 1140), (16, 185, 129), 3, cv2.LINE_AA)
    pts_smooth = [(170, 865), (380, 920), (620, 985), (910, 1055)]
    _draw_pipe_run(frame, pts_smooth, diam=28, col_pipe=(14, 116, 144), col_edge=(16, 185, 129), t=t * 1.9, n_beads=10)
    _draw_arrow_vec(frame, (635, 925), (890, 995), (16, 185, 129), 8, 22)

    textos_overlay.append(("pill_icon", 540, 395, "RESISTIR EL AGUA = FRICCIÓN Y ATASCO", (239, 68, 68), 23, "cross"))
    textos_overlay.append(("pill_icon", 540, 800, "DEJARLA CORRER = FLUJO SIN FRICCIÓN", (16, 185, 129), 23, "check"))


def _stage_comparativa_viviendas_3d(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Dos viviendas reales 3D en tarjeta comparativa contenidas limpiamente dentro de sus marcos
    # Arriba: Casa sin drenaje/pendiente sufriendo filtración y grietas
    cv2.rectangle(frame, (95, 280), (985, 705), (34, 15, 24), -1)
    cv2.rectangle(frame, (95, 280), (985, 705), (239, 68, 68), 3, cv2.LINE_AA)
    _draw_iso_ground_lot(frame, ox=325, oy=562, w=195, d=160, strata_h=36, saturado=True, t=t)
    _draw_iso_house(frame, ox=318, oy=548, w=132, d=110, h_wall=84, roof_style="plano", water_film=True, crack_p=0.85, moisture_p=0.8, tilt_dz=-8.0, t=t)

    # Abajo: Casa protegida con pendiente 2% + drenaje exterior
    cv2.rectangle(frame, (95, 735), (985, 1162), (10, 34, 38), -1)
    cv2.rectangle(frame, (95, 735), (985, 1162), (16, 185, 129), 3, cv2.LINE_AA)
    _draw_iso_ground_lot(frame, ox=325, oy=1018, w=195, d=160, strata_h=36, saturado=False, t=t)
    _draw_iso_house(frame, ox=318, oy=1004, w=132, d=110, h_wall=84, roof_style="pendiente", pendiente_px=24.0, water_film=True, crack_p=0.0, moisture_p=0.0, t=t)

    ets = spec.get("etiquetas") or ["SIN EVACUACIÓN", "CON PENDIENTE + DREN"]
    textos_overlay.append(("pill_icon", 735, 425, "SIN PENDIENTE · RUINA", (239, 68, 68), 23, "cross"))
    textos_overlay.append(("pill", 735, 515, "AGUA ESTANCADA Y GRIETAS", (249, 115, 22), 20))
    textos_overlay.append(("pill_icon", 735, 885, "EVACUACIÓN 2% · SEGURA", (16, 185, 129), 23, "check"))
    textos_overlay.append(("pill", 735, 975, ets[1] if len(ets) > 1 else "CIMIENTO SECO", (56, 189, 248), 20))


def _stage_edificio_moderno_grietas(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    crack_p = clamp01((p - 0.10) / 0.78)
    ox, oy = 530, 910
    _draw_iso_ground_lot(frame, ox=ox, oy=oy + 22, w=390, d=340, strata_h=95, saturado=True, t=t)
    _draw_iso_building(frame, ox=ox - 10, oy=oy, w=210, d=175, floors=4, floor_h=68, tilt_dz=-12.0 * crack_p, crack_p=crack_p, moisture_p=0.45 + 0.45 * crack_p)

    # Resaltado de grieta en pared y línea guía hacia etiqueta de falla
    gx, gy = _iso(20, 90, 120, ox - 10, oy)
    if crack_p > 0.2:
        _draw_glow_circle(frame, gx, gy, int(55 + 35 * crack_p), (239, 68, 68), 0.45)
    cv2.line(frame, (gx + 15, gy), (695, 650), (239, 68, 68), 2, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["SUELO SATURADO", "GRIETAS EN MURO", "EDIFICIO MODERNO"]
    textos_overlay.append(("pill", 245, 505, ets[2] if len(ets) > 2 else "EDIFICIO MODERNO", (56, 189, 248), 22))
    textos_overlay.append(("pill_icon", 805, 650, ets[1] if len(ets) > 1 else "FISURA EN FACHADA", (239, 68, 68), 22, "warn"))
    textos_overlay.append(("pill", 765, 1125, ets[0], (14, 165, 233), 23))


def _stage_plano_planta_drenaje(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Plano CENITAL (desde arriba) del terreno + edificio + tubería francesa perimetral con codos y registros
    _draw_topdown_lot_grid(frame, 115, 310, 965, 1135, (16, 185, 129))

    # Zanja de grava perimetral con partículas visibles de piedra
    zx0, zy0, zx1, zy1 = 235, 425, 845, 925
    cv2.rectangle(frame, (zx0, zy0), (zx1, zy1), (56, 65, 78), -1)
    for px_g in range(zx0 + 18, zx1 - 10, 26):
        cv2.circle(frame, (px_g, zy0 + 18), 4, (148, 163, 184), -1)
        cv2.circle(frame, (px_g, zy1 - 18), 4, (148, 163, 184), -1)
    for py_g in range(zy0 + 40, zy1 - 30, 26):
        cv2.circle(frame, (zx0 + 18, py_g), 4, (148, 163, 184), -1)
        cv2.circle(frame, (zx1 - 18, py_g), 4, (148, 163, 184), -1)
    cv2.rectangle(frame, (zx0, zy0), (zx1, zy1), (250, 204, 21), 2, cv2.LINE_AA)  # geotextil contorno

    # Edificio/vivienda vista en planta (cumbrera y limatesas + muro perimetral)
    bx0, by0, bx1, by1 = 310, 500, 770, 850
    cv2.rectangle(frame, (bx0, by0), (bx1, by1), (28, 42, 64), -1)
    cv2.rectangle(frame, (bx0, by0), (bx1, by1), (203, 213, 225), 4, cv2.LINE_AA)
    # Techo a cuatro aguas / plano arquitectónico cenital
    cv2.line(frame, (410, 675), (670, 675), (148, 163, 184), 4, cv2.LINE_AA)
    for cx_h, cy_h in ((bx0, by0), (bx0, by1)):
        cv2.line(frame, (cx_h, cy_h), (410, 675), (71, 85, 105), 2, cv2.LINE_AA)
    for cx_h, cy_h in ((bx1, by0), (bx1, by1)):
        cv2.line(frame, (cx_h, cy_h), (670, 675), (71, 85, 105), 2, cv2.LINE_AA)

    # Tubería perimetral perforada rodeando toda la cimentación -> saliendo a colector abajo
    pipe_loop_a = [(540, 462), (272, 462), (272, 888), (540, 888), (540, 1055), (890, 1055)]
    pipe_loop_b = [(540, 462), (808, 462), (808, 888), (540, 888)]
    _draw_pipe_run(frame, pipe_loop_a, diam=20, col_pipe=(14, 78, 112), col_edge=(56, 189, 248), perforado=True, t=t, n_beads=10)
    _draw_pipe_run(frame, pipe_loop_b, diam=20, col_pipe=(14, 78, 112), col_edge=(56, 189, 248), perforado=True, t=t + 0.2, n_beads=7)

    # Registros inspeccionables en esquinas
    for rx, ry in [(272, 462), (808, 462), (272, 888), (808, 888), (540, 1055)]:
        cv2.rectangle(frame, (rx - 15, ry - 15), (rx + 15, ry + 15), (15, 23, 42), -1)
        cv2.rectangle(frame, (rx - 15, ry - 15), (rx + 15, ry + 15), (16, 185, 129), 3, cv2.LINE_AA)

    _draw_arrow_vec(frame, (680, 1055), (900, 1055), (16, 185, 129), 8, 20)
    ets = spec.get("etiquetas") or ["ZANJA PERIMETRAL", "EDIFICIO EN PLANTA", "COLECTOR PLUVIAL"]
    textos_overlay.append(("pill", 540, 365, ets[0], (250, 204, 21), 23))
    textos_overlay.append(("pill", 540, 675, ets[1] if len(ets) > 1 else "CIMENTACIÓN", (203, 213, 225), 22))
    textos_overlay.append(("pill_icon", 385, 1055, ets[2] if len(ets) > 2 else "SALIDA A COLECTOR", (16, 185, 129), 22, "check"))


def _stage_perfil_tuberia_pendiente(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Perfil LONGITUDINAL subterráneo de tubería de drenaje en pendiente del 2% + grava + geotextil + cámara
    cv2.rectangle(frame, (85, 420), (995, 1125), (44, 31, 22), -1)
    cv2.rectangle(frame, (85, 365), (995, 420), (22, 74, 52), -1)
    cv2.line(frame, (85, 420), (995, 420), (74, 222, 128), 4, cv2.LINE_AA)

    # Cimiento a la izquierda
    _draw_concrete_slab(frame, 105, 300, 240, 960, tint_warm=0.0)
    _draw_concrete_slab(frame, 88, 955, 260, 1045, tint_warm=0.0)

    # Cama inclinada de grava envuelta en manto geotextil amarillo
    bed_poly = np.array([[275, 595], [855, 765], [855, 965], [275, 795]], np.int32)
    cv2.fillPoly(frame, [bed_poly], (71, 85, 105), cv2.LINE_AA)
    cv2.polylines(frame, [bed_poly], True, (250, 204, 21), 5, cv2.LINE_AA)
    for step_x in range(305, 835, 38):
        frac = (step_x - 275) / 580.0
        base_y = int(635 + frac * 170)
        for dy_g in (-12, 34, 72):
            cv2.circle(frame, (step_x, base_y + dy_g), 10, (148, 163, 184), -1, cv2.LINE_AA)

    # Cámara / caja de registro derecha con nivel de agua y tubo saliente al colector
    cv2.rectangle(frame, (855, 590), (960, 1040), (30, 41, 59), -1)
    cv2.rectangle(frame, (858, 900), (957, 1037), (14, 116, 190), -1)
    cv2.rectangle(frame, (855, 590), (960, 1040), (56, 189, 248), 3, cv2.LINE_AA)
    _draw_arrow_vec(frame, (920, 960), (995, 960), (16, 185, 129), 7, 16)

    # Tubería longitudinal inclinada perforada evacuada al registro
    _draw_pipe_run(frame, [(285, 690), (885, 865)], diam=44, col_pipe=(14, 78, 118), col_edge=(56, 189, 248), perforado=True, t=t, n_beads=9)

    # Flechas de infiltración a la izquierda dejando espacio limpio arriba-derecha para el rótulo
    for ax in (340, 470, 600):
        frac = (ax - 275) / 580.0
        ty = int(610 + frac * 170)
        _draw_arrow_vec(frame, (ax, 445), (ax, ty - 14), (56, 189, 248), 5, 15)

    _draw_arrow_vec(frame, (360, 620), (775, 742), (16, 185, 129), 6, 18)

    ets = spec.get("etiquetas") or ["PENDIENTE 2%", "TUBO + GRAVA", "CÁMARA REGISTRO"]
    textos_overlay.append(("pill", 795, 505, ets[0], (16, 185, 129), 24))
    textos_overlay.append(("pill", 540, 995, ets[1] if len(ets) > 1 else "GEOTEXTIL FILTRANTE", (250, 204, 21), 24))
    textos_overlay.append(("pill_icon", 835, 1105, ets[2] if len(ets) > 2 else "EVACUACIÓN LIBRE", (56, 189, 248), 22, "check"))


def _stage_drenaje_cimientos(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    # Corte transversal profundo: Muro + zapata + lámina drenante + grava + geotextil + sección frontal de tubo
    cv2.rectangle(frame, (85, 455), (995, 1110), (46, 34, 24), -1)
    cv2.rectangle(frame, (85, 405), (995, 455), (22, 74, 52), -1)
    cv2.line(frame, (85, 455), (995, 455), (74, 222, 128), 3, cv2.LINE_AA)

    # Interior pared casa/sótano a la izquierda con ventana arriba
    _draw_concrete_slab(frame, 120, 320, 395, 990, tint_warm=0.0)
    _draw_concrete_slab(frame, 95, 985, 460, 1100, tint_warm=0.0)
    cv2.line(frame, (400, 340), (400, 985), (16, 185, 129), 8, cv2.LINE_AA)  # membrana muro

    cx_p, cy_p = 670, 875
    cv2.circle(frame, (cx_p, cy_p), 178, (71, 85, 105), -1, cv2.LINE_AA)
    cv2.circle(frame, (cx_p, cy_p), 182, (250, 204, 21), 5, cv2.LINE_AA)
    for gx in range(cx_p - 140, cx_p + 145, 34):
        for gy in range(cy_p - 140, cy_p + 145, 34):
            dist = math.hypot(gx - cx_p, gy - cy_p)
            if 78 < dist < 156:
                cv2.circle(frame, (gx, gy), 11, (148, 163, 184), -1, cv2.LINE_AA)

    cv2.circle(frame, (cx_p, cy_p), 68, (15, 23, 42), -1, cv2.LINE_AA)
    cv2.circle(frame, (cx_p, cy_p), 68, (56, 189, 248), 8, cv2.LINE_AA)
    cv2.circle(frame, (cx_p, cy_p), 42, (14, 165, 233), -1, cv2.LINE_AA)

    for k in range(8):
        dt = (t * 0.8 + k * 0.14) % 1.0
        angle = -2.4 + (k * 0.52)
        rad_d = int(260 * (1.0 - dt) + 25)
        dx = int(cx_p + math.cos(angle) * rad_d * 0.8)
        dy = int(cy_p - 120 + (1.0 - abs(math.cos(angle))) * (-90) + dt * 150)
        cv2.circle(frame, (dx, min(cy_p + 18, dy)), 9, (56, 189, 248), -1, cv2.LINE_AA)

    _draw_arrow_vec(frame, (cx_p, 480), (cx_p, 670), (56, 189, 248), 8, 22)
    ets = spec.get("etiquetas") or ["MURO IMPERMEABLE", "GRAVA + GEOTEXTIL", "TUBO PERFORADO"]
    textos_overlay.append(("pill", 265, 375, ets[0], (16, 185, 129), 22))
    textos_overlay.append(("pill", 720, 395, ets[1] if len(ets) > 1 else "GRAVA + GEOTEXTIL", (250, 204, 21), 23))
    textos_overlay.append(("pill_icon", 670, 1140, ets[2] if len(ets) > 2 else "TUBO PERFORADO", (56, 189, 248), 24, "check"))


def _stage_presion_hidrostatica(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    surge = 0.5 + 0.5 * math.sin(t * 5.0)
    # Estrato agua freática saturada rodeando cimiento + losa de sótano pandeándose por subpresión
    cv2.rectangle(frame, (85, 520), (995, 1120), (14, 48, 86), -1)
    for wy in range(550, 1100, 34):
        wave_off = int(math.sin(t * 4.0 + wy * 0.05) * 14)
        cv2.line(frame, (100, wy), (980 + wave_off, wy), (30, 100, 175), 3, cv2.LINE_AA)

    # Losa y muros en U de edificación/sótano sumergida en nivel freático
    _draw_concrete_slab(frame, 430, 410, 505, 920, tint_warm=0.35 * surge)
    _draw_concrete_slab(frame, 880, 410, 955, 920, tint_warm=0.25 * surge)
    lift = int(surge * 14)
    _draw_concrete_slab(frame, 430, 865 - lift, 955, 940 - lift, tint_warm=0.45 * surge)

    # Ventana / silueta piso arriba indicando afectación interior
    cv2.rectangle(frame, (505, 420), (880, 865 - lift), (18, 28, 48), -1)

    for ay in (585, 705, 825):
        off = int(surge * 32)
        _draw_arrow_vec(frame, (135, ay), (385 + off, ay), (56, 189, 248), 10, 26)
    for ax in (570, 690, 810):
        _draw_arrow_vec(frame, (ax, 1125), (ax, 975 - lift), (239, 68, 68), 11, 26)

    ets = spec.get("etiquetas") or ["AGUA SATURADA", "EMPUJE LATERAL", "SUBPRESIÓN ↑"]
    textos_overlay.append(("pill", 265, 465, ets[0], (56, 189, 248), 23))
    textos_overlay.append(("pill", 690, 625, "SUBPRESIÓN ↑", (239, 68, 68), 26))
    textos_overlay.append(("pill", 690, 1148, ets[2] if len(ets) > 2 else "FUERZA HACIA ARRIBA", (249, 115, 22), 23))


def _stage_densidad_suelo_estratos(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    settle = ease_in_out(clamp01((p - 0.10) / 0.78))
    drop = int(settle * 46)

    def _draw_mini_house_cut(cx: int, base_y: int, w_h: int, h_wall: int, col_edge: tuple, cracked: bool):
        x0, x1 = cx - w_h // 2, cx + w_h // 2
        cv2.rectangle(frame, (x0, base_y - h_wall), (x1, base_y), (42, 54, 72), -1)
        cv2.rectangle(frame, (x0, base_y - h_wall), (x1, base_y), col_edge, 3)
        roof_poly = np.array([[x0 - 16, base_y - h_wall], [cx, base_y - h_wall - 44], [x1 + 16, base_y - h_wall]], np.int32)
        cv2.fillPoly(frame, [roof_poly], (56, 72, 92), cv2.LINE_AA)
        cv2.polylines(frame, [roof_poly], True, col_edge, 3, cv2.LINE_AA)
        for wx in (cx - 46, cx + 16):
            cv2.rectangle(frame, (wx, base_y - h_wall + 24), (wx + 30, base_y - 24), (96, 165, 250) if not cracked else (127, 29, 29), -1)
            cv2.rectangle(frame, (wx, base_y - h_wall + 24), (wx + 30, base_y - 24), (203, 213, 225), 2)
        if cracked:
            cv2.polylines(frame, [np.array([[cx, base_y - h_wall + 10], [cx - 10, base_y - h_wall // 2], [cx + 8, base_y - 8]], np.int32)], False, (248, 113, 113), 4, cv2.LINE_AA)

    # Columna Izquierda: Suelo mal compactado (huecos de aire/agua colapsando bajo carga)
    cv2.rectangle(frame, (110, 320), (505, 1110), (32, 22, 20), -1)
    cv2.rectangle(frame, (110, 320), (505, 1110), (239, 68, 68), 3, cv2.LINE_AA)
    top_l = 675 + drop
    cv2.rectangle(frame, (145, top_l), (470, 1080), (72, 52, 38), -1)
    for idx in range(18):
        vx = 175 + (idx * 67) % 270
        vy = top_l + 38 + int(((idx * 43) % max(40, (1040 - top_l))) * (1.0 - settle * 0.25))
        cv2.circle(frame, (vx, min(1060, vy)), max(4, int(14 * (1.0 - settle * 0.45))), (14, 78, 128), -1, cv2.LINE_AA)
    _draw_concrete_slab(frame, 185, top_l - 50, 430, top_l, tint_warm=0.55 * settle)
    _draw_mini_house_cut(308, top_l - 50, 168, 104, (248, 113, 113), cracked=settle > 0.25)
    _draw_arrow_vec(frame, (308, 395), (308, top_l - 210), (239, 68, 68), 10, 22)

    # Columna Derecha: Terreno bien densificado y estratos granulados estables
    cv2.rectangle(frame, (575, 320), (970, 1110), (14, 30, 34), -1)
    cv2.rectangle(frame, (575, 320), (970, 1110), (16, 185, 129), 3, cv2.LINE_AA)
    for s_idx, (y_a, y_b, col_s) in enumerate([(675, 795, (56, 78, 64)), (795, 935, (71, 85, 105)), (935, 1080, (51, 65, 85))]):
        cv2.rectangle(frame, (610, y_a), (935, y_b), col_s, -1)
        for gx in range(626, 920, 26):
            gy = y_a + 22 + ((gx + s_idx * 17) % max(20, (y_b - y_a - 38)))
            cv2.circle(frame, (gx, gy), 3 + (s_idx % 2), (148, 163, 184), -1)
        cv2.line(frame, (610, y_a), (935, y_a), (148, 163, 184), 2)
    _draw_concrete_slab(frame, 650, 625, 895, 675, tint_warm=0.0)
    _draw_mini_house_cut(772, 625, 168, 104, (16, 185, 129), cracked=False)

    ets = spec.get("etiquetas") or ["DENSIDAD BAJA", "DENSIDAD ÓPTIMA"]
    textos_overlay.append(("pill_icon", 308, 362, ets[0], (239, 68, 68), 22, "cross"))
    textos_overlay.append(("pill_icon", 772, 362, ets[1] if len(ets) > 1 else "ESTABLE", (16, 185, 129), 22, "check"))
    textos_overlay.append(("pill", 308, 1148, f"HUNDIMIENTO -{drop // 2} cm", (249, 115, 22), 21))
    textos_overlay.append(("pill", 772, 1148, "ASENTAMIENTO 0 cm", (16, 185, 129), 21))


def _stage_vivienda_colapso_3d(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    fail = ease_in_out(clamp01((p - 0.10) / 0.80))
    tilt = -26.0 * fail
    ox, oy = 540, 825
    _draw_iso_ground_lot(frame, ox=ox, oy=oy + 26, w=355, d=295, strata_h=80, saturado=True, t=t)
    _draw_iso_house(
        frame, ox=ox - 10, oy=oy, w=215, d=170, h_wall=138,
        roof_style="plano", water_film=True, crack_p=fail, moisture_p=0.35 + 0.55 * fail,
        tilt_dz=tilt, t=t,
    )
    _draw_arrow_vec(frame, (660, 480), (660, 565 + int(fail * 35)), (239, 68, 68), 11, 26)
    ets = spec.get("etiquetas") or ["HUNDIMIENTO", "FALLA ESTRUCTURAL", "< 5 AÑOS"]
    textos_overlay.append(("pill_icon", 740, 425, ets[0], (239, 68, 68), 23, "warn"))
    textos_overlay.append(("pill_icon", 540, 1148, ets[1] if len(ets) > 1 else "OBRA ARRUINADA", (239, 68, 68), 24, "cross"))


def _stage_puente_isometrico_calor(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    ent = ease_out_cubic(clamp01(t / 0.35))
    heat = ease_in_out(clamp01((p - 0.08) / 0.85))
    prim = (239, 68, 68)
    sec = (249, 115, 22)

    sun_x, sun_y = 470, int(395 - (1.0 - ent) * 35)
    pulse = 0.5 + 0.5 * math.sin(t * 5.0)
    _draw_glow_circle(frame, sun_x, sun_y, int(165 + 25 * pulse), sec, 0.42 + 0.15 * heat)
    cv2.circle(frame, (sun_x, sun_y), 54, sec, -1, cv2.LINE_AA)
    cv2.circle(frame, (sun_x, sun_y), 70, (253, 186, 116), 3, cv2.LINE_AA)
    for wx in (235, 355, 470, 595, 715):
        pts = [[int(wx + math.sin(t * 7.0 - sy * 0.045) * 12), sy] for sy in range(475, 625, 14)]
        cv2.polylines(frame, [np.array(pts, np.int32)], False, sec, 4, cv2.LINE_AA)

    # Puente 3D Isométrico (zapatas + pilares + tablero + barandas)
    ox, oy = 465, 865
    _draw_iso_ground_lot(frame, ox=ox, oy=oy + 35, w=380, d=270, strata_h=52, saturado=True, t=t)
    # Zapatas y dos pilotes 3D
    _draw_iso_box(frame, -115, -45, 0, 58, 100, 22, ox=ox, oy=oy, col_top=(148, 163, 184), col_left=(71, 85, 105), col_right=(51, 65, 85))
    _draw_iso_box(frame, 55, -45, 0, 58, 100, 22, ox=ox, oy=oy, col_top=(148, 163, 184), col_left=(71, 85, 105), col_right=(51, 65, 85))
    _draw_iso_box(frame, -105, -35, 22, 38, 80, 122, ox=ox, oy=oy, col_top=(148, 163, 184), col_left=(71, 85, 105), col_right=(51, 65, 85))
    _draw_iso_box(frame, 65, -35, 22, 38, 80, 122, ox=ox, oy=oy, col_top=(148, 163, 184), col_left=(71, 85, 105), col_right=(51, 65, 85))
    # Tablero del puente expandiéndose en X
    exp_len = heat * 36.0
    _draw_iso_box(
        frame, -175 - exp_len * 0.5, -52, 142, 350 + exp_len, 108, 34, ox=ox, oy=oy,
        col_top=(52 + int(heat * 90), 58, 72), col_left=(180, 72, 56), col_right=(135, 48, 42),
        edge_col=(253, 186, 116), edge_w=2,
    )
    # Barandas laterales y línea vial
    cv2.line(frame, _iso(-170 - exp_len * 0.5, 56, 190, ox, oy), _iso(170 + exp_len * 0.5, 56, 190, ox, oy), (226, 232, 240), 3, cv2.LINE_AA)
    cv2.line(frame, _iso(-150, 2, 178, ox, oy), _iso(150, 2, 178, ox, oy), (250, 204, 21), 4, cv2.LINE_AA)

    # Flechas de expansión en 3D
    _draw_arrow_vec(frame, _iso(-185, 0, 110, ox, oy), _iso(-255 - exp_len, 0, 110, ox, oy), prim, 7, 20)
    _draw_arrow_vec(frame, _iso(185, 0, 110, ox, oy), _iso(255 + exp_len, 0, 110, ox, oy), prim, 7, 20)

    # Termómetro a la derecha
    tx, ty0, ty1 = 935, 390, 995
    cv2.rectangle(frame, (tx - 24, ty0), (tx + 24, ty1), (15, 23, 42), -1)
    cv2.rectangle(frame, (tx - 24, ty0), (tx + 24, ty1), (148, 163, 184), 3, cv2.LINE_AA)
    fill_h = int((ty1 - ty0 - 40) * (0.28 + 0.68 * heat))
    col_merc = prim if heat > 0.45 else sec
    cv2.rectangle(frame, (tx - 12, ty1 - fill_h), (tx + 12, ty1), col_merc, -1)
    cv2.circle(frame, (tx, ty1 + 20), 34, col_merc, -1, cv2.LINE_AA)

    temp_val = int(22 + heat * 26)
    textos_overlay.append(("pill", 200, 355, "RADIACIÓN SOLAR", sec, 22))
    textos_overlay.append(("pill", 935, 340, f"{temp_val} °C", col_merc, 28))
    textos_overlay.append(("pill", 465, 1148, "EXPANSIÓN TÉRMICA ← →", prim, 24))


def _stage_compresion_sin_espacio(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    squeeze = ease_in_out(clamp01(p / 0.85))
    shake = int(math.sin(t * 36.0) * (3.0 * squeeze))
    cx = 540
    _draw_caliper_dim(frame, 480, 600, 445, (239, 68, 68))

    gap = max(0, int((1.0 - squeeze) * 14))
    y0, y1 = 560, 890
    _draw_concrete_slab(frame, 85 + int(squeeze * 18), y0 + shake, cx - gap, y1, tint_warm=0.3 + 0.65 * squeeze)
    _draw_concrete_slab(frame, cx + gap, y0 - shake, 995 - int(squeeze * 18), y1, tint_warm=0.3 + 0.65 * squeeze)

    _draw_glow_circle(frame, cx, (y0 + y1) // 2, int(70 + 65 * squeeze), (239, 68, 68), 0.35 + 0.55 * squeeze)
    zig = np.array([
        [cx - 8, y0 + 20], [cx + 12, y0 + 75], [cx - 14, y0 + 145],
        [cx + 14, y0 + 215], [cx - 10, y0 + 280], [cx + 6, y1 - 12],
    ], dtype=np.int32)
    cv2.polylines(frame, [zig], False, (254, 226, 226), 4, cv2.LINE_AA)
    arr_off = int(20 * math.sin(t * 7.0))
    _draw_arrow_vec(frame, (110, 725), (360 + arr_off, 725), (249, 115, 22), 14, 34)
    _draw_arrow_vec(frame, (970, 725), (720 - arr_off, 725), (249, 115, 22), 14, 34)

    ets = spec.get("etiquetas") or ["EMPUJE → ←", "COMPRESIÓN CRÍTICA"]
    textos_overlay.append(("pill_icon", 540, 385, "ESPACIO: 0 mm (BLOQUEADO)", (239, 68, 68), 26, "cross"))
    textos_overlay.append(("pill", 260, 995, ets[0], (249, 115, 22), 23))
    textos_overlay.append(("pill", 800, 995, ets[1] if len(ets) > 1 else "SIN HOLGURA", (239, 68, 68), 23))


def _stage_junta_dilatacion_3d(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    osc = 0.5 + 0.5 * math.sin(t * 2.8)
    gap = int(26 + osc * 46)
    cx = 540
    left_edge = cx - gap // 2 - 40
    right_edge = cx + gap // 2 + 40

    y0, y1 = 560, 880
    cv2.rectangle(frame, (left_edge - 20, y1 - 32), (right_edge + 20, y1 + 18), (6, 95, 70), -1)
    cv2.rectangle(frame, (left_edge - 20, y1 - 32), (right_edge + 20, y1 + 18), (16, 185, 129), 3, cv2.LINE_AA)
    _draw_concrete_slab(frame, 80, y0, left_edge, y1, tint_warm=0.0)
    _draw_concrete_slab(frame, right_edge, y0, 1000, y1, tint_warm=0.0)

    _draw_glow_circle(frame, cx, y0 + 70, 115, (6, 182, 212), 0.30)
    tooth_h = 34
    base_y = y0 + 24
    for idx in range(5):
        ty = base_y + idx * 54
        cv2.rectangle(frame, (left_edge - 14, ty), (left_edge + 110, ty + tooth_h), (203, 213, 225), -1)
        cv2.rectangle(frame, (left_edge - 14, ty), (left_edge + 110, ty + tooth_h), (56, 189, 248), 2, cv2.LINE_AA)
    for idx in range(4):
        ty = base_y + 27 + idx * 54
        cv2.rectangle(frame, (right_edge - 110, ty), (right_edge + 14, ty + tooth_h), (148, 163, 184), -1)
        cv2.rectangle(frame, (right_edge - 110, ty), (right_edge + 14, ty + tooth_h), (16, 185, 129), 2, cv2.LINE_AA)

    _draw_caliper_dim(frame, left_edge, right_edge, 430, (16, 185, 129))
    _draw_arrow_vec(frame, (310, 960), (210, 960), (6, 182, 212), 7, 20)
    _draw_arrow_vec(frame, (770, 960), (870, 960), (6, 182, 212), 7, 20)

    mm_live = int(14 + osc * 18)
    ets = spec.get("etiquetas") or ["DIENTES ACERO", "HOLGURA SEGURA"]
    textos_overlay.append(("pill_icon", cx, 370, f"JUNTA ACTIVA: {mm_live} mm", (16, 185, 129), 26, "check"))
    textos_overlay.append(("pill", 260, 1055, ets[0], (56, 189, 248), 23))
    textos_overlay.append(("pill", 800, 1055, ets[1] if len(ets) > 1 else "RESPIRO LIBRE", (16, 185, 129), 23))


def _stage_ciclo_termico(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    phase = 0.5 - 0.5 * math.cos(t * 2.4)
    bar_x0, bar_x1, bar_y0, bar_y1 = 150, 930, 390, 446
    for i in range(40):
        frac = i / 39.0
        bx0 = int(bar_x0 + frac * (bar_x1 - bar_x0))
        bx1 = int(bar_x0 + (i + 1) / 40.0 * (bar_x1 - bar_x0)) + 1
        r = int(56 + frac * (249 - 56))
        g = int(189 + frac * (115 - 189))
        b = int(248 + frac * (22 - 248))
        cv2.rectangle(frame, (bx0, bar_y0), (bx1, bar_y1), (r, g, b), -1)
    cv2.rectangle(frame, (bar_x0, bar_y0), (bar_x1, bar_y1), (226, 232, 240), 3, cv2.LINE_AA)

    knob_x = int(bar_x0 + phase * (bar_x1 - bar_x0))
    knob_col = (249, 115, 22) if phase > 0.5 else (56, 189, 248)
    _draw_glow_circle(frame, knob_x, (bar_y0 + bar_y1) // 2, 48, knob_col, 0.65)
    cv2.circle(frame, (knob_x, (bar_y0 + bar_y1) // 2), 26, (255, 255, 255), -1, cv2.LINE_AA)
    cv2.circle(frame, (knob_x, (bar_y0 + bar_y1) // 2), 18, knob_col, -1, cv2.LINE_AA)

    stretch = int(phase * 70)
    _draw_concrete_slab(frame, 180 - stretch // 2, 620, 900 + stretch // 2, 870, tint_warm=phase * 0.65)
    if phase >= 0.5:
        _draw_arrow_vec(frame, (220, 965), (110, 965), (249, 115, 22), 8, 22)
        _draw_arrow_vec(frame, (860, 965), (970, 965), (249, 115, 22), 8, 22)
        estado_txt, col_txt = "CALOR → EXPANDE", (249, 115, 22)
    else:
        _draw_arrow_vec(frame, (110, 965), (220, 965), (56, 189, 248), 8, 22)
        _draw_arrow_vec(frame, (970, 965), (860, 965), (56, 189, 248), 8, 22)
        estado_txt, col_txt = "FRÍO → CONTRAE", (56, 189, 248)

    temp_c = int(12 + phase * 33)
    textos_overlay.append(("pill", 220, 330, "12 °C FRÍO", (56, 189, 248), 24))
    textos_overlay.append(("pill", 860, 330, "45 °C CALOR", (249, 115, 22), 24))
    textos_overlay.append(("pill", knob_x, 515, f"{temp_c} °C", col_txt, 26))
    textos_overlay.append(("pill", 540, 1065, estado_txt, col_txt, 28))


def _stage_alerta_fallo_junta(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    pulse = 0.5 + 0.5 * math.sin(t * 8.0)
    cx = 540
    _draw_hazard_triangle(frame, cx, 395, 130, pulse, (245, 158, 11))
    _draw_concrete_slab(frame, 85, 595, 480, 885, tint_warm=0.35)
    _draw_concrete_slab(frame, 600, 595, 995, 885, tint_warm=0.35)
    _draw_glow_circle(frame, cx, 740, int(90 + 35 * pulse), (239, 68, 68), 0.55)
    for rx, ry, rr in [(520, 650, 26), (555, 705, 30), (528, 765, 28), (554, 825, 25)]:
        cv2.circle(frame, (rx, ry), rr, (120, 113, 108), -1, cv2.LINE_AA)
        cv2.circle(frame, (rx, ry), rr, (239, 68, 68), 3, cv2.LINE_AA)
    for kr in range(3):
        rad = int(60 + ((t * 120 + kr * 45) % 140))
        cv2.circle(frame, (cx, 740), rad, (239, 68, 68), 2, cv2.LINE_AA)

    bx0, bx1, by0, by1 = 180, 900, 975, 1020
    cv2.rectangle(frame, (bx0, by0), (bx1, by1), (30, 41, 59), -1)
    fill_w = int((bx1 - bx0) * (0.55 + 0.42 * ease_out_cubic(p)))
    cv2.rectangle(frame, (bx0, by0), (bx0 + fill_w, by1), (239, 68, 68), -1)
    cv2.rectangle(frame, (bx0, by0), (bx1, by1), (245, 158, 11), 3, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["BLOQUEO INTERNO", "SOBRECARGA"]
    textos_overlay.append(("pill_icon", cx, 520, "SEPARACIÓN BLOQUEADA", (245, 158, 11), 26, "warn"))
    textos_overlay.append(("pill", cx, 1085, f"{ets[0]} · PRESIÓN CRÍTICA", (239, 68, 68), 24))


def _stage_viga_fractura(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    crack_p = clamp01((p - 0.18) / 0.65)
    split_deg = ease_in_out(clamp01((p - 0.52) / 0.48))
    drop = int(split_deg * 26)
    cx = 540
    y0, y1 = 620, 850
    _draw_concrete_slab(frame, 110, y0, cx - 3, y1 + drop // 2, tint_warm=0.4 + 0.5 * crack_p)
    _draw_concrete_slab(frame, cx + 3, y0, 970, y1 + drop // 2, tint_warm=0.4 + 0.5 * crack_p)
    for sx in (150, 930):
        cv2.rectangle(frame, (sx - 35, y1 + 4), (sx + 35, 1060), (71, 85, 105), -1)
        cv2.rectangle(frame, (sx - 35, y1 + 4), (sx + 35, 1060), (148, 163, 184), 3, cv2.LINE_AA)
    push = int(math.sin(t * 9.0) * 8)
    _draw_arrow_vec(frame, (55, 735), (165 + push, 735), (239, 68, 68), 12, 30)
    _draw_arrow_vec(frame, (1025, 735), (915 - push, 735), (239, 68, 68), 12, 30)
    _draw_arrow_vec(frame, (cx, 385), (cx, 580 + push), (249, 115, 22), 14, 34)

    crack_nodes = [(cx, y0), (cx - 18, y0 + 46), (cx + 16, y0 + 95), (cx - 22, y0 + 148), (cx + 12, y0 + 195), (cx - 6, y1 + drop // 2)]
    if crack_p > 0.02:
        n_segs = max(2, int(round(crack_p * len(crack_nodes))))
        _draw_glow_circle(frame, cx, y0 + 115, int(60 + 70 * crack_p), (239, 68, 68), 0.70)
        pts = np.array(crack_nodes[:n_segs], dtype=np.int32)
        cv2.polylines(frame, [pts], False, (239, 68, 68), 11, cv2.LINE_AA)
        cv2.polylines(frame, [pts], False, (254, 242, 242), 4, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["CARGA EXTREMA", "FRACTURA"]
    textos_overlay.append(("pill", cx, 340, "CARGA EXTREMA ↓", (249, 115, 22), 25))
    textos_overlay.append(("pill_icon", cx, 1115, "RUPTURA ESTRUCTURAL" if crack_p > 0.5 else ets[0], (239, 68, 68), 25, "cross"))


def _stage_estructura_flexible(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    sway = math.sin(t * 3.0) * 9.0
    deck_y = int(835 + sway * 0.4)
    cv2.line(frame, (70, 1060), (1010, 1060), (16, 185, 129), 4, cv2.LINE_AA)
    for px in (330, 750):
        pylon_pts = np.array([[px - 22, 1060], [px - 10, 415], [px + 10, 415], [px + 22, 1060]], np.int32)
        cv2.fillPoly(frame, [pylon_pts], (51, 65, 85), cv2.LINE_AA)
        cv2.polylines(frame, [pylon_pts], True, (56, 189, 248), 3, cv2.LINE_AA)
        cv2.rectangle(frame, (px - 28, deck_y + 18), (px + 28, deck_y + 38), (16, 185, 129), -1)
        for offset in (-210, -145, -80, 80, 145, 210):
            ax = max(95, min(985, px + offset))
            cv2.line(frame, (px, 435), (ax, deck_y - 6), (30, 144, 180), 3, cv2.LINE_AA)
            dot_p = (t * 0.8 + abs(offset) * 0.003) % 1.0
            cv2.circle(frame, (int(px + (ax - px) * dot_p), int(435 + (deck_y - 441) * dot_p)), 5, (16, 185, 129), -1, cv2.LINE_AA)

    pts_deck = [[dx, int(deck_y + math.sin(((dx - 95) / 900.0) * math.pi) * sway)] for dx in range(95, 995, 25)]
    cv2.polylines(frame, [np.array(pts_deck, np.int32)], False, (226, 232, 240), 18, cv2.LINE_AA)
    cv2.polylines(frame, [np.array(pts_deck, np.int32)], False, (16, 185, 129), 4, cv2.LINE_AA)
    ets = spec.get("etiquetas") or ["CABLES TENSORES", "FLEXIÓN CONTROLADA"]
    textos_overlay.append(("pill", 540, 350, ets[0], (56, 189, 248), 25))
    textos_overlay.append(("pill_icon", 540, 1135, "FLEXIÓN CONTROLADA", (16, 185, 129), 26, "check"))


def _stage_comparativa_doble(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    pulse = 0.5 + 0.5 * math.sin(t * 4.5)
    cv2.rectangle(frame, (95, 325), (985, 725), (36, 15, 24), -1)
    cv2.rectangle(frame, (95, 325), (985, 725), (239, 68, 68), 3, cv2.LINE_AA)
    _draw_concrete_slab(frame, 180, 480, 536, 610, tint_warm=0.8)
    _draw_concrete_slab(frame, 544, 480, 900, 610, tint_warm=0.8)
    _draw_arrow_vec(frame, (125, 545), (225, 545), (239, 68, 68), 9, 22)
    _draw_arrow_vec(frame, (955, 545), (855, 545), (239, 68, 68), 9, 22)
    cv2.polylines(frame, [np.array([[540, 480], [528, 525], [552, 565], [538, 610]], np.int32)], False, (254, 202, 202), 6, cv2.LINE_AA)

    cv2.rectangle(frame, (95, 775), (985, 1175), (10, 36, 36), -1)
    cv2.rectangle(frame, (95, 775), (985, 1175), (16, 185, 129), 3, cv2.LINE_AA)
    gap = int(34 + 28 * pulse)
    _draw_concrete_slab(frame, 180, 930, 540 - gap // 2, 1060, tint_warm=0.0)
    _draw_concrete_slab(frame, 540 + gap // 2, 930, 900, 1060, tint_warm=0.0)
    cv2.rectangle(frame, (540 - gap // 2 - 10, 1035), (540 + gap // 2 + 10, 1075), (16, 185, 129), -1)
    textos_overlay.append(("pill_icon", 540, 395, "SIN ADAPTACIÓN · COLAPSO", (239, 68, 68), 25, "cross"))
    textos_overlay.append(("pill_icon", 540, 845, "CON DISEÑO FLEXIBLE · SEGURO", (16, 185, 129), 25, "check"))


def _stage_composicion_arquitectonica(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    """Renderizador paramétrico libre dirigido por Gemini para dibujar edificaciones y tuberías a medida."""
    dib = spec.get("dibujo") or {}
    elems = dib.get("elementos") or []
    vista = str(dib.get("vista") or "isometrica").lower()

    if not elems:
        # Fallback elegante según tema si no llegaron elementos
        if spec.get("tema_global") == "cimientos_drenaje":
            return _stage_edificio_moderno_grietas(frame, t, p, spec, textos_overlay)
        return _stage_casa_isometrica_tejado(frame, t, p, spec, textos_overlay)

    def _px(nx: float) -> int:
        return int(95 + (clamp01(nx / 100.0) * 890))

    def _py(ny: float) -> int:
        return int(300 + (clamp01(ny / 100.0) * 860))

    if vista == "planta":
        _draw_topdown_lot_grid(frame, 115, 315, 965, 1125, (56, 189, 248))

    for el in elems:
        if not isinstance(el, dict):
            continue
        tipo = str(el.get("tipo", "")).lower()
        etq = str(el.get("etiqueta") or "").strip().upper()
        if tipo == "terreno":
            _draw_iso_ground_lot(
                frame, ox=540, oy=_py(el.get("y", 72)),
                w=390, d=330, strata_h=85, saturado=bool(el.get("saturado", False)), t=t,
            )
        elif tipo == "casa_iso":
            ox_c, oy_c = _px(el.get("x", 50)), _py(el.get("y", 62))
            dano = str(el.get("dano", "none")).lower()
            _draw_iso_house(
                frame, ox=ox_c, oy=oy_c,
                w=float(el.get("w", 32)) * 6.5,
                d=float(el.get("h", 24)) * 6.8,
                h_wall=125,
                roof_style=str(el.get("techo", "pendiente")),
                water_film=(dano != "none" or el.get("techo") == "pendiente"),
                crack_p=0.8 if "grieta" in dano else 0.0,
                moisture_p=0.7 if "humed" in dano else 0.0,
                t=t,
            )
            if etq:
                textos_overlay.append(("pill", ox_c, max(340, oy_c - 220), etq[:18], (56, 189, 248), 22))
        elif tipo == "edificio_iso":
            ox_e, oy_e = _px(el.get("x", 50)), _py(el.get("y", 66))
            dano = str(el.get("dano", "none")).lower()
            _draw_iso_building(
                frame, ox=ox_e, oy=oy_e,
                floors=max(2, min(5, int(el.get("pisos", 3)))),
                crack_p=0.8 if "grieta" in dano else 0.0,
                moisture_p=0.65 if ("humed" in dano or "grieta" in dano) else 0.0,
            )
            if etq:
                textos_overlay.append(("pill", ox_e, max(340, oy_e - 270), etq[:18], (56, 189, 248), 22))
        elif tipo == "tuberia":
            pts_raw = el.get("puntos") or [[20, 68], [55, 76], [85, 80]]
            pts = [(_px(pt[0]), _py(pt[1])) for pt in pts_raw if isinstance(pt, (list, tuple)) and len(pt) >= 2]
            _draw_pipe_run(frame, pts, diam=int(el.get("diam", 24)), perforado=bool(el.get("perforada", False)), t=t)
            if etq and pts:
                textos_overlay.append(("pill", pts[len(pts) // 2][0], min(1130, pts[len(pts) // 2][1] + 55), etq[:18], (250, 204, 21), 21))
        elif tipo == "losa":
            if "x1" in el or "x2" in el:
                lx1, ly1, lx2, ly2 = el.get("x1", 20), el.get("y1", 55), el.get("x2", 80), el.get("y2", 70)
            else:
                cx_l, cy_l = float(el.get("x", 50)), float(el.get("y", 55))
                w_l, h_l = max(8.0, float(el.get("w", 50))), max(4.0, float(el.get("h", 14)))
                lx1, lx2 = cx_l - w_l * 0.5, cx_l + w_l * 0.5
                ly1, ly2 = cy_l - h_l * 0.5, cy_l + h_l * 0.5
            _draw_concrete_slab(
                frame, _px(lx1), _py(ly1), _px(lx2), _py(ly2),
                tint_warm=0.65 if el.get("calor") else 0.0,
            )
        elif tipo == "flecha_flujo":
            col_k = str(el.get("color", "agua")).lower()
            col = (239, 68, 68) if col_k == "peligro" else ((16, 185, 129) if col_k == "verde" else (56, 189, 248))
            _draw_arrow_vec(frame, (_px(el.get("x1", 25)), _py(el.get("y1", 40))), (_px(el.get("x2", 75)), _py(el.get("y2", 60))), col, 9, 24)
        elif tipo == "lluvia":
            z = el.get("zona") or [20, 12, 80, 42]
            zx0, zy0, zx1, zy1 = _px(z[0]), _py(z[1]), _px(z[2]), _py(z[3])
            for k in range(10):
                dt = (t * 1.1 + k * 0.13) % 1.0
                rx = zx0 + ((k * 67) % max(40, zx1 - zx0))
                ry = int(zy0 + dt * max(40, zy1 - zy0))
                cv2.line(frame, (rx, ry), (rx - 3, ry + 16), (125, 211, 252), 3, cv2.LINE_AA)
        elif tipo == "foco_alerta":
            fx, fy = _px(el.get("x", 50)), _py(el.get("y", 55))
            _draw_glow_circle(frame, fx, fy, 75, (239, 68, 68), 0.55)
        elif tipo == "cota":
            cy_cota = _py(el.get("y1", 25))
            _draw_caliper_dim(frame, _px(el.get("x1", 25)), _px(el.get("x2", 75)), cy_cota, (250, 204, 21))
            if el.get("texto"):
                y_pill = min(1152, cy_cota + 36) if el.get("y1", 25) > 55 else max(320, cy_cota - 40)
                textos_overlay.append(("pill", (_px(el.get("x1", 25)) + _px(el.get("x2", 75))) // 2, y_pill, str(el["texto"]).upper()[:18], (250, 204, 21), 22))


def _stage_pregunta_panorama(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    cx, cy = 540, 660
    pulse = 0.5 + 0.5 * math.sin(t * 3.8)
    _draw_glow_circle(frame, cx, cy, int(210 + 40 * pulse), (56, 189, 248), 0.35)

    # Plano arquitectónico wireframe acorde al tema de la obra (casa / edificio / puente)
    tema_g = spec.get("tema_global", "obra_general")
    dib_t = str((spec.get("dibujo") or {}).get("tema_visual", "")).lower()
    if dib_t == "edificio" or tema_g == "cimientos_drenaje":
        _draw_iso_building(frame, ox=540, oy=985, w=175, d=145, floors=3, floor_h=48, crack_p=0.0, moisture_p=0.0)
    elif dib_t == "puente" or tema_g == "puente_termico":
        arc_pts = [[ax, int(960 - (1.0 - ((ax - 540) / 360.0) ** 2) * 140)] for ax in range(180, 905, 20)]
        cv2.polylines(frame, [np.array(arc_pts, np.int32)], False, (56, 189, 248), 5, cv2.LINE_AA)
        cv2.line(frame, (170, 960), (910, 960), (148, 163, 184), 6, cv2.LINE_AA)
    else:
        _draw_iso_ground_lot(frame, ox=540, oy=990, w=290, d=240, strata_h=50, saturado=False, t=t)
        _draw_iso_house(frame, ox=535, oy=975, w=165, d=135, h_wall=95, roof_style="pendiente", pendiente_px=28.0, water_film=True, t=t)

    # Órbitas de análisis y signo '?' arriba de la maqueta
    cy_q = 520
    for rad_o, spd, col in [(175, 0.9, (56, 189, 248)), (135, -1.4, (250, 204, 21))]:
        cv2.circle(frame, (cx, cy_q), rad_o, (30, 58, 95), 2, cv2.LINE_AA)
        for k in range(3):
            ang = t * spd + k * (2.0 * math.pi / 3.0)
            cv2.circle(frame, (int(cx + math.cos(ang) * rad_o), int(cy_q + math.sin(ang) * rad_o)), 9, col, -1, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy_q), 84, (15, 32, 62), -1, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy_q), 84, (250, 204, 21), 5, cv2.LINE_AA)

    ets = spec.get("etiquetas") or ["FÍSICA", "ARQUITECTURA", "CIENCIA"]
    textos_overlay.append(("big_center", cx, cy_q, "?", (250, 204, 21), 104))
    textos_overlay.append(("pill", 540, 1135, " · ".join(ets[:3]), (56, 189, 248), 23))


def _stage_cta_comenta(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    ent = ease_out_cubic(clamp01(t / 0.35))
    pulse = 0.5 + 0.5 * math.sin(t * 5.2)
    cx, cy = 540, int(680 + (1.0 - ent) * 80)

    _draw_glow_circle(frame, cx, cy, int(230 + 40 * pulse), (56, 189, 248), 0.35)
    x0, y0, x1, y1 = 130, cy - 230, 950, cy + 230
    cv2.rectangle(frame, (x0, y0), (x1, y1), (15, 26, 46), -1)
    cv2.rectangle(frame, (x0, y0), (x1, y1), (56, 189, 248), 4, cv2.LINE_AA)

    btn_pad = int(pulse * 10)
    cv2.rectangle(frame, (240 - btn_pad, cy - 20), (840 + btn_pad, cy + 100), (2, 132, 199), -1)
    cv2.rectangle(frame, (240 - btn_pad, cy - 20), (840 + btn_pad, cy + 100), (125, 211, 252), 4, cv2.LINE_AA)

    tap_y = int(cy + 145 + math.sin(t * 7.0) * 14)
    _draw_arrow_vec(frame, (cx, tap_y + 55), (cx, tap_y - 10), (250, 204, 21), 10, 24)

    kw = spec.get("cta_palabra") or spec.get("kpi") or "COMENTA"
    textos_overlay.append(("big_center", cx, cy - 115, "ESCRIBE EN COMENTARIOS:", (203, 213, 225), 32))
    textos_overlay.append(("big_center", cx, cy + 40, f'"{kw.upper()}"', (255, 255, 255), 62))
    textos_overlay.append(("pill", cx, y1 + 75, "Y RECIBE EL PLANO TÉCNICO", (168, 85, 247), 25))


def _stage_engranajes_sistema(frame: np.ndarray, t: float, p: float, spec: dict, textos_overlay: list):
    ang = t * 1.4
    _draw_gear(frame, 360, 585, 135, 12, ang, (30, 58, 95), (56, 189, 248))
    _draw_gear(frame, 610, 520, 105, 10, -ang * 1.2 + 0.3, (30, 64, 58), (16, 185, 129))
    _draw_gear(frame, 750, 725, 95, 9, ang * 1.33, (55, 48, 30), (250, 204, 21))
    cv2.rectangle(frame, (130, 910), (950, 965), (15, 23, 42), -1)
    cv2.rectangle(frame, (130, 910), (950, 965), (56, 189, 248), 3, cv2.LINE_AA)
    for k in range(6):
        fx = int(155 + ((t * 320 + k * 140) % 770))
        cv2.circle(frame, (fx, 938), 11, (16, 185, 129), -1, cv2.LINE_AA)
    ets = spec.get("etiquetas") or ["SISTEMA", "ENERGÍA", "FLUJO"]
    textos_overlay.append(("pill", 360, 790, ets[0], (56, 189, 248), 24))
    textos_overlay.append(("pill", 540, 1055, ets[2] if len(ets) > 2 else "SISTEMA ACTIVO", (16, 185, 129), 25))


STAGE_DISPATCH = {
    "casa_isometrica_tejado": _stage_casa_isometrica_tejado,
    "plano_planta_tejado": _stage_plano_planta_tejado,
    "estancamiento_colapso_techo": _stage_estancamiento_colapso_techo,
    "corte_casa_terreno_humedad": _stage_corte_casa_terreno_humedad,
    "capas_impermeables_3d": _stage_capas_impermeables_3d,
    "desvio_hidraulico_planta": _stage_desvio_hidraulico_planta,
    "fluido_sin_friccion": _stage_fluido_sin_friccion,
    "comparativa_viviendas_3d": _stage_comparativa_viviendas_3d,
    "edificio_moderno_grietas": _stage_edificio_moderno_grietas,
    "plano_planta_drenaje": _stage_plano_planta_drenaje,
    "perfil_tuberia_pendiente": _stage_perfil_tuberia_pendiente,
    "drenaje_cimientos": _stage_drenaje_cimientos,
    "presion_hidrostatica": _stage_presion_hidrostatica,
    "densidad_suelo_estratos": _stage_densidad_suelo_estratos,
    "vivienda_colapso_3d": _stage_vivienda_colapso_3d,
    "puente_isometrico_calor": _stage_puente_isometrico_calor,
    "compresion_sin_espacio": _stage_compresion_sin_espacio,
    "junta_dilatacion_3d": _stage_junta_dilatacion_3d,
    "ciclo_termico": _stage_ciclo_termico,
    "alerta_fallo_junta": _stage_alerta_fallo_junta,
    "viga_fractura": _stage_viga_fractura,
    "estructura_flexible": _stage_estructura_flexible,
    "comparativa_doble": _stage_comparativa_doble,
    "composicion_arquitectonica": _stage_composicion_arquitectonica,
    "pregunta_panorama": _stage_pregunta_panorama,
    "cta_comenta": _stage_cta_comenta,
    "engranajes_sistema": _stage_engranajes_sistema,
    # Compatibilidad con nombres previos
    "tejado_pendiente": _stage_casa_isometrica_tejado,
    "puente_calor": _stage_puente_isometrico_calor,
    "junta_dilatacion": _stage_junta_dilatacion_3d,
    "flujo_general": _stage_desvio_hidraulico_planta,
}


def _render_frame_motion(
    t: float,
    dur: float,
    scene_idx: int,
    total_scenes: int,
    spec: dict,
) -> np.ndarray:
    p = clamp01(t / max(0.1, dur))
    acento = spec.get("acento", "ciencia")
    tema = TEMAS_ACENTO.get(acento, TEMAS_ACENTO["ciencia"])
    prim = tema["primario"]
    sec = tema["secundario"]

    frame = _build_base_canvas(acento).copy()

    # 1. Barra de progreso global arriba
    prog = clamp01((scene_idx + p) / max(1, total_scenes))
    cv2.rectangle(frame, (56, 30), (W - 56, 42), (30, 41, 59), -1)
    bar_w = int((W - 112) * prog)
    if bar_w > 2:
        cv2.rectangle(frame, (56, 30), (56 + bar_w, 42), prim, -1)

    # 2. Escenario animado multi-perspectiva
    textos_overlay = []
    plantilla = spec.get("plantilla", "casa_isometrica_tejado")
    fn = STAGE_DISPATCH.get(plantilla, _stage_casa_isometrica_tejado)
    fn(frame, t, p, spec, textos_overlay)

    # Indicador discreto de cámara / perspectiva arquitectónica en esquina superior del lienzo de dibujo
    _, persp_def = PERSPECTIVA_POR_PLANTILLA.get(plantilla, ("isometrica", "PLANO 3D"))
    persp_lbl = _limpiar_texto_visual(spec.get("perspectiva_label") or persp_def, "mono")[:24]

    # 3. Tarjeta superior de encabezado y overlays vectoriales crisp en Pillow
    ent_head = ease_out_cubic(clamp01(t / 0.25))
    hx_shift = int((1.0 - ent_head) * 35)
    _alpha_rect(frame, 60 + hx_shift, 78, W - 60 + hx_shift, 232, (14, 24, 44), 0.88)

    pil_img = Image.fromarray(frame)
    draw = ImageDraw.Draw(pil_img)

    draw.rounded_rectangle([60 + hx_shift, 78, W - 60 + hx_shift, 232], radius=16, outline=prim, width=3)
    draw.rounded_rectangle([60 + hx_shift, 78, 74 + hx_shift, 232], radius=6, fill=prim)

    esc_tag = f"ESCENA {scene_idx + 1:02d}/{total_scenes:02d}  ·  {spec.get('subtitulo', tema['tag'])}"
    _draw_text_fitted(
        draw, 98 + hx_shift, 96, esc_tag, max_w=640,
        sizes=(23, 20, 18), fill=sec, kind="bold", max_lines=1,
    )
    _draw_text_fitted(
        draw, 98 + hx_shift, 136, spec.get("titulo", f"ESCENA {scene_idx + 1}"),
        max_w=635, sizes=(40, 34, 28, 24), fill=(248, 250, 252), kind="bold", max_lines=2,
    )

    kpi_txt = (spec.get("kpi") or "").strip()
    if kpi_txt:
        kx0, ky0, kx1, ky1 = 758 + hx_shift, 102, W - 82 + hx_shift, 208
        draw.rounded_rectangle([kx0, ky0, kx1, ky1], radius=14, fill=(10, 18, 34), outline=sec, width=2)
        _draw_text_fitted(
            draw, (kx0 + kx1) // 2, (ky0 + ky1) // 2, kpi_txt,
            max_w=(kx1 - kx0 - 20), sizes=(30, 25, 21, 18, 15),
            fill=sec, kind="mono", centered=True, max_lines=1,
        )

    # Pill discreta de ángulo de cámara abajo a la izquierda dentro del marco seguro
    f_cam = _get_font(17, "mono")
    tw_cam, th_cam = _text_size(draw, persp_lbl, f_cam)
    draw.rounded_rectangle([72, 1200, min(460, 100 + tw_cam), 1232], radius=8, fill=(10, 18, 34), outline=prim, width=2)
    draw.text((86, 1205), persp_lbl, font=f_cam, fill=sec)

    for ov in textos_overlay:
        kind = ov[0]
        if kind in ("pill", "pill_icon"):
            if kind == "pill_icon":
                _, px, py, txt, col, sz, badge_type = ov
            else:
                _, px, py, txt, col, sz = ov
                badge_type = None
            txt_clean = _limpiar_texto_visual(txt, "bold")
            if not txt_clean:
                continue
            f = _get_font(sz, "bold")
            tw, th = _text_size(draw, txt_clean, f)
            pad_x, pad_y = 22, 11
            badge_r = max(11, int(sz * 0.44)) if badge_type else 0
            badge_gap = (badge_r * 2 + 12) if badge_type else 0
            half_w = (tw + badge_gap) // 2 + pad_x
            rx0 = max(65, px - half_w)
            rx1 = min(W - 65, px + half_w)
            ry0 = min(1192 - th - 2 * pad_y, max(254, py - th // 2 - pad_y))
            ry1 = ry0 + th + 2 * pad_y
            draw.rounded_rectangle([rx0, ry0, rx1, ry1], radius=14, fill=(11, 19, 36), outline=col, width=3)
            if badge_type:
                bx = rx0 + pad_x + badge_r
                by = (ry0 + ry1) // 2
                _draw_vector_badge(draw, bx, by, badge_r, badge_type)
                text_left = bx + badge_r + 12
                text_right = rx1 - pad_x
                text_cx = (text_left + text_right) // 2
                max_tw = max(80, text_right - text_left)
            else:
                text_cx = (rx0 + rx1) // 2
                max_tw = max(80, rx1 - rx0 - 16)
            _draw_text_fitted(
                draw, text_cx, (ry0 + ry1) // 2, txt_clean,
                max_w=max_tw, sizes=(sz, max(16, sz - 4), 16),
                fill=(248, 250, 252), kind="bold", centered=True, max_lines=1,
            )
        elif kind == "big_center":
            _, px, py, txt, col, sz = ov
            _draw_text_fitted(
                draw, px, py, txt, max_w=760,
                sizes=(sz, max(24, sz - 12), max(20, sz - 24)),
                fill=col, kind="bold", centered=True, max_lines=1,
            )

    return np.asarray(pil_img)


def render_escena_motion_mp4(
    out_path: str,
    duration: float,
    scene_idx: int,
    total_scenes: int,
    spec: dict,
    crf: int = 18,
    con_audio_silencio: bool = False,
) -> bool:
    """Renderiza una escena infográfica animada 2D/3D (1080x1920 @ 30fps) directamente a MP4."""
    dur = max(0.3, float(duration))
    total_frames = max(1, int(round(dur * FPS)))
    ffmpeg_bin = _resolver_ruta_ffmpeg("ffmpeg")

    cmd = [
        ffmpeg_bin, "-hide_banner", "-loglevel", "error", "-y",
        "-f", "rawvideo", "-vcodec", "rawvideo",
        "-s", f"{W}x{H}", "-pix_fmt", "rgb24", "-r", str(FPS),
        "-i", "-",
    ]
    if con_audio_silencio:
        cmd += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-c:a", "aac", "-shortest"]
    else:
        cmd += ["-an"]

    cmd += [
        "-c:v", "libx264", "-preset", "fast", "-crf", str(crf),
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        str(out_path),
    ]

    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    assert proc.stdin is not None
    try:
        for f_idx in range(total_frames):
            t = f_idx / float(FPS)
            rgb = _render_frame_motion(t, dur, scene_idx, total_scenes, spec)
            proc.stdin.write(rgb.tobytes())
        proc.stdin.close()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
        raise
    stderr_out = proc.stderr.read().decode("utf-8", errors="replace") if proc.stderr else ""
    rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"FFmpeg falló renderizando escena {scene_idx + 1}: {stderr_out[:300]}")
    return Path(out_path).is_file()
