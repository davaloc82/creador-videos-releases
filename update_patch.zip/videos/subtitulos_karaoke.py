#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
subtitulos_karaoke.py
---------------------
Genera subtítulos animados estilo karaoke idénticos a CapCut:
- Tipografía: Melvins One en MAYÚSCULAS completas.
- Soporte para tildes mayúsculas (Á, É, Í, Ó, Ú, Ñ, Ü) dibujadas con precisión.
- Estilo: Resaltado palabra por palabra con caja redondeada de color #ff0050.
- Distribución: 1 o 2 líneas centradas en la zona inferior (1080x1920).
- Alto rendimiento: Pre-renderizado de estados y renderizado mediante pipe FFmpeg (overlay RGBA).
"""

import argparse
import difflib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

_aqui = Path(__file__).resolve().parent
_root = _aqui.parent
for _p in (_root, _root / "core", _aqui):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
from PIL import Image, ImageFont, ImageDraw

try:
    from ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion, ajustar_comando_ffmpeg
except ImportError:
    try:
        from videos.ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion, ajustar_comando_ffmpeg
    except ImportError:
        detectar_ffmpeg = lambda: "ffmpeg"
        detectar_ffprobe = lambda: "ffprobe"
        obtener_duracion = lambda x: None
        ajustar_comando_ffmpeg = lambda x: x

# Configuración visual por defecto
DEFAULT_FONT_SIZE = 54
STROKE_WIDTH = 3                    # Calibrado exactamente al valor 37 de CapCut
BOX_COLOR = (255, 0, 80, 255)       # #ff0050
TEXT_COLOR = (255, 255, 255, 255)   # Blanco
STROKE_COLOR = (0, 0, 0, 255)       # Negro
BOX_RADIUS = 12
PAD_X = 12
PAD_TOP = 8
PAD_BOTTOM = 6
STRIP_H = 260
OVERLAY_Y = 1360

ACCENTS = {
    'Á': ('A', 'acute'),
    'É': ('E', 'acute'),
    'Í': ('I', 'acute'),
    'Ó': ('O', 'acute'),
    'Ú': ('U', 'acute'),
    'Ñ': ('N', 'tilde'),
    'Ü': ('U', 'dieresis'),
}

def find_font_path():
    """Busca la fuente Melvins One en la carpeta local del proyecto o en el sistema."""
    candidatos = [
        Path(__file__).parent.parent / "fonts" / "MelvinsoneRegular-d9mvR.otf",
        Path(__file__).parent / "fonts" / "MelvinsoneRegular-d9mvR.otf",
        Path(__file__).parent / "MelvinsoneRegular-d9mvR.otf",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts" / "MelvinsoneRegular-d9mvR.otf",
        Path(os.environ.get("USERPROFILE", str(Path.home()))) / "AppData" / "Local" / "Microsoft" / "Windows" / "Fonts" / "MelvinsoneRegular-d9mvR.otf",
        Path(r"C:\Windows\Fonts\MelvinsoneRegular-d9mvR.otf")
    ]
    for c in candidatos:
        if c.is_file():
            return str(c.resolve())
    return None

def get_font(font_size=DEFAULT_FONT_SIZE):
    fpath = find_font_path()
    if fpath:
        return ImageFont.truetype(fpath, font_size)
    print("AVISO: No se encontró Melvins One. Usando fuente predeterminada.")
    return ImageFont.load_default()

def get_fallback_font(font_size=DEFAULT_FONT_SIZE):
    candidatos = [
        Path(r"C:\Windows\Fonts\arialbd.ttf"),
        Path(r"C:\Windows\Fonts\arial.ttf"),
    ]
    for c in candidatos:
        if c.is_file():
            try:
                return ImageFont.truetype(str(c), int(round(font_size * 0.82)))
            except Exception:
                pass
    return ImageFont.load_default()

FALLBACK_FONT = get_fallback_font(DEFAULT_FONT_SIZE)
FALLBACK_CHARS = set("!&()*?@[]^{}¿¡\"':;<=>\\_`~")

def draw_accented_word(draw, font, text, x, y, stroke_w=STROKE_WIDTH, fill_col=TEXT_COLOR, stroke_col=STROKE_COLOR, fallback_font=None):
    """Dibuja una palabra en mayúsculas agregando acentos dinámicos y fallback para caracteres no soportados."""
    f_back = fallback_font or FALLBACK_FONT
    cur_x = x
    for ch in text.upper():
        if ch.isdigit() or ch in FALLBACK_CHARS:
            y_d = y + (4 if ch.isdigit() else 1)
            draw.text((cur_x, y_d), ch, font=f_back, fill=fill_col, stroke_width=stroke_w, stroke_fill=stroke_col)
            bb = draw.textbbox((cur_x, y_d), ch, font=f_back)
            cur_x += (bb[2] - bb[0]) + 1
        elif ch in ACCENTS:
            base, acc = ACCENTS[ch]
            draw.text((cur_x, y), base, font=font, fill=fill_col, stroke_width=stroke_w, stroke_fill=stroke_col)
            bb = draw.textbbox((cur_x, y), base, font=font)
            cw = bb[2] - bb[0]
            cx = cur_x + cw / 2.0
            top_y = bb[1]
            if acc == 'acute':
                draw.line([(cx - 2, top_y - 2), (cx + 5, top_y - 13)], fill=stroke_col, width=stroke_w + 2)
                draw.line([(cx - 2, top_y - 2), (cx + 5, top_y - 13)], fill=fill_col, width=stroke_w)
            elif acc == 'tilde':
                draw.line([(cx - 6, top_y - 7), (cx, top_y - 10), (cx + 6, top_y - 7)], fill=stroke_col, width=stroke_w + 2)
                draw.line([(cx - 6, top_y - 7), (cx, top_y - 10), (cx + 6, top_y - 7)], fill=fill_col, width=stroke_w)
            elif acc == 'dieresis':
                draw.line([(cx - 4, top_y - 8), (cx - 4, top_y - 8)], fill=fill_col, width=stroke_w)
                draw.line([(cx + 4, top_y - 8), (cx + 4, top_y - 8)], fill=fill_col, width=stroke_w)
            cur_x += cw + 1
        else:
            draw.text((cur_x, y), ch, font=font, fill=fill_col, stroke_width=stroke_w, stroke_fill=stroke_col)
            bb = draw.textbbox((cur_x, y), ch, font=font)
            cur_x += (bb[2] - bb[0]) + 1
    return cur_x

def measure_accented_word(draw, font, text, fallback_font=None):
    """Calcula el ancho horizontal exacto de una palabra renderizada con acentos."""
    f_back = fallback_font or FALLBACK_FONT
    w = 0
    for ch in text.upper():
        if ch.isdigit() or ch in FALLBACK_CHARS:
            bb = draw.textbbox((0, 0), ch, font=f_back)
            w += (bb[2] - bb[0]) + 1
        else:
            base = ACCENTS[ch][0] if ch in ACCENTS else ch
            bb = draw.textbbox((0, 0), base, font=font)
            w += (bb[2] - bb[0]) + 1
    return w

def layout_block_lines(draw, font, word_objs, max_width=880, space_w=16):
    """Distribuye las palabras de un bloque en 1 o 2 líneas centradas horizontalmente."""
    n = len(word_objs)
    if n == 0:
        return []

    widths = [measure_accented_word(draw, font, w['w']) for w in word_objs]
    total_single = sum(widths) + space_w * (n - 1)

    if total_single <= max_width and n <= 7:
        lines = [(word_objs, widths, 80)]
    else:
        best_split = n // 2
        min_diff = 1e9
        for split in range(1, n):
            w_l1 = sum(widths[:split]) + space_w * (split - 1)
            w_l2 = sum(widths[split:]) + space_w * (n - split - 1)
            if w_l1 <= max_width and w_l2 <= max_width:
                diff = abs(w_l1 - w_l2)
                if diff < min_diff:
                    min_diff = diff
                    best_split = split

        l1_words, l1_w = word_objs[:best_split], widths[:best_split]
        l2_words, l2_w = word_objs[best_split:], widths[best_split:]
        lines = [
            (l1_words, l1_w, 40),
            (l2_words, l2_w, 115)
        ]

    positioned_words = []
    for l_words, l_widths, y_pos in lines:
        tot_w = sum(l_widths) + space_w * (len(l_widths) - 1)
        cur_x = (1080 - tot_w) // 2
        for w_obj, w_len in zip(l_words, l_widths):
            positioned_words.append({
                'w': w_obj['w'].upper(),
                'start': w_obj['start'],
                'end': w_obj['end'],
                'x': cur_x,
                'y': y_pos,
                'width': w_len
            })
            cur_x += w_len + space_w

    return positioned_words

def build_smart_blocks(words, max_words=10, max_gap=0.45):
    """Agrupa palabras en bloques de lectura naturales según puntuación y pausas."""
    blocks = []
    cur = []
    for i, w in enumerate(words):
        cur.append(w)
        txt = w['w']
        is_last = (i == len(words) - 1)
        next_gap = (words[i+1]['start'] - w['end']) if not is_last else 0

        ends_period = txt.endswith(('.', '!', '?'))
        ends_comma = txt.endswith((',', ';', ':'))

        if is_last:
            blocks.append(cur)
            cur = []
        elif next_gap >= max_gap:
            blocks.append(cur)
            cur = []
        elif ends_period and len(cur) >= 3:
            blocks.append(cur)
            cur = []
        elif ends_comma and len(cur) >= 5:
            blocks.append(cur)
            cur = []
        elif len(cur) >= max_words:
            blocks.append(cur)
            cur = []

    return [b for b in blocks if len(b) > 0]

PATRONES_ALUCINACION = [
    r'\bamara(\.org)?\b',
    r'\bcomunidad\s+de\s+amara\b',
    r'\bsubt[ií]tulos\s+(?:por|realizados)\b',
    r'\btranscripci[oó]n\s+por\b',
    r'\bsuscr[ií]bete\s+al\s+canal\b',
    r'\bgracias\s+por\s+ver\b',
]

def transcribe_audio(audio_path, modelo="small"):
    """Transcribe el audio con faster-whisper obteniendo marcas temporales por palabra."""
    from faster_whisper import WhisperModel
    print(f"  Transcribiendo con faster-whisper ({modelo}) para subtítulos...", flush=True)
    model = WhisperModel(modelo, device="cpu", compute_type="int8")
    # vad_filter=False es fundamental en canciones y música para no silenciar estrofas
    segments, _ = model.transcribe(
        audio_path, language="es", word_timestamps=True,
        vad_filter=False
    )
    words = []
    for seg in segments:
        seg_text = seg.text or ""
        # Filtrar alucinaciones de Whisper comunes en silencios y música (ej. Amara.org)
        if any(re.search(pat, seg_text, re.IGNORECASE) for pat in PATRONES_ALUCINACION):
            continue
        for w in (seg.words or []):
            limpia = w.word.strip()
            if not limpia:
                continue
            # Descartar palabras con duración cero generadas por Whisper en silencios
            if round(w.start, 2) == round(w.end, 2):
                continue
            # Filtrar palabras sueltas de alucinación (ej. 'Amara', '.org')
            if re.search(r'^(amara|\.?org|subt[ií]tulos|transcripci[oó]n)$', limpia, re.IGNORECASE):
                continue
            words.append({"w": limpia, "start": round(w.start, 3), "end": round(w.end, 3)})
    return words

def align_with_script(whisper_words, script_path):
    """
    Corrige alucinaciones residuales y fonética dudosa sin alterar jamás los tiempos
    reales de la voz ni borrar palabras cantadas/habladas.
    """
    if not whisper_words:
        return []

    # 1. Filtro estricto de alucinaciones
    limpias = []
    for w in whisper_words:
        txt = w.get("w", "").strip()
        if not txt:
            continue
        # Descartar marcas espurias con duración cero generadas por Whisper en silencios
        if round(w.get("start", 0), 2) == round(w.get("end", 0), 2):
            continue
        if re.search(r'^(amara|\.?org|subt[ií]tulos|transcripci[oó]n)$', txt, re.IGNORECASE):
            continue
        limpias.append(w)

    # 2. Correcciones fonéticas directas de alta precisión (sin mover marcas de tiempo)
    i = 0
    fixed = []
    while i < len(limpias):
        w0 = limpias[i]
        txt0 = w0.get("w", "").lower()

        # "humilla lo vero" / "humilla lo héroe" / "humilla a lo vero" -> "humilla al obrero"
        if txt0 == 'humilla' and i + 2 < len(limpias):
            w1 = limpias[i + 1]
            w2 = limpias[i + 2]
            txt1 = w1.get("w", "").lower()
            txt2 = w2.get("w", "").lower()
            if txt1 in ('lo', 'a', 'a lo') and txt2 in ('vero', 'overo', 'héroe', 'heroe'):
                fixed.append(w0)
                fixed.append({'w': 'al', 'start': w1['start'], 'end': w1['end']})
                fixed.append({'w': 'obrero', 'start': w2['start'], 'end': w2['end']})
                i += 3
                continue

        # "la carne y la trata derrante" -> "la cana y la trata de errante"
        if txt0 == 'carne' and i > 0 and limpias[i - 1].get("w", "").lower() == 'la':
            fixed.append({'w': 'cana', 'start': w0['start'], 'end': w0['end']})
            i += 1
            continue
        if txt0 == 'derrante':
            t_mid = round((w0['start'] + w0['end']) / 2, 3)
            fixed.append({'w': 'de', 'start': w0['start'], 'end': t_mid})
            fixed.append({'w': 'errante', 'start': t_mid, 'end': w0['end']})
            i += 1
            continue

        # "soberbio sin perdo arruino" -> "soberbio su imperio arruinó"
        if txt0 == 'sin' and i + 2 < len(limpias) and limpias[i + 1].get("w", "").lower() == 'perdo':
            fixed.append({'w': 'su', 'start': w0['start'], 'end': w0['end']})
            fixed.append({'w': 'imperio', 'start': limpias[i + 1]['start'], 'end': limpias[i + 1]['end']})
            i += 2
            continue

        # "vida solinda" -> "vida solita"
        if txt0 == 'solinda':
            fixed.append({'w': 'solita', 'start': w0['start'], 'end': w0['end']})
            i += 1
            continue

        # "Pidiando" -> "Pidiendo"
        if txt0 == 'pidiando':
            fixed.append({'w': 'Pidiendo', 'start': w0['start'], 'end': w0['end']})
            i += 1
            continue

        # "desprecio unas manos" -> "desprecia unas manos"
        if txt0 == 'desprecio' and i + 2 < len(limpias) and limpias[i + 1].get("w", "").lower() == 'unas' and limpias[i + 2].get("w", "").lower() == 'manos':
            fixed.append({'w': 'desprecia', 'start': w0['start'], 'end': w0['end']})
            i += 1
            continue

        fixed.append(w0)
        i += 1

    return fixed

def generar_subtitulos_karaoke(
    video_in,
    audio_in=None,
    video_out=None,
    script_path=None,
    words=None,
    modelo="small",
    overlay_y=OVERLAY_Y,
    font_size=DEFAULT_FONT_SIZE,
    stroke_w=STROKE_WIDTH,
    cache_words_path=None,
    fps=None,
    estilo=None
):
    """
    Función principal: quema subtítulos karaoke sobre el video mediante streaming de FFmpeg.
    """
    video_in = str(Path(video_in).resolve())
    if not os.path.isfile(video_in):
        raise FileNotFoundError(f"No existe el video de entrada: {video_in}")

    if not video_out:
        p_in = Path(video_in)
        video_out = str(p_in.parent / f"{p_in.stem}_subtitulado.mp4")

    # Configuración de estilo visual dinámico
    box_col = BOX_COLOR
    txt_col = TEXT_COLOR
    strk_col = STROKE_COLOR
    strk_w = stroke_w or STROKE_WIDTH
    box_rad = BOX_RADIUS
    p_x = PAD_X
    p_top = PAD_TOP
    p_bottom = PAD_BOTTOM
    con_caja = True

    try:
        from subtitulos_estilos import obtener_estilo
        cfg_estilo = obtener_estilo(estilo or "capcut_karaoke")
        box_col = cfg_estilo.get("box_color", box_col)
        txt_col = cfg_estilo.get("text_color", txt_col)
        strk_col = cfg_estilo.get("stroke_color", strk_col)
        strk_w = stroke_w if stroke_w is not None else cfg_estilo.get("stroke_width", STROKE_WIDTH)
        box_rad = cfg_estilo.get("box_radius", box_rad)
        p_x = cfg_estilo.get("pad_x", p_x)
        p_top = cfg_estilo.get("pad_top", p_top)
        p_bottom = cfg_estilo.get("pad_bottom", p_bottom)
        con_caja = cfg_estilo.get("con_caja", True)
        font_size = font_size or cfg_estilo.get("font_size", DEFAULT_FONT_SIZE)
    except Exception:
        pass

    # Obtener palabras
    if not words:
        if cache_words_path and os.path.isfile(cache_words_path):
            try:
                with open(cache_words_path, "r", encoding="utf-8") as f:
                    words = json.load(f)
                print(f"  Usando marcas temporales cacheadas: {cache_words_path}")
            except Exception:
                words = None

        if not words:
            audio_source = audio_in if audio_in and os.path.isfile(audio_in) else video_in
            words = transcribe_audio(audio_source, modelo=modelo)
            if cache_words_path:
                try:
                    with open(cache_words_path, "w", encoding="utf-8") as f:
                        json.dump(words, f, ensure_ascii=False, indent=2)
                except Exception:
                    pass

    # Alinear texto con el guión si existe
    if script_path and os.path.isfile(script_path):
        words = align_with_script(words, script_path)

    if not words:
        raise ValueError("No se pudieron obtener palabras para los subtítulos.")

    global FALLBACK_FONT
    font = get_font(font_size)
    FALLBACK_FONT = get_fallback_font(font_size)
    dummy_img = Image.new("RGBA", (1080, STRIP_H))
    dummy_draw = ImageDraw.Draw(dummy_img)

    blocks = build_smart_blocks(words)
    print(f"  Subtítulos: {len(words)} palabras | {len(blocks)} bloques de frase")

    # Pre-renderizado de estados
    processed_blocks = []
    for blk in blocks:
        b_start = blk[0]['start']
        b_end = blk[-1]['end'] + 0.15
        pos_words = layout_block_lines(dummy_draw, font, blk)

        states = {}
        for active_idx in range(-1, len(pos_words)):
            frame_img = Image.new("RGBA", (1080, STRIP_H), (0, 0, 0, 0))
            d = ImageDraw.Draw(frame_img)

            if active_idx >= 0 and con_caja:
                ax = pos_words[active_idx]['x']
                ay = pos_words[active_idx]['y']
                aw = pos_words[active_idx]['width']
                d.rounded_rectangle(
                    [ax - p_x, ay - p_top, ax + aw + p_x, ay + 48 + p_bottom],
                    radius=box_rad,
                    fill=box_col
                )

            for pw in pos_words:
                draw_accented_word(d, font, pw['w'], pw['x'], pw['y'], stroke_w=strk_w, fill_col=txt_col, stroke_col=strk_col)

            states[active_idx] = frame_img.tobytes()

        processed_blocks.append({
            'start': b_start,
            'end': b_end,
            'words': pos_words,
            'states': states
        })

    empty_bytes = Image.new("RGBA", (1080, STRIP_H), (0, 0, 0, 0)).tobytes()

        # Duración y frames del video
    total_dur = obtener_duracion(video_in)
    if total_dur is None:
        try:
            probe = subprocess.run(ajustar_comando_ffmpeg([
                'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1', video_in
            ]), capture_output=True, text=True, check=True)
            total_dur = float(probe.stdout.strip())
        except Exception:
            total_dur = 10.0
    if fps is None:
        try:
            r_probe = subprocess.run(ajustar_comando_ffmpeg([
                'ffprobe', '-v', 'error', '-select_streams', 'v:0',
                '-show_entries', 'stream=r_frame_rate',
                '-of', 'default=noprint_wrappers=1:nokey=1', video_in
            ]), capture_output=True, text=True, check=True)
            raw_fps = r_probe.stdout.strip()
            if '/' in raw_fps:
                num, den = raw_fps.split('/')
                fps = int(round(float(num) / float(den)))
            else:
                fps = int(round(float(raw_fps)))
            if fps <= 0 or fps > 120:
                fps = 30
        except Exception:
            fps = 30
    total_frames = int(round(total_dur * fps))

    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", video_in,
        "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"1080x{STRIP_H}", "-r", str(fps), "-i", "-",
        "-filter_complex", f"[0:v][1:v]overlay=0:{overlay_y}:shortest=1[outv]",
        "-map", "[outv]", "-map", "0:a?",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "copy",
        "-movflags", "+faststart",
        video_out
    ]

    print(f"  Renderizando subtítulos sobre video ({total_dur:.1f}s, {total_frames} frames)...", flush=True)
    t0 = time.time()
    proc = subprocess.Popen(ajustar_comando_ffmpeg(cmd), stdin=subprocess.PIPE)

    cur_block_idx = 0
    for f_idx in range(total_frames):
        t = f_idx / fps

        active_block = None
        while cur_block_idx < len(processed_blocks) and t > processed_blocks[cur_block_idx]['end']:
            cur_block_idx += 1

        if cur_block_idx < len(processed_blocks):
            blk = processed_blocks[cur_block_idx]
            if blk['start'] <= t <= blk['end']:
                active_block = blk

        if not active_block:
            proc.stdin.write(empty_bytes)
            continue

        active_word_idx = -1
        b_words = active_block['words']
        for w_i, pw in enumerate(b_words):
            if pw['start'] <= t <= pw['end']:
                active_word_idx = w_i
                break
            elif pw['start'] <= t and (w_i == len(b_words) - 1 or t < b_words[w_i + 1]['start']):
                active_word_idx = w_i
                break

        state_bytes = active_block['states'].get(active_word_idx, active_block['states'][-1])
        proc.stdin.write(state_bytes)

    proc.stdin.close()
    proc.wait()
    t1 = time.time()

    if proc.returncode != 0:
        raise RuntimeError(f"FFmpeg falló al generar el video con subtítulos (código {proc.returncode}).")

    print(f"  [OK] Subtítulos completados en {t1 - t0:.1f}s -> {video_out}")
    return video_out

def cli_main():
    ap = argparse.ArgumentParser(description="Quema subtítulos animados estilo karaoke (Melvins One / #ff0050) sobre video.")
    ap.add_argument("origen", help="Ruta al video o a la carpeta del proyecto de guion")
    ap.add_argument("--audio", default=None, help="Archivo de audio opcional (por defecto toma el audio del video o aud.mp3)")
    ap.add_argument("--salida", default=None, help="Ruta de guardado para el video subtitulado")
    ap.add_argument("--script", default=None, help="Ruta al guion o sincronia.txt para asegurar ortografía perfecta")
    ap.add_argument("--modelo", default="small", help="Modelo Whisper: tiny|base|small|medium")
    ap.add_argument("--trazo", type=int, default=STROKE_WIDTH, help="Grosor del contorno negro (por defecto 3, idéntico a 37 en CapCut)")
    ap.add_argument("--estilo", default=None, help="Estilo visual: capcut_karaoke | tiktok_amarillo | verde_neon | blanco_minimal | azul_electrico")
    args = ap.parse_args()

    p_orig = Path(args.origen).resolve()
    estilo_sel = args.estilo
    if not estilo_sel:
        # Intentar leer estilo de config_nicho.json
        cfg_cand = p_orig / "config_nicho.json" if p_orig.is_dir() else p_orig.parent / "config_nicho.json"
        if cfg_cand.is_file():
            try:
                import json
                with open(cfg_cand, "r", encoding="utf-8") as f:
                    estilo_sel = json.load(f).get("estilo_subtitulos")
            except Exception:
                pass

    if p_orig.is_dir():
        # Detectar proyecto de ecos
        cortes_dir = p_orig / "cortes" if (p_orig / "cortes").is_dir() else p_orig
        vid = cortes_dir / "video_completo.mp4"
        if not vid.is_file():
            vid = p_orig / "video.mp4"
        if not vid.is_file():
            vids = list(cortes_dir.glob("*.mp4"))
            vid = vids[0] if vids else None

        if not vid or not vid.is_file():
            sys.exit(f"ERROR: No encontré ningún video en {p_orig}")

        audio = args.audio
        if not audio:
            for cand in [cortes_dir / "aud_limpio.mp3", p_orig / "aud.mp3", p_orig / "audio.mp3"]:
                if cand.is_file():
                    audio = str(cand)
                    break

        cand_scripts = [p_orig / "guion_limpio.txt", p_orig / "sincronia.txt", p_orig / "guion.txt"]
        script = args.script or next((str(s) for s in cand_scripts if s.is_file()), None)
        salida = args.salida or str(cortes_dir / "video_subtitulado.mp4")
        cache_words = str(cortes_dir / "_words.json")
        generar_subtitulos_karaoke(str(vid), audio_in=audio, video_out=salida, script_path=script, modelo=args.modelo, stroke_w=args.trazo, cache_words_path=cache_words, estilo=estilo_sel)
    else:
        # Archivo de video directo
        cache_words = str(p_orig.parent / "_words.json")
        generar_subtitulos_karaoke(str(p_orig), audio_in=args.audio, video_out=args.salida, script_path=args.script, modelo=args.modelo, stroke_w=args.trazo, cache_words_path=cache_words, estilo=estilo_sel)

if __name__ == "__main__":
    cli_main()
