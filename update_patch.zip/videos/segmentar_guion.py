# -*- coding: utf-8 -*-
"""
videos/segmentar_guion.py - Segmenta guiones largos en frases óptimas para Creador de Videos.

Soluciona el problema de los chats de prompts (ChatGPT, Claude) que se confunden
calculando tiempos y cantidades de prompts en videos largos:

1. Lee el guion (guion.txt) y detecta la duración exacta del audio (aud.mp3).
2. Segmenta el texto en frases visuales coherentes de ~4.0s a 6.0s según la cadencia
   de la voz Enceladus a 0.98x (~142-147 palabras por minuto).
3. Calibra los tiempos para que la suma coincida exactamente con aud.mp3.
4. Genera 'prompts_para_chat.txt': texto blindado listo para copiar y pegar en el chat
   de IA, organizado en lotes seguros (de 30 a 40 tomas) para que el chat nunca se corte ni alucine.
5. Genera 'sincronia.txt' con la estructura lista (# | inicio-fin | dur | cubre).
6. Opción --unir: fusiona las respuestas de imagen.txt de vuelta a sincronia.txt.

USO:
    python videos/segmentar_guion.py "C:\\...\\NUEVOS GUIONES\\1030"
    python videos/segmentar_guion.py "C:\\...\\NUEVOS GUIONES\\1030" --lote 35
    python videos/segmentar_guion.py "C:\\...\\NUEVOS GUIONES\\1030" --unir
"""
import argparse
import os
import re
import subprocess
import sys
from pathlib import Path

try:
    from ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion, ajustar_comando_ffmpeg
except ImportError:
    try:
        from videos.ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion, ajustar_comando_ffmpeg
    except ImportError:
        detectar_ffmpeg = lambda: "ffmpeg"
        detectar_ffprobe = lambda: "ffprobe"
        obtener_duracion = lambda x: None
        ajustar_comando_ffmpeg = lambda x: x


# ---------------------------------------------------------------------- audio utils
def ffprobe_dur(path):
    """Devuelve la duración en segundos con ffprobe/ffmpeg o None."""
    dur = obtener_duracion(path)
    if dur is not None:
        return dur
    try:
        r = subprocess.run(
            ajustar_comando_ffmpeg(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(path)]),
            capture_output=True, text=True, check=True
        )
        return float(r.stdout.strip())
    except Exception:
        return None


def buscar_archivos_proyecto(folder):
    """Localiza guion.txt y aud.mp3 en la carpeta del proyecto."""
    p = Path(folder).resolve()
    
    # Buscar guion
    guion_cands = ["guion.txt", "guion.md", "guion", "script.txt"]
    guion_file = None
    for cand in guion_cands:
        if (p / cand).is_file():
            guion_file = p / cand
            break
            
    # Buscar audio
    audio_file = None
    for cand in ("aud.mp3", "aud_limpio.mp3", "audio.mp3"):
        if (p / cand).is_file():
            audio_file = p / cand
            break
    if not audio_file:
        for f in p.glob("*.mp3"):
            if not f.name.startswith("_"):
                audio_file = f
                break

    return p, guion_file, audio_file


# ------------------------------------------------------------------ segmentacion
def partir_oracion_larga(oracion, max_palabras=13, min_palabras=4):
    """
    Subdivide una oración larga en cláusulas visualmente coherentes
    respetando pausas naturales de la narración en español.
    Asegura que ninguna toma exceda max_palabras (~5.5s de voz),
    permitiendo frases cortas naturales desde min_palabras (~2.5s de voz).
    """
    palabras = oracion.split()
    n = len(palabras)
    if n <= max_palabras:
        return [oracion.strip()]

    candidatos = []
    # 1. Puntuación fuerte (; : — –)
    for m in re.finditer(r'(;\s+|:\s+|\s+—\s+|\s+–\s+)', oracion):
        candidatos.append((m.start(), m.group(), 50, True))

    # 2. Coma + conector subordinante
    for m in re.finditer(r',\s+(?:mientras\s+que|mientras|pero|aunque|porque|cuando|donde|hasta\s+que|ya\s+que|para\s+que|sin\s+embargo|a\s+pesar\s+de\s+que|con\s+el\s+fin\s+de|a\s+fin\s+de|por\s+lo\s+que|quien|cuyo|cuya)\s+', oracion, re.I):
        candidatos.append((m.start(), m.group(), 45, True))

    # 3. Coma + que
    for m in re.finditer(r',\s+que\s+', oracion, re.I):
        candidatos.append((m.start(), m.group(), 40, True))

    # 4. Comas estándar
    for m in re.finditer(r',\s+', oracion):
        candidatos.append((m.start(), m.group(), 35, True))

    # 5. Conectores sin coma
    for m in re.finditer(r'\s+(?:mientras\s+que|mientras|a\s+fin\s+de|con\s+el\s+fin\s+de|para\s+que|hasta\s+que|ya\s+que|sin\s+embargo|hasta\s+llegar|para\s+represar|para\s+evitar|para\s+presentar|para\s+no|sin\s+importar)\s+', oracion, re.I):
        candidatos.append((m.start(), m.group(), 28, False))

    # 6. Conjunciones coordinantes (' y ', ' e ', ' pero ', ' o ')
    for m in re.finditer(r'\s+(?:y|e|pero|o)\s+', oracion, re.I):
        candidatos.append((m.start(), m.group(), 22, False))

    # 7. ' que ', ' quien ', ' donde ', ' cuando ' sin coma
    for m in re.finditer(r'\s+(?:que|quien|donde|cuando)\s+', oracion, re.I):
        candidatos.append((m.start(), m.group(), 16, False))

    # 8. Preposiciones de apoyo
    for m in re.finditer(r'\s+(?:de|en|con|por|para|hacia|sobre)\s+', oracion, re.I):
        candidatos.append((m.start(), m.group(), 8, False))

    target_izq = n / 2.0
    mejor, mejor_puntuacion = None, -9999

    for pos, grp, base_score, tiene_signo in candidatos:
        corte = pos + 1 if tiene_signo and grp.startswith((',', ';', ':', '—', '–')) else pos
        izq = oracion[:corte].strip()
        der = oracion[corte:].strip()
        n_izq = len(izq.split())
        n_der = len(der.split())

        if n_izq < min_palabras or n_der < min_palabras:
            continue

        score = base_score - abs(n_izq - target_izq) * 2.5
        if score > mejor_puntuacion:
            mejor_puntuacion = score
            mejor = (izq, der)

    # Si no hubo candidato con min_palabras estricto, relajar a 3 palabras
    if not mejor:
        for pos, grp, base_score, tiene_signo in candidatos:
            corte = pos + 1 if tiene_signo and grp.startswith((',', ';', ':', '—', '–')) else pos
            izq = oracion[:corte].strip()
            der = oracion[corte:].strip()
            n_izq = len(izq.split())
            n_der = len(der.split())
            if n_izq < 3 or n_der < 3:
                continue
            score = base_score - abs(n_izq - target_izq) * 2.5
            if score > mejor_puntuacion:
                mejor_puntuacion = score
                mejor = (izq, der)

    if not mejor:
        idx = n // 2
        izq = ' '.join(palabras[:idx])
        der = ' '.join(palabras[idx:])
        return partir_oracion_larga(izq, max_palabras, min_palabras) + partir_oracion_larga(der, max_palabras, min_palabras)

    izq, der = mejor
    res_izq = partir_oracion_larga(izq, max_palabras, min_palabras) if len(izq.split()) > max_palabras else [izq]
    res_der = partir_oracion_larga(der, max_palabras, min_palabras) if len(der.split()) > max_palabras else [der]
    return res_izq + res_der


def segmentar_guion(texto, dur_total=None, wpm=145.0, dur_min=2.5, dur_max=5.5):
    """
    Toma el texto completo del guion y lo segmenta en escenas con tiempos exactos.
    Garantiza que toda escena esté dentro del rango [dur_min, dur_max] (2.5s a 5.5s),
    respetando frases cortas naturales de 4 a 6 palabras (>=2.5s) y evitando tomas
    largas (>5.5s) que excedan el metraje de movimiento limpio de clips animados.
    """
    pal_por_seg = wpm / 60.0
    max_palabras = 13
    min_palabras = 4

    parrafos = [p.strip() for p in texto.splitlines() if p.strip()]
    oraciones_crudas = []

    for parrafo in parrafos:
        partes = re.split(r'([.?!]+(?:\s+|$))', parrafo)
        i = 0
        while i < len(partes):
            trozo = partes[i].strip()
            if not trozo:
                i += 1
                continue
            if i + 1 < len(partes) and re.match(r'^[.?!]+', partes[i+1]):
                oraciones_crudas.append(trozo + partes[i+1].strip())
                i += 2
            else:
                oraciones_crudas.append(trozo)
                i += 1

    escenas_texto = []
    for orac in oraciones_crudas:
        if not orac.strip():
            continue
        partes = partir_oracion_larga(orac, max_palabras=max_palabras, min_palabras=min_palabras)
        escenas_texto.extend(partes)

    # Fusionar fragmentos extremadamente cortos (< 4 palabras) con vecinos para alcanzar dur_min
    j = 0
    while j < len(escenas_texto):
        p = escenas_texto[j].strip()
        n_p = len(p.split())
        if n_p < min_palabras and len(escenas_texto) > 1:
            if j + 1 < len(escenas_texto) and len(escenas_texto[j+1].split()) + n_p <= max_palabras:
                escenas_texto[j+1] = f"{p} {escenas_texto[j+1]}"
                escenas_texto.pop(j)
            elif j > 0 and len(escenas_texto[j-1].split()) + n_p <= max_palabras:
                escenas_texto[j-1] = f"{escenas_texto[j-1]} {p}"
                escenas_texto.pop(j)
            else:
                j += 1
        else:
            j += 1

    # Cálculo ponderado de duraciones según palabras y pausas de narración
    pesos = []
    for esc in escenas_texto:
        pals = len(esc.split())
        pausa = 0.35 if esc.endswith(('.', '!', '?')) else (0.15 if esc.endswith(',') else 0.1)
        peso = (pals / pal_por_seg) + pausa
        pesos.append(peso)

    cum_pesos = sum(pesos) if pesos else 1.0
    dur_real = dur_total if (dur_total and dur_total > 0) else cum_pesos

    # Duraciones brutas proporcionales
    durs = [(p / cum_pesos) * dur_real for p in pesos]

    # Ajuste iterativo para garantizar estrictamente dur_min <= durs[i] <= dur_max
    for _ in range(15):
        for k in range(len(durs)):
            if durs[k] < dur_min:
                durs[k] = dur_min
            elif durs[k] > dur_max:
                durs[k] = dur_max

        diff = dur_real - sum(durs)
        if abs(diff) < 0.01:
            break

        indices_libres = [k for k in range(len(durs))
                          if (diff > 0 and durs[k] < dur_max) or (diff < 0 and durs[k] > dur_min)]
        if not indices_libres:
            break
        suma_pesos_libres = sum(pesos[k] for k in indices_libres)
        if suma_pesos_libres <= 0:
            for k in indices_libres:
                durs[k] += diff / len(indices_libres)
        else:
            for k in indices_libres:
                durs[k] += diff * (pesos[k] / suma_pesos_libres)

    # Puntos temporales continuos acumulados
    puntos = [0.0]
    for d in durs[:-1]:
        puntos.append(round(puntos[-1] + d, 1))
    puntos.append(round(dur_real, 1))

    resultado = []
    for i, (esc, ini, fin) in enumerate(zip(escenas_texto, puntos[:-1], puntos[1:]), 1):
        dur = round(fin - ini, 1)
        resultado.append({
            "orden": i,
            "ini": ini,
            "fin": fin,
            "dur": dur,
            "frase": esc.strip()
        })

    return resultado


def fmt_min_sec(segundos):
    """Convierte segundos a formato M:SS."""
    m, s = divmod(int(round(segundos)), 60)
    return f"{m}:{s:02d}"


# ---------------------------------------------------------------- generacion archivos
def generar_sincronia(proy_dir, escenas, dur_total):
    """
    Escribe exclusivamente:
    - sincronia.txt (plantilla calibrada de tomas, duraciones y frases numeradas)
    """
    proy = Path(proy_dir)
    sinc_path = proy / "sincronia.txt"
    with open(sinc_path, "w", encoding="utf-8") as f:
        f.write("# | inicio–fin | dur | cubre\n")
        for esc in escenas:
            rango = f"{fmt_min_sec(esc['ini'])}–{fmt_min_sec(esc['fin'])}"
            f.write(f"{esc['orden']} | {rango} | {esc['dur']:.1f}s | \"{esc['frase']}\"\n")

    # Si existía algún prompts_para_chat.txt previo, se elimina para mantener limpia la carpeta
    obsoleto = proy / "prompts_para_chat.txt"
    if obsoleto.is_file():
        try:
            obsoleto.unlink()
        except Exception:
            pass

    return sinc_path


# ----------------------------------------------------------------- fusion / merge
def fusionar_imagen_txt(proy_dir):
    """
    Lee imagen.txt (los prompts generados por el chat) y sincronia.txt,
    verificando que coincidan y fusionando los prompts en sincronia.txt.
    """
    proy = Path(proy_dir)
    img_path = proy / "imagen.txt"
    sinc_path = proy / "sincronia.txt"

    if not img_path.is_file():
        sys.exit(f"ERROR: No se encontró {img_path}")
    if not sinc_path.is_file():
        sys.exit(f"ERROR: No se encontró {sinc_path}. Ejecuta primero la segmentación.")

    # 1. Leer sincronia
    lineas_sinc = []
    with open(sinc_path, encoding="utf-8-sig", errors="replace") as f:
        for linea in f:
            s = linea.strip()
            if s and not s.startswith("#") and "|" in s:
                lineas_sinc.append(s)

    # 2. Leer imagen.txt (admite formato con líneas vacías o formato '1 | prompt')
    raw_prompts = []
    with open(img_path, encoding="utf-8-sig", errors="replace") as f:
        for linea in f:
            s = linea.strip()
            if not s:
                continue
            # Si viene con número '1 | prompt' o '1. prompt'
            m = re.match(r"^\s*0*(\d+)\s*[|.:-]\s*(.*)$", s)
            if m and len(m.group(2).strip()) > 10:
                raw_prompts.append((int(m.group(1)), m.group(2).strip()))
            else:
                raw_prompts.append((len(raw_prompts) + 1, s))

    print(f"  Sincronía : {len(lineas_sinc)} tomas registradas")
    print(f"  imagen.txt: {len(raw_prompts)} prompts detectados")

    if len(raw_prompts) != len(lineas_sinc):
        print(f"  AVISO: La cantidad de prompts ({len(raw_prompts)}) no coincide exactamente "
              f"con las tomas de sincronia.txt ({len(lineas_sinc)}).")

    # Guardar sincronia actualizada con columna de prompt
    out_sinc = []
    for i, sinc_line in enumerate(lineas_sinc, 1):
        prompt_txt = next((p for num, p in raw_prompts if num == i), None)
        if prompt_txt is None and i <= len(raw_prompts):
            prompt_txt = raw_prompts[i - 1][1]
        
        # Limpiar partes del sinc_line
        cols = [c.strip() for c in sinc_line.split("|")]
        if len(cols) >= 4:
            base_sinc = f"{cols[0]} | {cols[1]} | {cols[2]} | {cols[3]}"
        else:
            base_sinc = sinc_line

        if prompt_txt:
            out_sinc.append(f"{base_sinc} | {prompt_txt}")
        else:
            out_sinc.append(base_sinc)

    with open(sinc_path, "w", encoding="utf-8") as f:
        f.write("# | inicio–fin | dur | cubre | prompt\n")
        for l in out_sinc:
            f.write(l + "\n")

    print(f"  [OK] sincronia.txt actualizado con los prompts fusionados de imagen.txt.")


# ------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(
        description="Segmenta guiones en frases óptimas y tiempos exactos para Creador de Videos.")
    ap.add_argument("folder", nargs="*", default=["."],
                    help="Carpeta del proyecto (ej. C:\\...\\NUEVOS GUIONES\\1030)")
    ap.add_argument("--duracion", type=float, default=None,
                    help="Duración total en segundos (si no existe aud.mp3)")
    ap.add_argument("--lote", type=int, default=35,
                    help="Cantidad de tomas por lote para el chat de IA (por defecto 35)")
    ap.add_argument("--dur-min", type=float, default=2.5,
                    help="Duración mínima por toma en segundos (por defecto 2.5s)")
    ap.add_argument("--dur-max", type=float, default=5.5,
                    help="Duración máxima por toma en segundos (por defecto 5.5s)")
    ap.add_argument("--wpm", type=float, default=145.0,
                    help="Palabras por minuto de la voz (por defecto 145 para Enceladus a 0.98x)")
    ap.add_argument("--unir", action="store_true",
                    help="Fusiona los prompts de imagen.txt en sincronia.txt")
    args = ap.parse_args()

    raw = " ".join(args.folder) if isinstance(args.folder, list) else args.folder
    proy_dir, guion_file, audio_file = buscar_archivos_proyecto(raw)

    print("=" * 65)
    print(f"  SEGMENTADOR DE GUIONES - CREADOR DE VIDEOS")
    print(f"  Proyecto : {proy_dir.name}")
    print(f"  Ruta     : {proy_dir}")
    print("=" * 65)

    if args.unir:
        fusionar_imagen_txt(proy_dir)
        return

    if not guion_file or not guion_file.is_file():
        sys.exit(f"ERROR: No encontré guion.txt en {proy_dir}.\n"
                 f"Coloca el texto del guion en 'guion.txt' dentro de esa carpeta.")

    texto_guion = guion_file.read_text(encoding="utf-8-sig", errors="replace").strip()
    if not texto_guion:
        sys.exit(f"ERROR: El archivo {guion_file.name} está vacío.")

    # Obtener duración del audio
    dur_total = args.duracion
    if dur_total is None and audio_file and audio_file.is_file():
        dur_total = ffprobe_dur(audio_file)
        if dur_total:
            print(f"  Audio detectado: {audio_file.name} ({fmt_min_sec(dur_total)} / {dur_total:.2f}s)")

    if not dur_total:
        pals = len(texto_guion.split())
        dur_estimada = (pals / args.wpm) * 60.0
        dur_total = dur_estimada
        print(f"  Sin audio: Estimando duración por Enceladus 0.98x -> {fmt_min_sec(dur_total)} ({dur_total:.1f}s)")

    palabras_totales = len(texto_guion.split())
    print(f"  Palabras guion : {palabras_totales} palabras")
    print(f"  Ritmo voz      : {args.wpm:.1f} WPM (~{args.wpm/60:.2f} palabras/segundo)")
    print(f"  Rango por toma : {args.dur_min:.1f}s a {args.dur_max:.1f}s (óptimo para clips animados Veo/Grok)")

    escenas = segmentar_guion(texto_guion, dur_total=dur_total, wpm=args.wpm,
                              dur_min=args.dur_min, dur_max=args.dur_max)
    print(f"  Tomas creadas  : {len(escenas)} escenas (promedio {dur_total/len(escenas):.2f}s por toma)")

    sinc_path = generar_sincronia(proy_dir, escenas, dur_total)

    print("\n  [LISTO] Sincronía generada con éxito:")
    print(f"  -> {sinc_path.name} ({len(escenas)} tomas numeradas y calibradas)")
    print("\n  Pasos siguientes:")
    print("  1. Pasa 'sincronia.txt' a tu chat de IA junto con tu instrucción maestra de prompts.")
    print("  2. Pega las respuestas de los prompts en 'imagen.txt'.")
    print("  3. Si deseas fusionar las respuestas en sincronia.txt, ejecuta:")
    print(f"     python videos/segmentar_guion.py \"{proy_dir}\" --unir\n")


if __name__ == "__main__":
    main()
