#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
cortar_escenas.py
-----------------
Recorta cada clip al tiempo que le corresponde segun la narracion (voz en off),
dejando las escenas SEPARADAS en una carpeta para unirlas luego en CapCut con
transiciones. NO genera el video final: solo los cortes.

Todo es local: usa faster-whisper (transcripcion) + ffmpeg. No consume creditos.

Convencion de carpeta (una por proyecto/video):
    proyecto/
        aud.mp3            (o cualquier .mp3/.wav/.m4a; se toma el primero)
        guion.txt          (opcional; solo mejora el reporte)
        001_*.mp4 ... NNN_*.mp4   (los clips, ordenados por nombre)

Salida:
    proyecto/cortes/
        01_corte.mp4 ... NN_corte.mp4   (listos para importar en CapCut)
        _mapeo.csv / _mapeo.txt         (que narracion cubre cada clip)

Uso:
    python cortar_escenas.py                 # usa la carpeta actual
    python cortar_escenas.py "C:\\ruta\\proyecto"
    python cortar_escenas.py . --handle 0.5  # +0.5s de cola en cada clip (para transiciones)
    python cortar_escenas.py . --modelo small --ventana 1.75
    python cortar_escenas.py . --limpiar-silencios   # quita silencios largos y genera aud_limpio.mp3

Si usas --limpiar-silencios: se genera cortes/<audio>_limpio.mp3 (DENTRO de la
carpeta cortes, junto a los clips) y los cortes se calculan sobre esa duracion
mas corta. Importa en CapCut ESE audio, no el original.
Los tiempos de silencio ya van por defecto (min 0.5s, max 0.35s); solo hace
falta pasar --limpiar-silencios.
"""
import argparse, csv, glob, json, os, re, subprocess, sys, unicodedata
from pathlib import Path

_aqui = Path(__file__).resolve().parent
_root = _aqui.parent
for _p in (_root, _root / "core", _aqui):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# Cargar resolutor de FFmpeg/FFprobe resiliente
try:
    from ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion, ajustar_comando_ffmpeg
except ImportError:
    try:
        from videos.ffmpeg_resolver import detectar_ffmpeg, detectar_ffprobe, obtener_duracion, ajustar_comando_ffmpeg
    except ImportError:
        detectar_ffmpeg = lambda: "ffmpeg"
        detectar_ffprobe = lambda: "ffprobe"
        obtener_duracion = lambda p: None
        ajustar_comando_ffmpeg = lambda c: c

try:
    from motion_graphics import planificar_escenas_motion, render_escena_motion_mp4
except ImportError:
    try:
        from videos.motion_graphics import planificar_escenas_motion, render_escena_motion_mp4
    except ImportError:
        try:
            from ecos.motion_graphics import planificar_escenas_motion, render_escena_motion_mp4
        except ImportError:
            planificar_escenas_motion = None
            render_escena_motion_mp4 = None

VIDEO_EXTS = (".mp4", ".mov", ".mkv", ".webm")
AUDIO_EXTS = (".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg")


def run(cmd):
    cmd = ajustar_comando_ffmpeg(cmd)
    try:
        return subprocess.run(cmd, capture_output=True, text=True)
    except FileNotFoundError:
        sys.exit(f"ERROR: No se encontró el componente multimedia '{cmd[0]}'. Asegúrate de tener FFmpeg instalado o conexión a internet para su resolución automática.")


def ffprobe_dur(path):
    dur = obtener_duracion(path)
    if dur is not None:
        return dur
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(path)])
    try:
        return float(r.stdout.strip())
    except (ValueError, AttributeError):
        return None

def detectar_silencios(audio, umbral_db, min_sil):
    """Devuelve lista de (inicio, fin) de los silencios detectados."""
    r = run(["ffmpeg", "-hide_banner", "-i", audio,
             "-af", f"silencedetect=noise={umbral_db}dB:d={min_sil}",
             "-f", "null", "-"])
    log = r.stderr
    starts = [float(m) for m in re.findall(r"silence_start:\s*([-\d.]+)", log)]
    ends = [float(m) for m in re.findall(r"silence_end:\s*([-\d.]+)", log)]
    sil = []
    for i, s in enumerate(starts):
        e = ends[i] if i < len(ends) else None
        sil.append((s, e))
    return sil


def limpiar_silencios(audio, folder, umbral_db, max_sil, min_sil):
    """Genera <base>_limpio.mp3 recortando cada silencio largo a max_sil.
    Devuelve (ruta_limpia, segundos_recortados) o (audio, 0) si no hubo nada."""
    total = ffprobe_dur(audio) or 0.0
    sil = detectar_silencios(audio, umbral_db, min_sil)

    # rangos a conservar del audio original
    keep, cursor, recortado = [], 0.0, 0.0
    for s, e in sil:
        if e is None:
            e = total
        dur = e - s
        if dur > max_sil:
            keep.append((cursor, s + max_sil))     # audio + un poco de silencio
            recortado += (e - (s + max_sil))
            cursor = e                              # salta el resto del silencio
    keep.append((cursor, total))
    keep = [(a, b) for a, b in keep if b - a > 0.01]

    if recortado < 0.05:
        return audio, 0.0  # no valia la pena

    base = os.path.splitext(os.path.basename(audio))[0]
    out = os.path.join(folder, f"{base}_limpio.mp3")
    parts = "".join(
        f"[0:a]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS[a{i}];"
        for i, (a, b) in enumerate(keep))
    concat = "".join(f"[a{i}]" for i in range(len(keep)))
    filt = parts + f"{concat}concat=n={len(keep)}:v=0:a=1[out]"
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", audio,
         "-filter_complex", filt, "-map", "[out]",
         "-c:a", "libmp3lame", "-q:a", "2", out])
    return out, recortado


def slug(txt, n=40):
    txt = unicodedata.normalize("NFD", txt)
    txt = "".join(c for c in txt if unicodedata.category(c) != "Mn")
    txt = re.sub(r"[^A-Za-z0-9]+", "-", txt).strip("-").lower()
    return (txt[:n] or "corte")


def match_num(name, num):
    """Comprueba si un archivo corresponde al numero num (ej. 001_..., 01..., 1.jpg, escena_1.mp4)."""
    stem = Path(name).stem.lower()
    m = re.match(r"^0*(\d+)(?:[\s_.\-]|$)", stem)
    if m and int(m.group(1)) == num:
        return True
    m = re.search(r"(?:^|[\s_.\-(\[])0*(\d+)(?:[\s_.\-)\]]|$)", stem)
    return m is not None and int(m.group(1)) == num


def find_project_layout(folder_path):
    """Detecta la carpeta raiz del proyecto, subcarpeta de video (video/grok),
    subcarpeta de imagen (imagen/veo) y carpeta cortes."""
    p = Path(folder_path).resolve()
    subnombres = {"grok", "video", "videos", "veo", "imagen", "imagenes", "image", "images", "clips", "animaciones", "cortes", "fotos", "pictures"}

    # Si se pasó una subcarpeta interna de trabajo (ej. 300/grok o 300/veo), el root del proyecto es la carpeta padre (300)
    if p.name.lower() in subnombres:
        root = p.parent
    else:
        root = p

    # Buscar carpeta de video: preferencia a video, videos, grok, clips
    grok = None
    for nom in ("video", "videos", "grok", "clips", "animaciones"):
        if (root / nom).is_dir():
            grok = root / nom
            break
    if not grok:
        grok = p if p.name.lower() in ("grok", "video", "videos") else root

    # Buscar carpeta de imagen: preferencia a imagen, imagenes, veo, fotos
    veo = None
    for nom in ("imagen", "imagenes", "veo", "fotos", "prompts", "images", "image"):
        if (root / nom).is_dir():
            veo = root / nom
            break
    if not veo:
        veo = p if p.name.lower() in ("veo", "imagen", "imagenes", "images", "image") else None

    out_dir = root / "cortes"
    return root, grok, veo, out_dir


def find_audio(root, grok):
    """Prefiere un audio ya procesado (_fluido / _limpio) si existe; si no,
    toma aud.mp3 o el primer audio encontrado EXCLUSIVAMENTE dentro del proyecto (root o sus subcarpetas)."""
    todos_audios = []
    vistos = set()

    carpetas = [root]
    if grok and grok != root and grok.is_dir():
        carpetas.append(grok)
    for sub in ("audio", "audios", "grok", "veo", "video", "videos", "imagen", "imagenes"):
        sd = root / sub
        if sd.is_dir() and sd not in carpetas:
            carpetas.append(sd)

    for c in carpetas:
        for f in sorted(c.iterdir()):
            if f.is_file() and f.suffix.lower() in AUDIO_EXTS and str(f.resolve()) not in vistos:
                vistos.add(str(f.resolve()))
                todos_audios.append(f)

    # Si todavía no hay audios, buscar recursivamente dentro de root (sin salirse jamás del proyecto)
    if not todos_audios and root and root.is_dir():
        for f in root.rglob("*"):
            if f.is_file() and f.suffix.lower() in AUDIO_EXTS and "cortes" not in f.parts and str(f.resolve()) not in vistos:
                vistos.add(str(f.resolve()))
                todos_audios.append(f)

    if not todos_audios:
        return None

    for marca in ("_fluido", "_limpio"):
        for f in todos_audios:
            if marca in f.name.lower():
                print(f"  (usando el audio procesado: {f.name})")
                return str(f)

    for f in todos_audios:
        if f.stem.lower() in ("aud", root.name.lower()):
            return str(f)

    return str(todos_audios[0])


def obtener_config_nicho_proyecto(root):
    """Busca y parsea config_nicho.json en root, root.parent o root.parent.parent."""
    p_root = Path(root).resolve()
    for c_dir in [p_root, p_root.parent, p_root.parent.parent]:
        p = c_dir / "config_nicho.json"
        if p.is_file():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
    return {}


def es_nicho_motion_graphics(cfg):
    """Determina si el nicho es de tipo animación por código, diagramas o no requiere imágenes externas."""
    if not cfg:
        return False
    if cfg.get("requiere_imagenes") is False and cfg.get("requiere_videos") is False:
        return True
    tipo_prod = str(cfg.get("tipo_produccion", "")).lower()
    if tipo_prod in ("codigo_motion", "motion", "animacion_codigo", "diagramas", "motion_graphics"):
        return True
    modo_montaje = str(cfg.get("modo_montaje", "")).lower()
    if modo_montaje in ("motion_graphics", "codigo"):
        return True
    estilo_v = str(cfg.get("estilo_visual", "")).lower()
    estilo_id = str(cfg.get("identidad_visual", {}).get("estilo_id", "")).lower()
    if "motion graphics" in estilo_v or "motion_graphics" in estilo_id or "infografía animada" in estilo_v:
        return True
    return False


def buscar_musica_fondo(root, cfg_nicho=None):
    """Busca musica_fondo.mp3 en audio_referencia, en la raíz del nicho o en la configuración."""
    if cfg_nicho and cfg_nicho.get("musica_fondo_ruta"):
        p = Path(cfg_nicho["musica_fondo_ruta"])
        if p.is_file():
            return str(p.resolve())

    cand_dirs = [root, root.parent, root.parent / "audio_referencia"]
    for d in cand_dirs:
        for nom in ("musica_fondo.mp3", "musica.mp3", "fondo.mp3", "bg_music.mp3"):
            f = d / nom
            if f.is_file() and f.stat().st_size > 1000:
                return str(f.resolve())
    return None


def generar_canvas_motion_scene(root, orden, total, cfg_nicho, beats=None):
    """Genera dinámicamente un canvas 1080x1920 con estética técnica/blueprint
    para proyectos de código y motion graphics que no requieren imágenes IA."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None

    cortes_dir = root / "cortes"
    canvas_dir = cortes_dir / "_canvas"
    canvas_dir.mkdir(parents=True, exist_ok=True)
    out_file = canvas_dir / f"canvas_{orden:02d}.png"
    if out_file.is_file() and out_file.stat().st_size > 1000:
        return out_file

    w, h = 1080, 1920
    bg_color = (15, 23, 42)        # Slate 900
    grid_color = (24, 34, 53)      # Cuadrícula azul petróleo
    border_color = (56, 189, 248)   # Cyan cielo #38bdf8
    accent_color = (250, 204, 21)  # Amarillo técnico #facc15

    img = Image.new("RGB", (w, h), color=bg_color)
    draw = ImageDraw.Draw(img)

    # 1. Cuadrícula técnica sutil
    grid_step = 60
    for x in range(0, w, grid_step):
        draw.line([(x, 0), (x, h)], fill=grid_color, width=1)
    for y in range(0, h, grid_step):
        draw.line([(0, y), (w, y)], fill=grid_color, width=1)

    # 2. Marco perimetral
    mx, my = 60, 100
    draw.rectangle([(mx, my), (w - mx, h - my)], outline=border_color, width=2)

    # 3. Marcas de esquina de precisión (esquinas tipo blueprint)
    m = 28
    for cx, cy in [(mx, my), (w - mx, my), (mx, h - my), (w - mx, h - my)]:
        draw.line([(cx - m, cy), (cx + m, cy)], fill=accent_color, width=3)
        draw.line([(cx, cy - m), (cx, cy + m)], fill=accent_color, width=3)

    # 4. Rótulo superior e inferior esquemático
    draw.rectangle([(mx + 40, my + 30), (w - mx - 40, my + 75)], fill=(30, 41, 59), outline=border_color, width=1)
    draw.rectangle([(mx + 80, h - my - 75), (w - mx - 80, h - my - 30)], fill=(30, 41, 59), outline=accent_color, width=1)

    # 5. Círculos y mira técnica central
    cy_mid = h // 2 - 80
    r_c = 150
    draw.ellipse([(w//2 - r_c, cy_mid - r_c), (w//2 + r_c, cy_mid + r_c)], outline=(30, 41, 59), width=2)
    draw.line([(w//2 - r_c - 40, cy_mid), (w//2 + r_c + 40, cy_mid)], fill=(30, 41, 59), width=1)
    draw.line([(w//2, cy_mid - r_c - 40), (w//2, cy_mid + r_c + 40)], fill=(30, 41, 59), width=1)

    img.save(out_file, "PNG")
    return out_file


def find_shots(total_escenas, grok, veo, beats=None):
    """Para cada escena 1..total_escenas busca primero el video animado (.mp4, .mov, .webm)
    y si no existe toma la imagen correspondiente (.jpg, .jpeg, .png, .webp).
    Si el nicho es de motion graphics o código sin imágenes externas, genera dinámicamente los canvas base."""
    subnombres = {"grok", "video", "videos", "veo", "imagen", "imagenes", "image", "images", "clips", "animaciones", "cortes", "fotos", "pictures"}
    if grok and grok.name.lower() in subnombres:
        root = grok.parent
    elif veo and veo.name.lower() in subnombres:
        root = veo.parent
    else:
        root = grok or veo

    cfg_nicho = obtener_config_nicho_proyecto(root)
    es_motion = es_nicho_motion_graphics(cfg_nicho)

    v_exts = (".mp4", ".mov", ".webm")
    i_exts = (".jpg", ".jpeg", ".png", ".webp")
    ignored_parts = {"cortes", "_videos finales", "_videos_finales", "_temp", "__pycache__"}

    videos = []
    images = []

    # Escanear dentro de root (el proyecto) y sus subcarpetas
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if any(ign in [part.lower() for part in p.parts] for ign in ignored_parts):
            continue
        suf = p.suffix.lower()
        if suf in v_exts:
            if p not in videos:
                videos.append(p)
        elif suf in i_exts:
            if p not in images:
                images.append(p)

    tomas = []
    for i in range(1, total_escenas + 1):
        vid = next((p for p in videos if match_num(p.name, i)), None)
        if vid:
            tomas.append({"orden": i, "tipo": "video", "ruta": str(vid), "nombre": vid.name})
            continue
        img = next((p for p in images if match_num(p.name, i)), None)
        if img:
            tomas.append({"orden": i, "tipo": "imagen", "ruta": str(img), "nombre": img.name})
            continue

        if es_motion:
            if render_escena_motion_mp4 is not None:
                tomas.append({"orden": i, "tipo": "motion", "ruta": f"motion_{i:02d}", "nombre": f"motion_{i:02d}.mp4"})
                continue
            canvas_p = generar_canvas_motion_scene(root, i, total_escenas, cfg_nicho, beats)
            if canvas_p and canvas_p.is_file():
                tomas.append({"orden": i, "tipo": "imagen", "ruta": str(canvas_p), "nombre": canvas_p.name})
                continue

        sys.exit(f"ERROR: No se encontró ni video ni imagen para la escena {i:02d} (buscado en video/, imagen/, o en el proyecto).")

    return tomas


def transcribe(audio, modelo):
    from faster_whisper import WhisperModel
    print(f"  Transcribiendo con faster-whisper ({modelo})...", flush=True)
    model = WhisperModel(modelo, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(audio, language="es",
                                   word_timestamps=True, vad_filter=False)
    words = []
    for seg in segments:
        for w in (seg.words or []):
            words.append({"w": w.word.strip(), "start": w.start, "end": w.end})
    return words


def build_gaps(words):
    """Huecos (pausas) entre palabras: lista de (tiempo_medio, tamano_del_hueco)."""
    gaps = []
    for i in range(len(words) - 1):
        g = words[i + 1]["start"] - words[i]["end"]
        if g > 0:
            gaps.append(((words[i]["end"] + words[i + 1]["start"]) / 2.0, g))
    return gaps


def snap_to_gap(t, gaps, ventana):
    """Ajusta el tiempo t a la pausa mas grande dentro de +-ventana; si no hay,
    devuelve t sin cambios."""
    mejor, mejor_g = t, -1.0
    for tg, g in gaps:
        if abs(tg - t) <= ventana and g > mejor_g:
            mejor, mejor_g = tg, g
    return mejor


def _monotonic(cuts):
    for i in range(1, len(cuts)):
        if cuts[i] <= cuts[i - 1]:
            cuts[i] = round(cuts[i - 1] + 0.5, 3)
    return cuts


def snap_cuts(words, audio_end, n_clips, ventana):
    """FALLBACK (reparto por reloj): reparte n_clips en franjas de tiempo IGUALES
    y ajusta cada corte a la pausa mas cercana. Se usa solo cuando NO hay lista de
    beats; su punto debil es el desfase acumulado cuando la narracion no es pareja."""
    gaps = build_gaps(words)
    cuts = [0.0]
    for k in range(1, n_clips):
        ideal = audio_end * k / n_clips
        mejor = snap_to_gap(ideal, gaps, ventana)
        mejor = max(mejor, cuts[-1] + 1.0)   # respeta orden y duracion minima
        cuts.append(round(mejor, 3))
    cuts.append(round(audio_end, 3))
    return _monotonic(cuts)


def _norm_tokens(txt):
    """Palabras normalizadas (sin tildes, minusculas, solo alfanumerico)."""
    txt = unicodedata.normalize("NFD", txt)
    txt = "".join(c for c in txt if unicodedata.category(c) != "Mn")
    return re.findall(r"[a-z0-9]+", txt.lower())


def _token_stream(words):
    """Convierte la transcripcion en tokens con su (inicio, fin) reales."""
    T = []
    for w in words:
        for tok in _norm_tokens(w["w"]):
            T.append((tok, w["start"], w["end"]))
    return T


def content_cuts(words, beats, audio_end, ventana):
    """CORTE POR CONTENIDO: cada clip i cubre el beat i (misma frase de la IA, en
    orden). Alinea las frases con la transcripcion real de Whisper y corta donde
    ARRANCA el siguiente beat, no en franjas de reloj. Elimina el desfase
    acumulado que desincronizaba los ultimos clips.

    Metodo: ancla proporcional por nº de palabras del guion (respeta la densidad:
    pasaje denso = mas palabras = mas tiempo) + afinado buscando el inicio real del
    siguiente beat en una ventana de tokens + ajuste a la pausa mas cercana."""
    T = _token_stream(words)
    if not T:
        return None
    beat_tokens = [_norm_tokens(b) for b in beats]
    total_tok = sum(len(bt) for bt in beat_tokens) or 1

    gaps = build_gaps(words)
    cuts = [0.0]
    cursor = 0          # indice de token donde termino el beat anterior
    cum = 0
    for k in range(len(beats) - 1):
        cum += len(beat_tokens[k])
        approx = int(round(len(T) * cum / total_tok))
        approx = min(max(approx, cursor + 1), len(T) - 1)

        # afinar: buscar el inicio del siguiente beat (sus 1-2 primeras palabras)
        nb = beat_tokens[k + 1]
        idx = approx
        if nb:
            win = max(len(beat_tokens[k]) // 2, 6)
            lo = max(cursor + 1, approx - win)
            hi = min(len(T) - 1, approx + win)
            mejor, mejor_d = None, None
            for i in range(lo, hi + 1):
                if T[i][0] == nb[0] and (len(nb) < 2 or (i + 1 < len(T) and T[i + 1][0] == nb[1])):
                    d = abs(i - approx)
                    if mejor_d is None or d < mejor_d:
                        mejor, mejor_d = i, d
            if mejor is not None:
                idx = mejor

        t = T[idx][1]                       # inicio real del siguiente beat
        t = snap_to_gap(t, gaps, ventana)
        t = max(t, cuts[-1] + 1.0)
        cuts.append(round(t, 3))
        cursor = idx
    cuts.append(round(audio_end, 3))
    return _monotonic(cuts)


def load_beats(root, grok, explicit=None):
    """Carga la lista ordenada de frases, duraciones y orden por escena.
    Busca en root y en grok/: sincronia.txt / guion.txt / guion / guion_beats.txt / beats.txt.
    Devuelve (beats, nombre_archivo). Cada beat: {'orden': int, 'frase': str, 'dur': float|None}."""
    if explicit:
        candidatos = [Path(explicit)]
    else:
        candidatos = []
        for c in (root, grok):
            if c and c.is_dir():
                for n in ("sincronia.txt", "guion.txt", "guion", "guion_beats.txt", "beats.txt"):
                    candidatos.append(c / n)
    ruta = next((c for c in candidatos if c.is_file()), None)
    if not ruta:
        return None, None

    beats = []
    with open(ruta, encoding="utf-8-sig", errors="replace") as f:
        for linea in f:
            s = linea.strip()
            if not s or s.startswith("#"):
                continue

            num = None
            dur = None
            frag = ""

            if "|" in s:
                # Comprobar si la línea empieza con número de escena (ej. 1 | ..., 01 | ...)
                m_num = re.match(r"^\s*0*(\d+)\s*\|(.*)$", s)
                if not m_num:
                    # No empieza con número -> encabezado tipo "ESCENA | INICIO-FIN | DURACION | ..."
                    continue
                num = int(m_num.group(1))
                cols = [c.strip() for c in s.split("|")]

                # Duración explícita (ej. 5.0s, 3.5s)
                md = re.search(r"(\d+(?:[.,]\d+)?)\s*s\b", s, re.IGNORECASE)
                if md:
                    dur = float(md.group(1).replace(",", "."))
                else:
                    # Intento por rango de tiempo (ej. 0:00–0:05, 1:00-1:05)
                    mt = re.search(r"(\d+):(\d+(?:\.\d+)?)\s*[-–—]\s*(\d+):(\d+(?:\.\d+)?)", s)
                    if mt:
                        t0 = int(mt.group(1)) * 60 + float(mt.group(2))
                        t1 = int(mt.group(3)) * 60 + float(mt.group(4))
                        if t1 > t0:
                            dur = round(t1 - t0, 3)

                # Texto / frase de la escena
                if len(cols) >= 4:
                    frag = cols[3]
                elif len(cols) == 3:
                    frag = cols[2]
                elif len(cols) == 2:
                    frag = cols[1]
                else:
                    frag = s
            else:
                # Línea sin pipes: comprobar si es un encabezado suelto
                if s.lower() in ("escena", "guion", "texto", "inicio", "duracion", "prompt"):
                    continue
                frag = s

            # Limpiar comillas externas sin cortar comillas internas
            frag = frag.strip()
            if (frag.startswith('"') and frag.endswith('"')) or (frag.startswith("'") and frag.endswith("'")):
                if len(frag) >= 2:
                    frag = frag[1:-1].strip()

            if _norm_tokens(frag) or dur is not None:
                beats.append({"orden": num, "frase": frag, "dur": dur})

    if not beats:
        return None, None

    # Si tienen orden asignado, ordenar por ese número para respetar la numeración exacta
    con_num = [b for b in beats if b["orden"] is not None]
    if len(con_num) == len(beats):
        beats.sort(key=lambda b: b["orden"])
    else:
        for idx, b in enumerate(beats, 1):
            if b["orden"] is None:
                b["orden"] = idx

    return beats, ruta.name


def words_in(words, a, b):
    txt = " ".join(w["w"] for w in words if a <= (w["start"] + w["end"]) / 2 < b)
    return re.sub(r"\s+", " ", txt).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", nargs="*", default=["."],
                    help="carpeta del proyecto (se admiten rutas con espacios sin comillas)")
    ap.add_argument("--modelo", default="small", help="tiny|base|small|medium")
    ap.add_argument("--ventana", type=float, default=1.75,
                    help="margen (s) para ajustar el corte a una pausa")
    ap.add_argument("--handle", type=float, default=0.0,
                    help="segundos extra de cola en cada clip (para transiciones)")
    ap.add_argument("--beats", default=None,
                    help="archivo de sincronia (por defecto busca sincronia.txt)")
    ap.add_argument("--sin-contenido", action="store_true",
                    help="fuerza el reparto por reloj aunque exista sincronia")
    ap.add_argument("--sin-whisper", action="store_true",
                    help="corta directamente por sincronia.txt sin transcribir con Whisper")
    ap.add_argument("--whisper", action="store_true",
                    help="fuerza el uso de Whisper aunque exista guion.txt")
    ap.add_argument("--crf", type=int, default=18, help="calidad (menor=mejor)")
    ap.add_argument("--con-audio", action="store_true",
                    help="conservar el audio original de cada clip")
    ap.add_argument("--limpiar-silencios", action="store_true",
                    help="genera <audio>_limpio.mp3 recortando los silencios largos")
    ap.add_argument("--max-silencio", type=float, default=0.35,
                    help="segundos de silencio que se conservan en cada pausa larga")
    ap.add_argument("--min-silencio", type=float, default=0.5,
                    help="a partir de cuantos segundos un silencio se considera largo")
    ap.add_argument("--umbral-db", type=float, default=-30.0,
                    help="nivel (dB) bajo el cual se considera silencio")
    ap.add_argument("--inicio-video", type=float, default=1.25,
                    help="segundo donde arranca el corte de clips animados para omitir el inicio estático (por defecto 1.25s, rango sugerido 1.0 a 1.5s)")
    ap.add_argument("--offset-video", dest="inicio_video", type=float,
                    help="alias de --inicio-video")
    ap.add_argument("--fin-video-margen", type=float, default=1.0,
                    help="segundos finales a descartar de los clips animados para evitar congelamiento o artefactos de cola (por defecto 1.0s)")
    ap.add_argument("--sin-zoom", dest="zoom_imagen", action="store_false", default=True,
                    help="desactiva el zoom dinámico en imágenes estáticas")
    ap.add_argument("--zoom-inicio", type=float, default=1.03,
                    help="zoom inicial para imágenes estáticas (por defecto 1.03 = 103%%)")
    ap.add_argument("--zoom-fin", type=float, default=1.30,
                    help="zoom final para imágenes estáticas (por defecto 1.30 = 130%%)")
    ap.add_argument("--modo-zoom", choices=["in", "out", "alternar"], default="alternar",
                    help="estilo de cámara: 'in' (zoom in), 'out' (zoom out) o 'alternar' (recomendado, dinamismo cinemático)")
    ap.add_argument("--montar", dest="montar_video", action="store_true", default=True,
                    help="une automáticamente todos los clips y el audio en video_completo.mp4 (por defecto activado)")
    ap.add_argument("--sin-montar", dest="montar_video", action="store_false",
                    help="solo genera los cortes individuales sin unir el video completo")
    ap.add_argument("--subtitulos", dest="subtitulos", action="store_true", default=True,
                    help="genera automáticamente video_subtitulado.mp4 con subtítulos estilo karaoke (por defecto activado)")
    ap.add_argument("--sin-subtitulos", dest="subtitulos", action="store_false",
                    help="no genera el video con subtítulos karaoke")
    ap.add_argument("--modelo-subtitulos", default="small",
                    help="modelo de Whisper para subtítulos si no se usó Whisper al cortar (por defecto small)")
    ap.add_argument("--trazo", type=int, default=3,
                    help="grosor del contorno negro de los subtítulos (por defecto 3, idéntico al valor 37 de CapCut)")
    ap.add_argument("--estilo-subtitulos", default="capcut_karaoke", help="estilo visual de subtitulos")
    args = ap.parse_args()

    raw = " ".join(args.folder) if isinstance(args.folder, list) else args.folder
    raw_path = os.path.abspath(raw.strip())
    if not os.path.isdir(raw_path):
        sys.exit(f"ERROR: no existe la carpeta: {raw_path}\n"
                 f"Sugerencia: pon la ruta entre comillas si tiene espacios.")

    root, grok, veo, out_dir = find_project_layout(raw_path)
    print(f"Proyecto : {root.name}")
    print(f"Ruta     : {root}")

    audio = find_audio(root, grok)
    if not audio:
        sys.exit("ERROR: no encontré ningún archivo de audio en la carpeta.")

    beats, beats_file = load_beats(root, grok, args.beats)

    # Identificar tomas (híbrido: videos en grok + imágenes en veo)
    if beats:
        tomas = find_shots(len(beats), grok, veo, beats=beats)
    else:
        # Modo legado: solo clips de video que empiecen con numero
        vids = [p for p in grok.glob("*.mp4") if re.match(r"^\d", p.name)] if grok.is_dir() else []
        tomas = [{"orden": i, "tipo": "video", "ruta": str(p), "nombre": p.name} for i, p in enumerate(vids, 1)]

    if not tomas:
        sys.exit("ERROR: no encontré clips ni imágenes para cortar.")

    out_dir.mkdir(parents=True, exist_ok=True)

    if args.limpiar_silencios:
        print("  Limpiando silencios largos...", flush=True)
        audio, recortado = limpiar_silencios(
            audio, str(out_dir), args.umbral_db, args.max_silencio, args.min_silencio)
        if recortado > 0:
            print(f"  -> cortes/{os.path.basename(audio)} (se quitaron {recortado:.2f}s de silencio)")
            print(f"     IMPORTANTE: usa ESTE audio en CapCut, no el original.")
        else:
            print("  -> no había silencios largos que quitar.")

    audio_end = ffprobe_dur(audio)
    n_vids = sum(1 for t in tomas if t["tipo"] == "video")
    n_imgs = sum(1 for t in tomas if t["tipo"] == "imagen")
    print(f"  Audio    : {os.path.basename(audio)} ({audio_end:.2f}s)")
    print(f"  Tomas    : {len(tomas)} ({n_vids} videos + {n_imgs} imágenes)")
    if n_vids > 0:
        print(f"  Clips animados: inicio en {args.inicio_video:.2f}s (omite inicio estático) | fin descartando últimos {args.fin_video_margen:.2f}s (evita congelamiento)")
    if n_imgs > 0:
        if args.zoom_imagen:
            print(f"  Imágenes veo : Zoom dinámico activo [{args.modo_zoom.upper()}] ({args.zoom_inicio*100:.0f}% a {args.zoom_fin*100:.0f}%, 1080x1920)")
        else:
            print(f"  Imágenes veo : Modo estático plano (sin zoom)")

    # Decidir si se usa Whisper o sincronía directa
    hay_guion_manual = any(
        (folder / name).is_file()
        for folder in (root, grok)
        for name in ("guion.txt", "guion", "guion.md")
    )
    todos_con_dur = bool(beats and all(b.get("dur") is not None and b["dur"] > 0 for b in beats))

    if args.whisper:
        usar_whisper = True
    elif args.sin_whisper:
        usar_whisper = False
    elif hay_guion_manual or todos_con_dur:
        # Sincronía directa: si sincronia.txt ya tiene las duraciones de cada escena,
        # o si se aportó un guion manual, se respeta esa duración exacta escalándola al audio.
        usar_whisper = False
    else:
        usar_whisper = True

    words = []
    cuts = None
    metodo = "reloj (reparto por franjas iguales)"

    if not usar_whisper and beats and todos_con_dur and not args.sin_contenido:
        total_sinc = sum(b["dur"] for b in beats)
        factor = audio_end / total_sinc if total_sinc > 0 else 1.0
        cuts = [0.0]
        for b in beats:
            cuts.append(round(cuts[-1] + b["dur"] * factor, 3))
        cuts[-1] = round(audio_end, 3)
        metodo = f"SINCRONÍA DIRECTA (tiempos de {beats_file} escalados proporcionalmente al audio)"
        print(f"  Modo     : Sincronía directa ({beats_file} -> duraciones respetadas)")
    else:
        words = transcribe(audio, args.modelo)
        if not words:
            sys.exit("ERROR: la transcripcion salio vacia.")
        if not args.sin_contenido and beats:
            frases = [b["frase"] for b in beats]
            if len(frases) == len(tomas):
                cc = content_cuts(words, frases, audio_end, args.ventana)
                if cc:
                    cuts = cc
                    metodo = f"CONTENIDO (segun {beats_file}: alineado con Whisper)"
            else:
                print(f"  AVISO: {beats_file} tiene {len(beats)} beats pero hay "
                      f"{len(tomas)} tomas. Uso reparto por reloj.")
        if cuts is None:
            cuts = snap_cuts(words, audio_end, len(tomas), args.ventana)

    print(f"  Método de corte: {metodo}")

    motion_plan = []
    if any(s.get("tipo") == "motion" for s in tomas) and planificar_escenas_motion is not None:
        cfg_nicho_m = obtener_config_nicho_proyecto(root)
        motion_beats = []
        for idx_m in range(len(tomas)):
            ini_m, fin_m = cuts[idx_m], cuts[idx_m + 1]
            narr_m = beats[idx_m]["frase"] if beats and idx_m < len(beats) else (words_in(words, ini_m, fin_m) if words else f"Escena {idx_m + 1}")
            motion_beats.append({"frase": narr_m, "dur": round(fin_m - ini_m, 3)})
        print("  [MOTION] Diseñando guion gráfico animado 2D por escena...", flush=True)
        motion_plan = planificar_escenas_motion(root, motion_beats, cfg_nicho_m)

    filas = []
    for i, shot in enumerate(tomas):
        ini, fin = cuts[i], cuts[i + 1]
        objetivo = fin - ini
        export = objetivo + (args.handle if i < len(tomas) - 1 else 0.0)

        narr = beats[i]["frase"] if beats and i < len(beats) else (words_in(words, ini, fin) if words else "")
        base = os.path.splitext(shot["nombre"])[0]
        out_name = f"{i+1:02d}_{slug(narr) or slug(base)}.mp4"
        out_path = str(out_dir / out_name)

        norm_v = ",scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30"

        if shot["tipo"] == "video":
            src = ffprobe_dur(shot["ruta"]) or objetivo
            # Punto de inicio para omitir los primeros 1.25 segundos estáticos del clip animado
            offset = max(0.0, min(args.inicio_video, max(0.0, src - 1.5)))
            # Margen final a descartar (por defecto 1.0s) para evitar congelamientos o artefactos de cola
            margen_fin = max(0.0, min(args.fin_video_margen, max(0.0, src - offset - 0.5)))
            t_limite = max(offset + 0.5, src - margen_fin)
            disponible = max(0.1, t_limite - offset)

            if export <= disponible + 0.01:
                t_fin = offset + export
                vf = f"trim={offset:.4f}:{t_fin:.4f},setpts=PTS-STARTPTS{norm_v}"
            else:
                # Si el tiempo requerido supera el metraje disponible tras el offset y margen final,
                # se ralentiza suavemente el metraje animado disponible para cubrir la duración
                factor = export / disponible
                vf = f"trim={offset:.4f}:{t_limite:.4f},setpts={factor:.5f}*(PTS-STARTPTS),trim=0:{export:.4f}{norm_v}"

            cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                   "-i", shot["ruta"], "-filter:v", vf,
                   "-c:v", "libx264", "-preset", "medium", "-crf", str(args.crf),
                   "-pix_fmt", "yuv420p"]
            cmd += ["-c:a", "aac", "-b:a", "160k"] if args.con_audio else ["-an"]
            cmd += ["-movflags", "+faststart", out_path]
        elif shot["tipo"] == "motion" and render_escena_motion_mp4 is not None:
            spec = motion_plan[i] if i < len(motion_plan) else {
                "orden": i + 1,
                "plantilla": "flujo_general",
                "titulo": (narr[:24] or f"ESCENA {i + 1:02d}").upper(),
                "subtitulo": "DIAGRAMA TÉCNICO",
                "acento": "ciencia",
                "kpi": f"{i + 1:02d}/{len(tomas):02d}",
                "etiquetas": ["INGENIERÍA", "ANÁLISIS"],
            }
            try:
                ok_m = render_escena_motion_mp4(
                    out_path=out_path,
                    duration=export,
                    scene_idx=i,
                    total_scenes=len(tomas),
                    spec=spec,
                    crf=args.crf,
                    con_audio_silencio=args.con_audio,
                )
            except Exception as exc_m:
                print(f"  [ERROR MOTION] Escena {i+1:02d}: {exc_m}", flush=True)
                ok_m = False
            ok = "OK" if ok_m else "FALLO"
            etq_tipo = "MOTION"
            print(f"  [{ok}] [{etq_tipo}] {out_name}  ({objetivo:.2f}s)  [{spec.get('plantilla', 'motion')}]  \"{narr[:42]}\"")
            filas.append({
                "orden": i + 1, "tipo": shot["tipo"], "archivo": out_name,
                "origen": f"motion:{spec.get('plantilla', 'flujo_general')}",
                "inicio_narracion": round(ini, 2), "fin_narracion": round(fin, 2),
                "duracion": round(objetivo, 2), "duracion_exportada": round(export, 2),
                "narracion": narr,
            })
            continue
        else:  # imagen estática con animación Zoom (Ken Burns)
            if args.zoom_imagen:
                if args.modo_zoom == "alternar":
                    es_in = (i % 2 == 0)
                elif args.modo_zoom == "in":
                    es_in = True
                else:
                    es_in = False

                fps = 30
                total_frames = max(1, int(round(export * fps)))
                delta_z = args.zoom_fin - args.zoom_inicio
                if es_in:
                    z_expr = f"{args.zoom_inicio:.3f}+{delta_z:.3f}*(on/{total_frames})"
                else:
                    z_expr = f"{args.zoom_fin:.3f}-{delta_z:.3f}*(on/{total_frames})"

                vf = (
                    f"scale=1080:1920:force_original_aspect_ratio=increase,"
                    f"crop=1080:1920,"
                    f"zoompan=z='{z_expr}':x='iw/2-(iw/zoom/2)':y='ih*0.42-(ih/zoom/2)':d=1:s=1080x1920:fps={fps},"
                    f"setsar=1,trim=duration={export:.4f}"
                )
            else:
                vf = ("scale=1080:1920:force_original_aspect_ratio=decrease,"
                      "pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30")

            cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                   "-loop", "1", "-i", shot["ruta"],
                   "-vf", vf,
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", str(args.crf),
                   "-pix_fmt", "yuv420p", "-t", f"{export:.4f}"]
            if args.con_audio:
                cmd += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-c:a", "aac", "-shortest"]
            else:
                cmd += ["-an"]
            cmd += ["-movflags", "+faststart", out_path]

        r = run(cmd)
        ok = "OK" if r.returncode == 0 else "FALLO"
        etq_tipo = "VIDEO " if shot["tipo"] == "video" else "IMAGEN"
        print(f"  [{ok}] [{etq_tipo}] {out_name}  ({objetivo:.2f}s)  \"{narr[:50]}\"")
        filas.append({
            "orden": i + 1, "tipo": shot["tipo"], "archivo": out_name, "origen": shot["nombre"],
            "inicio_narracion": round(ini, 2), "fin_narracion": round(fin, 2),
            "duracion": round(objetivo, 2), "duracion_exportada": round(export, 2),
            "narracion": narr,
        })

    with open(out_dir / "_mapeo.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0].keys()))
        w.writeheader()
        w.writerows(filas)
    with open(out_dir / "_mapeo.txt", "w", encoding="utf-8") as f:
        f.write(f"# Metodo de corte: {metodo}\n\n")
        for r in filas:
            f.write(f"{r['orden']:02d}  {r['inicio_narracion']:6.2f}-{r['fin_narracion']:6.2f}s "
                    f"({r['duracion']:.2f}s) [{r['tipo'].upper()}] <- {r['origen']}\n     \"{r['narracion']}\"\n")

    total = sum(r["duracion"] for r in filas)
    print(f"\nListo. {len(filas)} cortes en: {out_dir}")
    print(f"Suma de duraciones: {total:.2f}s  (audio: {audio_end:.2f}s)")
    print("Revisa _mapeo.txt para ver qué narración cubre cada clip.")

    if args.montar_video and filas:
        out_completo = out_dir / "video_completo.mp4"
        txt_list = out_dir / "_concat_list.txt"
        with open(txt_list, "w", encoding="utf-8") as f:
            for r in filas:
                clip_p = (out_dir / r["archivo"]).resolve()
                f.write(f"file '{clip_p.as_posix()}'\n")

        cfg_nicho = obtener_config_nicho_proyecto(root)
        musica_p = buscar_musica_fondo(root, cfg_nicho)
        if musica_p:
            print(f"  [AUDIO] Mezclando música de fondo: {os.path.basename(musica_p)} (15% volumen)...", flush=True)
            cmd_montaje = [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                "-f", "concat", "-safe", "0", "-i", str(txt_list),
                "-i", str(audio),
                "-stream_loop", "-1", "-i", str(musica_p),
                "-filter_complex", "[1:a]volume=1.0[v];[2:a]volume=0.15[m];[v][m]amix=inputs=2:duration=first:dropout_transition=2[aout]",
                "-map", "0:v", "-map", "[aout]",
                "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k",
                "-shortest",
                "-movflags", "+faststart",
                str(out_completo)
            ]
        else:
            cmd_montaje = [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                "-f", "concat", "-safe", "0", "-i", str(txt_list),
                "-i", str(audio),
                "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k",
                "-shortest",
                "-movflags", "+faststart",
                str(out_completo)
            ]
        r_m = run(cmd_montaje)
        if r_m.returncode == 0:
            print(f"\n  [OK] VIDEO COMPLETO MONTADO CON EXITO:")
            print(f"       -> {out_completo}")
            print(f"       (Audio sincronizado y cortes unidos en 1080x1920 listo para reproducir)")

            if args.subtitulos:
                try:
                    try:
                        from subtitulos_karaoke import generar_subtitulos_karaoke
                    except ImportError:
                        try:
                            from videos.subtitulos_karaoke import generar_subtitulos_karaoke
                        except ImportError:
                            from ecos.subtitulos_karaoke import generar_subtitulos_karaoke

                    out_sub = out_dir / "video_subtitulado.mp4"
                    cache_w = out_dir / "_words.json"
                    sinc_p = str(beats_file) if beats_file and os.path.isfile(beats_file) else None
                    generar_subtitulos_karaoke(
                        video_in=str(out_completo),
                        audio_in=str(audio),
                        video_out=str(out_sub),
                        script_path=sinc_p,
                        words=words if words else None,
                        modelo=args.modelo_subtitulos,
                        stroke_w=args.trazo,
                        cache_words_path=str(cache_w),
                        estilo=args.estilo_subtitulos
                    )
                    print(f"\n  [OK] VIDEO CON SUBTÍTULOS KARAOKE MONTADO CON EXITO:")
                    print(f"       -> {out_sub}")
                    print(f"       (Tipografía Melvins One, resaltado #ff0050, 100% mayúsculas con tildes)")
                except Exception as e:
                    print(f"  [AVISO] No se pudieron generar los subtítulos automáticos: {e}")


if __name__ == "__main__":
    main()
