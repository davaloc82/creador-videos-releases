' ==============================================================================
' Lanzador Silencioso del Panel de Videos (Sin Ventana Negra)
' NEXOR - Sistema Integrado de Replicacion de Canales
' ==============================================================================
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

strDir = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = strDir

Function FindPython(isWindowless)
    Dim exeName, localApp, progFiles, cands, i, installerPath
    If isWindowless Then
        exeName = "pythonw.exe"
    Else
        exeName = "python.exe"
    End If

    localApp = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%")
    progFiles = WshShell.ExpandEnvironmentStrings("%ProgramFiles%")

    cands = Array( _
        localApp & "\Programs\Python\Python311\" & exeName, _
        localApp & "\Programs\Python\Python312\" & exeName, _
        localApp & "\Programs\Python\Python310\" & exeName, _
        progFiles & "\Python311\" & exeName, _
        progFiles & "\Python312\" & exeName, _
        "C:\Python311\" & exeName, _
        "C:\Python312\" & exeName _
    )

    ' 1. Buscar en rutas estandar
    For i = 0 To UBound(cands)
        If fso.FileExists(cands(i)) Then
            FindPython = """" & cands(i) & """"
            Exit Function
        End If
    Next

    ' 2. Si no se encontro y existe el instalador en redist, autoinstalar silenciosamente
    installerPath = strDir & "\redist\python-3.11.9-amd64.exe"
    If fso.FileExists(installerPath) Then
        On Error Resume Next
        WshShell.Run """" & installerPath & """ /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 SimpleInstall=1", 0, True
        On Error Goto 0
        
        ' Reintentar buscar tras la instalacion
        For i = 0 To UBound(cands)
            If fso.FileExists(cands(i)) Then
                FindPython = """" & cands(i) & """"
                Exit Function
            End If
        Next
    End If

    ' Fallback
    If isWindowless Then
        FindPython = "pythonw.exe"
    Else
        FindPython = "python.exe"
    End If
End Function

pywCmd = FindPython(True)

' 1. Auditar entorno silenciosamente si existe el auditor y no se ha verificado previamente
If fso.FileExists(strDir & "\core\verificar_entorno.py") And Not fso.FileExists(strDir & "\.entorno_listo") Then
    On Error Resume Next
    WshShell.Run pywCmd & " """ & strDir & "\core\verificar_entorno.py""", 0, True
    If Err.Number = 0 Then
        Set fListo = fso.CreateTextFile(strDir & "\.entorno_listo", True)
        fListo.WriteLine "OK"
        fListo.Close
    End If
    On Error Goto 0
End If

' 1.5 Auto-actualizar silenciosamente si hay internet
If fso.FileExists(strDir & "\core\actualizador.py") Then
    On Error Resume Next
    WshShell.Run pywCmd & " """ & strDir & "\core\actualizador.py"" --auto", 0, True
    On Error Goto 0
End If

' 2. Lanzar panel.py con pythonw (sin ventana de consola)
On Error Resume Next
WshShell.Run pywCmd & " """ & strDir & "\panel.py""", 0, False
If Err.Number <> 0 Then
    ' Si falla pythonw, arrancar panel.bat como respaldo
    If fso.FileExists(strDir & "\panel.bat") Then
        WshShell.Run """" & strDir & "\panel.bat""", 1, False
    Else
        MsgBox "No se encontro el runtime de Python en su sistema. Por favor ejecute panel.bat para instalarlo.", 16, "NEXOR"
    End If
End If
