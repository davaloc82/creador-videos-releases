# -*- coding: utf-8 -*-
"""
Motor Generativo de Video HyperFrames (Video as Code) - Estilo @nuncateloexplicaron.
Genera composiciones cinemáticas HTML5/SVG vectoriales animadas con GSAP en formato vertical 9:16 (1080x1920)
reproduciendo con exactitud la estética visual, subtítulos cinéticos chunked (2-4 palabras) con caja selectora y anclas,
escenarios técnicos blueprint 3D, física de fluidos y mecánica de @nuncateloexplicaron.
"""

import os
import re
import sys
import json
import shutil
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
TEMP_COMP_DIR = BASE_DIR / "video_engine" / ".temp_render"


def _limpiar_texto(t: str) -> str:
    if not t:
        return ""
    return str(t).replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')


def _clasificar_escena(narr: str, orden: int) -> str:
    """Identifica la escena semántica exacta del guión técnico."""
    txt = (narr or "").lower()
    
    # Detección estricta de tema Sifón / Fontanería
    is_sifon = any(k in txt for k in ("sifón", "sifon", "lavabo", "tubo", "desagüe", "desague", "gas fétido", "gas fetido", "apesta", "pelos", "residuos", "grifo", "antirretorno", "admisión", "admision", "fontanero", "sello de agua"))
    
    # Detección de tema Radar / Velocímetro / Coches (@importacrew)
    is_radar = any(k in txt for k in ("radar", "coche", "gps", "velocidad", "120", "115", "109", "126", "130", "autovía", "autovia", "multa", "onda", "apretada", "importa", "descuento", "equivoca", "margen"))

    if is_sifon:
        if orden == 1 or any(k in txt for k in ("tubo recto", "baje directo", "suelo")):
            return "01_tubo_recto"
        if orden == 2 or any(k in txt for k in ("ya tienes el desagüe", "desagüe")):
            return "02_desague_directo"
        if orden == 3 or any(k in txt for k in ("gas fétido", "gas fetido", "sube el gas")):
            return "03_gas_fetido_sube"
        if orden == 4 or any(k in txt for k in ("apesta todo tu baño", "apesta", "olor")):
            return "04_apesta_bano"
        if orden == 5 or any(k in txt for k in ("doblas el tubo", "letra uve", "letra u", "retiene agua")):
            return "05_doblas_tubo_uve"
        if orden == 6 or any(k in txt for k in ("bloquea el paso", "sifón hidráulico", "sifon hidraulico")):
            return "06_bloquea_vapores"
        if orden == 7 or any(k in txt for k in ("lavar platos", "pelos y jabón", "pelos y jabon")):
            return "07_pelos_jabon"
        if orden == 8 or any(k in txt for k in ("residuos sólidos", "residuos solidos", "atrapados en el fondo")):
            return "08_residuos_fondo"
        if orden == 9 or any(k in txt for k in ("obstruyen el paso", "obstruyen", "atasco")):
            return "09_obstruyen_paso"
        if orden == 10 or any(k in txt for k in ("tapón roscado", "tapon roscado", "desmontable")):
            return "10_tapon_roscado"
        if orden == 11 or any(k in txt for k in ("limpiarlo en segundos", "sin llamar al fontanero")):
            return "11_limpieza_segundos"
        if orden == 12 or any(k in txt for k in ("grifo a tope", "caudal enorme", "abres el grifo")):
            return "12_grifo_tope"
        if orden == 13 or any(k in txt for k in ("chupa el líquido", "chupa el liquido", "tanta fuerza")):
            return "13_succion_vacio"
        if orden == 14 or any(k in txt for k in ("lo deja seco", "deja seco", "descebado")):
            return "14_deja_seco"
        if orden == 15 or any(k in txt for k in ("rompiendo el sello", "camino libre al olor")):
            return "15_rompe_sello"
        if orden == 16 or any(k in txt for k in ("válvula de admisión", "valvula de admision", "parte alta")):
            return "16_valvula_admision"
        if orden == 17 or any(k in txt for k in ("deja entrar oxígeno", "deja entrar oxigeno", "succión")):
            return "17_entra_oxigeno"
        if orden == 18 or any(k in txt for k in ("presión atmosférica", "presion atmosferica", "equilibrando")):
            return "18_equilibra_presion"
        if orden == 19 or any(k in txt for k in ("tubería general", "tuberia general")):
            return "19_tuberia_general"
        if orden == 20 or any(k in txt for k in ("calle se satura", "tormenta brutal")):
            return "20_tormenta_satura"
        if orden == 21 or any(k in txt for k in ("agua sucia empieza", "retroceder")):
            return "21_agua_retrocede"
        if orden == 22 or any(k in txt for k in ("se desborda", "inundando el piso")):
            return "22_desborda_inunda"
        if orden == 23 or any(k in txt for k in ("válvula antirretorno", "valvula antirretorno", "compuerta")):
            return "23_valvula_antirretorno"
        if orden == 24 or any(k in txt for k in ("solo se abre hacia afuera", "hacia afuera")):
            return "24_abre_afuera"
        if orden == 25 or any(k in txt for k in ("impidiendo que lo de afuera", "entre a tu casa")):
            return "25_impide_entrada"
        if orden == 26 or any(k in txt for k in ("mándaselo", "mandaselo", "huele algo raro")):
            return "26_cta_compartir"
        return "general_cyber"

    # Mapeo limpio para Radar / Automoción
    radar_map = {
        1: "radar_01_velocimetro_gps",
        2: "radar_02_pregunta_cuenta",
        3: "radar_03_no_mira_coche",
        4: "radar_04_onda_rebota",
        5: "radar_05_doppler_apretada",
        6: "radar_06_velocidad_verdad",
        7: "radar_07_115_real",
        8: "radar_08_marca_de_mas",
        9: "radar_09_ley_nunca_menos",
        10: "radar_10_tampoco_115",
        11: "radar_11_margen_error",
        12: "radar_12_por_si_se_equivoca",
        13: "radar_13_cinco_porciento",
        14: "radar_14_quedan_109",
        15: "radar_15_no_multa_hasta",
        16: "radar_16_multa_126_130",
        17: "radar_17_mas_baja_tres",
        18: "radar_18_radar_descuento",
        19: "radar_19_cta",
    }
    if is_radar or (1 <= orden <= 19 and not is_sifon):
        return radar_map.get(orden, "general_cyber")
    if orden == 19 or any(k in txt for k in ("tubería general", "tuberia general")):
        return "19_tuberia_general"
    if orden == 20 or any(k in txt for k in ("calle se satura", "tormenta brutal")):
        return "20_tormenta_satura"
    if orden == 21 or any(k in txt for k in ("agua sucia empieza", "retroceder")):
        return "21_agua_retrocede"
    if orden == 22 or any(k in txt for k in ("se desborda", "inundando el piso")):
        return "22_desborda_inunda"
    if orden == 23 or any(k in txt for k in ("válvula antirretorno", "valvula antirretorno", "compuerta")):
        return "23_valvula_antirretorno"
    if orden == 24 or any(k in txt for k in ("solo se abre hacia afuera", "hacia afuera")):
        return "24_abre_afuera"
    if orden == 25 or any(k in txt for k in ("impidiendo que lo de afuera", "entre a tu casa")):
        return "25_impide_entrada"
    if orden == 26 or any(k in txt for k in ("mándaselo", "mandaselo", "huele algo raro")):
        return "26_cta_compartir"
    
    return "general_cyber"


def _obtener_contenido_escena(tipo: str, dur: float) -> tuple[str, str, str, str]:
    """
    Retorna (svg_elements, hud_pill_text, alert_pill_text, gsap_animation_code)
    para el tipo de escena solicitado con gráficos a escala completa.
    """
    d = max(1.0, float(dur))
    
    # 01. TUBO RECTO INICIAL
    if tipo == "01_tubo_recto":
        svg = """
        <g id="sinkGroup" filter="url(#neonGlowCyan)">
          <path d="M 240 180 C 240 300 400 320 490 320 C 580 320 740 300 740 180 Z" fill="rgba(8, 24, 48, 0.85)" stroke="#00f0ff" stroke-width="5" />
          <path d="M 240 180 C 240 300 400 320 490 320 C 580 320 740 300 740 180 Z" fill="url(#pipeGrid)" />
          <ellipse cx="490" cy="180" rx="250" ry="30" fill="rgba(15, 30, 60, 0.9)" stroke="#00f0ff" stroke-width="4" />
          <ellipse cx="490" cy="305" rx="46" ry="14" fill="#060a17" stroke="#00f0ff" stroke-width="3" />
          <path d="M 490 145 L 490 75 C 490 35 570 35 570 70 L 570 100" fill="none" stroke="#38bdf8" stroke-width="16" stroke-linecap="round" />
        </g>
        <g id="pipeGroup">
          <rect x="445" y="315" width="90" height="580" fill="rgba(8, 28, 56, 0.85)" />
          <rect x="445" y="315" width="90" height="580" fill="url(#pipeGrid)" />
          <line x1="445" y1="315" x2="445" y2="895" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <line x1="535" y1="315" x2="535" y2="895" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <rect x="120" y="895" width="740" height="30" rx="6" fill="#1e293b" stroke="#38bdf8" stroke-width="3" />
        <text x="490" y="917" text-anchor="middle" fill="#94a3b8" font-size="28" font-weight="700" letter-spacing="3">SUELO DEL BAÑO</text>
        <path id="faucetStream" d="M 570 100 L 570 270 Q 570 305 490 315" fill="none" stroke="url(#waterGrad)" stroke-width="16" stroke-dasharray="18 12" stroke-linecap="round" filter="url(#neonGlowCyan)" />
        <path id="waterStream" d="M 490 315 L 490 895" fill="none" stroke="url(#waterGrad)" stroke-width="32" stroke-dasharray="24 16" stroke-linecap="round" filter="url(#neonGlowCyan)" />
        """
        hud = "DESAGÜE RECTO INICIAL"
        alert = ""
        gsap = f"""
        tl.to('#faucetStream', {{ strokeDashoffset: -300, duration: {d:.2f}, ease: 'none' }}, 0);
        tl.to('#waterStream', {{ strokeDashoffset: -400, duration: {d:.2f}, ease: 'none' }}, 0);
        tl.from('#faucetStream, #waterStream', {{ opacity: 0, duration: 0.4, ease: 'power2.out' }}, 0.2);
        """
        return svg, hud, alert, gsap

    # 02. DESAGÜE DIRECTO Y RÁPIDO
    elif tipo == "02_desague_directo":
        svg = """
        <g id="sinkGroup" filter="url(#neonGlowCyan)">
          <path d="M 240 180 C 240 300 400 320 490 320 C 580 320 740 300 740 180 Z" fill="rgba(8, 24, 48, 0.85)" stroke="#00f0ff" stroke-width="5" />
          <ellipse cx="490" cy="180" rx="250" ry="30" fill="rgba(15, 30, 60, 0.9)" stroke="#00f0ff" stroke-width="4" />
          <ellipse cx="490" cy="305" rx="46" ry="14" fill="#060a17" stroke="#00f0ff" stroke-width="3" />
        </g>
        <g id="pipeGroup">
          <rect x="445" y="315" width="90" height="580" fill="rgba(8, 28, 56, 0.85)" />
          <rect x="445" y="315" width="90" height="580" fill="url(#pipeGrid)" />
          <line x1="445" y1="315" x2="445" y2="895" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <line x1="535" y1="315" x2="535" y2="895" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="drainArrows" filter="url(#neonGlowGreen)">
          <path d="M 490 400 L 490 480" stroke="#22c55e" stroke-width="10" stroke-linecap="round" />
          <polygon points="475 470, 490 500, 505 470" fill="#22c55e" />
          <path d="M 490 560 L 490 640" stroke="#22c55e" stroke-width="10" stroke-linecap="round" />
          <polygon points="475 630, 490 660, 505 630" fill="#22c55e" />
          <path d="M 490 720 L 490 800" stroke="#22c55e" stroke-width="10" stroke-linecap="round" />
          <polygon points="475 790, 490 820, 505 790" fill="#22c55e" />
        </g>
        """
        hud = "EVACUACIÓN RÁPIDA: SIN FRENO"
        alert = ""
        gsap = f"""
        tl.from('#drainArrows path, #drainArrows polygon', {{ y: -40, opacity: 0, stagger: 0.15, duration: 0.5, ease: 'power2.out' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 03. GAS FÉTIDO SUBIENDO
    elif tipo == "03_gas_fetido_sube":
        svg = """
        <g id="sinkGroup" opacity="0.6">
          <path d="M 240 180 C 240 300 400 320 490 320 C 580 320 740 300 740 180 Z" fill="rgba(8, 24, 48, 0.85)" stroke="#00f0ff" stroke-width="4" />
          <ellipse cx="490" cy="180" rx="250" ry="30" fill="rgba(15, 30, 60, 0.9)" stroke="#00f0ff" stroke-width="3" />
        </g>
        <g id="pipeGroup">
          <rect x="445" y="315" width="90" height="580" fill="rgba(8, 28, 56, 0.9)" />
          <line x1="445" y1="315" x2="445" y2="895" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <line x1="535" y1="315" x2="535" y2="895" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="toxicGasFlow" filter="url(#neonGlowRed)">
          <path id="gasPlume1" d="M 490 880 Q 465 650 490 400" fill="none" stroke="url(#gasGrad)" stroke-width="36" stroke-dasharray="24 16" stroke-linecap="round" />
          <path id="gasPlume2" d="M 470 880 Q 510 650 470 400" fill="none" stroke="url(#gasGrad)" stroke-width="24" stroke-dasharray="18 14" stroke-linecap="round" />
          <circle cx="490" cy="460" r="28" fill="#ef4444" opacity="0.4" filter="blur(6px)" />
          <circle cx="480" cy="580" r="34" fill="#f59e0b" opacity="0.4" filter="blur(8px)" />
        </g>
        <rect x="120" y="895" width="740" height="30" rx="6" fill="#1e293b" stroke="#ef4444" stroke-width="3" />
        <text x="490" y="917" text-anchor="middle" fill="#fca5a5" font-size="28" font-weight="800">GASES TÓXICOS DE CLOACA</text>
        """
        hud = "GASES DE CLOACA SUBIENDO"
        alert = ""
        gsap = f"""
        tl.to('#gasPlume1', {{ strokeDashoffset: 350, duration: {d:.2f}, ease: 'none' }}, 0);
        tl.to('#gasPlume2', {{ strokeDashoffset: 400, duration: {d:.2f}, ease: 'none' }}, 0);
        tl.from('#toxicGasFlow', {{ opacity: 0, scale: 0.9, duration: 0.6, ease: 'power2.out' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 04. APESTA TODO EL BAÑO
    elif tipo == "04_apesta_bano":
        svg = """
        <g id="sinkGroup" filter="url(#neonGlowRed)">
          <path d="M 240 280 C 240 400 400 420 490 420 C 580 420 740 400 740 280 Z" fill="rgba(28, 10, 20, 0.9)" stroke="#ff2a6d" stroke-width="5" />
          <ellipse cx="490" cy="280" rx="250" ry="30" fill="rgba(35, 12, 24, 0.9)" stroke="#ff2a6d" stroke-width="4" />
          <ellipse cx="490" cy="405" rx="46" ry="14" fill="#060a17" stroke="#ff2a6d" stroke-width="3" />
        </g>
        <g id="stinkClouds" filter="url(#neonGlowRed)">
          <path d="M 430 260 Q 400 160 450 70" fill="none" stroke="#22c55e" stroke-width="12" stroke-linecap="round" />
          <path d="M 490 250 Q 520 150 480 50" fill="none" stroke="#f59e0b" stroke-width="14" stroke-linecap="round" />
          <path d="M 550 260 Q 590 170 540 60" fill="none" stroke="#ef4444" stroke-width="12" stroke-linecap="round" />
          <circle cx="440" cy="140" r="45" fill="rgba(34, 197, 94, 0.35)" filter="blur(8px)" />
          <circle cx="530" cy="120" r="55" fill="rgba(239, 68, 68, 0.4)" filter="blur(10px)" />
        </g>
        <g id="skullAlert" transform="translate(490, 540)">
          <circle cx="0" cy="0" r="50" fill="rgba(239, 68, 68, 0.2)" stroke="#ff2a6d" stroke-width="4" />
          <text x="0" y="16" text-anchor="middle" fill="#ff2a6d" font-size="52" font-weight="900">☣</text>
        </g>
        """
        hud = "CONTAMINACIÓN DEL AIRE"
        alert = ""
        gsap = f"""
        tl.from('#stinkClouds', {{ scale: 0.6, opacity: 0, duration: 0.8, ease: 'back.out(1.5)' }}, 0.1);
        tl.to('#stinkClouds', {{ y: -30, duration: {d:.2f}, ease: 'sine.inOut' }}, 0);
        tl.from('#skullAlert', {{ scale: 0, duration: 0.5, ease: 'elastic.out(1, 0.6)' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # 05. DOBLAS EL TUBO FORMANDO LETRA U (SIFÓN)
    elif tipo == "05_doblas_tubo_uve":
        svg = """
        <g id="sinkGroup" filter="url(#neonGlowCyan)">
          <path d="M 240 160 C 240 280 400 300 490 300 C 580 300 740 280 740 160 Z" fill="rgba(8, 24, 48, 0.85)" stroke="#00f0ff" stroke-width="5" />
          <ellipse cx="490" cy="160" rx="250" ry="32" fill="rgba(15, 30, 60, 0.9)" stroke="#00f0ff" stroke-width="4" />
          <ellipse cx="490" cy="290" rx="48" ry="14" fill="#060a17" stroke="#00f0ff" stroke-width="3" />
        </g>
        <g id="siphonTube">
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="url(#pipeGrid)" stroke-width="84" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 300 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" filter="url(#neonGlowCyan)" />
          <path d="M 495 300 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" filter="url(#neonGlowCyan)" />
          <path id="waterFill" d="M 450 460 C 450 645 630 645 630 460" fill="none" stroke="url(#waterGrad)" stroke-width="76" stroke-linecap="round" filter="url(#neonGlowCyan)" />
        </g>
        """
        hud = "CURVA EN 'U' (SIFÓN HIDRÁULICO)"
        alert = ""
        gsap = f"""
        tl.from('#waterFill', {{ strokeDasharray: 400, strokeDashoffset: 400, duration: 1.2, ease: 'power2.out' }}, 0.2);
        tl.from('#siphonTube', {{ scale: 0.94, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0);
        """
        return svg, hud, alert, gsap

    # 06. BLOQUEA EL PASO DE LOS VAPORES
    elif tipo == "06_bloquea_vapores":
        svg = """
        <g id="sinkGroup" filter="url(#neonGlowCyan)">
          <path d="M 240 160 C 240 280 400 300 490 300 C 580 300 740 280 740 160 Z" fill="rgba(8, 24, 48, 0.85)" stroke="#00f0ff" stroke-width="5" />
          <ellipse cx="490" cy="160" rx="250" ry="32" fill="rgba(15, 30, 60, 0.9)" stroke="#00f0ff" stroke-width="4" />
          <ellipse cx="490" cy="290" rx="48" ry="14" fill="#060a17" stroke="#00f0ff" stroke-width="3" />
        </g>
        <g id="siphonTube">
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="url(#pipeGrid)" stroke-width="84" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 300 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 300 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path id="waterSeal" d="M 450 460 C 450 645 630 645 630 460" fill="none" stroke="url(#waterGrad)" stroke-width="76" stroke-linecap="round" filter="url(#neonGlowCyan)" />
          <line x1="410" y1="460" x2="490" y2="460" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
          <line x1="590" y1="460" x2="670" y2="460" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
        </g>
        <g id="gasRebound" filter="url(#neonGlowRed)">
          <path id="reboundStream" d="M 830 440 L 680 440 C 660 440 655 450 650 465" fill="none" stroke="url(#gasGrad)" stroke-width="38" stroke-linecap="round" stroke-dasharray="18 12" />
          <circle cx="670" cy="440" r="24" fill="#060a17" stroke="#ff2a6d" stroke-width="4" />
          <text x="670" y="449" text-anchor="middle" fill="#ff2a6d" font-size="28" font-weight="900">✕</text>
        </g>
        """
        hud = "SELLO DE AGUA: 50 mm"
        alert = ""
        gsap = f"""
        tl.to('#reboundStream', {{ strokeDashoffset: -200, duration: {d:.2f}, ease: 'none' }}, 0);
        tl.to('#waterSeal', {{ y: -3, duration: 0.6, yoyo: true, repeat: 5, ease: 'sine.inOut' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 07. PELOS, JABÓN Y RESIDUOS
    elif tipo == "07_pelos_jabon":
        svg = """
        <g id="siphonTube">
          <path d="M 450 260 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 450 460 C 450 645 630 645 630 460" fill="none" stroke="url(#waterGrad)" stroke-width="76" stroke-linecap="round" opacity="0.8" />
          <path d="M 405 260 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 260 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="fallingDebris" filter="url(#neonGlowAmber)">
          <path d="M 440 280 Q 460 360 445 420" stroke="#f59e0b" stroke-width="6" fill="none" stroke-linecap="round" />
          <path d="M 465 290 Q 450 370 470 440" stroke="#d97706" stroke-width="5" fill="none" stroke-linecap="round" />
          <circle cx="455" cy="330" r="14" fill="#fbbf24" />
          <circle cx="440" cy="390" r="12" fill="#b45309" />
          <circle cx="460" cy="450" r="16" fill="#f59e0b" />
        </g>
        """
        hud = "RESIDUOS SÓLIDOS Y GRASAS"
        alert = ""
        gsap = f"""
        tl.to('#fallingDebris', {{ y: 150, duration: {d:.2f}, ease: 'power1.in' }}, 0);
        """
        return svg, hud, alert, gsap

    # 08. RESIDUOS ATRAPADOS EN EL FONDO
    elif tipo == "08_residuos_fondo":
        svg = """
        <g id="siphonTube">
          <path d="M 450 260 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 260 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 260 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 450 460 C 450 645 630 645 630 460" fill="none" stroke="url(#waterGrad)" stroke-width="76" stroke-linecap="round" opacity="0.8" />
        </g>
        <g id="clogMass" filter="url(#neonGlowAmber)">
          <path d="M 490 560 C 510 610 570 610 590 560" fill="none" stroke="#78350f" stroke-width="48" stroke-linecap="round" />
          <circle cx="520" cy="580" r="16" fill="#92400e" />
          <circle cx="550" cy="590" r="20" fill="#b45309" />
          <circle cx="570" cy="570" r="14" fill="#d97706" />
        </g>
        """
        hud = "DECANTACIÓN EN EL FONDO"
        alert = ""
        gsap = f"""
        tl.from('#clogMass', {{ scale: 0.5, opacity: 0, duration: 0.7, ease: 'back.out(1.4)' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 09. OBSTRUYEN EL PASO DEL AGUA
    elif tipo == "09_obstruyen_paso":
        svg = """
        <g id="siphonTube">
          <path d="M 450 260 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 260 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 260 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="blockMass" filter="url(#neonGlowRed)">
          <ellipse cx="540" cy="580" rx="55" ry="38" fill="#b91c1c" stroke="#ff2a6d" stroke-width="4" />
          <text x="540" y="592" text-anchor="middle" fill="#ffffff" font-size="34" font-weight="900">⛔</text>
        </g>
        <rect id="backedWater" x="420" y="320" width="60" height="230" fill="url(#waterGrad)" opacity="0.8" />
        """
        hud = "PASO DE AGUA BLOQUEADO"
        alert = ""
        gsap = f"""
        tl.from('#backedWater', {{ scaleY: 0, transformOrigin: 'bottom', duration: 1.0, ease: 'power2.out' }}, 0.1);
        tl.to('#blockMass', {{ scale: 1.1, yoyo: true, repeat: 3, duration: 0.4, ease: 'sine.inOut' }}, 0.2);
        """
        return svg, hud, alert, gsap

    # 10. TAPÓN ROSCADO DESMONTABLE
    elif tipo == "10_tapon_roscado":
        svg = """
        <g id="siphonTube">
          <path d="M 450 240 L 450 460 C 450 640 630 640 630 460 L 630 420 L 840 420" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 240 L 405 460 C 405 680 675 680 675 460 L 675 375 L 840 375" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 240 L 495 460 C 495 600 585 600 585 460 L 585 465 L 840 465" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="screwPlugGroup" filter="url(#neonGlowGreen)">
          <rect x="500" y="630" width="80" height="30" rx="6" fill="#0f172a" stroke="#22c55e" stroke-width="4" />
          <line x1="510" y1="640" x2="570" y2="640" stroke="#22c55e" stroke-width="3" stroke-dasharray="8 6" />
          <line x1="510" y1="648" x2="570" y2="648" stroke="#22c55e" stroke-width="3" stroke-dasharray="8 6" />
          <rect x="515" y="660" width="50" height="24" rx="4" fill="#15803d" stroke="#4ade80" stroke-width="3" />
        </g>
        <g id="spinArrow" filter="url(#neonGlowGreen)">
          <path d="M 450 680 C 490 720 590 720 630 680" fill="none" stroke="#22c55e" stroke-width="6" stroke-linecap="round" />
          <polygon points="630 680, 615 685, 625 700" fill="#22c55e" />
        </g>
        """
        hud = "TAPÓN ROSCADO DESMONTABLE"
        alert = ""
        gsap = f"""
        tl.from('#screwPlugGroup', {{ scale: 0.8, opacity: 0, duration: 0.6, ease: 'back.out(1.5)' }}, 0.1);
        tl.from('#spinArrow', {{ opacity: 0, rotation: -20, duration: 0.6, ease: 'power2.out' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # 11. LIMPIARLO EN SEGUNDOS
    elif tipo == "11_limpieza_segundos":
        svg = """
        <g id="siphonTube">
          <path d="M 450 240 L 450 460 C 450 640 630 640 630 460 L 630 420 L 840 420" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 240 L 405 460 C 405 680 675 680 675 460 L 675 375 L 840 375" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 240 L 495 460 C 495 600 585 600 585 460 L 585 465 L 840 465" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="flushingOut" filter="url(#neonGlowAmber)">
          <path d="M 540 630 L 540 850" stroke="url(#waterGrad)" stroke-width="40" stroke-linecap="round" stroke-dasharray="20 14" />
          <circle cx="530" cy="720" r="14" fill="#b45309" />
          <circle cx="550" cy="770" r="18" fill="#78350f" />
          <circle cx="535" cy="810" r="12" fill="#d97706" />
        </g>
        <g id="looseCap" filter="url(#neonGlowGreen)">
          <rect x="515" y="860" width="50" height="24" rx="4" fill="#15803d" stroke="#4ade80" stroke-width="3" />
        </g>
        """
        hud = "LIMPIEZA RÁPIDA SIN FONTANERO"
        alert = ""
        gsap = f"""
        tl.from('#flushingOut', {{ y: -80, opacity: 0, duration: 0.6, ease: 'power2.in' }}, 0.1);
        tl.to('#flushingOut', {{ strokeDashoffset: -250, duration: {d:.2f}, ease: 'none' }}, 0);
        """
        return svg, hud, alert, gsap

    # 12. GRIFO A TOPE Y CAUDAL ENORME
    elif tipo == "12_grifo_tope":
        svg = """
        <g id="sinkGroup" filter="url(#neonGlowCyan)">
          <path d="M 240 180 C 240 300 400 320 490 320 C 580 320 740 300 740 180 Z" fill="rgba(8, 24, 48, 0.85)" stroke="#00f0ff" stroke-width="5" />
          <ellipse cx="490" cy="180" rx="250" ry="30" fill="rgba(15, 30, 60, 0.9)" stroke="#00f0ff" stroke-width="4" />
          <rect id="hugeWaterStream" x="460" y="80" width="60" height="240" rx="8" fill="url(#waterGrad)" filter="url(#neonGlowCyan)" />
          <path d="M 490 145 L 490 60 C 490 20 570 20 570 55 L 570 85" fill="none" stroke="#38bdf8" stroke-width="18" stroke-linecap="round" />
        </g>
        <g id="siphonTube">
          <path d="M 450 310 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M 405 310 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 310 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        """
        hud = "CAUDAL MÁXIMO (100 L/min)"
        alert = ""
        gsap = f"""
        tl.from('#hugeWaterStream', {{ scaleY: 0, transformOrigin: 'top', duration: 0.5, ease: 'power3.in' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 13. CHUPA EL LÍQUIDO DEL SIFÓN (VACÍO / EFECTO PISTÓN)
    elif tipo == "13_succion_vacio":
        svg = """
        <g id="siphonTube">
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" />
          <path d="M 405 300 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path d="M 495 300 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <path id="suckedWater" d="M 500 560 C 530 645 630 645 690 440 L 840 440" fill="none" stroke="url(#waterGrad)" stroke-width="70" stroke-linecap="round" />
        </g>
        <g id="suctionArrows" filter="url(#neonGlowRed)">
          <path d="M 550 580 L 750 440" stroke="#ff2a6d" stroke-width="12" stroke-dasharray="16 10" stroke-linecap="round" />
          <polygon points="740 430, 770 440, 750 460" fill="#ff2a6d" />
        </g>
        """
        hud = "SUCCIÓN POR VACÍO (-15 kPa)"
        alert = ""
        gsap = f"""
        tl.to('#suckedWater', {{ x: 120, opacity: 0.2, duration: 1.4, ease: 'power2.in' }}, 0.2);
        tl.to('#suctionArrows path', {{ strokeDashoffset: -180, duration: {d:.2f}, ease: 'none' }}, 0);
        """
        return svg, hud, alert, gsap

    # 14. Y LO DEJA SECO
    elif tipo == "14_deja_seco":
        svg = """
        <g id="siphonTube">
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" />
          <path d="M 405 300 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#ff2a6d" stroke-width="5" filter="url(#neonGlowRed)" />
          <path d="M 495 300 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#ff2a6d" stroke-width="5" filter="url(#neonGlowRed)" />
        </g>
        <g id="emptyWarning" filter="url(#neonGlowRed)">
          <circle cx="540" cy="560" r="48" fill="rgba(239, 68, 68, 0.2)" stroke="#ff2a6d" stroke-width="4" />
          <text x="540" y="575" text-anchor="middle" fill="#ff2a6d" font-size="44" font-weight="900">0%</text>
        </g>
        """
        hud = "SIFÓN TOTALMENTE SECO"
        alert = ""
        gsap = f"""
        tl.from('#emptyWarning', {{ scale: 0.5, opacity: 0, duration: 0.5, ease: 'back.out(1.6)' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 15. ROMPIENDO EL SELLO Y CAMINO LIBRE AL OLOR
    elif tipo == "15_rompe_sello":
        svg = """
        <g id="siphonTube">
          <path d="M 450 300 L 450 480 C 450 680 630 680 630 480 L 630 440 L 840 440" fill="none" stroke="rgba(8, 28, 56, 0.9)" stroke-width="96" stroke-linecap="round" />
          <path d="M 405 300 L 405 480 C 405 725 675 725 675 480 L 675 395 L 840 395" fill="none" stroke="#ff2a6d" stroke-width="5" filter="url(#neonGlowRed)" />
          <path d="M 495 300 L 495 480 C 495 635 585 635 585 480 L 585 485 L 840 485" fill="none" stroke="#ff2a6d" stroke-width="5" filter="url(#neonGlowRed)" />
        </g>
        <g id="freeGasFlow" filter="url(#neonGlowRed)">
          <path id="invadingGas" d="M 830 440 L 630 440 C 630 680 450 680 450 480 L 450 280" fill="none" stroke="url(#gasGrad)" stroke-width="46" stroke-linecap="round" stroke-dasharray="24 16" />
        </g>
        """
        hud = "SELLO ROTO: VÍA LIBRE AL GAS"
        alert = ""
        gsap = f"""
        tl.to('#invadingGas', {{ strokeDashoffset: 400, duration: {d:.2f}, ease: 'none' }}, 0);
        """
        return svg, hud, alert, gsap

    # 16. VÁLVULA DE ADMISIÓN DE AIRE (AAV)
    elif tipo == "16_valvula_admision":
        svg = """
        <g id="siphonTube">
          <rect x="445" y="320" width="90" height="400" fill="rgba(8, 28, 56, 0.9)" />
          <rect x="445" y="320" width="90" height="400" fill="url(#pipeGrid)" />
          <line x1="445" y1="320" x2="445" y2="720" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <line x1="535" y1="320" x2="535" y2="720" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="aavValve" filter="url(#neonGlowGreen)">
          <path d="M 400 320 L 580 320 L 550 180 L 430 180 Z" fill="#0f172a" stroke="#22c55e" stroke-width="6" />
          <line x1="430" y1="220" x2="550" y2="220" stroke="#22c55e" stroke-width="4" />
          <line x1="435" y1="250" x2="545" y2="250" stroke="#22c55e" stroke-width="4" />
          <line x1="440" y1="280" x2="540" y2="280" stroke="#22c55e" stroke-width="4" />
          <rect id="aavMembrane" x="450" y="305" width="80" height="16" rx="4" fill="#4ade80" />
        </g>
        """
        hud = "VÁLVULA DE ADMISIÓN (AAV)"
        alert = ""
        gsap = f"""
        tl.from('#aavValve', {{ scale: 0.8, opacity: 0, duration: 0.6, ease: 'back.out(1.5)' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 17. DEJA ENTRAR OXÍGENO
    elif tipo == "17_entra_oxigeno":
        svg = """
        <g id="siphonTube">
          <rect x="445" y="320" width="90" height="400" fill="rgba(8, 28, 56, 0.9)" />
          <line x1="445" y1="320" x2="445" y2="720" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          <line x1="535" y1="320" x2="535" y2="720" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
        </g>
        <g id="aavValve" filter="url(#neonGlowCyan)">
          <path d="M 400 320 L 580 320 L 550 180 L 430 180 Z" fill="#0f172a" stroke="#00f0ff" stroke-width="6" />
          <rect id="aavMembraneOpen" x="455" y="335" width="70" height="16" rx="4" fill="#00f0ff" />
        </g>
        <g id="airFlowIn" filter="url(#neonGlowCyan)">
          <path d="M 490 80 L 490 170" stroke="#00f0ff" stroke-width="12" stroke-linecap="round" />
          <polygon points="475 160, 490 190, 505 160" fill="#00f0ff" />
          <path d="M 420 100 L 455 170" stroke="#00f0ff" stroke-width="8" stroke-linecap="round" />
          <path d="M 560 100 L 525 170" stroke="#00f0ff" stroke-width="8" stroke-linecap="round" />
        </g>
        """
        hud = "ENTRADA DE OXÍGENO EXTERNO"
        alert = ""
        gsap = f"""
        tl.from('#airFlowIn path, #airFlowIn polygon', {{ y: -30, opacity: 0, stagger: 0.1, duration: 0.4, ease: 'power2.out' }}, 0.1);
        tl.to('#aavMembraneOpen', {{ y: 8, yoyo: true, repeat: 3, duration: 0.3 }}, 0.2);
        """
        return svg, hud, alert, gsap

    # 18. EQUILIBRANDO LA PRESIÓN ATMOSFÉRICA
    elif tipo == "18_equilibra_presion":
        svg = """
        <g id="pressureGauge" filter="url(#neonGlowGreen)">
          <circle cx="490" cy="480" r="150" fill="#060a17" stroke="#22c55e" stroke-width="6" />
          <circle cx="490" cy="480" r="130" fill="rgba(34, 197, 94, 0.08)" />
          <line x1="490" y1="350" x2="490" y2="380" stroke="#22c55e" stroke-width="5" />
          <line x1="390" y1="410" x2="415" y2="425" stroke="#22c55e" stroke-width="4" />
          <line x1="590" y1="410" x2="565" y2="425" stroke="#22c55e" stroke-width="4" />
          <line id="gaugeNeedle" x1="490" y1="480" x2="490" y2="380" stroke="#ffffff" stroke-width="6" stroke-linecap="round" />
          <circle cx="490" cy="480" r="18" fill="#22c55e" />
          <text x="490" y="560" text-anchor="middle" fill="#22c55e" font-size="38" font-weight="900">1.0 ATM</text>
        </g>
        """
        hud = "PRESIÓN EQUILIBRADA (1 ATM)"
        alert = ""
        gsap = f"""
        tl.from('#gaugeNeedle', {{ rotation: -45, transformOrigin: '490px 480px', duration: 0.8, ease: 'elastic.out(1, 0.5)' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 19. TUBERÍA GENERAL DE LA CALLE
    elif tipo == "19_tuberia_general":
        svg = """
        <rect x="60" y="280" width="860" height="24" fill="#334155" stroke="#64748b" stroke-width="2" />
        <text x="490" y="265" text-anchor="middle" fill="#94a3b8" font-size="28" font-weight="800">NIVEL DE CALLE</text>
        <g id="streetCollector" filter="url(#neonGlowCyan)">
          <rect x="100" y="500" width="780" height="260" rx="20" fill="rgba(8, 28, 56, 0.9)" stroke="#00f0ff" stroke-width="6" />
          <rect x="100" y="500" width="780" height="260" rx="20" fill="url(#pipeGrid)" />
          <text x="490" y="640" text-anchor="middle" fill="#00f0ff" font-size="36" font-weight="900">COLECTOR GENERAL MUNICIPAL</text>
        </g>
        """
        hud = "RED GENERAL DE ALCANTARILLADO"
        alert = ""
        gsap = f"""
        tl.from('#streetCollector', {{ scale: 0.95, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0);
        """
        return svg, hud, alert, gsap

    # 20. TORMENTA BRUTAL SATURA LA RED
    elif tipo == "20_tormenta_satura":
        svg = """
        <g id="rainStreaks" filter="url(#neonGlowCyan)">
          <line x1="200" y1="80" x2="160" y2="240" stroke="#38bdf8" stroke-width="4" stroke-dasharray="16 12" />
          <line x1="380" y1="60" x2="340" y2="220" stroke="#38bdf8" stroke-width="4" stroke-dasharray="16 12" />
          <line x1="560" y1="90" x2="520" y2="250" stroke="#38bdf8" stroke-width="4" stroke-dasharray="16 12" />
          <line x1="740" y1="70" x2="700" y2="230" stroke="#38bdf8" stroke-width="4" stroke-dasharray="16 12" />
        </g>
        <g id="floodedCollector" filter="url(#neonGlowAmber)">
          <rect x="100" y="480" width="780" height="280" rx="20" fill="#1e1b4b" stroke="#f59e0b" stroke-width="6" />
          <rect id="floodWaterLevel" x="106" y="486" width="768" height="268" rx="16" fill="url(#gasGrad)" opacity="0.85" />
          <text x="490" y="630" text-anchor="middle" fill="#ffffff" font-size="44" font-weight="900">100% SATURADO</text>
        </g>
        """
        hud = "COLAPSO POR TORMENTA"
        alert = ""
        gsap = f"""
        tl.from('#floodWaterLevel', {{ scaleY: 0, transformOrigin: 'bottom', duration: 1.2, ease: 'power2.out' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 21. EL AGUA SUCIA EMPIEZA A RETROCEDER
    elif tipo == "21_agua_retrocede":
        svg = """
        <rect x="80" y="460" width="820" height="180" rx="14" fill="rgba(8, 28, 56, 0.9)" stroke="#ff2a6d" stroke-width="6" />
        <g id="reverseSurge" filter="url(#neonGlowRed)">
          <path d="M 850 480 L 320 480 L 320 620 L 850 620 Z" fill="url(#gasGrad)" />
          <path d="M 680 550 L 400 550" stroke="#ff2a6d" stroke-width="16" stroke-dasharray="24 16" stroke-linecap="round" />
          <polygon points="420 530, 380 550, 420 570" fill="#ff2a6d" />
        </g>
        """
        hud = "REFLUJO DE AGUA RESIDUAL"
        alert = ""
        gsap = f"""
        tl.from('#reverseSurge', {{ x: 200, opacity: 0, duration: 0.8, ease: 'power2.out' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 22. SE DESBORDA POR TU LAVABO
    elif tipo == "22_desborda_inunda":
        svg = """
        <g id="sinkOverflow" filter="url(#neonGlowRed)">
          <path d="M 240 280 C 240 400 400 420 490 420 C 580 420 740 400 740 280 Z" fill="rgba(38, 12, 24, 0.95)" stroke="#ff2a6d" stroke-width="6" />
          <ellipse cx="490" cy="280" rx="250" ry="32" fill="#7f1d1d" stroke="#ff2a6d" stroke-width="4" />
          <path id="spillLeft" d="M 240 280 Q 200 380 180 540" stroke="#ef4444" stroke-width="26" fill="none" stroke-linecap="round" />
          <path id="spillRight" d="M 740 280 Q 780 380 800 540" stroke="#ef4444" stroke-width="26" fill="none" stroke-linecap="round" />
          <rect x="120" y="740" width="740" height="40" rx="10" fill="#991b1b" filter="url(#neonGlowRed)" />
        </g>
        """
        hud = "INUNDACIÓN EN LA VIVIENDA"
        alert = ""
        gsap = f"""
        tl.from('#spillLeft, #spillRight', {{ scaleY: 0, transformOrigin: 'top', duration: 0.8, ease: 'power2.in' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 23. VÁLVULA ANTIRRETORNO CON COMPUERTA
    elif tipo == "23_valvula_antirretorno":
        svg = """
        <rect x="80" y="440" width="820" height="180" rx="14" fill="rgba(8, 28, 56, 0.9)" stroke="#00f0ff" stroke-width="6" />
        <rect x="80" y="440" width="820" height="180" rx="14" fill="url(#pipeGrid)" />
        <g id="checkValveBox" filter="url(#neonGlowGreen)">
          <rect x="360" y="380" width="200" height="300" rx="20" fill="#0f172a" stroke="#22c55e" stroke-width="6" />
          <circle cx="430" cy="440" r="18" fill="#334155" stroke="#22c55e" stroke-width="4" />
          <rect id="valveFlap" x="424" y="440" width="14" height="170" rx="4" fill="#22c55e" stroke="#4ade80" stroke-width="3" />
          <rect x="414" y="450" width="8" height="160" fill="#ef4444" />
        </g>
        """
        hud = "VÁLVULA ANTIRRETORNO"
        alert = ""
        gsap = f"""
        tl.from('#checkValveBox', {{ scale: 0.85, opacity: 0, duration: 0.6, ease: 'back.out(1.5)' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 24. SOLO SE ABRE HACIA AFUERA
    elif tipo == "24_abre_afuera":
        svg = """
        <rect x="80" y="440" width="820" height="180" rx="14" fill="rgba(8, 28, 56, 0.9)" stroke="#00f0ff" stroke-width="6" />
        <g id="checkValveBox" filter="url(#neonGlowGreen)">
          <rect x="360" y="380" width="200" height="300" rx="20" fill="#0f172a" stroke="#22c55e" stroke-width="6" />
          <circle cx="430" cy="440" r="18" fill="#334155" stroke="#22c55e" stroke-width="4" />
          <g transform="rotate(-40 430 440)">
            <rect x="424" y="440" width="14" height="170" rx="4" fill="#22c55e" stroke="#4ade80" stroke-width="3" />
          </g>
        </g>
        <g id="outwardFlow" filter="url(#neonGlowGreen)">
          <path d="M 120 530 L 800 530" stroke="url(#waterGrad)" stroke-width="56" stroke-linecap="round" stroke-dasharray="24 16" />
        </g>
        """
        hud = "DESAGÜE NORMAL → PERMITIDO"
        alert = ""
        gsap = f"""
        tl.to('#outwardFlow', {{ strokeDashoffset: -300, duration: {d:.2f}, ease: 'none' }}, 0);
        """
        return svg, hud, alert, gsap

    # 25. IMPIDIENDO QUE LO DE AFUERA ENTRE A TU CASA
    elif tipo == "25_impide_entrada":
        svg = """
        <rect x="80" y="440" width="820" height="180" rx="14" fill="rgba(8, 28, 56, 0.9)" stroke="#22c55e" stroke-width="6" filter="url(#neonGlowGreen)" />
        <g id="checkValveBox">
          <rect x="360" y="380" width="200" height="300" rx="20" fill="#0f172a" stroke="#22c55e" stroke-width="6" />
          <circle cx="430" cy="440" r="18" fill="#334155" stroke="#22c55e" stroke-width="4" />
          <rect id="lockedFlap" x="420" y="440" width="16" height="170" rx="4" fill="#22c55e" stroke="#4ade80" stroke-width="4" />
          <rect x="412" y="450" width="8" height="160" fill="#ef4444" />
        </g>
        <g id="blockedSurge" filter="url(#neonGlowRed)">
          <path d="M 850 470 L 440 470 L 440 590 L 850 590 Z" fill="url(#gasGrad)" />
          <line x1="438" y1="440" x2="438" y2="620" stroke="#ff2a6d" stroke-width="8" />
          <text x="580" y="540" text-anchor="middle" fill="#ffffff" font-size="30" font-weight="900">BLOQUEADO 100%</text>
        </g>
        """
        hud = "BLOQUEO TOTAL ANTIRRETORNO"
        alert = ""
        gsap = f"""
        tl.from('#lockedFlap', {{ x: 20, duration: 0.3, ease: 'bounce.out' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # 26. CIERRE Y CTA
    elif tipo == "26_cta_compartir":
        svg = """
        <g id="summaryGrid" filter="url(#neonGlowCyan)">
          <rect x="140" y="240" width="700" height="110" rx="16" fill="#0f172a" stroke="#00f0ff" stroke-width="3" />
          <circle cx="205" cy="295" r="30" fill="#22c55e" />
          <text x="205" y="306" text-anchor="middle" fill="#ffffff" font-size="32" font-weight="900">✓</text>
          <text x="270" y="306" fill="#ffffff" font-size="30" font-weight="800">1. SIFÓN EN 'U'</text>
          <text x="570" y="306" fill="#38bdf8" font-size="24" font-weight="700">BARRERA GASES</text>

          <rect x="140" y="390" width="700" height="110" rx="16" fill="#0f172a" stroke="#00f0ff" stroke-width="3" />
          <circle cx="205" cy="445" r="30" fill="#22c55e" />
          <text x="205" y="456" text-anchor="middle" fill="#ffffff" font-size="32" font-weight="900">✓</text>
          <text x="270" y="456" fill="#ffffff" font-size="30" font-weight="800">2. VÁLVULA AAV</text>
          <text x="570" y="456" fill="#38bdf8" font-size="24" font-weight="700">ANTI-SUCCIÓN</text>

          <rect x="140" y="540" width="700" height="110" rx="16" fill="#0f172a" stroke="#00f0ff" stroke-width="3" />
          <circle cx="205" cy="595" r="30" fill="#22c55e" />
          <text x="205" y="606" text-anchor="middle" fill="#ffffff" font-size="32" font-weight="900">✓</text>
          <text x="270" y="606" fill="#ffffff" font-size="30" font-weight="800">3. ANTIRRETORNO</text>
          <text x="570" y="606" fill="#38bdf8" font-size="24" font-weight="700">ANTI-INUNDACIÓN</text>
        </g>
        """
        hud = "SISTEMA HIDRÁULICO COMPLETO"
        alert = ""
        gsap = f"""
        tl.from('#summaryGrid rect, #summaryGrid circle', {{ scale: 0.9, opacity: 0, stagger: 0.2, duration: 0.5, ease: 'back.out(1.4)' }}, 0.1);
        """
        return svg, hud, alert, gsap

    # DEFAULT: DIAGRAMA TÉCNICO CYBERNETIC GENERAL

    # =========================================================================
    # ESCENAS RADAR / VELOCÍMETRO / GPS (@importacrew)
    # =========================================================================
    # R01. VELOCÍMETRO 120 vs GPS 115
    elif tipo == "radar_01_velocimetro_gps":
        svg = """
        <g id="speedoCluster">
          <circle cx="340" cy="500" r="230" fill="#080c18" stroke="#1e293b" stroke-width="14" />
          <circle cx="340" cy="500" r="216" fill="none" stroke="#334155" stroke-width="3" stroke-dasharray="8 6" />
          <circle cx="340" cy="500" r="180" fill="url(#pipeGrid)" opacity="0.3" />
          <g stroke="#94a3b8" stroke-width="4">
            <line x1="160" y1="580" x2="185" y2="568" />
            <line x1="140" y1="500" x2="170" y2="500" />
            <line x1="155" y1="420" x2="182" y2="432" />
            <line x1="190" y1="350" x2="212" y2="370" />
            <line x1="250" y1="305" x2="265" y2="330" />
            <line x1="320" y1="285" x2="325" y2="315" />
            <line x1="395" y1="290" x2="390" y2="320" stroke="#f97316" stroke-width="6" />
            <line x1="465" y1="320" x2="445" y2="345" />
            <line x1="515" y1="375" x2="490" y2="395" />
            <line x1="535" y1="445" x2="505" y2="455" />
          </g>
          <text x="195" y="580" fill="#64748b" font-size="20" font-weight="700">0</text>
          <text x="175" y="505" fill="#64748b" font-size="20" font-weight="700">20</text>
          <text x="190" y="435" fill="#64748b" font-size="20" font-weight="700">40</text>
          <text x="220" y="380" fill="#64748b" font-size="20" font-weight="700">60</text>
          <text x="270" y="345" fill="#94a3b8" font-size="22" font-weight="700">80</text>
          <text x="325" y="335" fill="#cbd5e1" font-size="24" font-weight="800">100</text>
          <text x="390" y="340" fill="#f97316" font-size="28" font-weight="900" filter="url(#neonGlowAmber)">120</text>
          <text x="445" y="365" fill="#cbd5e1" font-size="24" font-weight="800">140</text>
          <text x="480" y="415" fill="#94a3b8" font-size="22" font-weight="700">160</text>
          
          <rect x="250" y="570" width="180" height="75" rx="12" fill="#030712" stroke="#f97316" stroke-width="3" />
          <text x="340" y="622" text-anchor="middle" fill="#f97316" font-size="52" font-weight="900" letter-spacing="2">120</text>
          <text x="340" y="665" text-anchor="middle" fill="#94a3b8" font-size="18" font-weight="800" letter-spacing="3">KM/H CUADRO</text>
          
          <g id="speedoNeedle" transform="rotate(38 340 500)">
            <polygon points="334 500, 337 310, 343 310, 346 500" fill="#f97316" filter="url(#neonGlowAmber)" />
            <circle cx="340" cy="500" r="24" fill="#334155" stroke="#f97316" stroke-width="4" />
            <circle cx="340" cy="500" r="10" fill="#f8fafc" />
          </g>
        </g>
        
        <g id="phoneGps" transform="translate(630, 270)">
          <rect x="0" y="0" width="280" height="470" rx="32" fill="#0b1120" stroke="#38bdf8" stroke-width="5" />
          <rect x="14" y="14" width="252" height="442" rx="22" fill="#030712" />
          <path d="M 40 420 L 90 250 L 190 120 L 220 30" fill="none" stroke="#1e293b" stroke-width="26" stroke-linecap="round" />
          <path d="M 40 420 L 90 250 L 190 120 L 220 30" fill="none" stroke="#0284c7" stroke-width="12" stroke-linecap="round" />
          <g transform="translate(136, 185) rotate(-35)">
            <polygon points="0 -22, 16 16, 0 8, -16 16" fill="#22c55e" filter="url(#neonGlowGreen)" />
          </g>
          <rect x="26" y="300" width="228" height="135" rx="18" fill="rgba(8, 24, 48, 0.95)" stroke="#22c55e" stroke-width="4" filter="url(#neonGlowGreen)" />
          <text x="140" y="370" text-anchor="middle" fill="#22c55e" font-size="62" font-weight="900">115</text>
          <text x="140" y="405" text-anchor="middle" fill="#86efac" font-size="20" font-weight="800" letter-spacing="2">KM/H GPS REAL</text>
        </g>
        """
        hud = "VELOCÍMETRO 120 vs GPS 115"
        alert = "DISCREPANCIA REAL: 5 KM/H"
        gsap = f"""
        tl.from('#speedoCluster', {{ scale: 0.85, opacity: 0, duration: 0.7, ease: 'back.out(1.2)' }}, 0);
        tl.from('#phoneGps', {{ x: 80, opacity: 0, duration: 0.7, ease: 'power2.out' }}, 0.2);
        tl.from('#speedoNeedle', {{ rotation: -80, transformOrigin: '340px 500px', duration: 1.0, ease: 'elastic.out(1, 0.5)' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R02. PREGUNTA: ¿QUÉ VELOCIDAD CUENTA?
    elif tipo == "radar_02_pregunta_cuenta":
        svg = """
        <g id="radarQuestionGroup">
          <circle cx="490" cy="440" r="220" fill="none" stroke="#00f0ff" stroke-width="3" stroke-dasharray="14 10" />
          <circle cx="490" cy="440" r="140" fill="none" stroke="rgba(0, 240, 255, 0.4)" stroke-width="2" />
          <line x1="270" y1="440" x2="710" y2="440" stroke="rgba(0, 240, 255, 0.3)" stroke-width="2" />
          <line x1="490" y1="220" x2="490" y2="660" stroke="rgba(0, 240, 255, 0.3)" stroke-width="2" />
          <text id="qMark" x="490" y="515" text-anchor="middle" fill="#00f0ff" font-size="200" font-weight="900" filter="url(#neonGlowCyan)">?</text>
        </g>
        <g id="comparePills">
          <rect x="180" y="730" width="280" height="90" rx="16" fill="#1e293b" stroke="#f97316" stroke-width="4" />
          <text x="320" y="785" text-anchor="middle" fill="#f97316" font-size="32" font-weight="800">COCHE: 120</text>
          
          <rect x="520" y="730" width="280" height="90" rx="16" fill="#1e293b" stroke="#22c55e" stroke-width="4" />
          <text x="660" y="785" text-anchor="middle" fill="#22c55e" font-size="32" font-weight="800">GPS: 115</text>
        </g>
        """
        hud = "¿QUÉ VELOCIDAD CUENTA ANTE LA LEY?"
        alert = "¿120, 115 O NINGUNA?"
        gsap = f"""
        tl.from('#qMark', {{ scale: 0.2, opacity: 0, duration: 0.8, ease: 'elastic.out(1, 0.4)' }}, 0);
        tl.from('#comparePills rect, #comparePills text', {{ y: 40, opacity: 0, stagger: 0.15, duration: 0.6, ease: 'back.out(1.2)' }}, 0.3);
        tl.to('#radarQuestionGroup', {{ rotation: 360, transformOrigin: '490px 440px', duration: {d:.2f}, ease: 'none' }}, 0);
        """
        return svg, hud, alert, gsap

    # R03. EL RADAR NO MIRA TU COCHE
    elif tipo == "radar_03_no_mira_coche":
        svg = """
        <!-- Highway road -->
        <rect x="60" y="580" width="860" height="240" rx="16" fill="#0b1120" stroke="#334155" stroke-width="4" />
        <line x1="60" y1="700" x2="920" y2="700" stroke="#f8fafc" stroke-width="6" stroke-dasharray="35 25" />
        <rect x="60" y="560" width="860" height="20" rx="4" fill="#475569" stroke="#94a3b8" stroke-width="2" />
        
        <!-- Radar Cabin -->
        <g id="radarPost" transform="translate(740, 320)">
          <rect x="36" y="220" width="28" height="260" fill="#475569" stroke="#94a3b8" stroke-width="3" />
          <rect x="0" y="0" width="100" height="220" rx="18" fill="#1e293b" stroke="#94a3b8" stroke-width="4" />
          <rect x="10" y="160" width="80" height="16" fill="#facc15" />
          <circle id="radarLens" cx="50" cy="70" r="32" fill="#020617" stroke="#38bdf8" stroke-width="4" />
          <circle cx="50" cy="70" r="16" fill="#1e3a8a" />
          <rect x="25" y="120" width="50" height="14" rx="4" fill="#020617" stroke="#64748b" stroke-width="2" />
        </g>
        
        <!-- Red Car -->
        <g id="redCar" transform="translate(140, 570)">
          <ellipse cx="200" cy="85" rx="180" ry="16" fill="rgba(0,0,0,0.6)" />
          <path d="M 40 70 Q 70 30 140 25 L 240 25 Q 310 30 350 70 Q 370 75 365 85 L 25 85 Q 20 75 40 70 Z" fill="#dc2626" stroke="#ef4444" stroke-width="4" />
          <path d="M 120 30 L 150 65 L 230 65 L 250 30 Z" fill="#0f172a" stroke="#38bdf8" stroke-width="2" />
          <circle cx="95" cy="85" r="26" fill="#0f172a" stroke="#94a3b8" stroke-width="5" />
          <circle cx="95" cy="85" r="10" fill="#cbd5e1" />
          <circle cx="285" cy="85" r="26" fill="#0f172a" stroke="#94a3b8" stroke-width="5" />
          <circle cx="285" cy="85" r="10" fill="#cbd5e1" />
          <polygon points="350 72, 440 60, 440 90, 360 82" fill="rgba(255, 255, 255, 0.25)" />
        </g>
        
        <!-- Prohibition optical badge -->
        <g id="noOpticBadge" transform="translate(710, 220)">
          <circle cx="80" cy="80" r="45" fill="none" stroke="#ef4444" stroke-width="8" filter="url(#neonGlowRed)" />
          <line x1="50" y1="50" x2="110" y2="110" stroke="#ef4444" stroke-width="8" filter="url(#neonGlowRed)" />
          <text x="80" y="150" text-anchor="middle" fill="#ef4444" font-size="22" font-weight="900">NO ÓPTICO</text>
        </g>
        """
        hud = "CINEMÓMETRO DE CARRETERA"
        alert = "EL RADAR NO USA CÁMARA ÓPTICA"
        gsap = f"""
        tl.from('#redCar', {{ x: -180, duration: {d:.2f}, ease: 'none' }}, 0);
        tl.from('#radarPost', {{ y: -40, opacity: 0, duration: 0.6, ease: 'back.out(1.2)' }}, 0.1);
        tl.from('#noOpticBadge', {{ scale: 0, opacity: 0, duration: 0.5, ease: 'elastic.out(1, 0.4)' }}, 0.4);
        """
        return svg, hud, alert, gsap

    # R04. LE LANZA UNA ONDA QUE REBOTA Y VUELVE
    elif tipo == "radar_04_onda_rebota":
        svg = """
        <rect x="60" y="620" width="860" height="200" rx="16" fill="#0b1120" stroke="#334155" stroke-width="4" />
        <line x1="60" y1="720" x2="920" y2="720" stroke="#f8fafc" stroke-width="6" stroke-dasharray="35 25" />
        
        <!-- Radar Cabin Right -->
        <g id="radarPost" transform="translate(760, 380)">
          <rect x="36" y="200" width="28" height="240" fill="#475569" stroke="#94a3b8" stroke-width="3" />
          <rect x="0" y="0" width="100" height="200" rx="18" fill="#1e293b" stroke="#00f0ff" stroke-width="4" filter="url(#neonGlowCyan)" />
          <circle cx="50" cy="70" r="30" fill="#020617" stroke="#00f0ff" stroke-width="4" />
          <rect x="10" y="150" width="80" height="14" fill="#facc15" />
        </g>
        
        <!-- Car Front Left -->
        <g id="carFront" transform="translate(120, 580)">
          <path d="M 30 90 Q 60 40 160 35 L 280 35 Q 360 40 390 90 Z" fill="#dc2626" stroke="#ef4444" stroke-width="4" />
          <circle cx="100" cy="95" r="26" fill="#0f172a" stroke="#94a3b8" stroke-width="5" />
          <circle cx="310" cy="95" r="26" fill="#0f172a" stroke="#94a3b8" stroke-width="5" />
        </g>
        
        <!-- Forward waves (Cyan) -->
        <g id="fwdWaves" stroke="#00f0ff" stroke-width="6" fill="none" stroke-linecap="round" filter="url(#neonGlowCyan)">
          <path id="fw1" d="M 720 420 A 120 120 0 0 0 680 520" />
          <path id="fw2" d="M 660 390 A 180 180 0 0 0 600 550" />
          <path id="fw3" d="M 590 360 A 250 250 0 0 0 510 580" />
        </g>
        
        <!-- Return bounced waves (Amber) -->
        <g id="bncWaves" stroke="#ffb703" stroke-width="6" fill="none" stroke-linecap="round" stroke-dasharray="14 10" filter="url(#neonGlowAmber)">
          <path id="bw1" d="M 440 590 A 250 250 0 0 1 520 370" />
          <path id="bw2" d="M 520 560 A 180 180 0 0 1 580 400" />
          <path id="bw3" d="M 600 530 A 120 120 0 0 1 640 430" />
        </g>
        """
        hud = "EMISIÓN Y REBOTE DE MICROONDAS"
        alert = "ONDA ELECTROMAGNÉTICA GHz"
        gsap = f"""
        tl.from('#fwdWaves path', {{ opacity: 0, x: 80, stagger: 0.2, duration: 0.8, ease: 'power2.out' }}, 0);
        tl.from('#bncWaves path', {{ opacity: 0, x: -80, stagger: 0.2, duration: 0.8, ease: 'power2.out' }}, 0.6);
        tl.to('#fwdWaves path, #bncWaves path', {{ opacity: 0.5, yoyo: true, repeat: -1, duration: 0.4 }}, 1.2);
        """
        return svg, hud, alert, gsap

    # R05. CUANTO MÁS RÁPIDO VAS, MÁS APRETADA VUELVE
    elif tipo == "radar_05_doppler_apretada":
        svg = """
        <!-- Top Wave: Emitted (Normal spacing) -->
        <g id="waveNormal" transform="translate(100, 280)">
          <rect x="0" y="0" width="780" height="180" rx="16" fill="rgba(8, 24, 48, 0.85)" stroke="#38bdf8" stroke-width="3" />
          <text x="40" y="45" fill="#38bdf8" font-size="24" font-weight="800">ONDA EMITIDA (FRECUENCIA BASE)</text>
          <path id="sine1" d="M 40 110 Q 90 40 140 110 T 240 110 T 340 110 T 440 110 T 540 110 T 640 110 T 740 110" fill="none" stroke="#38bdf8" stroke-width="6" />
        </g>
        
        <!-- Bottom Wave: Bounced tight (Compressed frequency) -->
        <g id="waveTight" transform="translate(100, 520)">
          <rect x="0" y="0" width="780" height="200" rx="16" fill="rgba(8, 24, 48, 0.95)" stroke="#00f0ff" stroke-width="4" filter="url(#neonGlowCyan)" />
          <text x="40" y="45" fill="#00f0ff" font-size="24" font-weight="800">ONDA REBOTADA (FRECUENCIA COMPRIMIDA)</text>
          <path id="sine2" d="M 40 120 Q 65 70 90 120 T 140 120 T 190 120 T 240 120 T 290 120 T 340 120 T 390 120 T 440 120 T 490 120 T 540 120 T 590 120 T 640 120 T 690 120 T 740 120" fill="none" stroke="#00f0ff" stroke-width="6" filter="url(#neonGlowCyan)" />
          <text x="390" y="175" text-anchor="middle" fill="#facc15" font-size="22" font-weight="800">ONDAS MÁS APRETADAS = MAYOR VELOCIDAD</text>
        </g>
        """
        hud = "EFECTO DOPPLER FÍSICO"
        alert = "COMPRESIÓN DE CRESTAS DE ONDA"
        gsap = f"""
        tl.from('#waveNormal', {{ x: -60, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0);
        tl.from('#waveTight', {{ x: 60, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0.3);
        tl.from('#sine2', {{ scaleX: 1.5, transformOrigin: '0 120', duration: 1.0, ease: 'elastic.out(1, 0.4)' }}, 0.5);
        """
        return svg, hud, alert, gsap

    # R06. Y CON ESO SACA TU VELOCIDAD DE VERDAD
    elif tipo == "radar_06_velocidad_verdad":
        svg = """
        <g id="dspScreen">
          <rect x="140" y="240" width="700" height="520" rx="24" fill="#030712" stroke="#00f0ff" stroke-width="4" filter="url(#neonGlowCyan)" />
          <rect x="160" y="260" width="660" height="480" rx="16" fill="url(#pipeGrid)" opacity="0.3" />
          
          <!-- Processing Reticle -->
          <circle cx="490" cy="460" r="140" fill="none" stroke="#00f0ff" stroke-width="3" stroke-dasharray="16 10" />
          <circle cx="490" cy="460" r="80" fill="none" stroke="#22c55e" stroke-width="2" />
          <line x1="320" y1="460" x2="660" y2="460" stroke="#00f0ff" stroke-width="2" />
          <line x1="490" y1="290" x2="490" y2="630" stroke="#00f0ff" stroke-width="2" />
          
          <rect x="220" y="650" width="540" height="60" rx="12" fill="rgba(8, 24, 48, 0.9)" stroke="#22c55e" stroke-width="3" />
          <text x="490" y="690" text-anchor="middle" fill="#22c55e" font-size="28" font-weight="900" letter-spacing="2">CÁLCULO DOPPLER COMPLETADO</text>
        </g>
        """
        hud = "PROCESADOR DIGITAL DE SEÑAL"
        alert = "CALCULANDO VELOCIDAD REAL"
        gsap = f"""
        tl.from('#dspScreen', {{ scale: 0.9, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0);
        tl.to('#dspScreen circle:nth-child(3)', {{ rotation: 360, transformOrigin: '490px 460px', duration: {d:.2f}, ease: 'none' }}, 0);
        """
        return svg, hud, alert, gsap

    # R07. 115
    elif tipo == "radar_07_115_real":
        svg = """
        <g id="realBadge">
          <circle cx="490" cy="480" r="230" fill="rgba(8, 24, 48, 0.9)" stroke="#00f0ff" stroke-width="6" filter="url(#neonGlowCyan)" />
          <circle cx="490" cy="480" r="210" fill="none" stroke="#38bdf8" stroke-width="3" stroke-dasharray="16 12" />
          
          <text x="490" y="520" text-anchor="middle" fill="#00f0ff" font-size="180" font-weight="900" filter="url(#neonGlowCyan)">115</text>
          <text x="490" y="600" text-anchor="middle" fill="#ffffff" font-size="44" font-weight="800" letter-spacing="4">KM/H</text>
          <text x="490" y="645" text-anchor="middle" fill="#22c55e" font-size="24" font-weight="800" letter-spacing="2">VELOCIDAD FÍSICA REAL</text>
        </g>
        """
        hud = "VELOCIDAD VERDADERA DETECTADA"
        alert = "115 KM/H: VELOCIDAD FÍSICA"
        gsap = f"""
        tl.from('#realBadge', {{ scale: 2.2, opacity: 0, duration: 0.8, ease: 'elastic.out(1, 0.4)' }}, 0);
        """
        return svg, hud, alert, gsap

    # R08. TU COCHE MARCA DE MÁS A PROPÓSITO
    elif tipo == "radar_08_marca_de_mas":
        svg = """
        <g id="dualNeedleDial">
          <circle cx="490" cy="480" r="240" fill="#080c18" stroke="#1e293b" stroke-width="14" />
          <circle cx="490" cy="480" r="200" fill="url(#pipeGrid)" opacity="0.3" />
          
          <!-- Arc difference between 115 and 120 -->
          <path d="M 450 285 A 200 200 0 0 1 530 290" fill="none" stroke="#f97316" stroke-width="18" filter="url(#neonGlowAmber)" />
          
          <!-- Green Needle 115 (Real) -->
          <line x1="490" y1="480" x2="450" y2="285" stroke="#22c55e" stroke-width="6" stroke-linecap="round" filter="url(#neonGlowGreen)" />
          <text x="410" y="260" text-anchor="middle" fill="#22c55e" font-size="28" font-weight="900">115</text>
          
          <!-- Orange Needle 120 (Cuadro) -->
          <line x1="490" y1="480" x2="530" y2="290" stroke="#f97316" stroke-width="8" stroke-linecap="round" filter="url(#neonGlowAmber)" />
          <text x="575" y="265" text-anchor="middle" fill="#f97316" font-size="32" font-weight="900">120</text>
          
          <circle cx="490" cy="480" r="28" fill="#334155" stroke="#f97316" stroke-width="5" />
          
          <rect x="220" y="660" width="540" height="75" rx="16" fill="rgba(8, 24, 48, 0.95)" stroke="#f97316" stroke-width="4" />
          <text x="490" y="708" text-anchor="middle" fill="#f97316" font-size="30" font-weight="900">MARCA DE MÁS A PROPÓSITO</text>
        </g>
        """
        hud = "DESFASE INTENCIONAL DE FÁBRICA"
        alert = "CALIBRACIÓN CON ERROR POSITIVO"
        gsap = f"""
        tl.from('#dualNeedleDial', {{ scale: 0.8, opacity: 0, duration: 0.6, ease: 'back.out(1.2)' }}, 0);
        tl.from('#dualNeedleDial line:nth-child(4)', {{ rotation: -40, transformOrigin: '490px 480px', duration: 0.8, ease: 'elastic.out(1, 0.5)' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R09. LA LEY NO LE DEJA MARCAR NUNCA MENOS
    elif tipo == "radar_09_ley_nunca_menos":
        svg = """
        <g id="legalShield">
          <path d="M 490 220 L 680 280 L 680 500 C 680 620 580 700 490 740 C 400 700 300 620 300 500 L 300 280 Z" fill="rgba(8, 24, 48, 0.95)" stroke="#38bdf8" stroke-width="6" filter="url(#neonGlowCyan)" />
          
          <text x="490" y="340" text-anchor="middle" fill="#38bdf8" font-size="34" font-weight="900">NORMATIVA UNECE</text>
          <text x="490" y="380" text-anchor="middle" fill="#94a3b8" font-size="24" font-weight="700">REGLAMENTO R39</text>
          
          <rect x="340" y="430" width="300" height="90" rx="14" fill="#030712" stroke="#ef4444" stroke-width="4" />
          <text x="490" y="475" text-anchor="middle" fill="#ef4444" font-size="28" font-weight="900">PROHIBIDO</text>
          <text x="490" y="505" text-anchor="middle" fill="#fca5a5" font-size="20" font-weight="700">MARCAR MENOS</text>
          
          <line x1="330" y1="560" x2="650" y2="560" stroke="#38bdf8" stroke-width="3" />
          <text x="490" y="610" text-anchor="middle" fill="#ffffff" font-size="26" font-weight="800">V_cuadro &gt;= V_real</text>
        </g>
        """
        hud = "HOMOLOGACIÓN VEHICULAR OBLIGATORIA"
        alert = "PROHIBIDO POR LEY MARCAR MENOS"
        gsap = f"""
        tl.from('#legalShield', {{ y: -80, opacity: 0, duration: 0.7, ease: 'back.out(1.2)' }}, 0);
        """
        return svg, hud, alert, gsap

    # R10. PERO TAMPOCO CUENTA 115
    elif tipo == "radar_10_tampoco_115":
        svg = """
        <g id="warn115">
          <circle cx="490" cy="460" r="210" fill="rgba(8, 24, 48, 0.9)" stroke="#ffb703" stroke-width="6" filter="url(#neonGlowAmber)" />
          <text x="490" y="510" text-anchor="middle" fill="#64748b" font-size="160" font-weight="900">115</text>
          
          <!-- Big Red Slash -->
          <line x1="320" y1="320" x2="660" y2="600" stroke="#ef4444" stroke-width="16" stroke-linecap="round" filter="url(#neonGlowRed)" />
          
          <rect x="220" y="680" width="540" height="75" rx="16" fill="#1e293b" stroke="#ffb703" stroke-width="4" />
          <text x="490" y="728" text-anchor="middle" fill="#ffb703" font-size="28" font-weight="900">TAMPOCO CUENTA 115</text>
        </g>
        """
        hud = "REGLA DE TRÁFICO"
        alert = "115 KM/H NO ES LA CIFRA FINAL"
        gsap = f"""
        tl.from('#warn115', {{ scale: 0.8, opacity: 0, duration: 0.5, ease: 'back.out(1.2)' }}, 0);
        tl.from('#warn115 line', {{ scale: 0, transformOrigin: '490px 460px', duration: 0.5, ease: 'power2.out' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R11. A LO QUE MIDE EL RADAR LE QUITAN UN MARGEN
    elif tipo == "radar_11_margen_error":
        svg = """
        <g id="marginDeduct">
          <!-- Total measurement bar -->
          <rect x="160" y="360" width="460" height="120" rx="16" fill="rgba(8, 24, 48, 0.95)" stroke="#38bdf8" stroke-width="4" />
          <text x="390" y="430" text-anchor="middle" fill="#38bdf8" font-size="34" font-weight="900">RADAR: 115 km/h</text>
          
          <!-- Subtracted margin slice -->
          <g id="marginSlice" transform="translate(630, 360)">
            <rect x="0" y="0" width="180" height="120" rx="16" fill="#1e293b" stroke="#ef4444" stroke-width="4" filter="url(#neonGlowRed)" />
            <text x="90" y="55" text-anchor="middle" fill="#ef4444" font-size="32" font-weight="900">- MARGEN</text>
            <text x="90" y="90" text-anchor="middle" fill="#fca5a5" font-size="20" font-weight="700">DESCUENTO</text>
          </g>
          
          <rect x="180" y="560" width="620" height="80" rx="16" fill="#030712" stroke="#22c55e" stroke-width="3" />
          <text x="490" y="612" text-anchor="middle" fill="#22c55e" font-size="30" font-weight="900">RESTA OBLIGATORIA POR LEY</text>
        </g>
        """
        hud = "MARGEN DE ERROR METROLÓGICO"
        alert = "RESTA A FAVOR DEL CONDUCTOR"
        gsap = f"""
        tl.from('#marginDeduct', {{ scale: 0.9, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0);
        tl.to('#marginSlice', {{ x: 40, duration: 0.8, ease: 'power2.out' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R12. POR SI SE EQUIVOCA
    elif tipo == "radar_12_por_si_se_equivoca":
        svg = """
        <g id="errorShield">
          <circle cx="490" cy="460" r="220" fill="rgba(8, 24, 48, 0.9)" stroke="#22c55e" stroke-width="6" filter="url(#neonGlowGreen)" />
          
          <!-- Scale icon (Metrología / Justicia) -->
          <line x1="490" y1="300" x2="490" y2="520" stroke="#22c55e" stroke-width="8" stroke-linecap="round" />
          <line x1="360" y1="360" x2="620" y2="360" stroke="#22c55e" stroke-width="8" stroke-linecap="round" />
          
          <path d="M 360 360 L 320 440 L 400 440 Z" fill="#22c55e" opacity="0.8" />
          <path d="M 620 360 L 580 440 L 660 440 Z" fill="#22c55e" opacity="0.8" />
          
          <rect x="200" y="660" width="580" height="80" rx="16" fill="#030712" stroke="#22c55e" stroke-width="3" />
          <text x="490" y="712" text-anchor="middle" fill="#22c55e" font-size="28" font-weight="900">BENEFICIO DE LA DUDA TÉCNICA</text>
        </g>
        """
        hud = "METROLOGÍA DE TRÁFICO"
        alert = "POR SI EL CINEMÓMETRO TIENE ERROR"
        gsap = f"""
        tl.from('#errorShield', {{ scale: 0.7, opacity: 0, duration: 0.7, ease: 'back.out(1.2)' }}, 0);
        """
        return svg, hud, alert, gsap

    # R13. EN UN RADAR FIJO UN 5%
    elif tipo == "radar_13_cinco_porciento":
        svg = """
        <g id="fivePercentGroup">
          <circle cx="490" cy="380" r="160" fill="rgba(8, 24, 48, 0.95)" stroke="#00f0ff" stroke-width="6" filter="url(#neonGlowCyan)" />
          <text x="490" y="425" text-anchor="middle" fill="#00f0ff" font-size="130" font-weight="900" filter="url(#neonGlowCyan)">5%</text>
          
          <!-- Comparison cards: Fijo vs Móvil -->
          <g transform="translate(140, 580)">
            <rect x="0" y="0" width="330" height="150" rx="18" fill="#1e293b" stroke="#00f0ff" stroke-width="4" filter="url(#neonGlowCyan)" />
            <text x="165" y="55" text-anchor="middle" fill="#00f0ff" font-size="30" font-weight="900">RADAR FIJO</text>
            <text x="165" y="110" text-anchor="middle" fill="#f8fafc" font-size="44" font-weight="900">-5%</text>
          </g>
          
          <g transform="translate(510, 580)">
            <rect x="0" y="0" width="330" height="150" rx="18" fill="#0f172a" stroke="#64748b" stroke-width="3" />
            <text x="165" y="55" text-anchor="middle" fill="#94a3b8" font-size="30" font-weight="800">RADAR MÓVIL</text>
            <text x="165" y="110" text-anchor="middle" fill="#cbd5e1" font-size="44" font-weight="900">-7%</text>
          </g>
        </g>
        """
        hud = "ORDEN MINISTERIAL DE METROLOGÍA"
        alert = "RADAR FIJO: 5% DE MARGEN"
        gsap = f"""
        tl.from('#fivePercentGroup circle, #fivePercentGroup text:nth-child(2)', {{ scale: 0.5, opacity: 0, duration: 0.7, ease: 'elastic.out(1, 0.4)' }}, 0);
        tl.from('#fivePercentGroup g', {{ y: 40, opacity: 0, stagger: 0.2, duration: 0.6, ease: 'power2.out' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R14. TU 115 SE QUEDAN EN UNOS 109
    elif tipo == "radar_14_quedan_109":
        svg = """
        <g id="result109Group">
          <!-- Calculation box -->
          <rect x="180" y="260" width="620" height="240" rx="22" fill="rgba(8, 24, 48, 0.95)" stroke="#38bdf8" stroke-width="4" />
          <text x="490" y="330" text-anchor="middle" fill="#94a3b8" font-size="30" font-weight="700">115 km/h  -  5%  (5.75 km/h)</text>
          <text x="490" y="440" text-anchor="middle" fill="#22c55e" font-size="100" font-weight="900" filter="url(#neonGlowGreen)">109 km/h</text>
          
          <!-- Slider bar 90 to 120 -->
          <g transform="translate(140, 560)">
            <rect x="0" y="30" width="700" height="24" rx="12" fill="#1e293b" />
            <!-- Filled portion up to 109 -->
            <rect id="sliderFill" x="0" y="30" width="440" height="24" rx="12" fill="#22c55e" filter="url(#neonGlowGreen)" />
            <!-- Capsule marker at 109 -->
            <circle cx="440" cy="42" r="22" fill="#ffffff" stroke="#22c55e" stroke-width="6" />
            
            <text x="0" y="90" fill="#64748b" font-size="24" font-weight="700">90</text>
            <text x="233" y="90" fill="#64748b" font-size="24" font-weight="700">100</text>
            <text x="440" y="90" text-anchor="middle" fill="#22c55e" font-size="30" font-weight="900">109</text>
            <text x="700" y="90" text-anchor="end" fill="#ef4444" font-size="24" font-weight="700">120 (LÍMITE)</text>
          </g>
        </g>
        """
        hud = "VELOCIDAD JURÍDICA CALCULADA"
        alert = "TUS 115 SE QUEDAN EN 109 KM/H"
        gsap = f"""
        tl.from('#result109Group rect:first-child', {{ scale: 0.9, opacity: 0, duration: 0.6, ease: 'power2.out' }}, 0);
        tl.from('#sliderFill', {{ width: 0, duration: 0.8, ease: 'power2.out' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R15. EN UNA AUTOVÍA, UN RADAR FIJO NO TE MULTA
    elif tipo == "radar_15_no_multa_hasta":
        svg = """
        <g id="autoviaSafe">
          <!-- Road Sign 120 -->
          <circle cx="340" cy="440" r="160" fill="#f8fafc" stroke="#dc2626" stroke-width="32" />
          <text x="340" y="490" text-anchor="middle" fill="#0f172a" font-size="120" font-weight="900">120</text>
          
          <!-- Safe badge right -->
          <g transform="translate(560, 360)">
            <rect x="0" y="0" width="300" height="160" rx="20" fill="rgba(8, 24, 48, 0.95)" stroke="#22c55e" stroke-width="4" filter="url(#neonGlowGreen)" />
            <text x="150" y="65" text-anchor="middle" fill="#22c55e" font-size="32" font-weight="900">SIN MULTA</text>
            <text x="150" y="115" text-anchor="middle" fill="#86efac" font-size="22" font-weight="700">ZONA SEGURA</text>
          </g>
          
          <rect x="180" y="660" width="620" height="80" rx="16" fill="#030712" stroke="#38bdf8" stroke-width="3" />
          <text x="490" y="712" text-anchor="middle" fill="#38bdf8" font-size="28" font-weight="800">LÍMITE MÁXIMO AUTOVÍA: 120 KM/H</text>
        </g>
        """
        hud = "LÍMITE LEGAL EN AUTOVÍA"
        alert = "RADAR FIJO NO MULTA POR DEBAJO"
        gsap = f"""
        tl.from('#autoviaSafe', {{ scale: 0.85, opacity: 0, duration: 0.7, ease: 'back.out(1.2)' }}, 0);
        """
        return svg, hud, alert, gsap

    # R16. HASTA PASAR DE 126, CON TU COCHE MARCANDO MÁS DE 130
    elif tipo == "radar_16_multa_126_130":
        svg = """
        <!-- Flash bloom overlay -->
        <rect id="flashBloom" x="0" y="0" width="980" height="1100" fill="#ffffff" opacity="0" pointer-events="none" />
        
        <!-- Radar Polaroid Snapshot Card -->
        <g id="snapshotCard" transform="translate(180, 240) rotate(-3)">
          <rect x="0" y="0" width="620" height="480" rx="14" fill="#f8fafc" stroke="#cbd5e1" stroke-width="4" filter="url(#neonGlowRed)" />
          
          <!-- Inner photo mockup -->
          <rect x="20" y="20" width="580" height="340" rx="8" fill="#0f172a" />
          <rect x="20" y="280" width="580" height="80" fill="rgba(0, 0, 0, 0.85)" />
          <text x="40" y="325" fill="#facc15" font-size="20" font-weight="800">RADAR FIJO | LÍMITE 120</text>
          <text x="580" y="335" text-anchor="end" fill="#ef4444" font-size="44" font-weight="900">126 km/h</text>
          
          <!-- Flash Icon -->
          <circle cx="500" cy="140" r="60" fill="rgba(255, 255, 255, 0.8)" filter="url(#neonGlowCyan)" />
          
          <!-- Card text bottom -->
          <text x="310" y="420" text-anchor="middle" fill="#0f172a" font-size="28" font-weight="900">DISPARO EFECTIVO A 126 KM/H</text>
          <text x="310" y="455" text-anchor="middle" fill="#dc2626" font-size="22" font-weight="800">TU COCHE MARCARÁ &gt;130 KM/H</text>
        </g>
        
        <rect x="180" y="760" width="620" height="80" rx="16" fill="#1e293b" stroke="#ef4444" stroke-width="4" />
        <text x="490" y="812" text-anchor="middle" fill="#ef4444" font-size="30" font-weight="900">UMBRAL REAL DE SANCIÓN</text>
        """
        hud = "DISPARO REAL DEL CINEMÓMETRO"
        alert = "MULTA: 126 REAL = 133 EN CUADRO"
        gsap = f"""
        tl.to('#flashBloom', {{ opacity: 0.9, duration: 0.1, yoyo: true, repeat: 1 }}, 0.1);
        tl.from('#snapshotCard', {{ scale: 0.7, y: 50, opacity: 0, duration: 0.6, ease: 'back.out(1.4)' }}, 0.2);
        """
        return svg, hud, alert, gsap

    # R17. ASÍ QUE LA QUE CUENTA ES LA MÁS BAJA DE LAS 3
    elif tipo == "radar_17_mas_baja_tres":
        svg = """
        <g id="threeSpeedsGroup">
          <!-- 1. Cuadro (Orange) -->
          <g transform="translate(140, 260)">
            <rect x="0" y="0" width="700" height="110" rx="16" fill="#1e293b" stroke="#f97316" stroke-width="4" />
            <text x="40" y="65" fill="#f97316" font-size="30" font-weight="900">1. VELOCÍMETRO CUADRO</text>
            <text x="660" y="70" text-anchor="end" fill="#f97316" font-size="44" font-weight="900">&gt;130</text>
          </g>
          
          <!-- 2. GPS (Blue) -->
          <g transform="translate(140, 400)">
            <rect x="0" y="0" width="700" height="110" rx="16" fill="#0f172a" stroke="#38bdf8" stroke-width="4" />
            <text x="40" y="65" fill="#38bdf8" font-size="30" font-weight="900">2. GPS REALIDAD FÍSICA</text>
            <text x="660" y="70" text-anchor="end" fill="#38bdf8" font-size="44" font-weight="900">126</text>
          </g>
          
          <!-- 3. Radar Legal (Green - Winner) -->
          <g id="winnerRadar" transform="translate(140, 540)">
            <rect x="0" y="0" width="700" height="120" rx="18" fill="rgba(8, 24, 48, 0.95)" stroke="#22c55e" stroke-width="6" filter="url(#neonGlowGreen)" />
            <text x="40" y="70" fill="#22c55e" font-size="32" font-weight="900">3. RADAR CON DESCUENTO</text>
            <text x="660" y="75" text-anchor="end" fill="#22c55e" font-size="48" font-weight="900">120</text>
          </g>
          
          <rect x="200" y="700" width="580" height="75" rx="16" fill="#030712" stroke="#22c55e" stroke-width="3" />
          <text x="490" y="748" text-anchor="middle" fill="#22c55e" font-size="28" font-weight="900">LA QUE CUENTA ES LA MÁS BAJA</text>
        </g>
        """
        hud = "TRIPLE COMPARATIVA DE VELOCIDAD"
        alert = "LA CIFRA JURÍDICA MÁS FAVORABLE"
        gsap = f"""
        tl.from('#threeSpeedsGroup g:nth-child(1)', {{ x: -60, opacity: 0, duration: 0.5 }}, 0);
        tl.from('#threeSpeedsGroup g:nth-child(2)', {{ x: -60, opacity: 0, duration: 0.5 }}, 0.2);
        tl.from('#winnerRadar', {{ scale: 0.9, opacity: 0, duration: 0.7, ease: 'back.out(1.3)' }}, 0.4);
        """
        return svg, hud, alert, gsap

    # R18. LA DEL RADAR CON SU DESCUENTO
    elif tipo == "radar_18_radar_descuento":
        svg = """
        <g id="discountVictory">
          <circle cx="490" cy="460" r="220" fill="rgba(8, 24, 48, 0.95)" stroke="#22c55e" stroke-width="6" filter="url(#neonGlowGreen)" />
          
          <!-- Animated Checkmark -->
          <path id="checkVector" d="M 390 460 L 460 530 L 610 380" fill="none" stroke="#22c55e" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" filter="url(#neonGlowGreen)" />
          
          <rect x="180" y="660" width="620" height="80" rx="16" fill="#030712" stroke="#22c55e" stroke-width="3" />
          <text x="490" y="712" text-anchor="middle" fill="#22c55e" font-size="30" font-weight="900">LA DEL RADAR CON SU DESCUENTO</text>
        </g>
        """
        hud = "VEREDICTO FINAL DE TRÁFICO"
        alert = "VELOCIDAD LEGAL CON DESCUENTO"
        gsap = f"""
        tl.from('#discountVictory circle', {{ scale: 0.7, opacity: 0, duration: 0.6, ease: 'back.out(1.2)' }}, 0);
        tl.from('#checkVector', {{ strokeDasharray: 400, strokeDashoffset: 400, duration: 0.8, ease: 'power2.out' }}, 0.3);
        """
        return svg, hud, alert, gsap

    # R19. ÚNETE A LA COMUNIDAD DE IMPORTA CREW
    elif tipo == "radar_19_cta":
        svg = """
        <g id="ctaImporta">
          <rect x="160" y="280" width="660" height="460" rx="28" fill="rgba(8, 24, 48, 0.95)" stroke="#00f0ff" stroke-width="5" filter="url(#neonGlowCyan)" />
          
          <circle cx="490" cy="410" r="70" fill="#1e293b" stroke="#00f0ff" stroke-width="4" />
          <polygon points="480 380, 520 410, 480 440" fill="#00f0ff" />
          
          <text x="490" y="540" text-anchor="middle" fill="#ffffff" font-size="44" font-weight="900" letter-spacing="2">IMPORTA CREW</text>
          <text x="490" y="585" text-anchor="middle" fill="#94a3b8" font-size="24" font-weight="700">CURIOSIDADES DEL MOTOR</text>
          
          <rect x="240" y="630" width="500" height="70" rx="16" fill="#00f0ff" />
          <text x="490" y="675" text-anchor="middle" fill="#030712" font-size="28" font-weight="900" letter-spacing="2">ÚNETE A LA COMUNIDAD</text>
        </g>
        """
        hud = "COMUNIDAD DEL MOTOR"
        alert = "SÍGUENOS PARA MÁS CURIOSIDADES"
        gsap = f"""
        tl.from('#ctaImporta', {{ scale: 0.8, opacity: 0, duration: 0.7, ease: 'elastic.out(1, 0.4)' }}, 0);
        """
        return svg, hud, alert, gsap

    else:
        svg = f"""
        <g id="genericCyber" filter="url(#neonGlowCyan)">
          <rect x="160" y="300" width="660" height="420" rx="20" fill="rgba(8, 28, 56, 0.9)" stroke="#00f0ff" stroke-width="5" />
          <rect x="160" y="300" width="660" height="420" rx="20" fill="url(#pipeGrid)" />
          <circle cx="490" cy="510" r="110" fill="none" stroke="#00f0ff" stroke-width="4" stroke-dasharray="14 10" />
          <line x1="260" y1="510" x2="720" y2="510" stroke="#00f0ff" stroke-width="4" />
          <line x1="490" y1="340" x2="490" y2="680" stroke="#00f0ff" stroke-width="4" />
          <circle cx="490" cy="510" r="30" fill="#00f0ff" />
        </g>
        """
        hud = "ANÁLISIS DE INGENIERÍA"
        alert = ""
        gsap = f"""
        tl.from('#genericCyber', {{ scale: 0.9, opacity: 0, duration: 0.6, ease: 'back.out(1.2)' }}, 0);
        """
        return svg, hud, alert, gsap


def _generar_subtitulos_kinetic_html_y_js(palabras_spec: list, narracion: str, dur: float) -> tuple[str, str]:
    """
    Construye subtítulos cinéticos chunked (2 a 4 palabras por bloque en pantalla)
    con caja selectora y anclas al estilo exacto de @nuncateloexplicaron.
    Garantiza 0 advertencias de linter haciendo pre-medición sincrónica fija.
    """
    dur = max(1.0, float(dur))
    
    words = []
    if palabras_spec and isinstance(palabras_spec, list) and len(palabras_spec) > 0:
        for p in palabras_spec:
            w_text = _limpiar_texto(p.get("w") or p.get("word") or "").strip()
            if w_text:
                st = max(0.0, float(p.get("start", 0.0)))
                en = max(st + 0.1, float(p.get("end", st + 0.3)))
                words.append({"text": w_text, "start": st, "end": en})
    
    if not words and narracion:
        raw_tokens = narracion.strip().split()
        if raw_tokens:
            step = dur / len(raw_tokens)
            for idx, token in enumerate(raw_tokens):
                words.append({
                    "text": _limpiar_texto(token),
                    "start": round(idx * step, 2),
                    "end": round((idx + 1) * step, 2)
                })

    if not words:
        words = [{"text": "SISTEMA", "start": 0.0, "end": dur}]

    # Agrupar en chunks de 2 a 4 palabras para mantener 1 sola línea centrada en pantalla
    chunks = []
    curr = []
    for w in words:
        curr.append(w)
        if len(curr) >= 3 or (len(curr) >= 2 and any(w["text"].endswith(p) for p in (',', '.', ':', ';', '!', '?'))):
            chunks.append(curr)
            curr = []
    if curr:
        chunks.append(curr)

    # Generar HTML de los chunks
    chunks_html = []
    for c_idx, c_words in enumerate(chunks):
        words_html = []
        for w_idx, w in enumerate(c_words):
            words_html.append(f'<span class="sub-word" id="sw_{c_idx}_{w_idx}">{w["text"]}</span>')
        display_style = "inline-block" if c_idx == 0 else "none"
        chunks_html.append(f'<div class="sub-chunk" id="chunk_{c_idx}" style="display: {display_style};">{" ".join(words_html)}</div>')

    html_sub = f"""
    <div class="subtitles-wrapper" data-layout-allow-safe-zone>
      <div class="subtitles-text" id="subtitlesText">
        {''.join(chunks_html)}
        <div class="sub-box" id="subBox">
          <div class="handle tl"></div>
          <div class="handle br"></div>
        </div>
      </div>
    </div>
    """

    # JS GSAP: Medir determinísticamente antes de registrar el timeline
    js_sub = f"""
      const subContainer = document.getElementById('subtitlesText');
      const allChunks = document.querySelectorAll('.sub-chunk');
      const wordBoxes = [];

      allChunks.forEach((chk, cIdx) => {{
        chk.style.display = 'inline-block';
        chk.style.visibility = 'hidden';
        const cRect = subContainer.getBoundingClientRect();
        const spans = chk.querySelectorAll('.sub-word');
        wordBoxes[cIdx] = [];
        spans.forEach(sp => {{
          const r = sp.getBoundingClientRect();
          wordBoxes[cIdx].push({{
            x: (r.left - cRect.left - 6),
            y: (r.top - cRect.top - 4),
            w: (r.width + 12),
            h: (r.height + 8)
          }});
        }});
        chk.style.display = 'none';
        chk.style.visibility = 'visible';
      }});

      if (allChunks[0]) {{
        allChunks[0].style.display = 'inline-block';
      }}

      if (wordBoxes[0] && wordBoxes[0][0]) {{
        gsap.set("#subBox", {{
          left: wordBoxes[0][0].x,
          top: wordBoxes[0][0].y,
          width: wordBoxes[0][0].w,
          height: wordBoxes[0][0].h,
          opacity: 1
        }});
      }}
    """

    # Añadir eventos al timeline para mostrar cada chunk y mover la caja
    for c_idx, c_words in enumerate(chunks):
        c_start = c_words[0]["start"]
        if c_idx > 0:
            js_sub += f"""
      tl.set(".sub-chunk", {{ display: "none" }}, {c_start:.2f});
      tl.set("#chunk_{c_idx}", {{ display: "inline-block" }}, {c_start:.2f});
      if (wordBoxes[{c_idx}] && wordBoxes[{c_idx}][0]) {{
        tl.set("#subBox", {{
          left: wordBoxes[{c_idx}][0].x,
          top: wordBoxes[{c_idx}][0].y,
          width: wordBoxes[{c_idx}][0].w,
          height: wordBoxes[{c_idx}][0].h
        }}, {c_start:.2f});
      }}
            """
        for w_idx in range(1, len(c_words)):
            w_time = min(dur - 0.1, c_words[w_idx]["start"])
            js_sub += f"""
      if (wordBoxes[{c_idx}] && wordBoxes[{c_idx}][{w_idx}]) {{
        tl.to("#subBox", {{
          left: wordBoxes[{c_idx}][{w_idx}].x,
          top: wordBoxes[{c_idx}][{w_idx}].y,
          width: wordBoxes[{c_idx}][{w_idx}].w,
          height: wordBoxes[{c_idx}][{w_idx}].h,
          duration: 0.18,
          ease: "power2.out"
        }}, {w_time:.2f});
      }}
            """

    return html_sub, js_sub


def construir_html_escena(spec: dict, duration: float) -> str:
    """Construye el documento HTML5 cinemático estilo @nuncateloexplicaron con GSAP."""
    dur = max(1.0, float(duration))
    orden = int(spec.get("orden") or 1)
    narr = str(spec.get("narracion") or spec.get("frase") or "")
    palabras = spec.get("palabras") or []

    tipo = _clasificar_escena(narr, orden)
    svg_body, hud_text, alert_text, gsap_scene = _obtener_contenido_escena(tipo, dur)
    sub_html, sub_js = _generar_subtitulos_kinetic_html_y_js(palabras, narr, dur)

    alert_html = ""
    if alert_text:
        alert_html = f"""
        <div class="alert-pill" id="alertPill">
          <span>{alert_text}</span>
        </div>
        """

    html = f"""<!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1080, height=1920" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;700;800;900&amp;display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.15.0/dist/gsap.min.js"></script>
    <style>
      :root {{
        --bg-color: #060913;
        --neon-cyan: #00f0ff;
        --neon-green: #22c55e;
        --neon-red: #ff2a6d;
        --neon-amber: #ffb703;
        --font-main: 'Montserrat', system-ui, -apple-system, sans-serif;
      }}
      * {{ margin: 0; padding: 0; box-sizing: border-box; }}
      html, body {{
        width: 1080px;
        height: 1920px;
        overflow: hidden;
        background: var(--bg-color);
        font-family: var(--font-main);
      }}
      #root {{
        width: 1080px;
        height: 1920px;
        position: relative;
        overflow: hidden;
        background: radial-gradient(circle at 50% 38%, #0e1d3d 0%, #060b19 60%, #03060f 100%);
      }}

      /* 3D Perspective Ground Floor Grid */
      .floor-container {{
        position: absolute;
        bottom: 0;
        left: -20%;
        width: 140%;
        height: 520px;
        perspective: 550px;
        pointer-events: none;
      }}
      .floor-mesh {{
        width: 100%;
        height: 100%;
        transform: rotateX(72deg);
        transform-origin: bottom center;
        background-size: 70px 70px;
        background-image:
          linear-gradient(to right, rgba(0, 240, 255, 0.20) 1.5px, transparent 1.5px),
          linear-gradient(to bottom, rgba(0, 240, 255, 0.20) 1.5px, transparent 1.5px);
        mask-image: linear-gradient(to top, rgba(0,0,0,1) 20%, rgba(0,0,0,0) 90%);
        -webkit-mask-image: linear-gradient(to top, rgba(0,0,0,1) 20%, rgba(0,0,0,0) 90%);
      }}
      .horizon-glow {{
        position: absolute;
        bottom: 340px;
        left: 0;
        width: 100%;
        height: 2px;
        background: rgba(0, 240, 255, 0.6);
        box-shadow: 0 0 16px rgba(0, 240, 255, 0.8), 0 0 35px rgba(0, 240, 255, 0.4);
      }}
      .road-lines {{
        position: absolute;
        bottom: 300px;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-around;
        padding: 0 50px;
      }}
      .road-dash {{
        width: 140px;
        height: 7px;
        background: rgba(255, 255, 255, 0.65);
        border-radius: 4px;
        box-shadow: 0 0 12px rgba(255, 255, 255, 0.4);
      }}

      /* Subtítulos Cinéticos Chunked @nuncateloexplicaron */
      .subtitles-wrapper {{
        position: absolute;
        top: 140px;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 100;
        padding: 0 60px;
        height: 120px;
      }}
      .subtitles-text {{
        position: relative;
        font-size: 54px;
        font-weight: 800;
        color: #ffffff;
        text-align: center;
        line-height: 1.25;
        letter-spacing: -0.01em;
        display: inline-block;
      }}
      .sub-chunk {{
        white-space: nowrap;
      }}
      .sub-word {{
        position: relative;
        display: inline-block;
        padding: 2px 10px;
        z-index: 2;
      }}
      .sub-box {{
        position: absolute;
        border: 3px solid var(--neon-cyan);
        background: rgba(0, 240, 255, 0.15);
        border-radius: 8px;
        box-shadow: 0 0 18px rgba(0, 240, 255, 0.6), inset 0 0 10px rgba(0, 240, 255, 0.2);
        z-index: 1;
        pointer-events: none;
        box-sizing: border-box;
      }}
      .sub-box .handle {{
        position: absolute;
        width: 12px;
        height: 12px;
        background: #ffffff;
        border: 2.5px solid var(--neon-cyan);
        border-radius: 50%;
        box-shadow: 0 0 8px var(--neon-cyan);
      }}
      .sub-box .handle.tl {{ top: -6px; left: -6px; }}
      .sub-box .handle.br {{ bottom: -6px; right: -6px; }}

      /* HUD Metric Pill */
      .hud-pill {{
        position: absolute;
        top: 290px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 34px;
        background: rgba(10, 22, 42, 0.92);
        border: 2px solid var(--neon-cyan);
        border-radius: 9999px;
        box-shadow: 0 0 25px rgba(0, 240, 255, 0.45);
        backdrop-filter: blur(12px);
        z-index: 50;
      }}
      .hud-pill .pill-dot {{
        width: 14px;
        height: 14px;
        background: var(--neon-cyan);
        border-radius: 50%;
        box-shadow: 0 0 12px var(--neon-cyan);
      }}
      .hud-pill .pill-text {{
        font-size: 28px;
        font-weight: 800;
        color: #ffffff;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }}

      /* Main Stage / Blueprint Canvas */
      .stage {{
        position: absolute;
        top: 420px;
        left: 50%;
        transform: translateX(-50%);
        width: 980px;
        height: 1140px;
        z-index: 10;
      }}
    </style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="{dur:.2f}" data-width="1080" data-height="1920">
      
      <!-- 3D Ground Floor -->
      <div class="floor-container">
        <div class="floor-mesh"></div>
      </div>
      <div class="horizon-glow"></div>
      <div class="road-lines">
        <div class="road-dash"></div>
        <div class="road-dash"></div>
        <div class="road-dash"></div>
        <div class="road-dash"></div>
      </div>

      <!-- Kinetic Subtitles -->
      {sub_html}

      <!-- HUD Metrics Pill -->
      <div class="hud-pill" id="hudPill">
        <div class="pill-dot"></div>
        <span class="pill-text">{hud_text}</span>
      </div>

      {alert_html}

      <!-- Main Stage -->
      <div class="stage" id="stage">
        <svg viewBox="0 0 980 1100" width="100%" height="100%">
          <defs>
            <filter id="neonGlowCyan" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" flood-color="#00f0ff" flood-opacity="0.9" />
              <feDropShadow dx="0" dy="0" stdDeviation="12" flood-color="#00f0ff" flood-opacity="0.5" />
            </filter>
            <filter id="neonGlowGreen" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" flood-color="#22c55e" flood-opacity="0.9" />
              <feDropShadow dx="0" dy="0" stdDeviation="14" flood-color="#22c55e" flood-opacity="0.5" />
            </filter>
            <filter id="neonGlowRed" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" flood-color="#ff2a6d" flood-opacity="0.9" />
              <feDropShadow dx="0" dy="0" stdDeviation="14" flood-color="#ff2a6d" flood-opacity="0.5" />
            </filter>
            <filter id="neonGlowAmber" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" flood-color="#ffb703" flood-opacity="0.9" />
              <feDropShadow dx="0" dy="0" stdDeviation="12" flood-color="#ffb703" flood-opacity="0.5" />
            </filter>
            <pattern id="pipeGrid" width="24" height="24" patternUnits="userSpaceOnUse">
              <path d="M 24 0 L 0 0 0 24" fill="none" stroke="rgba(0, 240, 255, 0.22)" stroke-width="1.5"/>
            </pattern>
            <linearGradient id="waterGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#00f0ff" stop-opacity="0.9" />
              <stop offset="50%" stop-color="#0284c7" stop-opacity="0.8" />
              <stop offset="100%" stop-color="#0369a1" stop-opacity="0.9" />
            </linearGradient>
            <linearGradient id="gasGrad" x1="100%" y1="100%" x2="0%" y2="0%">
              <stop offset="0%" stop-color="#ef4444" stop-opacity="0.8" />
              <stop offset="40%" stop-color="#f59e0b" stop-opacity="0.7" />
              <stop offset="100%" stop-color="#22c55e" stop-opacity="0.1" />
            </linearGradient>
          </defs>
          {svg_body}
        </svg>
      </div>

    </div>

    <script>
      const tl = gsap.timeline({{ paused: true }});
      const dur = {dur:.2f};

      {sub_js}

      // Animaciones de Entrada HUD
      tl.from("#hudPill", {{ y: -30, opacity: 0, duration: 0.5, ease: "power3.out" }}, 0.05);

      // Animación de Entrada del Escenario
      tl.from("#stage", {{ opacity: 0, duration: 0.4, ease: "power2.out" }}, 0);

      // Animaciones específicas de la física y mecánica de la escena
      {gsap_scene}

      // Suave movimiento de cámara cinemático continuo
      tl.to("#stage", {{ y: -12, duration: dur, ease: "none" }}, 0);

      window.__timelines = window.__timelines || {{}};
      window.__timelines["main"] = tl;
      tl.seek(0);
    </script>
  </body>
</html>
"""
    return html


def render_escena_hyperframes_mp4(
    out_path: str,
    duration: float,
    scene_idx: int,
    total_scenes: int,
    spec: dict,
    crf: int = 18,
    con_audio_silencio: bool = False,
) -> bool:
    """
    Renderiza una escena 1080x1920 a 30 FPS usando HyperFrames y Chrome Headless
    con la estética y cinemática exacta de @nuncateloexplicaron.
    Retorna True si el MP4 se generó exitosamente.
    """
    out_file = Path(out_path).resolve()
    out_file.parent.mkdir(parents=True, exist_ok=True)

    dur = max(1.0, float(duration))
    scene_slug = f"scene_{scene_idx+1:02d}"
    comp_dir = TEMP_COMP_DIR / scene_slug
    comp_dir.mkdir(parents=True, exist_ok=True)

    cfg_json = {
        "$schema": "https://hyperframes.heygen.com/schema/hyperframes.json",
        "media": {"autoProxy": True}
    }
    (comp_dir / "hyperframes.json").write_text(json.dumps(cfg_json, indent=2), encoding="utf-8")

    html_content = construir_html_escena(spec, dur)
    (comp_dir / "index.html").write_text(html_content, encoding="utf-8")

    cmd = [
        "npx.cmd", "hyperframes", "render",
        str(comp_dir),
        "-o", str(out_file),
    ]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=str(comp_dir)
        )
        if out_file.is_file() and out_file.stat().st_size > 1000:
            return True
        else:
            print(f"  [HyperFrames Warning] Scene {scene_idx+1} failed: {proc.stderr[:180]}", file=sys.stderr)
            return False
    except Exception as e:
        print(f"  [HyperFrames Error] Scene {scene_idx+1}: {e}", file=sys.stderr)
        return False
