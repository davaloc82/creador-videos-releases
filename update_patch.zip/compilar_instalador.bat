@echo off
rem ==============================================================================
rem Compilador Automático del Instalador .EXE para Clientes
rem NEXOR - Sistema Integrado de Replicación de Canales
rem ==============================================================================
chcp 65001 >nul
cd /d "%~dp0"
title Compilar Instalador NEXOR Setup.exe

echo ====================================================================
echo      COMPILADOR MAESTRO DEL INSTALADOR (.EXE) PARA CLIENTES
echo                 NEXOR v2.5.0 Setup
echo ====================================================================
echo.

set "ISCC="
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if "%ISCC%"=="" (
    where iscc >nul 2>&1
    if not errorlevel 1 set "ISCC=iscc"
)

if "%ISCC%"=="" (
    echo [ERROR] No se encontro Inno Setup 6 instalado en la computadora.
    echo Descargalo gratis de: https://jrsoftware.org/isdl.php
    if not "%~1"=="--no-pause" pause
    exit /b 1
)

echo [*] Compilador detectado en: %ISCC%
echo [*] Empaquetando sistema, binarios de FFmpeg, librerias y runtime de Python...
echo     (Esto toma aproximadamente 2-3 minutos con compresion ultra LZMA2)
echo.

if not exist "dist_instalador" mkdir "dist_instalador"

"%ISCC%" "instalador_config\instalador_creador_universal.iss"

if errorlevel 1 (
    echo.
    echo [ERROR] Hubo un problema durante la compilacion.
    if not "%~1"=="--no-pause" pause
    exit /b 1
)

echo.
echo ====================================================================
echo  [EXITO] Instalador NEXOR compilado con exito.
echo.
echo  Archivo listo para entregar a clientes:
echo  dist_instalador\Instalador_NEXOR_v2.5.0_Setup.exe
echo ====================================================================
echo.
if not "%~1"=="--no-pause" pause
