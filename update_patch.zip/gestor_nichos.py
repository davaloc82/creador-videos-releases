# -*- coding: utf-8 -*-
"""
gestor_nichos.py
----------------
Gestor de Proyectos de Nichos Replicados.
Cuando el usuario decide replicar un canal analizado:
1. Crea la carpeta estructurada del proyecto con nombre sugerido personalizable.
2. Guarda las 3 instrucciones maestras adaptadas y la identidad visual.
3. Extrae la muestra de voz (<= 29.5s) y la música de fondo con Demucs.
4. Incluye las fuentes locales (Melvins One) y registra el proyecto en el menú del sistema.
"""

import json
import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
ARCHIVO_NICHOS_USUARIO = AQUI / "nichos_usuario.json"

# Carpeta base para proyectos replicados
CARPETA_PROYECTOS_DEF = (Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads" / "PROYECTOS_VIDEO").resolve()


def slugify(texto: str, max_len: int = 40) -> str:
    """Convierte texto a un nombre de carpeta seguro y limpio."""
    texto = unicodedata.normalize("NFD", str(texto))
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    texto = re.sub(r"[^A-Za-z0-9]+", "_", texto).strip("_")
    return texto[:max_len] or "Proyecto_Nicho"


def sugerir_nombre_proyecto(canal: str, tipo_nicho: str = "") -> str:
    """Genera una sugerencia inteligente y legible para la carpeta del nuevo proyecto."""
    c_limpio = slugify(canal, 25).title()
    n_limpio = slugify(tipo_nicho, 25).title()

    if "Ojosdelobo" in c_limpio or "Ojos_De_Lobo" in c_limpio:
        return "Ojos_de_Lobo_Curiosidades"
    elif "Sabiduria" in c_limpio or "Eterna" in c_limpio:
        return "Sabiduria_Eterna_Reflexion"
    elif "Zack" in c_limpio or "Youandangel" in c_limpio or "Zack" in n_limpio or "Simulacion" in n_limpio:
        return f"{c_limpio}_Curiosidades_3D"
    elif "Gelo" in c_limpio or "Roblox" in c_limpio or "Gaming" in n_limpio or "Bloque" in n_limpio:
        return f"{c_limpio}_Animacion_3D"
    elif "Finanz" in n_limpio or "Dinero" in n_limpio:
        return f"{c_limpio}_Finanzas"
    elif "Animal" in n_limpio or "Fabula" in n_limpio:
        return f"{c_limpio}_Fabulas"
    elif c_limpio and c_limpio != "Nicho_Analizado":
        return f"{c_limpio}_Contenido"
    return f"Nicho_{n_limpio or 'Replicado'}"


def cargar_nichos_usuario() -> list:
    """Carga los nichos replicados guardados por el usuario y auto-detecta canales en PROYECTOS_VIDEO."""
    registrados = []
    rutas_vistas = set()
    if ARCHIVO_NICHOS_USUARIO.is_file():
        try:
            with open(ARCHIVO_NICHOS_USUARIO, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    for n in data:
                        p_r = Path(n.get("ruta", "")).resolve()
                        if p_r.is_dir() and str(p_r).lower() not in rutas_vistas:
                            registrados.append(n)
                            rutas_vistas.add(str(p_r).lower())
        except Exception:
            pass

    # Auto-detectar carpetas de canales dentro de CARPETA_PROYECTOS_DEF
    if CARPETA_PROYECTOS_DEF.is_dir():
        for d in CARPETA_PROYECTOS_DEF.iterdir():
            if not d.is_dir() or d.name.startswith(("_", ".")) or d.name.lower() in ("plantilla", "__pycache__"):
                continue
            str_d = str(d.resolve()).lower()
            if str_d in rutas_vistas:
                continue
            # Si contiene config_nicho.json o instrucciones o ai33_config.txt (canal independiente)
            if (d / "config_nicho.json").is_file() or (d / "instrucciones").is_dir() or (d / "ai33_config.txt").is_file():
                info_cfg = {}
                if (d / "config_nicho.json").is_file():
                    try:
                        info_cfg = json.loads((d / "config_nicho.json").read_text(encoding="utf-8"))
                    except Exception:
                        pass
                nombre_limpio = info_cfg.get("nombre") or d.name.replace("_", " ").title()
                auto_nicho = {
                    "id": f"nicho_{slugify(d.name, 40).lower()}",
                    "nombre": nombre_limpio,
                    "nombre_carpeta": d.name,
                    "ruta": str(d.resolve()),
                    "canal_origen": info_cfg.get("canal_origen", ""),
                    "tipo_nicho": info_cfg.get("tipo_nicho", "Canal de Video"),
                    "formato": info_cfg.get("formato", "Vertical (9:16)"),
                    "fecha_creacion": info_cfg.get("fecha_creacion", ""),
                    "configurado": True
                }
                registrados.append(auto_nicho)
                rutas_vistas.add(str_d)

    return registrados


def guardar_nicho_usuario(nicho_info: dict):
    """Agrega o actualiza un nicho en el registro de nichos del usuario."""
    existentes = cargar_nichos_usuario()
    # Evitar duplicados por id o ruta
    existentes = [n for n in existentes if n.get("id") != nicho_info.get("id") and n.get("ruta") != nicho_info.get("ruta")]
    existentes.insert(0, nicho_info)
    try:
        with open(ARCHIVO_NICHOS_USUARIO, "w", encoding="utf-8") as f:
            json.dump(existentes, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error guardando nichos_usuario.json: {e}")


def crear_proyecto_nicho(
    nombre_proyecto: str,
    analisis_datos: dict,
    extraer_audio: bool = True,
    estilo_subtitulos: str = "capcut_karaoke",
    carpeta_base: str = None
) -> dict:
    """
    Crea la carpeta completa del proyecto y estructura todos los recursos.
    """
    nombre_seguro = slugify(nombre_proyecto, 50)
    base = Path(carpeta_base).resolve() if carpeta_base else CARPETA_PROYECTOS_DEF
    base.mkdir(parents=True, exist_ok=True)

    ruta_proyecto = base / nombre_seguro
    ruta_proyecto.mkdir(parents=True, exist_ok=True)

    # Subcarpetas del proyecto
    dir_instrucciones = ruta_proyecto / "instrucciones"
    dir_instrucciones.mkdir(parents=True, exist_ok=True)

    dir_audio_ref = ruta_proyecto / "audio_referencia"
    dir_audio_ref.mkdir(parents=True, exist_ok=True)

    dir_fuentes = ruta_proyecto / "fuentes"
    dir_fuentes.mkdir(parents=True, exist_ok=True)

    # 1. Guardar las 3 Instrucciones Maestras Adaptadas
    shorts_md = analisis_datos.get("instruccion_shorts") or analisis_datos.get("prompt_maestro", "")
    largos_md = analisis_datos.get("instruccion_largos") or ""
    prompts_md = analisis_datos.get("instruccion_prompts") or ""
    iv = analisis_datos.get("identidad_visual", {})

    with open(dir_instrucciones / "INSTRUCCION_SHORTS.md", "w", encoding="utf-8") as f:
        f.write(shorts_md)

    with open(dir_instrucciones / "INSTRUCCION_LARGOS.md", "w", encoding="utf-8") as f:
        f.write(largos_md)

    with open(dir_instrucciones / "INSTRUCCION_PROMPTS.md", "w", encoding="utf-8") as f:
        f.write(prompts_md)

    with open(dir_instrucciones / "IDENTIDAD_VISUAL.json", "w", encoding="utf-8") as f:
        json.dump(iv, f, ensure_ascii=False, indent=2)

    # 2. Copiar fuente Melvins One
    fuente_src = AQUI / "fonts" / "MelvinsoneRegular-d9mvR.otf"
    if not fuente_src.is_file():
        fuente_src = AQUI / "ecos" / "fonts" / "MelvinsoneRegular-d9mvR.otf"

    if fuente_src.is_file():
        shutil.copy2(fuente_src, dir_fuentes / fuente_src.name)
        # Intentar registrar en Windows
        try:
            from subtitulos_estilos import instalar_fuente_en_windows
            instalar_fuente_en_windows(fuente_src.name)
        except Exception:
            pass

    # 2.1 Copiar ai33_config.txt al proyecto para facilitar la generación de voz
    cfg_src = AQUI / "ai33" / "ai33_config.txt"
    if cfg_src.is_file():
        cfg_dst = ruta_proyecto / "ai33_config.txt"
        if not cfg_dst.exists():
            shutil.copy2(cfg_src, cfg_dst)

    # 3. Crear plantilla de guiones inicial
    guiones_txt = ruta_proyecto / "guiones.txt"
    if not guiones_txt.exists():
        ejemplos = analisis_datos.get("ejemplos", [])
        contenido_guiones = f"""# GUIONES PARA EL PROYECTO: {nombre_proyecto}
# Nicho: {analisis_datos.get('tipo_nicho', '')}
# Canal de Referencia: {analisis_datos.get('canal', '')}
# Formato: GUION: [Numero] y la narración en voz en off limpia.

GUION: 01
[Pega aquí el texto de tu primer guion en voz en off continua...]

GUION: 02
[Pega aquí el texto de tu segundo guion en voz en off continua...]
"""
        guiones_txt.write_text(contenido_guiones, encoding="utf-8")

    # 4. Diseccionar y extraer audios del video de referencia si se solicitó
    datos_diseccion = {}
    if extraer_audio:
        videos = analisis_datos.get("videos", [])
        url_a_procesar = None
        for v in videos:
            u = v.get("url")
            if u:
                url_a_procesar = u
                break

        if url_a_procesar:
            try:
                from diseccionar_audio import diseccionar_video_para_proyecto
                print(f"  Iniciando disección de audio desde {url_a_procesar}...", flush=True)
                datos_diseccion = diseccionar_video_para_proyecto(url_a_procesar, ruta_proyecto)
            except Exception as e:
                print(f"  Aviso: Error durante la disección de audio: {e}", flush=True)
                datos_diseccion = {"error": str(e)}

    # 5. Guardar configuración completa del nicho
    nicho_id = f"nicho_{nombre_seguro.lower()}"
    config_nicho = {
        "id": nicho_id,
        "nombre": nombre_proyecto,
        "nombre_carpeta": nombre_seguro,
        "ruta": str(ruta_proyecto),
        "canal_origen": analisis_datos.get("canal", ""),
        "tipo_nicho": analisis_datos.get("tipo_nicho", ""),
        "formato": analisis_datos.get("formato", "Vertical (9:16)"),
        "estilo_visual": iv.get("estilo_nombre", "Comic"),
        "sufijo_estilo": iv.get("sufijo_estilo", ""),
        "estilo_subtitulos": estilo_subtitulos,
        "fecha_creacion": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "audio_clonacion": datos_diseccion.get("muestra_voz_nombre", ""),
        "audio_clonacion_ruta": datos_diseccion.get("muestra_voz", ""),
        "duracion_muestra": datos_diseccion.get("duracion_muestra", 0),
        "musica_fondo": datos_diseccion.get("musica_fondo_nombre", ""),
        "musica_fondo_ruta": datos_diseccion.get("musica_fondo", ""),
        "configurado": True
    }

    with open(ruta_proyecto / "config_nicho.json", "w", encoding="utf-8") as f:
        json.dump(config_nicho, f, ensure_ascii=False, indent=2)

    # 6. Registrar en nichos_usuario.json
    guardar_nicho_usuario(config_nicho)

    return {
        "ok": True,
        "msg": f"¡Proyecto '{nombre_proyecto}' creado y configurado con éxito!",
        "proyecto": config_nicho,
        "diseccion": datos_diseccion
    }
